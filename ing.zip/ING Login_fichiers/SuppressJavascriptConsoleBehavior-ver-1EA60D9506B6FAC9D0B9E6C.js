;console = {
log : function() {},
debug : function() {},
warn : function() {},
info : function() {}
};
