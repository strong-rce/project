/*! ing-feat-cookie-consent-de - 1.3.0 */(()=>{var e,t,n={5554:(e,t,n)=>{"use strict";n.d(t,{f:()=>N});var i=n(4971),s=n(1077);class o{constructor(e){this._parent=e,this._cache=new Map}has(e){return!!(this._cache.has(e)||this._parent&&this._parent._cache.has(e))}set(e,t){return this._cache.set(e,t),this}get(e){return this._cache.get(e)||this._parent&&this._parent._cache.get(e)}}let r=Math.round(1e5*Math.random());const a="-|\\.|[0-9]|[a-z]",c=new RegExp(`[a-z](${a})*-(${a})*`),l=(e,t)=>{const n=`${e}-${r+=1}`;return((e,t)=>!!t.get(e))(n,t)?l(e,t):n};function d(e,t=customElements){if(n=e,null===c.exec(n))throw new Error("tagName is invalid");var n;return l(e,t)}const u=new WeakMap,h=(e,t)=>u.set(t,e);const p=(e,t,n=customElements)=>{h(e,t),n.define(e,class extends t{})},f=(e,t,n)=>{const i=customElements;if(!function(e){let t=e;for(;t;){if(t===window.HTMLElement||"HTMLElement"===t.name)return!0;t=Object.getPrototypeOf(t)}return!1}(t))return((e,t,n)=>{const i=d(e,t);if(!n)throw new Error("Lazy scoped elements requires the use of tags cache");return n.set(e,i),i})(e,i,n);if(t===customElements.get(e))return h(e,t),e;const s=d(e,i);return p(s,t,i),s};function g(e,t,n){return(e=>u.get(e))(t)||n&&n.get(e)||f(e,t,n)}const v=new RegExp("<\\/?([a-z](-|\\.|[0-9]|[a-z])*-(-|\\.|[0-9]|[a-z])*)","g"),_=new o,b=(e,t,n,i)=>{const s=e.map((e=>{let n=e;const s=(e=>{const t=[];let n;for(;null!==(n=v.exec(e));)t.push(n);return t})(e);for(let e=s.length-1;e>=0;e-=1){const o=s[e],[r,a]=o,c=g(a,t[a],i),l=o.index+r.length-a.length,d=l+a.length,u=0===r.indexOf("</");n=n.slice(0,l)+(u?c:`${c} data-tag-name="${a}"`)+n.slice(d)}return n}));return n.set(e,s),s};var m=n(7630),y=n(4557);let S=!0;const{ShadyCSS:C}=window;(void 0===C||void 0===C.prepareTemplateDom)&&(S=!1);const w=new WeakMap,E=new WeakMap,T=e=>(E.has(e)||E.set(e,new o(E.get(e.constructor))),E.get(e)),I=(e,t,n,s)=>e.map((e=>e instanceof i.js?A(e,t,n,s):Array.isArray(e)?I(e,t,n,s):e)),A=(e,t,n,s)=>new i.js(function(e,t,n=_,i){return n.get(e)||b(e,t,n,i)}(e.strings,t,n,s),I(e.values,t,n,s),e.type,e.processor),x=(e,t,n,i)=>s=>{const o=A(s,t,n,i);return(e=>t=>{const n=((e,t)=>`${e}--${t}`)(t.type,e);let i=m.r.get(n);void 0===i&&(i={stringsArray:new WeakMap,keyString:new Map},m.r.set(n,i));let s=i.stringsArray.get(t.strings);if(void 0!==s)return s;const o=t.strings.join(y.Jw);if(s=i.keyString.get(o),void 0===s){const n=t.getTemplateElement();S&&C.prepareTemplateDom(n,e),s=new y.YS(t,n),i.keyString.set(o,s)}return i.stringsArray.set(t.strings,s),s})(e)(o)},N=(0,s.S)((e=>class extends e{static get scopedElements(){return{}}static render(e,t,n){if(!n||"object"!=typeof n||!n.scopeName)throw new Error("The `scopeName` option is required.");const{scopeName:i,eventContext:s}=n,r=(a=s,w.has(a)||w.set(a,new o(w.get(a.constructor))),w.get(a));var a;const c=T(s),{scopedElements:l}=this;return super.render(e,t,{...n,templateFactory:x(i,l,r,c)})}defineScopedElement(e,t){return function(e,t,n){const i=n.get(e);i?void 0===customElements.get(i)&&p(i,t,customElements):n.set(e,g(e,t,n))}(e,t,T(this))}static getScopedTagName(e){const t=this.scopedElements[e];return t?g(e,t,T(this)):T(this).get(e)}getScopedTagName(e){const t=this.constructor.scopedElements[e];return t?g(e,t,T(this)):T(this).get(e)}}))},4459:(e,t,n)=>{"use strict";n.d(t,{f:()=>i});const i=(0,n(1077).S)((e=>class extends e{static get properties(){return{disabled:{type:Boolean,reflect:!0}}}constructor(){super(),this._requestedToBeDisabled=!1,this.__isUserSettingDisabled=!0,this.__restoreDisabledTo=!1,this.disabled=!1}makeRequestToBeDisabled(){!1===this._requestedToBeDisabled&&(this._requestedToBeDisabled=!0,this.__restoreDisabledTo=this.disabled,this.__internalSetDisabled(!0))}retractRequestToBeDisabled(){!0===this._requestedToBeDisabled&&(this._requestedToBeDisabled=!1,this.__internalSetDisabled(this.__restoreDisabledTo))}__internalSetDisabled(e){this.__isUserSettingDisabled=!1,this.disabled=e,this.__isUserSettingDisabled=!0}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),"disabled"===e&&(this.__isUserSettingDisabled&&(this.__restoreDisabledTo=this.disabled),!1===this.disabled&&!0===this._requestedToBeDisabled&&this.__internalSetDisabled(!0))}}))},5538:(e,t,n)=>{"use strict";n.d(t,{b:()=>o});var i=n(1077),s=n(4459);const o=(0,i.S)((e=>class extends((0,s.f)(e)){static get properties(){return{tabIndex:{type:Number,reflect:!0,attribute:"tabindex"}}}constructor(){super(),this.__isUserSettingTabIndex=!0,this.__restoreTabIndexTo=0,this.__internalSetTabIndex(0)}makeRequestToBeDisabled(){super.makeRequestToBeDisabled(),!1===this._requestedToBeDisabled&&null!=this.tabIndex&&(this.__restoreTabIndexTo=this.tabIndex)}retractRequestToBeDisabled(){super.retractRequestToBeDisabled(),!0===this._requestedToBeDisabled&&this.__internalSetTabIndex(this.__restoreTabIndexTo)}__internalSetTabIndex(e){this.__isUserSettingTabIndex=!1,this.tabIndex=e,this.__isUserSettingTabIndex=!0}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),"disabled"===e&&(this.disabled?this.__internalSetTabIndex(-1):this.__internalSetTabIndex(this.__restoreTabIndexTo)),"tabIndex"===e&&(this.__isUserSettingTabIndex&&null!=this.tabIndex&&(this.__restoreTabIndexTo=this.tabIndex),-1!==this.tabIndex&&!0===this._requestedToBeDisabled&&this.__internalSetTabIndex(-1))}firstUpdated(e){super.firstUpdated(e),this.disabled&&this.__internalSetTabIndex(-1)}}))},3320:(e,t,n)=>{"use strict";n.d(t,{J:()=>i});const i=(0,n(1077).S)((e=>class extends e{get slots(){return{}}constructor(){super(),this.__privateSlots=new Set(null)}connectedCallback(){super.connectedCallback&&super.connectedCallback(),this._connectSlotMixin()}_connectSlotMixin(){this.__isConnectedSlotMixin||(Object.keys(this.slots).forEach((e=>{if(!this.querySelector(`[slot=${e}]`)){const t=(0,this.slots[e])();t instanceof Element&&(t.setAttribute("slot",e),this.appendChild(t),this.__privateSlots.add(e))}})),this.__isConnectedSlotMixin=!0)}_isPrivateSlot(e){return this.__privateSlots.has(e)}}))},3515:(e,t,n)=>{"use strict";function i(e="google-chrome"){const t=window.chrome;if("chromium"===e)return t;const n=window.navigator,i=n.vendor,s=void 0!==window.opr,o=n.userAgent.indexOf("Edge")>-1,r=n.userAgent.match("CriOS");return"ios"===e?r:"google-chrome"===e?null!=t&&"Google Inc."===i&&!1===s&&!1===o:void 0}n.d(t,{n:()=>s});const s={isIE11:/Trident/.test(window.navigator.userAgent),isChrome:i(),isIOSChrome:i("ios"),isChromium:i("chromium"),isMac:-1!==navigator.appVersion.indexOf("Mac")}},9058:(e,t,n)=>{"use strict";n.d(t,{t:()=>i});class i{constructor(){this.__iconResolvers=new Map}addIconResolver(e,t){if(this.__iconResolvers.has(e))throw new Error(`An icon resolver has already been registered for namespace: ${e}`);this.__iconResolvers.set(e,t)}removeIconResolver(e){this.__iconResolvers.delete(e)}resolveIcon(e,t,n){const i=this.__iconResolvers.get(e);if(i)return i(t,n);throw new Error(`Could not find any icon resolver for namespace ${e}.`)}resolveIconForId(e){const t=e.split(":");if(3!==t.length)throw new Error(`Incorrect iconId: ${e}. Format: <namespace>:<iconset>:<icon>`);return this.resolveIcon(t[0],t[1],t[2])}}},6495:(e,t,n)=>{"use strict";n.d(t,{c:()=>o,r:()=>r});var i=n(6979),s=n(9058);let o=i.d.get("@lion/icon::icons::0.5.x")||new s.t;function r(e){o=e}},194:(e,t,n)=>{"use strict";function i(e,t){return e(t={exports:{}},t.exports),t.exports}n.d(t,{$:()=>T});var s="long",o="short",r="narrow",a="numeric",c="2-digit",l={number:{decimal:{style:"decimal"},integer:{style:"decimal",maximumFractionDigits:0},currency:{style:"currency",currency:"USD"},percent:{style:"percent"},default:{style:"decimal"}},date:{short:{month:a,day:a,year:c},medium:{month:o,day:a,year:a},long:{month:s,day:a,year:a},full:{month:s,day:a,year:a,weekday:s},default:{month:o,day:a,year:a}},time:{short:{hour:a,minute:a},medium:{hour:a,minute:a,second:a},long:{hour:a,minute:a,second:a,timeZoneName:o},full:{hour:a,minute:a,second:a,timeZoneName:o},default:{hour:a,minute:a,second:a}},duration:{default:{hours:{minimumIntegerDigits:1,maximumFractionDigits:0},minutes:{minimumIntegerDigits:2,maximumFractionDigits:0},seconds:{minimumIntegerDigits:2,maximumFractionDigits:3}}},parseNumberPattern:function(e){if(e){var t={},n=e.match(/\b[A-Z]{3}\b/i),i=e.replace(/[^¤]/g,"").length;if(!i&&n&&(i=1),i?(t.style="currency",t.currencyDisplay=1===i?"symbol":2===i?"code":"name",t.currency=n?n[0].toUpperCase():"USD"):e.indexOf("%")>=0&&(t.style="percent"),!/[@#0]/.test(e))return t.style?t:void 0;if(t.useGrouping=e.indexOf(",")>=0,/E\+?[@#0]+/i.test(e)||e.indexOf("@")>=0){var s=e.replace(/E\+?[@#0]+|[^@#0]/gi,"");t.minimumSignificantDigits=Math.min(Math.max(s.replace(/[^@0]/g,"").length,1),21),t.maximumSignificantDigits=Math.min(Math.max(s.length,1),21)}else{for(var o=e.replace(/[^#0.]/g,"").split("."),r=o[0],a=r.length-1;"0"===r[a];)--a;t.minimumIntegerDigits=Math.min(Math.max(r.length-1-a,1),21);var c=o[1]||"";for(a=0;"0"===c[a];)++a;for(t.minimumFractionDigits=Math.min(Math.max(a,0),20);"#"===c[a];)++a;t.maximumFractionDigits=Math.min(Math.max(a,0),20)}return t}},parseDatePattern:function(e){if(e){for(var t={},n=0;n<e.length;){for(var i=e[n],l=1;e[++n]===i;)++l;switch(i){case"G":t.era=5===l?r:4===l?s:o;break;case"y":case"Y":t.year=2===l?c:a;break;case"M":case"L":l=Math.min(Math.max(l-1,0),4),t.month=[a,c,o,s,r][l];break;case"E":case"e":case"c":t.weekday=5===l?r:4===l?s:o;break;case"d":case"D":t.day=2===l?c:a;break;case"h":case"K":t.hour12=!0,t.hour=2===l?c:a;break;case"H":case"k":t.hour12=!1,t.hour=2===l?c:a;break;case"m":t.minute=2===l?c:a;break;case"s":case"S":t.second=2===l?c:a;break;case"z":case"Z":case"v":case"V":t.timeZoneName=1===l?o:s}}return Object.keys(t).length?t:void 0}}},d="zero",u="one",h="two",p="few",f="many",g="other",v=[function(e){return 1===+e?u:g},function(e){var t=+e;return 0<=t&&t<=1?u:g},function(e){return 0===Math.floor(Math.abs(+e))||1===+e?u:g},function(e){var t=+e;return 0===t?d:1===t?u:2===t?h:3<=t%100&&t%100<=10?p:11<=t%100&&t%100<=99?f:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length;return 1===t&&0===n?u:g},function(e){var t=+e;return t%10==1&&t%100!=11?u:2<=t%10&&t%10<=4&&(t%100<12||14<t%100)?p:t%10==0||5<=t%10&&t%10<=9||11<=t%100&&t%100<=14?f:g},function(e){var t=+e;return t%10==1&&t%100!=11&&t%100!=71&&t%100!=91?u:t%10==2&&t%100!=12&&t%100!=72&&t%100!=92?h:(3<=t%10&&t%10<=4||t%10==9)&&(t%100<10||19<t%100)&&(t%100<70||79<t%100)&&(t%100<90||99<t%100)?p:0!==t&&t%1e6==0?f:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length,i=+(e+".").split(".")[1];return 0===n&&t%10==1&&t%100!=11||i%10==1&&i%100!=11?u:0===n&&2<=t%10&&t%10<=4&&(t%100<12||14<t%100)||2<=i%10&&i%10<=4&&(i%100<12||14<i%100)?p:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length;return 1===t&&0===n?u:2<=t&&t<=4&&0===n?p:0!==n?f:g},function(e){var t=+e;return 0===t?d:1===t?u:2===t?h:3===t?p:6===t?f:g},function(e){var t=Math.floor(Math.abs(+e)),n=+(""+e).replace(/^[^.]*.?|0+$/g,"");return 1===+e||0!==n&&(0===t||1===t)?u:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length,i=+(e+".").split(".")[1];return 0===n&&t%100==1||i%100==1?u:0===n&&t%100==2||i%100==2?h:0===n&&3<=t%100&&t%100<=4||3<=i%100&&i%100<=4?p:g},function(e){var t=Math.floor(Math.abs(+e));return 0===t||1===t?u:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length,i=+(e+".").split(".")[1];return 0===n&&(1===t||2===t||3===t)||0===n&&t%10!=4&&t%10!=6&&t%10!=9||0!==n&&i%10!=4&&i%10!=6&&i%10!=9?u:g},function(e){var t=+e;return 1===t?u:2===t?h:3<=t&&t<=6?p:7<=t&&t<=10?f:g},function(e){var t=+e;return 1===t||11===t?u:2===t||12===t?h:3<=t&&t<=10||13<=t&&t<=19?p:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length;return 0===n&&t%10==1?u:0===n&&t%10==2?h:0!==n||t%100!=0&&t%100!=20&&t%100!=40&&t%100!=60&&t%100!=80?0!==n?f:g:p},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length,i=+e;return 1===t&&0===n?u:2===t&&0===n?h:0===n&&(i<0||10<i)&&i%10==0?f:g},function(e){var t=Math.floor(Math.abs(+e)),n=+(""+e).replace(/^[^.]*.?|0+$/g,"");return 0===n&&t%10==1&&t%100!=11||0!==n?u:g},function(e){var t=+e;return 1===t?u:2===t?h:g},function(e){var t=+e;return 0===t?d:1===t?u:g},function(e){var t=Math.floor(Math.abs(+e)),n=+e;return 0===n?d:0!==t&&1!==t||0===n?g:u},function(e){var t=+(e+".").split(".")[1],n=+e;return n%10==1&&(n%100<11||19<n%100)?u:2<=n%10&&n%10<=9&&(n%100<11||19<n%100)?p:0!==t?f:g},function(e){var t=(e+".").split(".")[1].length,n=+(e+".").split(".")[1],i=+e;return i%10==0||11<=i%100&&i%100<=19||2===t&&11<=n%100&&n%100<=19?d:i%10==1&&i%100!=11||2===t&&n%10==1&&n%100!=11||2!==t&&n%10==1?u:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length,i=+(e+".").split(".")[1];return 0===n&&t%10==1&&t%100!=11||i%10==1&&i%100!=11?u:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length,i=+e;return 1===t&&0===n?u:0!==n||0===i||1!==i&&1<=i%100&&i%100<=19?p:g},function(e){var t=+e;return 1===t?u:0===t||2<=t%100&&t%100<=10?p:11<=t%100&&t%100<=19?f:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length;return 1===t&&0===n?u:0===n&&2<=t%10&&t%10<=4&&(t%100<12||14<t%100)?p:0===n&&1!==t&&0<=t%10&&t%10<=1||0===n&&5<=t%10&&t%10<=9||0===n&&12<=t%100&&t%100<=14?f:g},function(e){var t=Math.floor(Math.abs(+e));return 0<=t&&t<=1?u:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length;return 0===n&&t%10==1&&t%100!=11?u:0===n&&2<=t%10&&t%10<=4&&(t%100<12||14<t%100)?p:0===n&&t%10==0||0===n&&5<=t%10&&t%10<=9||0===n&&11<=t%100&&t%100<=14?f:g},function(e){var t=+e;return 0===Math.floor(Math.abs(+e))||1===t?u:2<=t&&t<=10?p:g},function(e){var t=Math.floor(Math.abs(+e)),n=+(e+".").split(".")[1],i=+e;return 0===i||1===i||0===t&&1===n?u:g},function(e){var t=Math.floor(Math.abs(+e)),n=(e+".").split(".")[1].length;return 0===n&&t%100==1?u:0===n&&t%100==2?h:0===n&&3<=t%100&&t%100<=4||0!==n?p:g},function(e){var t=+e;return 0<=t&&t<=1||11<=t&&t<=99?u:g},function(e){var t=+e;return 1===t||5===t||7===t||8===t||9===t||10===t?u:2===t||3===t?h:4===t?p:6===t?f:g},function(e){var t=Math.floor(Math.abs(+e));return t%10==1||t%10==2||t%10==5||t%10==7||t%10==8||t%100==20||t%100==50||t%100==70||t%100==80?u:t%10==3||t%10==4||t%1e3==100||t%1e3==200||t%1e3==300||t%1e3==400||t%1e3==500||t%1e3==600||t%1e3==700||t%1e3==800||t%1e3==900?p:0===t||t%10==6||t%100==40||t%100==60||t%100==90?f:g},function(e){var t=+e;return t%10!=2&&t%10!=3||t%100==12||t%100==13?g:p},function(e){var t=+e;return 1===t||3===t?u:2===t?h:4===t?p:g},function(e){var t=+e;return 0===t||7===t||8===t||9===t?d:1===t?u:2===t?h:3===t||4===t?p:5===t||6===t?f:g},function(e){var t=+e;return t%10==1&&t%100!=11?u:t%10==2&&t%100!=12?h:t%10==3&&t%100!=13?p:g},function(e){var t=+e;return 1===t?u:2===t||3===t?h:4===t?p:6===t?f:g},function(e){var t=+e;return 1===t||5===t?u:g},function(e){var t=+e;return 11===t||8===t||80===t||800===t?f:g},function(e){var t=Math.floor(Math.abs(+e));return 1===t?u:0===t||2<=t%100&&t%100<=20||t%100==40||t%100==60||t%100==80?f:g},function(e){var t=+e;return t%10==6||t%10==9||t%10==0&&0!==t?f:g},function(e){var t=Math.floor(Math.abs(+e));return t%10==1&&t%100!=11?u:t%10==2&&t%100!=12?h:t%10!=7&&t%10!=8||t%100==17||t%100==18?g:f},function(e){var t=+e;return 1===t?u:2===t||3===t?h:4===t?p:g},function(e){var t=+e;return 1<=t&&t<=4?u:g},function(e){var t=+e;return 1===t||5===t||7<=t&&t<=9?u:2===t||3===t?h:4===t?p:6===t?f:g},function(e){var t=+e;return 1===t?u:t%10==4&&t%100!=14?f:g},function(e){var t=+e;return t%10!=1&&t%10!=2||t%100==11||t%100==12?g:u},function(e){var t=+e;return t%10==6||t%10==9||10===t?p:g},function(e){var t=+e;return t%10==3&&t%100!=13?p:g}],_={af:{cardinal:v[0]},ak:{cardinal:v[1]},am:{cardinal:v[2]},ar:{cardinal:v[3]},ars:{cardinal:v[3]},as:{cardinal:v[2],ordinal:v[34]},asa:{cardinal:v[0]},ast:{cardinal:v[4]},az:{cardinal:v[0],ordinal:v[35]},be:{cardinal:v[5],ordinal:v[36]},bem:{cardinal:v[0]},bez:{cardinal:v[0]},bg:{cardinal:v[0]},bh:{cardinal:v[1]},bn:{cardinal:v[2],ordinal:v[34]},br:{cardinal:v[6]},brx:{cardinal:v[0]},bs:{cardinal:v[7]},ca:{cardinal:v[4],ordinal:v[37]},ce:{cardinal:v[0]},cgg:{cardinal:v[0]},chr:{cardinal:v[0]},ckb:{cardinal:v[0]},cs:{cardinal:v[8]},cy:{cardinal:v[9],ordinal:v[38]},da:{cardinal:v[10]},de:{cardinal:v[4]},dsb:{cardinal:v[11]},dv:{cardinal:v[0]},ee:{cardinal:v[0]},el:{cardinal:v[0]},en:{cardinal:v[4],ordinal:v[39]},eo:{cardinal:v[0]},es:{cardinal:v[0]},et:{cardinal:v[4]},eu:{cardinal:v[0]},fa:{cardinal:v[2]},ff:{cardinal:v[12]},fi:{cardinal:v[4]},fil:{cardinal:v[13],ordinal:v[0]},fo:{cardinal:v[0]},fr:{cardinal:v[12],ordinal:v[0]},fur:{cardinal:v[0]},fy:{cardinal:v[4]},ga:{cardinal:v[14],ordinal:v[0]},gd:{cardinal:v[15]},gl:{cardinal:v[4]},gsw:{cardinal:v[0]},gu:{cardinal:v[2],ordinal:v[40]},guw:{cardinal:v[1]},gv:{cardinal:v[16]},ha:{cardinal:v[0]},haw:{cardinal:v[0]},he:{cardinal:v[17]},hi:{cardinal:v[2],ordinal:v[40]},hr:{cardinal:v[7]},hsb:{cardinal:v[11]},hu:{cardinal:v[0],ordinal:v[41]},hy:{cardinal:v[12],ordinal:v[0]},io:{cardinal:v[4]},is:{cardinal:v[18]},it:{cardinal:v[4],ordinal:v[42]},iu:{cardinal:v[19]},iw:{cardinal:v[17]},jgo:{cardinal:v[0]},ji:{cardinal:v[4]},jmc:{cardinal:v[0]},ka:{cardinal:v[0],ordinal:v[43]},kab:{cardinal:v[12]},kaj:{cardinal:v[0]},kcg:{cardinal:v[0]},kk:{cardinal:v[0],ordinal:v[44]},kkj:{cardinal:v[0]},kl:{cardinal:v[0]},kn:{cardinal:v[2]},ks:{cardinal:v[0]},ksb:{cardinal:v[0]},ksh:{cardinal:v[20]},ku:{cardinal:v[0]},kw:{cardinal:v[19]},ky:{cardinal:v[0]},lag:{cardinal:v[21]},lb:{cardinal:v[0]},lg:{cardinal:v[0]},ln:{cardinal:v[1]},lt:{cardinal:v[22]},lv:{cardinal:v[23]},mas:{cardinal:v[0]},mg:{cardinal:v[1]},mgo:{cardinal:v[0]},mk:{cardinal:v[24],ordinal:v[45]},ml:{cardinal:v[0]},mn:{cardinal:v[0]},mo:{cardinal:v[25],ordinal:v[0]},mr:{cardinal:v[2],ordinal:v[46]},mt:{cardinal:v[26]},nah:{cardinal:v[0]},naq:{cardinal:v[19]},nb:{cardinal:v[0]},nd:{cardinal:v[0]},ne:{cardinal:v[0],ordinal:v[47]},nl:{cardinal:v[4]},nn:{cardinal:v[0]},nnh:{cardinal:v[0]},no:{cardinal:v[0]},nr:{cardinal:v[0]},nso:{cardinal:v[1]},ny:{cardinal:v[0]},nyn:{cardinal:v[0]},om:{cardinal:v[0]},or:{cardinal:v[0],ordinal:v[48]},os:{cardinal:v[0]},pa:{cardinal:v[1]},pap:{cardinal:v[0]},pl:{cardinal:v[27]},prg:{cardinal:v[23]},ps:{cardinal:v[0]},pt:{cardinal:v[28]},"pt-PT":{cardinal:v[4]},rm:{cardinal:v[0]},ro:{cardinal:v[25],ordinal:v[0]},rof:{cardinal:v[0]},ru:{cardinal:v[29]},rwk:{cardinal:v[0]},saq:{cardinal:v[0]},scn:{cardinal:v[4],ordinal:v[42]},sd:{cardinal:v[0]},sdh:{cardinal:v[0]},se:{cardinal:v[19]},seh:{cardinal:v[0]},sh:{cardinal:v[7]},shi:{cardinal:v[30]},si:{cardinal:v[31]},sk:{cardinal:v[8]},sl:{cardinal:v[32]},sma:{cardinal:v[19]},smi:{cardinal:v[19]},smj:{cardinal:v[19]},smn:{cardinal:v[19]},sms:{cardinal:v[19]},sn:{cardinal:v[0]},so:{cardinal:v[0]},sq:{cardinal:v[0],ordinal:v[49]},sr:{cardinal:v[7]},ss:{cardinal:v[0]},ssy:{cardinal:v[0]},st:{cardinal:v[0]},sv:{cardinal:v[4],ordinal:v[50]},sw:{cardinal:v[4]},syr:{cardinal:v[0]},ta:{cardinal:v[0]},te:{cardinal:v[0]},teo:{cardinal:v[0]},ti:{cardinal:v[1]},tig:{cardinal:v[0]},tk:{cardinal:v[0],ordinal:v[51]},tl:{cardinal:v[13],ordinal:v[0]},tn:{cardinal:v[0]},tr:{cardinal:v[0]},ts:{cardinal:v[0]},tzm:{cardinal:v[33]},ug:{cardinal:v[0]},uk:{cardinal:v[29],ordinal:v[52]},ur:{cardinal:v[4]},uz:{cardinal:v[0]},ve:{cardinal:v[0]},vo:{cardinal:v[0]},vun:{cardinal:v[0]},wa:{cardinal:v[1]},wae:{cardinal:v[0]},xh:{cardinal:v[0]},xog:{cardinal:v[0]},yi:{cardinal:v[4]},zu:{cardinal:v[2]},lo:{ordinal:v[0]},ms:{ordinal:v[0]},vi:{ordinal:v[0]}},b=i((function(e,t){function n(e,t,s,o,r){var a=e.map((function(e){return function(e,t,s,o,r){if("string"==typeof e){var a=e;return function(){return a}}var l,d=e[0],u=e[1];if(t&&"#"===e[0]){d=t[0];var h=t[2],p=(o.number||c.number)([d,"number"],s);return function(e){return p(i(d,e)-h,e)}}"plural"===u||"selectordinal"===u?(l={},Object.keys(e[3]).forEach((function(t){l[t]=n(e[3][t],e,s,o,r)})),e=[e[0],e[1],e[2],l]):e[2]&&"object"==typeof e[2]&&(l={},Object.keys(e[2]).forEach((function(t){l[t]=n(e[2][t],e,s,o,r)})),e=[e[0],e[1],l]);var f=u&&(o[u]||c[u]);if(f){var g=f(e,s);return function(e){return g(i(d,e),e)}}return r?function(e){return String(i(d,e))}:function(e){return i(d,e)}}(e,t,s,o,r)}));return r?1===a.length?a[0]:function(e){for(var t="",n=0;n<a.length;++n)t+=a[n](e);return t}:function(e){return a.reduce((function(t,n){return t.concat(n(e))}),[])}}function i(e,t){if(t&&e in t)return t[e];for(var n=e.split("."),i=t,s=0,o=n.length;i&&s<o;++s)i=i[n[s]];return i}function s(e,t){var n=e[2],i=l.number[n]||l.parseNumberPattern(n)||l.number.default;return new Intl.NumberFormat(t,i).format}function o(e,t){var n=e[1],i=e[2],s=l[n][i]||l.parseDatePattern(i)||l[n].default;return new Intl.DateTimeFormat(t,s).format}function r(e,t){var n,i="selectordinal"===e[1]?"ordinal":"cardinal",s=e[2],o=e[3];if(Intl.PluralRules&&Intl.PluralRules.supportedLocalesOf(t).length>0)n=new Intl.PluralRules(t,{type:i});else{var r=function(e,t){if("string"==typeof e&&t[e])return e;for(var n=[].concat(e||[]),i=0,s=n.length;i<s;++i)for(var o=n[i].split("-");o.length;){var r=o.join("-");if(t[r])return r;o.pop()}}(t,_),c=r&&_[r][i]||a;n={select:c}}return function(e,t){return(o["="+ +e]||o[n.select(e-s)]||o.other)(t)}}function a(){return"other"}(t=e.exports=function(e,t,i){return n(e,null,t||"en",i||{},!0)}).toParts=function(e,t,i){return n(e,null,t||"en",i||{},!1)};var c={number:s,ordinal:s,spellout:s,duration:function(e,t){var n=e[2],i=l.duration[n]||l.duration.default,s=new Intl.NumberFormat(t,i.seconds).format,o=new Intl.NumberFormat(t,i.minutes).format,r=new Intl.NumberFormat(t,i.hours).format,a=/^fi$|^fi-|^da/.test(String(t))?".":":";return function(e,t){if(e=+e,!isFinite(e))return s(e);var n=~~(e/60/60),i=~~(e/60%60),c=(n?r(Math.abs(n))+a:"")+o(Math.abs(i))+a+s(Math.abs(e%60));return e<0?r(-1).replace(r(1),c):c}},date:o,time:o,plural:r,selectordinal:r,select:function(e,t){var n=e[2];return function(e,t){return(n[e]||n.other)(t)}}};t.types=c})),m=(b.toParts,b.types,i((function(e,t){var n="{",i="}",s=",",o="#",r="<",a=">",c="</",l="/>",d="'",u="offset:",h=["number","date","time","ordinal","duration","spellout"],p=["plural","select","selectordinal"];function f(e,t){var n=e.pattern,s=n.length,o=[],r=e.index,a=g(e,t);for(a&&o.push(a),a&&e.tokens&&e.tokens.push(["text",n.slice(r,e.index)]);e.index<s;){if(n[e.index]===i){if(!t)throw E(e);break}if(t&&e.tagsType&&n.slice(e.index,e.index+c.length)===c)break;o.push(b(e)),r=e.index,(a=g(e,t))&&o.push(a),a&&e.tokens&&e.tokens.push(["text",n.slice(r,e.index)])}return o}function g(e,t){for(var s=e.pattern,a=s.length,c="plural"===t||"selectordinal"===t,l=!!e.tagsType,u="{style}"===t,h="";e.index<a;){var p=s[e.index];if(p===n||p===i||c&&p===o||l&&p===r||u&&v(p.charCodeAt(0)))break;if(p===d)if((p=s[++e.index])===d)h+=p,++e.index;else if(p===n||p===i||c&&p===o||l&&p===r||u)for(h+=p;++e.index<a;)if((p=s[e.index])===d&&s[e.index+1]===d)h+=d,++e.index;else{if(p===d){++e.index;break}h+=p}else h+=d;else h+=p,++e.index}return h}function v(e){return e>=9&&e<=13||32===e||133===e||160===e||6158===e||e>=8192&&e<=8205||8232===e||8233===e||8239===e||8287===e||8288===e||12288===e||65279===e}function _(e){for(var t=e.pattern,n=t.length,i=e.index;e.index<n&&v(t.charCodeAt(e.index));)++e.index;i<e.index&&e.tokens&&e.tokens.push(["space",e.pattern.slice(i,e.index)])}function b(e){var t=e.pattern;if(t[e.index]===o)return e.tokens&&e.tokens.push(["syntax",o]),++e.index,[o];var d=function(e){var t=e.tagsType;if(!t||e.pattern[e.index]!==r)return;if(e.pattern.slice(e.index,e.index+c.length)===c)throw E(e,null,"closing tag without matching opening tag");e.tokens&&e.tokens.push(["syntax",r]);++e.index;var n=m(e,!0);if(!n)throw E(e,"placeholder id");e.tokens&&e.tokens.push(["id",n]);if(_(e),e.pattern.slice(e.index,e.index+l.length)===l)return e.tokens&&e.tokens.push(["syntax",l]),e.index+=l.length,[n,t];if(e.pattern[e.index]!==a)throw E(e,a);e.tokens&&e.tokens.push(["syntax",a]);++e.index;var i=f(e,t),s=e.index;if(e.pattern.slice(e.index,e.index+c.length)!==c)throw E(e,c+n+a);e.tokens&&e.tokens.push(["syntax",c]);e.index+=c.length;var o=m(e,!0);o&&e.tokens&&e.tokens.push(["id",o]);if(n!==o)throw e.index=s,E(e,c+n+a,c+o+a);if(_(e),e.pattern[e.index]!==a)throw E(e,a);e.tokens&&e.tokens.push(["syntax",a]);return++e.index,[n,t,{children:i}]}(e);if(d)return d;if(t[e.index]!==n)throw E(e,n);e.tokens&&e.tokens.push(["syntax",n]),++e.index,_(e);var p=m(e);if(!p)throw E(e,"placeholder id");e.tokens&&e.tokens.push(["id",p]),_(e);var g=t[e.index];if(g===i)return e.tokens&&e.tokens.push(["syntax",i]),++e.index,[p];if(g!==s)throw E(e,", or }");e.tokens&&e.tokens.push(["syntax",s]),++e.index,_(e);var v,b=m(e);if(!b)throw E(e,"placeholder type");if(e.tokens&&e.tokens.push(["type",b]),_(e),(g=t[e.index])===i){if(e.tokens&&e.tokens.push(["syntax",i]),"plural"===b||"selectordinal"===b||"select"===b)throw E(e,b+" sub-messages");return++e.index,[p,b]}if(g!==s)throw E(e,", or }");if(e.tokens&&e.tokens.push(["syntax",s]),++e.index,_(e),"plural"===b||"selectordinal"===b){var w=function(e){var t=e.pattern,n=t.length,i=0;if(t.slice(e.index,e.index+u.length)===u){e.tokens&&e.tokens.push(["offset","offset"],["syntax",":"]),e.index+=u.length,_(e);for(var s=e.index;e.index<n&&S(t.charCodeAt(e.index));)++e.index;if(s===e.index)throw E(e,"offset number");e.tokens&&e.tokens.push(["number",t.slice(s,e.index)]),i=+t.slice(s,e.index)}return i}(e);_(e),v=[p,b,w,C(e,b)]}else if("select"===b)v=[p,b,C(e,b)];else if(h.indexOf(b)>=0)v=[p,b,y(e)];else{var T=e.index,I=y(e);_(e),t[e.index]===n&&(e.index=T,I=C(e,b)),v=[p,b,I]}if(_(e),t[e.index]!==i)throw E(e,i);return e.tokens&&e.tokens.push(["syntax",i]),++e.index,v}function m(e,t){for(var c=e.pattern,l=c.length,u="";e.index<l;){var h=c[e.index];if(h===n||h===i||h===s||h===o||h===d||v(h.charCodeAt(0))||t&&(h===r||h===a||"/"===h))break;u+=h,++e.index}return u}function y(e){var t=e.index,n=g(e,"{style}");if(!n)throw E(e,"placeholder style name");return e.tokens&&e.tokens.push(["style",e.pattern.slice(t,e.index)]),n}function S(e){return e>=48&&e<=57}function C(e,t){for(var n=e.pattern,s=n.length,o={};e.index<s&&n[e.index]!==i;){var r=m(e);if(!r)throw E(e,"sub-message selector");e.tokens&&e.tokens.push(["selector",r]),_(e),o[r]=w(e,t),_(e)}if(!o.other&&p.indexOf(t)>=0)throw E(e,null,null,'"other" sub-message must be specified in '+t);return o}function w(e,t){if(e.pattern[e.index]!==n)throw E(e,"{ to start sub-message");e.tokens&&e.tokens.push(["syntax",n]),++e.index;var s=f(e,t);if(e.pattern[e.index]!==i)throw E(e,"} to end sub-message");return e.tokens&&e.tokens.push(["syntax",i]),++e.index,s}function E(e,t,n,i){var s=e.pattern,o=s.slice(0,e.index).split(/\r?\n/),r=e.index,a=o.length,c=o.slice(-1)[0].length;return n=n||(e.index>=s.length?"end of message pattern":m(e)||s[e.index]),i||(i=function(e,t){return e?"Expected "+e+" but found "+t:"Unexpected "+t+" found"}(t,n)),new T(i+=" in "+s.replace(/\r?\n/g,"\n"),t,n,r,a,c)}function T(e,t,n,i,s,o){Error.call(this,e),this.name="SyntaxError",this.message=e,this.expected=t,this.found=n,this.offset=i,this.line=s,this.column=o}t=e.exports=function(e,t){return f({pattern:String(e),index:0,tagsType:t&&t.tagsType||null,tokens:t&&t.tokens||null},"")},T.prototype=Object.create(Error.prototype),t.SyntaxError=T}))),y=(m.SyntaxError,new RegExp("^("+Object.keys(_).join("|")+")\\b")),S=new WeakMap;
/*!
 * Intl.MessageFormat prollyfill
 * Copyright(c) 2015 Andy VanWagoner
 * MIT licensed
 **/
function C(e,t,n){if(!(this instanceof C)||S.has(this))throw new TypeError("calling MessageFormat constructor without new is invalid");var i=m(e);S.set(this,{ast:i,format:b(i,t,n&&n.types),locale:C.supportedLocalesOf(t)[0]||"en",locales:t,options:n})}var w=C;Object.defineProperties(C.prototype,{format:{configurable:!0,get:function(){var e=S.get(this);if(!e)throw new TypeError("MessageFormat.prototype.format called on value that's not an object initialized as a MessageFormat");return e.format}},formatToParts:{configurable:!0,writable:!0,value:function(e){var t=S.get(this);if(!t)throw new TypeError("MessageFormat.prototype.formatToParts called on value that's not an object initialized as a MessageFormat");return(t.toParts||(t.toParts=b.toParts(t.ast,t.locales,t.options&&t.options.types)))(e)}},resolvedOptions:{configurable:!0,writable:!0,value:function(){var e=S.get(this);if(!e)throw new TypeError("MessageFormat.prototype.resolvedOptions called on value that's not an object initialized as a MessageFormat");return{locale:e.locale}}}}),"undefined"!=typeof Symbol&&Object.defineProperty(C.prototype,Symbol.toStringTag,{value:"Object"}),Object.defineProperties(C,{supportedLocalesOf:{configurable:!0,writable:!0,value:function(e){return[].concat(Intl.NumberFormat.supportedLocalesOf(e),Intl.DateTimeFormat.supportedLocalesOf(e),Intl.PluralRules?Intl.PluralRules.supportedLocalesOf(e):[],[].concat(e||[]).filter((function(e){return y.test(e)}))).filter((function(e,t,n){return n.indexOf(e)===t}))}}});const E=w;class T{constructor({autoLoadOnLocaleChange:e=!1,fallbackLocale:t=""}={}){this.__delegationTarget=document.createDocumentFragment(),this._autoLoadOnLocaleChange=!!e,this._fallbackLocale=t,this.__storage={},this.__namespacePatternsMap=new Map,this.__namespaceLoadersCache={},this.__namespaceLoaderPromisesCache={},this.formatNumberOptions={returnIfNaN:"",postProcessors:new Map},this.formatDateOptions={postProcessors:new Map};const n=document.documentElement.getAttribute("data-localize-lang");this._supportExternalTranslationTools=Boolean(n),this._supportExternalTranslationTools&&(this.locale=n||"en-GB",this._setupTranslationToolSupport()),document.documentElement.lang||(document.documentElement.lang=this.locale||"en-GB"),this._setupHtmlLangAttributeObserver()}_setupTranslationToolSupport(){this._langAttrSetByTranslationTool=document.documentElement.lang||null}teardown(){this._teardownHtmlLangAttributeObserver()}get locale(){return this._supportExternalTranslationTools?this.__locale||"":document.documentElement.lang}set locale(e){let t;this._supportExternalTranslationTools?(t=this.__locale,this.__locale=e,null===this._langAttrSetByTranslationTool&&this._setHtmlLangAttribute(e)):(t=document.documentElement.lang,this._setHtmlLangAttribute(e)),e.includes("-")||this.__handleLanguageOnly(e),this._onLocaleChanged(e,t)}_setHtmlLangAttribute(e){this._teardownHtmlLangAttributeObserver(),document.documentElement.lang=e,this._setupHtmlLangAttributeObserver()}__handleLanguageOnly(e){throw new Error(`\n      Locale was set to ${e}.\n      Language only locales are not allowed, please use the full language locale e.g. 'en-GB' instead of 'en'.\n      See https://github.com/ing-bank/lion/issues/187 for more information.\n    `)}get loadingComplete(){return Promise.all(Object.values(this.__namespaceLoaderPromisesCache[this.locale]))}reset(){this.__storage={},this.__namespacePatternsMap=new Map,this.__namespaceLoadersCache={},this.__namespaceLoaderPromisesCache={}}addData(e,t,n){if(this._isNamespaceInCache(e,t))throw new Error(`Namespace "${t}" has been already added for the locale "${e}".`);this.__storage[e]=this.__storage[e]||{},this.__storage[e][t]=n}setupNamespaceLoader(e,t){this.__namespacePatternsMap.set(e,t)}loadNamespaces(e,{locale:t}={}){return Promise.all(e.map((e=>this.loadNamespace(e,{locale:t}))))}loadNamespace(e,{locale:t=this.locale}={locale:this.locale}){const n="object"==typeof e,i=n?Object.keys(e)[0]:e;if(this._isNamespaceInCache(t,i))return Promise.resolve();const s=this._getCachedNamespaceLoaderPromise(t,i);return s||this._loadNamespaceData(t,e,n,i)}msg(e,t,n={}){const i=n.locale?n.locale:this.locale,s=this._getMessageForKeys(e,i);if(!s)return"";return new E(s,i).format(t)}_setupHtmlLangAttributeObserver(){this._htmlLangAttributeObserver||(this._htmlLangAttributeObserver=new MutationObserver((e=>{e.forEach((e=>{this._supportExternalTranslationTools?"auto"===document.documentElement.lang?(this._langAttrSetByTranslationTool=null,this._setHtmlLangAttribute(this.locale)):this._langAttrSetByTranslationTool=document.documentElement.lang:this._onLocaleChanged(document.documentElement.lang,e.oldValue||"")}))}))),this._htmlLangAttributeObserver.observe(document.documentElement,{attributes:!0,attributeFilter:["lang"],attributeOldValue:!0})}_teardownHtmlLangAttributeObserver(){this._htmlLangAttributeObserver&&this._htmlLangAttributeObserver.disconnect()}_isNamespaceInCache(e,t){return!(!this.__storage[e]||!this.__storage[e][t])}_getCachedNamespaceLoaderPromise(e,t){return this.__namespaceLoaderPromisesCache[e]?this.__namespaceLoaderPromisesCache[e][t]:null}_loadNamespaceData(e,t,n,i){const s=this._getNamespaceLoader(t,n,i),o=this._getNamespaceLoaderPromise(s,e,i);return this._cacheNamespaceLoaderPromise(e,i,o),o.then((t=>{const n=function(e){return!(!e||!e.default||"object"!=typeof e.default||1!==Object.keys(e).length)}(t)?t.default:t;this.addData(e,i,n)}))}_getNamespaceLoader(e,t,n){let i=this.__namespaceLoadersCache[n];if(!i)if(t){i=e[n],this.__namespaceLoadersCache[n]=i}else i=this._lookupNamespaceLoader(n),this.__namespaceLoadersCache[n]=i;if(!i)throw new Error(`Namespace "${n}" was not properly setup.`);return this.__namespaceLoadersCache[n]=i,i}_getNamespaceLoaderPromise(e,t,n,i=this._fallbackLocale){return e(t,n).catch((()=>{const s=this._getLangFromLocale(t);return e(s,n).catch((()=>{if(i)return this._getNamespaceLoaderPromise(e,i,n,"").catch((()=>{const e=this._getLangFromLocale(i);throw new Error(`Data for namespace "${n}" and current locale "${t}" or fallback locale "${i}" could not be loaded. Make sure you have data either for locale "${t}" (and/or generic language "${s}") or for fallback "${i}" (and/or "${e}").`)}));throw new Error(`Data for namespace "${n}" and locale "${t}" could not be loaded. Make sure you have data for locale "${t}" (and/or generic language "${s}").`)}))}))}_cacheNamespaceLoaderPromise(e,t,n){this.__namespaceLoaderPromisesCache[e]||(this.__namespaceLoaderPromisesCache[e]={}),this.__namespaceLoaderPromisesCache[e][t]=n}_lookupNamespaceLoader(e){for(const[t,n]of this.__namespacePatternsMap){const i="string"==typeof t&&t===e,s="object"==typeof t&&"RegExp"===t.constructor.name&&t.test(e);if(i||s)return n}return null}_getLangFromLocale(e){return e.substring(0,2)}addEventListener(e,t,...n){this.__delegationTarget.addEventListener(e,t,...n)}removeEventListener(e,t,...n){this.__delegationTarget.removeEventListener(e,t,...n)}dispatchEvent(e){this.__delegationTarget.dispatchEvent(e)}_onLocaleChanged(e,t){e!==t&&(this._autoLoadOnLocaleChange&&this._loadAllMissing(e,t),this.dispatchEvent(new CustomEvent("localeChanged",{detail:{newLocale:e,oldLocale:t}})))}_loadAllMissing(e,t){const n=this.__storage[t]||{},i=this.__storage[e]||{},s=[];return Object.keys(n).forEach((t=>{i[t]||s.push(this.loadNamespace(t,{locale:e}))})),Promise.all(s)}_getMessageForKeys(e,t){if("string"==typeof e)return this._getMessageForKey(e,t);const n=Array.from(e).reverse();let i,s;for(;n.length;)if(i=n.pop(),s=this._getMessageForKey(i,t),s)return s}_getMessageForKey(e,t){if(!e||-1===e.indexOf(":"))throw new Error(`Namespace is missing in the key "${e}". The format for keys is "namespace:name".`);const[n,i]=e.split(":"),s=this.__storage[t],o=s?s[n]:{},r=i.split(".").reduce(((e,t)=>"object"==typeof e?e[t]:e),o);return String(r||"")}setDatePostProcessorForLocale({locale:e,postProcessor:t}){this.formatDateOptions.postProcessors.set(e,t)}setNumberPostProcessorForLocale({locale:e,postProcessor:t}){this.formatNumberOptions.postProcessors.set(e,t)}}},3009:(e,t,n)=>{"use strict";n.d(t,{l:()=>a});var i=n(7345),s=n(4971),o=n(1077),r=n(813);const a=(0,o.S)((e=>class extends e{static get localizeNamespaces(){return[]}static get waitForLocalizeNamespaces(){return!0}constructor(){super(),this.__boundLocalizeOnLocaleChanged=(...e)=>{const t=Array.from(e)[0];this.__localizeOnLocaleChanged(t)},this.__localizeStartLoadingNamespaces(),this.localizeNamespacesLoaded&&this.localizeNamespacesLoaded.then((()=>{this.__localizeMessageSync=!0}))}async performUpdate(){Object.getPrototypeOf(this).constructor.waitForLocalizeNamespaces&&await this.localizeNamespacesLoaded,super.performUpdate()}connectedCallback(){super.connectedCallback&&super.connectedCallback(),this.localizeNamespacesLoaded&&this.localizeNamespacesLoaded.then((()=>this.onLocaleReady())),this.__localizeAddLocaleChangedListener()}disconnectedCallback(){super.disconnectedCallback&&super.disconnectedCallback(),this.__localizeRemoveLocaleChangedListener()}msgLit(e,t,n){return this.__localizeMessageSync?r.N.msg(e,t,n):this.localizeNamespacesLoaded?(0,i.C)(this.localizeNamespacesLoaded.then((()=>r.N.msg(e,t,n))),s.Ld):""}__getUniqueNamespaces(){const e=[],t=new Set;return Object.getPrototypeOf(this).constructor.localizeNamespaces.forEach(t.add.bind(t)),t.forEach((t=>{e.push(t)})),e}__localizeStartLoadingNamespaces(){this.localizeNamespacesLoaded=r.N.loadNamespaces(this.__getUniqueNamespaces())}__localizeAddLocaleChangedListener(){r.N.addEventListener("localeChanged",this.__boundLocalizeOnLocaleChanged)}__localizeRemoveLocaleChangedListener(){r.N.removeEventListener("localeChanged",this.__boundLocalizeOnLocaleChanged)}__localizeOnLocaleChanged(e){this.onLocaleChanged(e.detail.newLocale,e.detail.oldLocale)}onLocaleReady(){this.onLocaleUpdated()}onLocaleChanged(e,t){this.__localizeStartLoadingNamespaces(),this.onLocaleUpdated(),this.requestUpdate()}onLocaleUpdated(){}}))},813:(e,t,n)=>{"use strict";n.d(t,{N:()=>o,o:()=>r});var i=n(6979),s=n(194);let o=i.d.get("@lion/localize::localize::0.10.x")||new s.$({autoLoadOnLocaleChange:!0,fallbackLocale:"en-GB"});function r(e){o.teardown(),o=e}},1447:(e,t,n)=>{"use strict";n.d(t,{v:()=>o});const i=n(7206).iv`
  .global-overlays {
    position: fixed;
    z-index: 200;
  }

  .global-overlays__overlay {
    pointer-events: auto;
  }

  .global-overlays__overlay-container {
    display: flex;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }

  .global-overlays__overlay-container--top-left {
    justify-content: flex-start;
    align-items: flex-start;
  }

  .global-overlays__overlay-container--top {
    justify-content: center;
    align-items: flex-start;
  }

  .global-overlays__overlay-container--top-right {
    justify-content: flex-end;
    align-items: flex-start;
  }

  .global-overlays__overlay-container--right {
    justify-content: flex-end;
    align-items: center;
  }

  .global-overlays__overlay-container--bottom-left {
    justify-content: flex-start;
    align-items: flex-end;
  }

  .global-overlays__overlay-container--bottom {
    justify-content: center;
    align-items: flex-end;
  }

  .global-overlays__overlay-container--bottom-right {
    justify-content: flex-end;
    align-items: flex-end;
  }
  .global-overlays__overlay-container--left {
    justify-content: flex-start;
    align-items: center;
  }

  .global-overlays__overlay-container--center {
    justify-content: center;
    align-items: center;
  }

  .global-overlays__overlay--bottom-sheet {
    width: 100%;
  }

  .global-overlays .global-overlays__backdrop {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    background-color: #333333;
    opacity: 0.3;
    display: none;
  }

  .global-overlays .global-overlays__backdrop--visible {
    display: block;
  }

  .global-overlays .global-overlays__backdrop--animation-in {
    animation: global-overlays-backdrop-fade-in 300ms;
  }

  .global-overlays .global-overlays__backdrop--animation-out {
    animation: global-overlays-backdrop-fade-out 300ms;
    opacity: 0;
  }

  @keyframes global-overlays-backdrop-fade-in {
    from {
      opacity: 0;
    }
  }

  @keyframes global-overlays-backdrop-fade-out {
    from {
      opacity: 0.3;
    }
  }

  body > *[inert] {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    pointer-events: none;
  }

  body.global-overlays-scroll-lock {
    overflow: hidden;
  }

  body.global-overlays-scroll-lock-ios-fix {
    position: fixed;
    width: 100%;
  }
`,s=navigator.userAgent.match(/iPhone|iPad|iPod/i);class o{static __createGlobalRootNode(){const e=document.createElement("div");return e.classList.add("global-overlays"),document.body.appendChild(e),e}static __createGlobalStyleNode(){const e=document.createElement("style");return e.setAttribute("data-global-overlays",""),e.textContent=i.cssText,document.head.appendChild(e),e}get globalRootNode(){return o.__globalRootNode||(o.__globalRootNode=o.__createGlobalRootNode(),o.__globalStyleNode=o.__createGlobalStyleNode()),o.__globalRootNode}get list(){return this.__list}get shownList(){return this.__shownList}constructor(){this.__list=[],this.__shownList=[],this.__siblingsInert=!1,this.__blockingMap=new WeakMap}add(e){if(this.list.find((t=>e===t)))throw new Error("controller instance is already added");return this.list.push(e),e}remove(e){if(!this.list.find((t=>e===t)))throw new Error("could not find controller to remove");this.__list=this.list.filter((t=>t!==e))}show(e){this.list.find((t=>e===t))&&this.hide(e),this.__shownList.unshift(e),Array.from(this.__shownList).reverse().forEach(((e,t)=>{e.elevation=t+1}))}hide(e){if(!this.list.find((t=>e===t)))throw new Error("could not find controller to hide");this.__shownList=this.shownList.filter((t=>t!==e))}teardown(){this.list.forEach((e=>{e.teardown()})),this.__list=[],this.__shownList=[],this.__siblingsInert=!1;const e=o.__globalRootNode;e&&(e.parentElement&&e.parentElement.removeChild(e),o.__globalRootNode=void 0,document.head.removeChild(o.__globalStyleNode),o.__globalStyleNode=void 0)}get siblingsInert(){return this.__siblingsInert}disableTrapsKeyboardFocusForAll(){this.shownList.forEach((e=>{!0===e.trapsKeyboardFocus&&e.disableTrapsKeyboardFocus&&e.disableTrapsKeyboardFocus({findNewTrap:!1})}))}informTrapsKeyboardFocusGotEnabled(e){!1===this.siblingsInert&&"global"===e&&(o.__globalRootNode&&function(e){const t=e.parentElement?.children;for(let n=0;n<t.length;n+=1){const i=t[n];i!==e&&(i.setAttribute("inert",""),i.setAttribute("aria-hidden","true"))}}(this.globalRootNode),this.__siblingsInert=!0)}informTrapsKeyboardFocusGotDisabled({disabledCtrl:e,findNewTrap:t=!0}={}){const n=this.shownList.find((t=>t!==e&&!0===t.trapsKeyboardFocus));n?t&&n.enableTrapsKeyboardFocus():!0===this.siblingsInert&&(o.__globalRootNode&&function(e){const t=e.parentElement?.children;for(let n=0;n<t.length;n+=1){const i=t[n];i!==e&&(i.removeAttribute("inert"),i.removeAttribute("aria-hidden"))}}(this.globalRootNode),this.__siblingsInert=!1)}requestToPreventScroll(){document.body.classList.add("global-overlays-scroll-lock"),s&&document.body.classList.add("global-overlays-scroll-lock-ios-fix")}requestToEnableScroll(){this.shownList.some((e=>!0===e.preventsScroll))||(document.body.classList.remove("global-overlays-scroll-lock"),s&&document.body.classList.remove("global-overlays-scroll-lock-ios-fix"))}requestToShowOnly(e){const t=this.shownList.filter((t=>t!==e));t.map((e=>e.hide())),this.__blockingMap.set(e,t)}retractRequestToShowOnly(e){if(this.__blockingMap.has(e)){this.__blockingMap.get(e).map((e=>e.show()))}}}o.__globalRootNode=void 0,o.__globalStyleNode=void 0},1940:(e,t,n)=>{"use strict";n.d(t,{V:()=>o,o:()=>r});var i=n(6979),s=n(1447);let o=i.d.get("@lion/overlays::overlays::0.15.x")||new s.v;function r(e){o=e}},1077:(e,t,n)=>{"use strict";n.d(t,{S:()=>s});const i=new WeakMap;function s(e){return t=>{if(function(e,t){let n=t;for(;n;){if(i.get(n)===e)return!0;n=Object.getPrototypeOf(n)}return!1}(e,t))return t;const n=e(t);return i.set(n,e),n}}},5939:(e,t,n)=>{"use strict";function i(e){return(i="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}n.d(t,{$:()=>_e,A:()=>_t,B:()=>Et,C:()=>Me,D:()=>Be,E:()=>V,F:()=>$e,G:()=>Ot,H:()=>Dt,I:()=>Rt,J:()=>Ge,K:()=>Q,L:()=>M,M:()=>Y,N:()=>m,O:()=>Pt,P:()=>Ut,Q:()=>b,R:()=>Ft,S:()=>tt,T:()=>We,U:()=>te,V:()=>de,W:()=>He,X:()=>ue,Y:()=>ve,Z:()=>ne,_:()=>E,a:()=>w,a0:()=>me,a1:()=>he,a2:()=>ge,a3:()=>pe,a4:()=>fe,a5:()=>v,a6:()=>Z,a7:()=>ee,a8:()=>kn,ab:()=>Ht,ac:()=>Gt,b:()=>je,c:()=>jt,d:()=>o,e:()=>Ye,f:()=>Fe,g:()=>qt,h:()=>S,i:()=>C,j:()=>nn,k:()=>Jt,l:()=>y,m:()=>vt,n:()=>N,o:()=>nt,p:()=>i,q:()=>T,r:()=>D,s:()=>ot,t:()=>k,u:()=>R,v:()=>ht,w:()=>Lt,x:()=>en,y:()=>x,z:()=>kt});var s=function(e,t){return s=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])},s(e,t)};function o(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Class extends value "+String(t)+" is not a constructor or null");function n(){this.constructor=e}s(e,t),e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)}var r,a,c,l,d,u,h,p,f,g,v,_,b,m,y=function(){return y=Object.assign||function(e){for(var t,n=1,i=arguments.length;n<i;n++)for(var s in t=arguments[n])Object.prototype.hasOwnProperty.call(t,s)&&(e[s]=t[s]);return e},y.apply(this,arguments)};function S(e,t,n,i){return new(n||(n=Promise))((function(s,o){function r(e){try{c(i.next(e))}catch(e){o(e)}}function a(e){try{c(i.throw(e))}catch(e){o(e)}}function c(e){var t;e.done?s(e.value):(t=e.value,t instanceof n?t:new n((function(e){e(t)}))).then(r,a)}c((i=i.apply(e,t||[])).next())}))}function C(e,t){var n,i,s,o,r={label:0,sent:function(){if(1&s[0])throw s[1];return s[1]},trys:[],ops:[]};return o={next:a(0),throw:a(1),return:a(2)},"function"==typeof Symbol&&(o[Symbol.iterator]=function(){return this}),o;function a(o){return function(a){return function(o){if(n)throw new TypeError("Generator is already executing.");for(;r;)try{if(n=1,i&&(s=2&o[0]?i.return:o[0]?i.throw||((s=i.return)&&s.call(i),0):i.next)&&!(s=s.call(i,o[1])).done)return s;switch(i=0,s&&(o=[2&o[0],s.value]),o[0]){case 0:case 1:s=o;break;case 4:return r.label++,{value:o[1],done:!1};case 5:r.label++,i=o[1],o=[0];continue;case 7:o=r.ops.pop(),r.trys.pop();continue;default:if(!((s=(s=r.trys).length>0&&s[s.length-1])||6!==o[0]&&2!==o[0])){r=0;continue}if(3===o[0]&&(!s||o[1]>s[0]&&o[1]<s[3])){r.label=o[1];break}if(6===o[0]&&r.label<s[1]){r.label=s[1],s=o;break}if(s&&r.label<s[2]){r.label=s[2],r.ops.push(o);break}s[2]&&r.ops.pop(),r.trys.pop();continue}o=t.call(e,r)}catch(e){o=[6,e],i=0}finally{n=s=0}if(5&o[0])throw o[1];return{value:o[0]?o[1]:void 0,done:!0}}([o,a])}}}function w(e,t){var n="function"==typeof Symbol&&e[Symbol.iterator];if(!n)return e;var i,s,o=n.call(e),r=[];try{for(;(void 0===t||t-- >0)&&!(i=o.next()).done;)r.push(i.value)}catch(e){s={error:e}}finally{try{i&&!i.done&&(n=o.return)&&n.call(o)}finally{if(s)throw s.error}}return r}function E(e,t,n){if(n||2===arguments.length)for(var i,s=0,o=t.length;s<o;s++)!i&&s in t||(i||(i=Array.prototype.slice.call(t,0,s)),i[s]=t[s]);return e.concat(i||Array.prototype.slice.call(t))}!function(e){e.CONSENT_RESPONSE="consent-response",e.CONSENT_UI="consent-ui"}(r||(r={})),function(e){e.ACCEPT="accept",e.REJECT="reject",e.DISMISS="dismiss",e.FULLSCREEN="enter-fullscreen",e.READY="ready"}(a||(a={})),function(e){e[e.TCF_V2=2]="TCF_V2",e[e.CCPA=3]="CCPA"}(c||(c={})),function(e){e[e.FALSE=0]="FALSE",e[e.TRUE=1]="TRUE"}(l||(l={})),function(e){e[e.DATA_LAYER=0]="DATA_LAYER",e[e.WINDOW_EVENT=1]="WINDOW_EVENT"}(d||(d={})),function(e){e[e.MAJOR=0]="MAJOR",e[e.MINOR=1]="MINOR",e[e.PATCH=2]="PATCH"}(u||(u={})),function(e){e.CALL_INIT="Usercentrics: You have to call the init method before!",e.DATA_LOCAL="Usercentrics: disableServerConsents and controllerId should not be present at the same time in the InitOptions!",e.UNKNOWN_VARIANT="Usercentrics: Unknown variant",e.NOT_CCPA="Usercentrics: CCPA was not initialized",e.NOT_DEFAULT="Usercentrics: GDPR was not initialized",e.NOT_TCF="Usercentrics: TCF was not initialized"}(h||(h={})),function(e){e.BANNER="BANNER",e.WALL="WALL"}(p||(p={})),function(e){e.CENTER="CENTER",e.SIDE="SIDE"}(f||(f={})),function(e){e[e.DARK=0]="DARK",e[e.LIGHT=1]="LIGHT"}(g||(g={})),function(e){e.LINK="LINK",e.BUTTON="BUTTON",e.MORE_LINK_BUTTON="MORE_LINK_BUTTON"}(v||(v={})),function(e){e.LEFT="LEFT",e.RIGHT="RIGHT"}(_||(_={})),function(e){e.HORIZONTAL="HORIZONTAL",e.VERTICAL="VERTICAL"}(b||(b={})),function(e){e.ALL="ALL",e.SHORT="SHORT"}(m||(m={}));var T="3.9.0",I=function(e,t){return-1!==e.indexOf(t)},A=function(){return"SDK-".concat("3.9.0")},x=function(){return parseInt("3",10)},N=function(e){return Array.isArray(e)&&e.length>0},L=function(e){return"object"===i(e)&&null!==e&&Object.keys(e).length>0},k=function(e,t){if(void 0===t)throw new Error("altElement of nullishOperation can not be undefined");return null!=e?e:t},O=function(e,t,n,i,s){return{applicationVersion:A(),consent:{action:n,status:t.consent.status,type:i},service:{id:t.id,name:t.name,processorId:t.processorId,version:t.version},settings:{controllerId:e.controllerId,id:e.id,language:e.selectedLanguage,referrerControllerId:k(null==s?void 0:s.referrerControllerId,""),version:e.version},timestamp:k(null==s?void 0:s.timestamp,(new Date).valueOf())}},D=function(e,t){return e.reduce((function(e,n){var i=t[n];if(!(null==i?void 0:i.name))return e;var s=i.name;return E(E([],w(e),!1),[{id:n,name:s}],!1)}),[])};function R(e){return E([],w(new Set(e)),!1)}function P(e){return new Promise((function(t,n){return e.then(n,t)}))}var U,F,V,M,B,$,j,H,G,z=function(e){return e&&"object"===i(e)},W=function e(t,n,i){void 0===i&&(i=!1);var s=y({},n);if(!z(s))throw new Error("Source param should be an object");return z(t)?(Object.keys(t).forEach((function(n){var o,r,a,c,l,d=t[n],u=s[n];void 0!==u&&(s=Array.isArray(d)&&Array.isArray(u)?y(y({},s),i?((o={})[n]=(l=d.concat(u)).filter((function(e,t){return l.indexOf(e)===t})),o):((r={})[n]=d,r)):z(d)&&z(u)?y(y({},s),((a={})[n]=e(y({},d),u),a)):y(y({},s),((c={})[n]=d,c)))})),s):s},q=function(e,t,n,i){return void 0===n&&(n=2e4),void 0===i&&(i=5),new Promise((function(s,o){var r=setInterval((function(){e()&&(clearTimeout(a),clearInterval(r),s())}),i),a=setTimeout((function(){clearTimeout(a),clearInterval(r),o(new Error(t))}),n)}))},J=function(e,t){for(var n=e.split("."),i=t.split("."),s=Math.min(n.length,i.length),o=0;o<s;o+=1){var r=Number(n[o])||0,a=Number(i[o])||0;if(r!==a)return r>a?1:-1}return i.length-n.length};!function(e){e[e.COOKIE=0]="COOKIE",e[e.WEB=1]="WEB",e[e.APP=2]="APP"}(U||(U={})),function(e){e.LEFT="LEFT",e.CENTER="CENTER",e.RIGHT="RIGHT"}(F||(F={})),function(e){e.AVAILABLE_LANGUAGES_NOT_FOUND="Unable to find available languages using given settingsId and version.",e.FETCH_AVAILABLE_LANGUAGES="Something went wrong while fetching the available languages.",e.FETCH_DATA_PROCESSING_SERVICES="Something went wrong while fetching the data processing services.",e.FETCH_LEGAL_BASIS="Something went wrong while fetching the legal data translations.",e.FETCH_SETTINGS="Something went wrong while fetching the settings.",e.FETCH_USER_CONSENTS="Something went wrong while fetching the user's consents.",e.FETCH_USER_COUNTRY="Something went wrong while fetching the user's country.",e.FETCH_USER_TCF_DATA="Something went wrong while fetching the user's tcf data.",e.GENERATE_DATA_PROCESSING_SERVICES="Something went wrong while generating the data processing services.",e.RULESET_NOT_FOUND="Config Map not found!",e.SAVE_CONSENTS="Something went wrong while saving user consents.",e.SETTINGS_NOT_FOUND="Unable to find settings using given settingsId and version."}(V||(V={})),function(e){e.US_CA_ONLY="US_CA_ONLY",e.US="US"}(M||(M={})),function(e){e[e.FIRST_LAYER=1]="FIRST_LAYER",e[e.SECOND_LAYER=3]="SECOND_LAYER"}(B||(B={})),function(e){e[e.DATA_LAYER=1]="DATA_LAYER",e[e.WINDOW_EVENT=4]="WINDOW_EVENT"}($||($={})),function(e){e.DATA_COLLECTED_LIST="dataCollectedList",e.DATA_PURPOSES_LIST="dataPurposesList",e.DATA_RECIPIENTS_LIST="dataRecipientsList",e.TECHNOLOGY_USED="technologyUsed"}(j||(j={})),function(e){e.MAJOR="major",e.MINOR="minor",e.PATCH="patch"}(H||(H={})),function(e){e.ICON="ICON",e.LINK="LINK"}(G||(G={}));var K,Y=function(e,t){return"boolean"==typeof e?e:t},Q=function(e){if(!e)return null;var t=e.startsWith("#")?e:"#".concat(e);return X(t)?t:"#0045A5"},X=function(e){return!(""===e||!e)&&new RegExp("^#(?:[0-9a-fA-F]{3}){1,2}$").test(e)},Z=function(e){if(null!=e.firstLayer.isOverlayEnabled)return e.firstLayer.isOverlayEnabled;var t=e.backgroundOverlay.find((function(e){var t;return(null===(t=e.target)||void 0===t?void 0:t[0])===B.FIRST_LAYER}));return!!t&&(null==t?void 0:t.darken)>0},ee=function(e){if(null!=e.secondLayer.isOverlayEnabled)return e.secondLayer.isOverlayEnabled;var t=e.backgroundOverlay.find((function(e){var t;return(null===(t=e.target)||void 0===t?void 0:t[0])===B.SECOND_LAYER}));return!!t&&(null==t?void 0:t.darken)>0},te=function(e){return"number"==typeof e||"string"==typeof e&&!e.includes("px")?"".concat(e,"px"):e},ne=function(e){switch(e){case F.CENTER:return"center";case F.RIGHT:return"right";default:case F.LEFT:return"left"}},ie={description:"",deviceStorage:null,id:"",legalBasis:[],name:""},se=function e(t,n){return t.reduce((function(t,i){var s=n.find((function(e){return e.id===i.id}));return E(E([],w(t),!1),[y(y(y({},i),s||ie),{subServices:e(i.subServices,n)})],!1)}),[])},oe=function(e){return null!=e&&null!=e.region},re=function(e){return null!=e&&null!=e.changedPurposes},ae=function(e){var t,n;return null!=e&&null!=(null===(t=e.firstLayer)||void 0===t?void 0:t.showShortDescriptionOnMobile)&&null==(null===(n=e.firstLayer)||void 0===n?void 0:n.isCategoryTogglesEnabled)},ce=function(e){var t;return null!=e&&null!=(null===(t=e.firstLayer)||void 0===t?void 0:t.hideNonIabPurposes)},le=function(e){var t;return null!=e&&null!=(null===(t=e.firstLayer)||void 0===t?void 0:t.isCategoryTogglesEnabled)},de="BlinkMacSystemFont, -apple-system, Segoe UI, Roboto, Oxygen-Sans, Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue, Helvetica, Arial, sans-serif",ue=14,he="#336AB7",pe="#dedede",fe="#595959",ge="#ffffff",ve="8px",_e=.7,be={acceptAllButton:"Accept All",ccpaButton:"Agree to CCPA",ccpaMoreInformation:"More Information",closeButton:"Close Second Layer",collapse:"Collapse",cookiePolicyButton:"Open Cookie Policy",copyControllerId:"Copy Controller ID",denyAllButton:"Deny all",expand:"Expand",fullscreenButton:"Enter full screen",imprintButton:"Open Imprint",languageSelector:"Select language",privacyButton:"Open",privacyPolicyButton:"Open Privacy Policy",saveButton:"Save",serviceInCategoryDetails:"View Service details",servicesInCategory:"List of Services in this category",tabButton:"Tab",usercentricsCard:"Card",usercentricsCMPButtons:"Footer including buttons",usercentricsCMPContent:"Content",usercentricsCMPHeader:"Header including language selection and external links",usercentricsCMPUI:"Consent Management Platform Interface",usercentricsList:"List",vendorConsentToggle:"Consent",vendorDetailedStorageInformation:"Detailed Storage Information",vendorLegIntToggle:"Legitimate Interest"},me="https://www.usercentrics.com/",ye=function(e,t){var n,i,s,o,r,a,c,l,d,u,h=e.labels;return{cnil:{denyLabel:(null===(n=null==t?void 0:t.labels)||void 0===n?void 0:n.CNIL_DENY_LINK_TEXT)||"Continuer sans accepter"},cookieInformation:{anyDomain:h.anyDomain||"any domain (ex. first party cookie)",cookieRefresh:(null===(i=null==t?void 0:t.labels)||void 0===i?void 0:i.COOKIE_REFRESH)||(null===(s=null==t?void 0:t.labels)||void 0===s?void 0:s.COOKIE_REFRESH)||"Cookie Refresh",cookieStorage:(null===(o=null==t?void 0:t.labels)||void 0===o?void 0:o.COOKIE_STORAGE)||(null===(r=null==t?void 0:t.labels)||void 0===r?void 0:r.COOKIE_STORAGE)||"Cookie Storage",day:h.day,days:h.days,description:h.storageInformationDescription||"Below you can see the longest potential duration for storage on a device, as set when using the cookie method of storage and if there are any other methods used.",domain:h.domain||"Domain",duration:h.duration||"Duration",error:h.informationLoadingNotPossible||"Sorry; we could not load the required information.",hour:h.hour,hours:h.hours,identifier:h.identifier||"Identifier",loading:h.loadingStorageInformation||"Loading storage information",maximumAge:h.maximumAgeCookieStorage||"Maximum age of cookie storage",minute:h.minute,minutes:h.minutes,month:h.month,months:h.months,multipleDomains:h.multipleDomains||"multiple subdomains may exist",name:h.name||"Name",no:h.no||"no",nonCookieStorage:h.nonCookieStorage||"Non-cookie storage",purposes:h.purposes||"Purposes",second:h.second||"second",seconds:h.seconds||"seconds",session:h.session||"Session",storedInformation:h.storedInformation||"Stored Information",storedInformationDescription:h.storedInformationDescription||"This service uses different means of storing information on a user's device as listed below.",title:h.storageInformation||"Storage Information",titleDetailed:h.detailedStorageInformation||"Detailed Storage Information",tryAgain:h.tryAgain||"Try again?",type:h.type||"Type",year:h.year,years:h.years,yes:h.yes||"yes"},general:{back:(null===(a=null==t?void 0:t.labels)||void 0===a?void 0:a.BACK)||"Back",consentGiven:h.accepted,consentNotGiven:h.denied,consentType:h.consentType,controllerId:"Controller ID",copied:h.copied,copy:h.copy,date:h.date,decision:h.decision,details:(null===(c=null==t?void 0:t.labels)||void 0===c?void 0:c.DETAILS)||"Details",explicit:h.explicit,implicit:h.implicit,implicitNo:h.noImplicit,implicitYes:h.yesImplicit,privacyButton:h.btnChipName,showLess:h.readLess,showMore:h.btnBannerReadMore||h.showMore,subservice:(null===(l=null==t?void 0:t.labels)||void 0===l?void 0:l.SUB_SERVICE)||"Subservice",subservices:(null===(d=null==t?void 0:t.labels)||void 0===d?void 0:d.SUB_SERVICES)||"Subservices",subservicesDescription:(null===(u=null==t?void 0:t.labels)||void 0===u?void 0:u.SUB_SERVICES_DESCRIPTION)||"Below you can find all the services that are subordinate to this service. The current consent status of this service applies to all subservices."},service:{dataCollected:{description:h.dataCollectedInfo,title:h.dataCollectedList},dataDistribution:{processingLocationDescription:h.locationofProcessingInfo,processingLocationTitle:h.locationOfProcessing,thirdPartyCountriesDescription:h.transferToThirdCountriesInfo,thirdPartyCountriesTitle:h.transferToThirdCountries},dataProtectionOfficer:{description:h.dataProtectionOfficerInfo,title:h.dataProtectionOfficer},dataPurposes:{description:h.dataPurposesInfo,title:h.dataPurposes},dataRecipients:{description:h.dataRecipientsListInfo,title:h.dataRecipientsList},descriptionTitle:h.descriptionOfService,history:{description:null,title:h.history},legalBasis:{description:h.legalBasisInfo,title:h.legalBasisList},processingCompanyTitle:h.processingCompany,retentionPeriod:{description:h.retentionPeriodInfo,title:h.retentionPeriod},technologiesUsed:{description:h.technologiesUsedInfo,title:h.technologiesUsed},urls:{cookiePolicyTitle:h.cookiePolicyInfo,optOutTitle:h.optOut,privacyPolicyTitle:h.policyOf}}}},Se=function(e,t){var n,i,s,o,r,a,c,l,d,u,h,p,f,g,_,m,y,S,C,w,E,T,I,A,x,N,L,O=t.customization,D=t.labels;return{customCss:(null===(n=t.features)||void 0===n?void 0:n.customCss)&&t.useUnsafeCustomCss&&null!=t.stylesCss?t.stylesCss:null,customization:{button:{alignment:(null==O?void 0:O.buttonAlignment)||b.HORIZONTAL,borderRadius:te(k(null==O?void 0:O.borderRadiusButton,"4px"))},color:{accentColor:k(Q(null===(i=null==O?void 0:O.color)||void 0===i?void 0:i.tabsBorderColor),"#DDDDDD"),acceptBtn:{backgroundColor:Q(null===(s=null==O?void 0:O.color)||void 0===s?void 0:s.acceptBtnBackground),textColor:Q(null===(o=null==O?void 0:O.color)||void 0===o?void 0:o.acceptBtnText)},denyButton:{backgroundColor:Q(null===(r=null==O?void 0:O.color)||void 0===r?void 0:r.denyBtnBackground),textColor:Q(null===(a=null==O?void 0:O.color)||void 0===a?void 0:a.denyBtnText)},layerBackground:k(Q(null===(c=null==O?void 0:O.color)||void 0===c?void 0:c.layerBackground),"#ffffff"),linkFontColor:k(Q(null===(l=null==O?void 0:O.color)||void 0===l?void 0:l.linkFont),"#303030"),linkIconColor:k(Q(null===(d=null==O?void 0:O.color)||void 0===d?void 0:d.linkIcon),"#595959"),moreBtn:{backgroundColor:k(Q(null===(u=null==O?void 0:O.color)||void 0===u?void 0:u.moreBtnBackground),"#0045A5"),textColor:k(Q(null===(h=null==O?void 0:O.color)||void 0===h?void 0:h.moreBtnText),"#FAFAFA")},overlayColor:k(Q(null===(p=null==O?void 0:O.color)||void 0===p?void 0:p.overlay),"#333"),primary:k(Q(null===(f=null==O?void 0:O.color)||void 0===f?void 0:f.primary),"#0045A5"),saveButton:{backgroundColor:Q(null===(g=null==O?void 0:O.color)||void 0===g?void 0:g.saveBtnBackground),textColor:Q(null===(_=null==O?void 0:O.color)||void 0===_?void 0:_.saveBtnText)},secondLayerTab:Q(null===(m=null==O?void 0:O.color)||void 0===m?void 0:m.secondLayerTab),textFontColor:k(Q(null===(y=null==O?void 0:O.color)||void 0===y?void 0:y.text),"#303030")},firstLayer:{secondLayerTrigger:k(t.firstLayer.secondLayerTrigger,v.LINK)},font:{family:k(null===(S=null==O?void 0:O.font)||void 0===S?void 0:S.family,de),size:k(null===(C=null==O?void 0:O.font)||void 0===C?void 0:C.size,14)},layer:{borderRadius:te(k(null==O?void 0:O.borderRadiusLayer,"8px"))},logo:{altTag:k(null==O?void 0:O.logoAltTag,null),position:ne(t.firstLayer.logoPosition),url:k(null==O?void 0:O.logoUrl,null)},overlay:{opacity:k(null==O?void 0:O.overlayOpacity,.7)},privacyButton:{backgroundColor:k(Q(null===(w=null==O?void 0:O.color)||void 0===w?void 0:w.privacyButtonBackground),null),desktopSize:k(null==O?void 0:O.privacyButtonSizeDesktop,null),iconColor:k(Q(null===(E=null==O?void 0:O.color)||void 0===E?void 0:E.privacyButtonIcon),null),mobileSize:k(null==O?void 0:O.privacyButtonSizeMobile,null)},theme:1,toggle:{active:{backgroundColor:Q(null===(T=null==O?void 0:O.color)||void 0===T?void 0:T.toggleActiveBackground)||"#336AB7",iconColor:Q(null===(I=null==O?void 0:O.color)||void 0===I?void 0:I.toggleActiveIcon)||"#ffffff"},disabled:{backgroundColor:Q(null===(A=null==O?void 0:O.color)||void 0===A?void 0:A.toggleDisabledBackground)||"#dedede",iconColor:Q(null===(x=null==O?void 0:O.color)||void 0===x?void 0:x.toggleDisabledIcon)||"#ffffff"},inactive:{backgroundColor:Q(null===(N=null==O?void 0:O.color)||void 0===N?void 0:N.toggleInactiveBackground)||"#595959",iconColor:Q(null===(L=null==O?void 0:O.color)||void 0===L?void 0:L.toggleInactiveIcon)||"#ffffff"}},useBackgroundShadow:k(null==O?void 0:O.useBackgroundShadow,!0)},isEmbeddingsEnabled:!0,language:{available:e.language.available,selected:e.language.selected},links:{cookiePolicy:{ariaLabel:be.cookiePolicyButton,label:k(D.cookiePolicyLinkText,""),url:t.cookiePolicyUrl},imprint:{ariaLabel:be.imprintButton,label:D.imprintLinkText||null,url:t.imprintUrl},privacyPolicy:{ariaLabel:be.privacyPolicyButton,label:D.privacyPolicyLinkText,url:t.privacyPolicyUrl}},poweredBy:{isEnabled:t.enablePoweredBy,label:"Powered by",partnerUrl:k(t.partnerPoweredByUrl,null),partnerUrlLabel:k(t.labels.partnerPoweredByLinkText,null),url:"https://www.usercentrics.com/",urlLabel:"Usercentrics Consent Management"},privacyButton:{iconUrl:t.buttonPrivacyOpenIconUrl||null,isEnabled:t.privacyButtonIsVisible,position:t.buttonDisplayLocation||"bl"},showCookieInformation:t.showCookieInformation}},Ce=function(e,t,n){var i=ye(e,n);return{cookieInformation:y(y({},i.cookieInformation),{purposes:t.labelsPurposes}),general:{features:t.labelsFeatures,iabVendors:t.labelsIabVendors,nonIabPurposes:t.labelsNonIabPurposes,nonIabVendors:t.labelsNonIabVendors,purposes:t.labelsPurposes},nonTCFLabels:i,vendor:{features:t.vendorFeatures,legitimateInterest:t.vendorLegitimateInterestPurposes,privacyPolicy:e.labels.privacyPolicyLinkText,purposes:t.vendorPurpose,specialFeatures:t.vendorSpecialFeatures,specialPurposes:t.vendorSpecialPurposes,toggleAll:t.labelsActivateAllVendors}}},we=function(e){return{categories:e.categories,consentTemplates:e.consentTemplates}},Ee=function(){function e(){this.ampEnabled=!1}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.ampEnabled=!1},e.prototype.isAmpEnabled=function(){return this.ampEnabled},e.prototype.setIsAmpEnabled=function(e){this.ampEnabled=e},e}(),Te={EU_URI:{AGGREGATOR:"https://aggregator.eu.usercentrics.eu/aggregate/",CDN:"https://config.eu.usercentrics.eu",FETCH_CONSENTS:"https://consents.eu.usercentrics.eu/consentsHistory",FETCH_TCF_DATA:"https://consents.eu.usercentrics.eu/consentsHistoryTCF",FETCH_TCF_DATA_V2:"https://consents.eu.usercentrics.eu/consentState",GRAPHQL:"https://api.eu.usercentrics.eu/graphql",TRACK_EVENT:"https://uct.eu.usercentrics.eu/uct"},FOLDER:{RULESET:"ruleSet",SETTINGS:"settings",TEMPLATES:"consent-templates",TRANSLATIONS:"translations"},URI:{AGGREGATOR:"https://aggregator.service.usercentrics.eu/aggregate/",CDN:"https://api.usercentrics.eu",FETCH_CONSENTS:"https://consents.usercentrics.eu/consentsHistory",FETCH_TCF_DATA:"https://consents.usercentrics.eu/consentsHistoryTCF",FETCH_TCF_DATA_V2:"https://consents.usercentrics.eu/consentState",GRAPHQL:"https://graphql.usercentrics.eu/graphql",RULESET:"https://api.usercentrics.eu",SAVE_CONSENTS_V2:"https://consent-api.service.consent.usercentrics.eu/consent",TRACK_EVENT:"https://uct.service.usercentrics.eu/uct"}},Ie={EU_URI:{AGGREGATOR:"https://aggregator.service.usercentrics-sandbox.eu/aggregate/",CDN:"https://api.usercentrics-sandbox.eu",FETCH_CONSENTS:"https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistory",FETCH_TCF_DATA:"https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistoryTCF",FETCH_TCF_DATA_V2:"https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentState",GRAPHQL:"https://api-v2-sandbox-consent-dot-usercentrics-playground.nw.r.appspot.com/",TRACK_EVENT:"https://uct.eu.usercentrics.eu/uct"},FOLDER:{RULESET:"ruleSet",SETTINGS:"settings",TEMPLATES:"consent-templates",TRANSLATIONS:"translations"},URI:{AGGREGATOR:"https://aggregator.service.usercentrics-sandbox.eu/aggregate/",CDN:"https://api.usercentrics-sandbox.eu",FETCH_CONSENTS:"https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistory",FETCH_TCF_DATA:"https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentsHistoryTCF",FETCH_TCF_DATA_V2:"https://api-consent-sandbox-dot-usercentrics-playground.nw.r.appspot.com/consentState",GRAPHQL:"https://api-v2-sandbox-consent-dot-usercentrics-playground.nw.r.appspot.com/",RULESET:"https://api.usercentrics-sandbox.eu",SAVE_CONSENTS_V2:"https://consent-api.service.consent.usercentrics-staging.eu/consent",TRACK_EVENT:"https://uct.service.usercentrics.eu/uct"}},Ae={countryCode:"DE",countryName:"Germany (default)",regionCode:""},xe=function(e,t,n){return S(void 0,void 0,void 0,(function(){return C(this,(function(i){return[2,Le(e,t,null,n)]}))}))},Ne=function(e,t,n,i){return S(void 0,void 0,void 0,(function(){return C(this,(function(s){return[2,Le(e,n,t,i)]}))}))},Le=function(e,t,n,i){return S(void 0,void 0,void 0,(function(){var s,o;return C(this,(function(r){return s={"content-type":"application/json"},o=y(y({},i),{headers:s,method:n?"POST":"GET"}),n&&(o.body=JSON.stringify(n)),(null==i?void 0:i.headers)&&(o.headers=y(y({},s),i.headers)),[2,fetch(e,o).then((function(e){return S(void 0,void 0,void 0,(function(){return C(this,(function(n){if(e.ok)return[2,Oe(e)];throw ke(t,e.status)}))}))}))]}))}))},ke=function(e,t){return{errorMessage:e,statusCode:t}},Oe=function(e){return S(void 0,void 0,void 0,(function(){return C(this,(function(t){switch(t.label){case 0:return[4,De(e)];case 1:return[2,{data:t.sent(),location:e.headers.get("x-client-geo-location"),statusCode:e.status}]}}))}))},De=function(e){return S(void 0,void 0,void 0,(function(){var t,n;return C(this,(function(i){switch(i.label){case 0:return[4,e.text()];case 1:return t=i.sent(),[2,(n=""===t?{}:JSON.parse(t)).data||n]}}))}))};!function(e){e[e.RESOURCE_NOT_FOUND=403]="RESOURCE_NOT_FOUND"}(K||(K={}));var Re,Pe,Ue,Fe,Ve,Me=1,Be="1---",$e="__uspapiLocator",je=/^[1][nNyY-][nNyY-][nNyY-]$/,He="__uspapi";!function(e){e.CCPA="uc_usprivacy",e.CCPA_DATA="uc_ccpa",e.CONSENTS_BUFFER="uc_consents_buffer",e.LEGACY_SETTINGS="ucSettings",e.SERVICES="uc_services",e.SETTINGS="uc_settings",e.TCF="uc_tcf",e.USER_INTERACTION="uc_user_interaction"}(Re||(Re={})),function(e){e.USER_COUNTRY="uc_user_country"}(Pe||(Pe={})),function(e){e.CROSS_DEVICE_DATA_NOT_AVAILABLE="Usercentrics: Cross Device Consents data is not available",e.CROSS_DEVICE_TCF_DATA_NOT_AVAILABLE="Usercentrics: Cross Device TCF data is not available"}(Ue||(Ue={})),function(e){e.CROSS_DOMAIN_DATA_NOT_AVAILABLE="Usercentrics: Cross Domain Consents data is not available",e.CROSS_DOMAIN_TCF_DATA_NOT_AVAILABLE="Usercentrics: Cross Domain TCF data is not available",e.CROSS_DOMAIN_FEATURE_NOT_AVAILABLE="Usercentrics: Cross Domain Consent Sharing is not available.",e.CROSS_DOMAIN_LANGUAGE_NOT_AVAILABLE="Usercentrics: Cross Domain Consent language is not available",e.CROSS_DOMAIN_SET_DATA_FAILURE="Usercentrics: Unable to set Cross Domain data",e.CROSS_DOMAIN_SET_TCF_DATA_FAILURE="Usercentrics: Unable to set Cross Domain TCF data",e.CROSS_DOMAIN_IFRAME_ERROR="Usercentrics: Iframe error",e.CROSS_DOMAIN_IFRAME_NOT_FOUND="Usercentrics: Cross Domain iFrame not found",e.CROSS_DOMAIN_IFRAME_LOAD_ERROR="Usercentrics: IFrame did not load"}(Fe||(Fe={})),function(e){e.CLEAR="clear",e.GET_CROSS_DOMAIN_LANGUAGE="getCrossDomainLanguage",e.GET_CROSS_DOMAIN_SESSION_DATA="getCrossDomainSessionData",e.GET_CROSS_DOMAIN_TCF_DATA="getCrossDomainTcfData",e.GET_CROSS_DOMAIN_CCPA_DATA="getCrossDomainCcpaData",e.GET_TC_STRING="getTCString",e.PING="ping",e.SET_CROSS_DOMAIN_DATA="setCrossDomainData",e.SET_CROSS_DOMAIN_TCF_DATA="setCrossDomainTcfData",e.SET_CROSS_DOMAIN_CCPA_DATA="setCrossDomainCcpaData",e.SET_TC_STRING="setTCString"}(Ve||(Ve={}));var Ge,ze,We,qe,Je="https://app.usercentrics.eu/browser-sdk/".concat("3.9.0","/cross-domain-bridge.html"),Ke="https://app.eu.usercentrics.eu/browser-sdk/".concat("3.9.0","/cross-domain-bridge.html"),Ye=function(){function e(){}return e.setDomainBridgeUri=function(t){var n="";t&&(t.crossDomainConsentSharingIFrame?n=t.crossDomainConsentSharingIFrame:t.app&&(n="".concat(t.app,"/browser-sdk/").concat("3.9.0","/cross-domain-bridge.html")));var i=""!==n?n:Je,s=Ke;e.domainBridgeUri=e.useEuCdn?s:i},e.getDomainBridgeUri=function(){return e.domainBridgeUri},e.init=function(t,n){return S(this,void 0,void 0,(function(){return C(this,(function(i){return e.setDomainBridgeUri(n),e.setUseEuCdn((null==t?void 0:t.useEuCdn)||!1),e.setDomainBridgeUri(n),[2,this.initIFrame(e.getDomainBridgeUri(),"uc-cross-domain-bridge")]}))}))},e.initIFrame=function(t,n){return S(this,void 0,void 0,(function(){var i=this;return C(this,(function(s){return[2,new Promise((function(s,o){var r=e.createIFrame(t,n);r.onload=function(){return S(i,void 0,void 0,(function(){var i;return C(this,(function(a){return i=setTimeout((function(){r={},o(new Error(Fe.CROSS_DOMAIN_IFRAME_LOAD_ERROR))}),1e3),e.queryIFrame(t,n,Ve.PING).then((function(){clearTimeout(i),s(!0)})).catch((function(e){clearTimeout(i),o(e)})),[2]}))}))},r.onerror=function(){return S(i,void 0,void 0,(function(){return C(this,(function(e){return o(new Error(Fe.CROSS_DOMAIN_IFRAME_ERROR)),[2]}))}))},e.appendIFrame(r)}))]}))}))},e.setIsCrossDomainAvailable=function(t){e.crossDomainAvailable=t},e.isCookieBridgeAvailable=function(){return e.cookieBridgeAvailable},e.setIsCookieBridgeAvailable=function(t){e.cookieBridgeAvailable=t},e.isCrossDomainAvailable=function(){return e.crossDomainAvailable},e.getCrossDomainId=function(){return e.crossDomainId},e.setCrossDomainId=function(t){e.crossDomainId="".concat("uc_cross_domain_data","_").concat(t)},e.setCookieBridgeDomain=function(e,t){this.cookieBridgeDomain="".concat(e).concat(t)},e.setUseEuCdn=function(t){e.useEuCdn=t},e.createIFrame=function(t,n){e.removeIFrame(n);var i=document.createElement("iframe");return i.style.display="none",i.id=n,i.src=t,i},e.removeIFrame=function(e){var t=document.getElementById(e);t&&t.parentNode&&t.parentNode.removeChild(t)},e.queryIFrame=function(e,t,n,i,s){return S(this,void 0,void 0,(function(){var o;return C(this,(function(r){if(!(o=document.getElementById(t))||!o.id)throw new Error(Fe.CROSS_DOMAIN_IFRAME_NOT_FOUND);return[2,new Promise((function(t,r){var a=JSON.stringify({crossDomainId:s,method:n,payload:i}),c=new MessageChannel;c.port1.onmessage=function(e){var n=JSON.parse(e.data),i=n.success,s=n.data;i?t(s):r(e)},o&&o.contentWindow&&o.contentWindow.postMessage(a,e,[c.port2])}))]}))}))},e.appendIFrame=function(e){try{document.body?document.body.appendChild(e):document.addEventListener("DOMContentLoaded",(function(){document.body.appendChild(e)}))}catch(e){return new Error(Fe.CROSS_DOMAIN_IFRAME_ERROR)}return null},e.query=function(t,n){return S(this,void 0,void 0,(function(){return C(this,(function(i){return[2,e.queryIFrame(e.getDomainBridgeUri(),"uc-cross-domain-bridge",t,n,e.crossDomainId)]}))}))},e.getCrossDomainLanguage=function(){return e.query(Ve.GET_CROSS_DOMAIN_LANGUAGE)},e.setCrossDomainData=function(t){return S(this,void 0,void 0,(function(){return C(this,(function(n){return[2,e.query(Ve.SET_CROSS_DOMAIN_DATA,(i=t,{consents:i.services.map((function(e){return e.history.map((function(t){return{action:t.action,consentId:"",settingsVersion:t.versions.settings,status:t.status,templateId:e.id,timestamp:"".concat(t.timestamp),updatedBy:t.type}}))})).reduce((function(e,t){return e.concat(t)}),[]).sort((function(e,t){return parseInt(e.timestamp,10)-parseInt(t.timestamp,10)})),controllerId:i.controllerId,language:i.language}))];var i}))}))},e.setCrossDomainCcpaData=function(t){return S(this,void 0,void 0,(function(){return C(this,(function(n){return[2,e.query(Ve.SET_CROSS_DOMAIN_CCPA_DATA,t)]}))}))},e.getCrossDomainCcpaData=function(){return S(this,void 0,void 0,(function(){return C(this,(function(t){return[2,e.query(Ve.GET_CROSS_DOMAIN_CCPA_DATA)]}))}))},e.getCrossDomainSessionData=function(){return S(this,void 0,void 0,(function(){return C(this,(function(t){return[2,e.query(Ve.GET_CROSS_DOMAIN_SESSION_DATA)]}))}))},e.getCrossDomainTcfData=function(){return S(this,void 0,void 0,(function(){return C(this,(function(t){return[2,e.query(Ve.GET_CROSS_DOMAIN_TCF_DATA)]}))}))},e.setCrossDomainTcfData=function(t){return S(this,void 0,void 0,(function(){return C(this,(function(n){return[2,e.query(Ve.SET_CROSS_DOMAIN_TCF_DATA,t)]}))}))},e.clearCrossDomainStorage=function(){return S(this,void 0,void 0,(function(){return C(this,(function(t){return[2,e.query(Ve.CLEAR)]}))}))},e.crossDomainId="",e.cookieBridgeDomain="",e.domainBridgeUri=Je,e.useEuCdn=!1,e.cookieBridgeAvailable=!1,e.crossDomainAvailable=!1,e}();!function(e){e.COOKIE_BRIDGE_NOT_AVAILABLE="Usercentrics: Cookie bridge is not available.",e.COOKIE_BRIDGE_OPTIONS_NOT_SET="Usercentrics: Cookie bridge options are not set",e.GET_GLOBAL_TC_STRING_FAILURE="Usercentrics: Unable to get the Global TC string",e.INIT_TCF_ERROR="Usercentrics: Unable to init TCF",e.RESET_GVL_FAILURE="Usercentrics: Unable to reset Global Vendor List",e.SET_GLOBAL_TC_STRING_FAILURE="Usercentrics: Unable to set the Global TC string",e.VENDOR_REMOVED="Usercentrics: The following vendor is not part of the official vendors list anymore: ",e.TC_MODEL_UNDEFINED="Usercentrics: tcModel can not be null.",e.SELECTED_LANGUAGE_UNDEFINED="Usercentrics: Selected language can not be undefined"}(Ge||(Ge={})),function(e){e.LEGITIMATE_INTEREST="legIntPurposes",e.PURPOSES="purposes"}(ze||(ze={})),function(e){e[e.ID=0]="ID",e[e.LEGITIMATE_INTEREST=1]="LEGITIMATE_INTEREST",e[e.PURPOSES=2]="PURPOSES",e[e.SPECIAL_PURPOSES=3]="SPECIAL_PURPOSES"}(We||(We={})),function(e){e[e.FIRST_LAYER=1]="FIRST_LAYER",e[e.SECOND_LAYER=2]="SECOND_LAYER"}(qe||(qe={}));var Qe,Xe=function(e){switch(e){case"onAcceptAllBtnClick":case"onSpecialFunctionAcceptAllConsentTrigger":return"onAcceptAllServices";case"onDenyAllAnchorClick":case"onDenyAllBtnClick":return"onDenyAllServices";case"onNonEURegion":return"onNonEURegion";case"onInitialPageLoad":case"onCountdownFinished":default:return"onInitialPageLoad";case"onToggleCategory":case"onToggleConsent":case"onToggleSelectAll":return"onEssentialChange";case"onWindowFunctionUpdateConsent":case"bySettingsUpdate":case"onSaveBtnClick":return"onUpdateServices"}},Ze=function(e){switch(e){case"update":case"implicit":default:return"implicit";case"explicit":return"explicit"}},et="RAMDOM_KEY_LOCAL_STORAGE",tt=function(){function e(){this.localStorage=null,this.sessionStorage=null,this.storeServiceIdToNameMapping=!1}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.localStorage=null,e.instance.sessionStorage=null},e.prototype.init=function(){try{localStorage.setItem(et,et),localStorage.removeItem(et),this.localStorage=localStorage}catch(e){this.localStorage=null}try{sessionStorage.setItem(et,et),sessionStorage.removeItem(et),this.sessionStorage=sessionStorage}catch(e){this.sessionStorage=null}},e.appendToConsentsBuffer=function(t){var n,i=e.fetchConsentsBuffer();i.push({consents:t,timestamp:(new Date).valueOf()}),null===(n=e.getInstance().localStorage)||void 0===n||n.setItem(Re.CONSENTS_BUFFER,JSON.stringify(i))},e.clearOnNewSettingsId=function(t){t!==e.fetchSettingsId()&&e.clear()},e.removeConsentsBufferItem=function(t){var n,i,s=e.fetchConsentsBuffer(),o=s.length+0;(s=s.filter((function(e){return JSON.stringify(e)!==JSON.stringify(t)}))).length&&s.length!==o?null===(n=e.getInstance().localStorage)||void 0===n||n.setItem(Re.CONSENTS_BUFFER,JSON.stringify(s)):null===(i=e.getInstance().localStorage)||void 0===i||i.removeItem(Re.CONSENTS_BUFFER)},e.getCcpaString=function(){var t,n=null===(t=e.getInstance().localStorage)||void 0===t?void 0:t.getItem(Re.CCPA);return n&&je.test(n)?n:"1---"},e.getCcpaData=function(){var t,n=null===(t=e.getInstance().localStorage)||void 0===t?void 0:t.getItem(Re.CCPA_DATA);return n?JSON.parse(n):null},e.fetchConsentsBuffer=function(){var t,n=null===(t=e.getInstance().localStorage)||void 0===t?void 0:t.getItem(Re.CONSENTS_BUFFER);return n?JSON.parse(n):[]},e.fetchControllerId=function(){var t=e.fetchSettings();return t?t.controllerId:""},e.fetchLanguage=function(){var t=e.fetchSettings();return t?t.language:""},e.fetchServices=function(){var t=e.fetchSettings();return t?t.services:[]},e.fetchLegacySettings=function(){var t,n=null===(t=e.getInstance().localStorage)||void 0===t?void 0:t.getItem(Re.LEGACY_SETTINGS);return n?JSON.parse(n):null},e.fetchSettings=function(){var t,n=null===(t=e.getInstance().localStorage)||void 0===t?void 0:t.getItem(Re.SETTINGS);return n?JSON.parse(n):{}},e.fetchSettingsId=function(){var t=e.fetchSettings();return t?t.id:""},e.fetchSettingsVersion=function(){var t=e.fetchSettings();return t?t.version:""},e.fetchTCFData=function(){var t,n=null===(t=e.getInstance().localStorage)||void 0===t?void 0:t.getItem(Re.TCF),i=n?JSON.parse(n):{tcString:"",timestamp:Date.now(),vendors:[]};return i.vendors||(i.vendors=[]),i},e.fetchTCFVendorsDisclosedObject=function(t){var n,i=e.fetchTCFData(),s=i.tcString,o=i.vendors,r=i.vendorsDisclosed;if(!o&&!r)return{};if((r||!r&&!o.length&&s)&&t){var a=Object.keys(t).map(Number);n=(r||a).filter((function(e){return t[e]})).map((function(e){var n=t[e];return[n.id,n.legIntPurposes,n.purposes,n.specialPurposes]})),e.saveTCFData({tcString:s,timestamp:Date.now(),vendors:n})}else n=o;return n.reduce((function(e,t){var n;return y(y({},e),((n={})[t[We.ID]]=!0,n))}),{})},e.fetchTCString=function(){return e.fetchTCFData().tcString||""},e.fetchUserActionPerformed=function(){var t;return null!==(null===(t=e.getInstance().localStorage)||void 0===t?void 0:t.getItem(Re.USER_INTERACTION))},e.fetchUserCountryResponse=function(){var t;try{return JSON.parse((null===(t=e.getInstance().sessionStorage)||void 0===t?void 0:t.getItem(Pe.USER_COUNTRY))||"null")}catch(e){return null}},e.setUserCountryResponse=function(t){var n;null===(n=e.getInstance().sessionStorage)||void 0===n||n.setItem(Pe.USER_COUNTRY,JSON.stringify(t))},e.mapServices=function(e){return e.map((function(e){return{history:e.consent.history,id:e.id,processorId:e.processorId,status:e.consent.status}}))},e.mapSettings=function(t,n){return{controllerId:t.controllerId,id:t.id,language:t.selectedLanguage,services:e.mapServices(n),version:t.version}},e.migrateLegacySettings=function(t){if(!e.settingsExist()){var n,i,s=e.fetchLegacySettings();if(e.clearLegacySettings(),null==s?void 0:s[t]){var o=(n=s[t])&&N(n.ucConsents.consents)?((i={})[Re.SETTINGS]={controllerId:n.ucConsents.consents[0].controllerId,id:n.usercentrics.settings.settingsId,language:n.usercentrics.settings.language,services:n.ucConsents.consents.map((function(e){return{history:e.history.map((function(e){return{action:Xe(e.action),language:e.language,status:e.consentStatus,timestamp:e.updatedAt,type:Ze(e.updatedBy),versions:{application:e.appVersion,service:e.consentTemplateVersion,settings:e.settingsVersion}}})),id:e.templateId,processorId:e.processorId,status:e.consentStatus}})),version:n.usercentrics.settings.version},i[Re.USER_INTERACTION]=n.usercentrics.firstUserInteraction.stateSaved,i):null;o&&(e.saveSettings(o[Re.SETTINGS]),o[Re.USER_INTERACTION]&&e.setUserActionPerformed())}}},e.saveSettings=function(t,n){var i,s;if(null===(i=e.getInstance().localStorage)||void 0===i||i.setItem(Re.SETTINGS,JSON.stringify(t)),e.prototype.storeServiceIdToNameMapping&&n&&n.length){var o=n.reduce((function(e,t){return e[t.id]=t.name,e}),{});null===(s=e.getInstance().localStorage)||void 0===s||s.setItem(Re.SERVICES,JSON.stringify(o))}Ye.isCrossDomainAvailable()&&Ye.setCrossDomainData(t).catch((function(){console.warn(Fe.CROSS_DOMAIN_SET_DATA_FAILURE)}))},e.saveTCFData=function(t){var n;null===(n=e.getInstance().localStorage)||void 0===n||n.setItem(Re.TCF,JSON.stringify(t)),Ye.isCrossDomainAvailable()&&Ye.setCrossDomainTcfData(t).catch((function(){console.warn(Fe.CROSS_DOMAIN_SET_TCF_DATA_FAILURE)}))},e.saveTCString=function(t){var n=e.fetchTCFData();this.saveTCFData(y(y({},n),{tcString:t}))},e.setCcpaTimeStamp=function(t){var n,i=t||{ccpaString:this.getCcpaString()||"",timestamp:(new Date).getTime()};null===(n=e.getInstance().localStorage)||void 0===n||n.setItem(Re.CCPA_DATA,JSON.stringify(i))},e.getCcpaTimeStamp=function(){var e=this.getCcpaData();return e&&e.timestamp?e.timestamp:(new Date).getTime()},e.setCcpaString=function(t){var n;null===(n=e.getInstance().localStorage)||void 0===n||n.setItem(Re.CCPA,t)},e.settingsExist=function(){return L(e.fetchSettings())},e.setUserActionPerformed=function(){var t;null===(t=e.getInstance().localStorage)||void 0===t||t.setItem(Re.USER_INTERACTION,JSON.stringify(!0))},e.clearCcpa=function(){var t;this.clearCcpaData(),null===(t=e.getInstance().localStorage)||void 0===t||t.removeItem(Re.CCPA)},e.clearCcpaData=function(){var t;null===(t=e.getInstance().localStorage)||void 0===t||t.removeItem(Re.CCPA_DATA)},e.clearTcf=function(){var t;null===(t=e.getInstance().localStorage)||void 0===t||t.removeItem(Re.TCF)},e.clear=function(){var t,n;e.clearCcpa(),e.clearTcf(),null===(t=e.getInstance().localStorage)||void 0===t||t.removeItem(Re.SETTINGS),null===(n=e.getInstance().localStorage)||void 0===n||n.removeItem(Re.USER_INTERACTION)},e.clearAll=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return this.clear(),Ye.isCrossDomainAvailable()?[4,Ye.clearCrossDomainStorage()]:[3,2];case 1:e.sent(),e.label=2;case 2:return[2]}}))}))},e.clearLegacySettings=function(){var t;null===(t=e.getInstance().localStorage)||void 0===t||t.removeItem(Re.LEGACY_SETTINGS)},e}(),nt="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:void 0!==n.g?n.g:"undefined"!=typeof self?self:{},it={exports:{}};it.exports=(Qe=Qe||function(e,t){var i;if("undefined"!=typeof window&&window.crypto&&(i=window.crypto),"undefined"!=typeof self&&self.crypto&&(i=self.crypto),"undefined"!=typeof globalThis&&globalThis.crypto&&(i=globalThis.crypto),!i&&"undefined"!=typeof window&&window.msCrypto&&(i=window.msCrypto),!i&&void 0!==nt&&nt.crypto&&(i=nt.crypto),!i)try{i=n(641)}catch(e){}var s=function(){if(i){if("function"==typeof i.getRandomValues)try{return i.getRandomValues(new Uint32Array(1))[0]}catch(e){}if("function"==typeof i.randomBytes)try{return i.randomBytes(4).readInt32LE()}catch(e){}}throw new Error("Native crypto module could not be used to get secure random number.")},o=Object.create||function(){function e(){}return function(t){var n;return e.prototype=t,n=new e,e.prototype=null,n}}(),r={},a=r.lib={},c=a.Base={extend:function(e){var t=o(this);return e&&t.mixIn(e),t.hasOwnProperty("init")&&this.init!==t.init||(t.init=function(){t.$super.init.apply(this,arguments)}),t.init.prototype=t,t.$super=this,t},create:function(){var e=this.extend();return e.init.apply(e,arguments),e},init:function(){},mixIn:function(e){for(var t in e)e.hasOwnProperty(t)&&(this[t]=e[t]);e.hasOwnProperty("toString")&&(this.toString=e.toString)},clone:function(){return this.init.prototype.extend(this)}},l=a.WordArray=c.extend({init:function(e,t){e=this.words=e||[],this.sigBytes=null!=t?t:4*e.length},toString:function(e){return(e||u).stringify(this)},concat:function(e){var t=this.words,n=e.words,i=this.sigBytes,s=e.sigBytes;if(this.clamp(),i%4)for(var o=0;o<s;o++){var r=n[o>>>2]>>>24-o%4*8&255;t[i+o>>>2]|=r<<24-(i+o)%4*8}else for(var a=0;a<s;a+=4)t[i+a>>>2]=n[a>>>2];return this.sigBytes+=s,this},clamp:function(){var t=this.words,n=this.sigBytes;t[n>>>2]&=4294967295<<32-n%4*8,t.length=e.ceil(n/4)},clone:function(){var e=c.clone.call(this);return e.words=this.words.slice(0),e},random:function(e){for(var t=[],n=0;n<e;n+=4)t.push(s());return new l.init(t,e)}}),d=r.enc={},u=d.Hex={stringify:function(e){for(var t=e.words,n=e.sigBytes,i=[],s=0;s<n;s++){var o=t[s>>>2]>>>24-s%4*8&255;i.push((o>>>4).toString(16)),i.push((15&o).toString(16))}return i.join("")},parse:function(e){for(var t=e.length,n=[],i=0;i<t;i+=2)n[i>>>3]|=parseInt(e.substr(i,2),16)<<24-i%8*4;return new l.init(n,t/2)}},h=d.Latin1={stringify:function(e){for(var t=e.words,n=e.sigBytes,i=[],s=0;s<n;s++){var o=t[s>>>2]>>>24-s%4*8&255;i.push(String.fromCharCode(o))}return i.join("")},parse:function(e){for(var t=e.length,n=[],i=0;i<t;i++)n[i>>>2]|=(255&e.charCodeAt(i))<<24-i%4*8;return new l.init(n,t)}},p=d.Utf8={stringify:function(e){try{return decodeURIComponent(escape(h.stringify(e)))}catch(e){throw new Error("Malformed UTF-8 data")}},parse:function(e){return h.parse(unescape(encodeURIComponent(e)))}},f=a.BufferedBlockAlgorithm=c.extend({reset:function(){this._data=new l.init,this._nDataBytes=0},_append:function(e){"string"==typeof e&&(e=p.parse(e)),this._data.concat(e),this._nDataBytes+=e.sigBytes},_process:function(t){var n,i=this._data,s=i.words,o=i.sigBytes,r=this.blockSize,a=o/(4*r),c=(a=t?e.ceil(a):e.max((0|a)-this._minBufferSize,0))*r,d=e.min(4*c,o);if(c){for(var u=0;u<c;u+=r)this._doProcessBlock(s,u);n=s.splice(0,c),i.sigBytes-=d}return new l.init(n,d)},clone:function(){var e=c.clone.call(this);return e._data=this._data.clone(),e},_minBufferSize:0});a.Hasher=f.extend({cfg:c.extend(),init:function(e){this.cfg=this.cfg.extend(e),this.reset()},reset:function(){f.reset.call(this),this._doReset()},update:function(e){return this._append(e),this._process(),this},finalize:function(e){return e&&this._append(e),this._doFinalize()},blockSize:16,_createHelper:function(e){return function(t,n){return new e.init(n).finalize(t)}},_createHmacHelper:function(e){return function(t,n){return new g.HMAC.init(e,n).finalize(t)}}});var g=r.algo={};return r}(Math),Qe);var st,ot={exports:{}}.exports=function(e){return function(t){var n=e,i=n.lib,s=i.WordArray,o=i.Hasher,r=n.algo,a=[],c=[];!function(){function e(e){for(var n=t.sqrt(e),i=2;i<=n;i++)if(!(e%i))return!1;return!0}function n(e){return 4294967296*(e-(0|e))|0}for(var i=2,s=0;s<64;)e(i)&&(s<8&&(a[s]=n(t.pow(i,.5))),c[s]=n(t.pow(i,1/3)),s++),i++}();var l=[],d=r.SHA256=o.extend({_doReset:function(){this._hash=new s.init(a.slice(0))},_doProcessBlock:function(e,t){for(var n=this._hash.words,i=n[0],s=n[1],o=n[2],r=n[3],a=n[4],d=n[5],u=n[6],h=n[7],p=0;p<64;p++){if(p<16)l[p]=0|e[t+p];else{var f=l[p-15],g=(f<<25|f>>>7)^(f<<14|f>>>18)^f>>>3,v=l[p-2],_=(v<<15|v>>>17)^(v<<13|v>>>19)^v>>>10;l[p]=g+l[p-7]+_+l[p-16]}var b=i&s^i&o^s&o,m=(i<<30|i>>>2)^(i<<19|i>>>13)^(i<<10|i>>>22),y=h+((a<<26|a>>>6)^(a<<21|a>>>11)^(a<<7|a>>>25))+(a&d^~a&u)+c[p]+l[p];h=u,u=d,d=a,a=r+y|0,r=o,o=s,s=i,i=y+(m+b)|0}n[0]=n[0]+i|0,n[1]=n[1]+s|0,n[2]=n[2]+o|0,n[3]=n[3]+r|0,n[4]=n[4]+a|0,n[5]=n[5]+d|0,n[6]=n[6]+u|0,n[7]=n[7]+h|0},_doFinalize:function(){var e=this._data,n=e.words,i=8*this._nDataBytes,s=8*e.sigBytes;return n[s>>>5]|=128<<24-s%32,n[14+(s+64>>>9<<4)]=t.floor(i/4294967296),n[15+(s+64>>>9<<4)]=i,e.sigBytes=4*n.length,this._process(),this._hash},clone:function(){var e=o.clone.call(this);return e._hash=this._hash.clone(),e}});n.SHA256=o._createHelper(d),n.HmacSHA256=o._createHmacHelper(d)}(Math),e.SHA256}(it.exports),rt=new Uint8Array(16);function at(){if(!st&&!(st="undefined"!=typeof crypto&&crypto.getRandomValues&&crypto.getRandomValues.bind(crypto)||"undefined"!=typeof msCrypto&&"function"==typeof msCrypto.getRandomValues&&msCrypto.getRandomValues.bind(msCrypto)))throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");return st(rt)}var ct=/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;function lt(e){return"string"==typeof e&&ct.test(e)}for(var dt=[],ut=0;ut<256;++ut)dt.push((ut+256).toString(16).substr(1));function ht(e,t,n){var i=(e=e||{}).random||(e.rng||at)();if(i[6]=15&i[6]|64,i[8]=63&i[8]|128,t){n=n||0;for(var s=0;s<16;++s)t[n+s]=i[s];return t}return function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0,n=(dt[e[t+0]]+dt[e[t+1]]+dt[e[t+2]]+dt[e[t+3]]+"-"+dt[e[t+4]]+dt[e[t+5]]+"-"+dt[e[t+6]]+dt[e[t+7]]+"-"+dt[e[t+8]]+dt[e[t+9]]+"-"+dt[e[t+10]]+dt[e[t+11]]+dt[e[t+12]]+dt[e[t+13]]+dt[e[t+14]]+dt[e[t+15]]).toLowerCase();if(!lt(n))throw TypeError("Stringified UUID is invalid");return n}(i)}var pt,ft=function(){function e(){this.needsSessionRestore=!1,this.controllerId=""}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.controllerId=""},Object.defineProperty(e.prototype,"value",{get:function(){return this.controllerId},set:function(e){this.controllerId=e},enumerable:!1,configurable:!0}),e.prototype.init=function(){if(""===this.controllerId){var e=this.getStorageControllerId();this.controllerId=e||this.generateControllerId(),this.needsSessionRestore=!1}else this.needsSessionRestore=!0},e.prototype.generateControllerId=function(){return"".concat(ot(ht()))},e.prototype.getStorageControllerId=function(){return tt.fetchControllerId()},e}(),gt=function(e,t){return{id:e,version:t}},vt=function(e){if(!e)return[];var t,n,i=e.reduce((function(e,t){return E(E([],w(e),!1),[gt(t.templateId,t.version)],!1)}),[]);return function(e,t){return e.sort((function(e,t){return e.id>t.id?1:-1}))}((t=function(e,t){return e.id===t.id&&e.version===t.version},n=[],i.forEach((function(e){-1===n.findIndex((function(n){return t(e,n)}))&&n.push(e)})),n))},_t=function(){function e(){this.API=Te,this.abTestVariant="",this.controllerIdInstance=ft.getInstance(),this.fetchUserCountryPromise=null,this.jsonCacheBustingString="",this.jsonFileLanguage="",this.jsonFileVersion="latest",this.settingsId="",this.rulesetId="",this.useEuCdn=!1,this.disableServerConsents=!1,this.aggregatedServicesCache=null,this.translationsCache=null}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.jsonCacheBustingString="",e.instance.jsonFileLanguage="",e.instance.jsonFileVersion="latest",e.instance.settingsId="",e.instance.disableServerConsents=!1},e.prototype.resetAggregatedServicesCache=function(){this.aggregatedServicesCache=null},e.prototype.resetTranslationsCache=function(){this.translationsCache=null},e.prototype.getAbTestVariant=function(){return this.abTestVariant},e.prototype.getJsonFileLanguage=function(){return this.jsonFileLanguage},e.prototype.getJsonFileVersion=function(){return this.jsonFileVersion},e.prototype.getSettingsId=function(){return this.settingsId},e.prototype.getRulesetId=function(){return this.rulesetId},e.prototype.getDisableServerConsents=function(){return this.disableServerConsents},e.prototype.setJsonCacheBustingString=function(e){this.jsonCacheBustingString=e},e.prototype.setJsonFileLanguage=function(e){this.jsonFileLanguage=e},e.prototype.setJsonFileVersion=function(e){this.jsonFileVersion=e},e.prototype.setDisableServerConsents=function(e){this.disableServerConsents=e},e.prototype.setDomains=function(e,t){this.API=e?Ie:t?{EU_URI:{AGGREGATOR:Te.EU_URI.AGGREGATOR,CDN:Te.EU_URI.CDN,FETCH_CONSENTS:Te.EU_URI.FETCH_CONSENTS,FETCH_TCF_DATA:Te.EU_URI.FETCH_TCF_DATA,FETCH_TCF_DATA_V2:Te.EU_URI.FETCH_TCF_DATA_V2,GRAPHQL:Te.EU_URI.GRAPHQL,TRACK_EVENT:Te.EU_URI.TRACK_EVENT},FOLDER:{RULESET:"configMap",SETTINGS:"settings",TEMPLATES:"consent-templates",TRANSLATIONS:"translations"},URI:y(y({AGGREGATOR:""!==t.aggregator?"".concat(t.aggregator,"/aggregate/"):Te.URI.AGGREGATOR,CDN:""!==t.cdn?t.cdn:Te.URI.CDN,RULESET:Te.URI.RULESET},""!==t.consents?{FETCH_CONSENTS:"".concat(t.consents,"/consentsHistory"),FETCH_TCF_DATA:"".concat(t.consents,"/consentsHistoryTCF"),FETCH_TCF_DATA_V2:"".concat(t.consents,"/consentState")}:{FETCH_CONSENTS:Te.URI.FETCH_CONSENTS,FETCH_TCF_DATA:Te.URI.FETCH_TCF_DATA,FETCH_TCF_DATA_V2:Te.URI.FETCH_TCF_DATA_V2}),{GRAPHQL:""!==t.graphql?"".concat(t.graphql,"/graphql"):Te.URI.GRAPHQL,TRACK_EVENT:""!==t.trackingEvent?"".concat(t.trackingEvent,"/uct"):Te.URI.TRACK_EVENT})}:Te},e.prototype.setSettingsId=function(e){this.settingsId=e},e.prototype.setRulesetId=function(e){this.rulesetId=e},e.prototype.setEuMode=function(e){this.useEuCdn=e},e.prototype.isEuMode=function(){return this.useEuCdn},e.prototype.getAggregatorUri=function(){return this.isEuMode()?this.API.EU_URI.AGGREGATOR:this.API.URI.AGGREGATOR},e.prototype.getCdnUri=function(){return this.isEuMode()?this.API.EU_URI.CDN:this.API.URI.CDN},e.prototype.getGraphQLUri=function(){return this.isEuMode()?this.API.EU_URI.GRAPHQL:this.API.URI.GRAPHQL},e.prototype.getTcfDataV2Uri=function(){return this.isEuMode()?this.API.EU_URI.FETCH_TCF_DATA_V2:this.API.URI.FETCH_TCF_DATA_V2},e.prototype.fetchAggregatedServices=function(e,t){return void 0===t&&(t=!0),S(this,void 0,void 0,(function(){var n,i;return C(this,(function(s){switch(s.label){case 0:return this.aggregatedServicesCache&&t?[2,this.aggregatedServicesCache]:(n="".concat(this.getAggregatorUri()).concat(this.jsonFileLanguage,"?templates=").concat(e.map((function(e){return"".concat(e.id,"@").concat(e.version)})).join(",")),[4,xe(n,V.GENERATE_DATA_PROCESSING_SERVICES)]);case 1:return i=s.sent(),t&&(this.aggregatedServicesCache=i.data.templates),[2,i.data.templates]}}))}))},e.prototype.fetchRuleset=function(){var e;return S(this,void 0,void 0,(function(){var t,n,i,s;return C(this,(function(o){switch(o.label){case 0:return o.trys.push([0,2,,3]),t=this.createRulesetUrl(),[4,xe(t,V.RULESET_NOT_FOUND)];case 1:return n=o.sent(),i=null===(e=n.location)||void 0===e?void 0:e.split(","),[2,{defaultRule:n.data.defaultRule,location:{code:i?i[0]:"",name:n.location||"",regionCode:i&&i[1]?i[1]:""},rules:n.data.rules}];case 2:throw(s=o.sent()).statusCode&&s.statusCode===K.RESOURCE_NOT_FOUND&&(s.errorMessage=V.RULESET_NOT_FOUND),s;case 3:return[2]}}))}))},e.prototype.fetchAvailableLanguages=function(){return S(this,void 0,void 0,(function(){var e,t;return C(this,(function(n){switch(n.label){case 0:return n.trys.push([0,2,,3]),e=this.createAvailableLanguagesUrl(),[4,xe(e,V.FETCH_AVAILABLE_LANGUAGES)];case 1:return[2,n.sent().data.languagesAvailable];case 2:throw(t=n.sent()).statusCode&&t.statusCode===K.RESOURCE_NOT_FOUND&&(t.errorMessage=V.AVAILABLE_LANGUAGES_NOT_FOUND),t;case 3:return[2]}}))}))},e.prototype.fetchTranslations=function(){return S(this,void 0,void 0,(function(){var e,t,n;return C(this,(function(i){switch(i.label){case 0:if(this.translationsCache)return[2,this.translationsCache];i.label=1;case 1:return i.trys.push([1,3,,4]),e=this.createLanguagesUrl(),[4,xe(e,V.FETCH_LEGAL_BASIS)];case 2:return t=i.sent(),this.translationsCache=t.data,[2,t.data];case 3:return(n=i.sent()).statusCode&&n.statusCode===K.RESOURCE_NOT_FOUND&&(n.errorMessage=V.FETCH_LEGAL_BASIS),[2,null];case 4:return[2]}}))}))},e.prototype.fetchCoreJson=function(){return S(this,void 0,void 0,(function(){var e,t;return C(this,(function(n){switch(n.label){case 0:return n.trys.push([0,2,,3]),e=this.createCoreJsonUrl(),[4,xe(e,V.FETCH_SETTINGS,{removeTimeout:!0})];case 1:return[2,n.sent().data];case 2:throw(t=n.sent()).statusCode&&t.statusCode===K.RESOURCE_NOT_FOUND&&(t.errorMessage=V.SETTINGS_NOT_FOUND),t;case 3:return[2]}}))}))},e.prototype.fetchDpsJson=function(){return S(this,void 0,void 0,(function(){var e,t,n,i;return C(this,(function(s){switch(s.label){case 0:return s.trys.push([0,2,,3]),e=this.createDpsJsonUrl(),[4,xe(e,V.FETCH_SETTINGS,{removeTimeout:!0})];case 1:return t=s.sent(),n=function(e){return e.reduce((function(e,t){return t.isDeactivated||e.push(t),e}),[])}(t.data.consentTemplates),[2,y(y({},t.data),{consentTemplates:n})];case 2:throw(i=s.sent()).statusCode&&i.statusCode===K.RESOURCE_NOT_FOUND&&(i.errorMessage=V.SETTINGS_NOT_FOUND),i;case 3:return[2]}}))}))},e.prototype.fetchSettingsJson=function(){return S(this,void 0,void 0,(function(){var e,t,n,i,s,o;return C(this,(function(r){switch(r.label){case 0:return r.trys.push([0,7,,8]),e=this.createSettingsJsonUrl(),[4,xe(e,V.FETCH_SETTINGS)];case 1:if(t=r.sent(),["ccpa","firstLayer","secondLayer"].forEach((function(e){t.data[e]||(t.data[e]={})})),t.data.tcf2&&(t.data.tcf2.selectedVendorIds=(t.data.tcf2.selectedVendorIds||[]).sort((function(e,t){return e-t}))),!(t.data&&t.data.variants&&t.data.variants.enabled&&function(e,t){try{JSON.parse(e)}catch(t){return console.warn("Invalid JSON string from ".concat("A/B Testing",': "').concat(e,'"')),!1}return!0}(t.data.variants.experiments)))return[3,6];if(n=JSON.parse(t.data.variants.experiments),"UC"===t.data.variants.activateWith)return i=Object.keys(n),this.abTestVariant=i[Math.floor(Math.random()*i.length)],[2,W(n[this.abTestVariant],t.data)];r.label=2;case 2:return r.trys.push([2,4,,5]),[4,q((function(){return!!window.UC_AB_VARIANT}),"window.UC_AB_VARIANT is not defined",2e3)];case 3:return r.sent(),[3,5];case 4:return s=r.sent(),console.warn(s),[3,5];case 5:if(window.UC_AB_VARIANT&&n&&n[window.UC_AB_VARIANT])return this.abTestVariant=window.UC_AB_VARIANT,[2,W(n[window.UC_AB_VARIANT],t.data)];r.label=6;case 6:return[2,t.data];case 7:throw(o=r.sent()).statusCode&&o.statusCode===K.RESOURCE_NOT_FOUND&&(o.errorMessage=V.SETTINGS_NOT_FOUND),o;case 8:return[2]}}))}))},e.prototype.fetchUserConsents=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return this.getDisableServerConsents()?[3,2]:(e=this.createFetchUserConsentsUrl(),[4,xe(e,V.FETCH_USER_CONSENTS)]);case 1:return[2,t.sent().data.reverse()];case 2:return[2,[]]}}))}))},e.prototype.fetchUserCountry=function(){return S(this,void 0,void 0,(function(){var e,t,n,i,s;return C(this,(function(o){return(e=tt.fetchUserCountryResponse())?[2,Promise.resolve(e)]:(this.fetchUserCountryPromise||(t=bt(),n=mt(),i=Ne(this.getGraphQLUri(),t,V.FETCH_USER_COUNTRY,n).then((function(e){return e.data.clientLocation})),s=new Promise((function(e){setTimeout(e,3e3,Ae)})),this.fetchUserCountryPromise=function(e){return P((t=e.map(P),new Promise((function(e,n){var i=t.length,s=[],o=function(){0==(i-=1)&&e(s)};t.forEach((function(e,t){e.then((function(e){s[t]=e}),n).then(o)}))}))));var t}([i,s]).then((function(e){return tt.setUserCountryResponse(e),e})).catch((function(){return tt.setUserCountryResponse(Ae),Ae}))),[2,this.fetchUserCountryPromise])}))}))},e.prototype.fetchUserTcfData=function(){return S(this,void 0,void 0,(function(){var e,t,n,i,s;return C(this,(function(o){switch(o.label){case 0:return this.getDisableServerConsents()?[3,2]:(e=this.createFetchUserTcfDataUrl(),[4,xe(e,V.FETCH_USER_TCF_DATA)]);case 1:return t=o.sent(),n=t.data,i=n.tcString,s=n.meta,[2,y({tcString:i},JSON.parse(s)||{})];case 2:return[2,null]}}))}))},e.prototype.fetchUserTcfDataV2=function(){return S(this,void 0,void 0,(function(){var e,t,n,i,s;return C(this,(function(o){switch(o.label){case 0:return e=this.createFetchUserTcfDataV2Url(),[4,xe(e,V.FETCH_USER_TCF_DATA)];case 1:if((t=o.sent()).data&&t.data.tcf2)return n=t.data.tcf2,i=n.tcString,s=n.meta,[2,y({tcString:i},JSON.parse(s)||{})];throw new Error(V.FETCH_USER_TCF_DATA)}}))}))},e.prototype.saveTCFConsents=function(e,t,n,i){return S(this,void 0,void 0,(function(){var s,o,r,a,c;return C(this,(function(l){return s={consent:{status:!0},id:"tcf2",name:"tcf2",processorId:"abcd",version:"1.0.0"},o=t.tcString,r=function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var s=0;for(i=Object.getOwnPropertySymbols(e);s<i.length;s++)t.indexOf(i[s])<0&&Object.prototype.propertyIsEnumerable.call(e,i[s])&&(n[i[s]]=e[i[s]])}return n}(t,["tcString"]),a=O(e,s,n,i),c={consentMeta:{TCF2:JSON.stringify(r)},consentString:{TCF2:o},dataTransferObjects:[a]},[2,this.saveConsents(c)]}))}))},e.prototype.saveConsents=function(e){return S(this,void 0,void 0,(function(){var t,n;return C(this,(function(i){switch(i.label){case 0:if(this.getDisableServerConsents())return[3,4];t=mt(),n=yt(e),i.label=1;case 1:return i.trys.push([1,3,,4]),[4,Ne(this.getGraphQLUri(),n,V.SAVE_CONSENTS,t)];case 2:return i.sent(),[3,4];case 3:return i.sent(),tt.appendToConsentsBuffer(e),[3,4];case 4:return[2]}}))}))},e.prototype.saveConsentsV2=function(e){return S(this,void 0,void 0,(function(){var t,n,i;return C(this,(function(s){switch(s.label){case 0:t=this.createSaveConsentsV2Url(),n=e,i={credentials:"omit",headers:{Accept:"application/json","Access-Control-Allow-Origin":"*","content-type":"application/json","X-Request-ID":ht()},mode:"cors"},s.label=1;case 1:return s.trys.push([1,3,,4]),[4,Ne(t,n,V.SAVE_CONSENTS,i)];case 2:case 3:return s.sent(),[3,4];case 4:return[2]}}))}))},e.prototype.saveConsentsFromBuffer=function(){var e=this;if(!this.getDisableServerConsents()){var t=tt.fetchConsentsBuffer();Array.isArray(t)&&t.length&&t.forEach((function(t,n){var i=3e3+1e3*n;setTimeout((function(){return S(e,void 0,void 0,(function(){var e,n,i;return C(this,(function(s){switch(s.label){case 0:e=mt(),n=yt(t.consents),s.label=1;case 1:return s.trys.push([1,3,,4]),[4,Ne(this.getGraphQLUri(),n,V.SAVE_CONSENTS,e)];case 2:return s.sent(),tt.removeConsentsBufferItem(t),[3,4];case 3:return i=s.sent(),console.warn(i),[3,4];case 4:return[2]}}))}))}),i>0?i:0)}))}},e.prototype.setTrackingPixel=function(e,t){var n=(new Date).getTime(),i=encodeURIComponent(document.location.href),s="".concat(this.isEuMode()?this.API.EU_URI.TRACK_EVENT:this.API.URI.TRACK_EVENT,"?v=").concat(1,"&cid=").concat(t,"&sid=").concat(this.settingsId,"&t=").concat(e.eventType,"&abv=").concat(e.abTestVariant,"&r=").concat(i,"&cb=").concat(n);(new Image).src=s},e.prototype.updateTagLoggerData=function(e){var t=this.settingsId,n=window.location.href,i=St({settingsId:t,source:n,targets:e});this.saveTagLoggerData(i)},e.prototype.addJsonCacheBustingString=function(e){return this.jsonCacheBustingString?"".concat(e,"?c=").concat(this.jsonCacheBustingString):e},e.prototype.createAvailableLanguagesUrl=function(){return this.addJsonCacheBustingString("".concat(this.getCdnUri(),"/").concat(this.API.FOLDER.SETTINGS,"/").concat(this.settingsId,"/").concat(this.jsonFileVersion,"/languages.json"))},e.prototype.createLanguagesUrl=function(){return this.addJsonCacheBustingString("".concat(this.getCdnUri(),"/").concat(this.API.FOLDER.TRANSLATIONS,"/translations-").concat(this.jsonFileLanguage,".json"))},e.prototype.getSettingsUrl=function(){return"".concat(this.getCdnUri(),"/").concat(this.API.FOLDER.SETTINGS,"/").concat(this.settingsId,"/").concat(this.jsonFileVersion)},e.prototype.createCoreJsonUrl=function(){return this.addJsonCacheBustingString("".concat(this.getSettingsUrl(),"/core.json"))},e.prototype.createDpsJsonUrl=function(){return this.addJsonCacheBustingString("".concat(this.getSettingsUrl(),"/dps-").concat(this.jsonFileLanguage,".json"))},e.prototype.createSettingsJsonUrl=function(){return this.addJsonCacheBustingString("".concat(this.getSettingsUrl(),"/").concat(this.jsonFileLanguage,".json"))},e.prototype.createFetchUserConsentsUrl=function(){return"".concat(this.isEuMode()?this.API.EU_URI.FETCH_CONSENTS:this.API.URI.FETCH_CONSENTS,"?controllerId=").concat(this.controllerIdInstance.value)},e.prototype.createFetchUserTcfDataUrl=function(){return"".concat(this.API.URI.FETCH_TCF_DATA,"?controllerId=").concat(this.controllerIdInstance.value)},e.prototype.createFetchUserTcfDataV2Url=function(){return"".concat(this.getTcfDataV2Uri(),"?controllerId=").concat(this.controllerIdInstance.value,"&tcf2=true&settingsId=").concat(this.settingsId)},e.prototype.createRulesetUrl=function(){return"".concat(this.API.URI.RULESET,"/").concat(this.API.FOLDER.RULESET,"/").concat(this.rulesetId,".json")},e.prototype.createSaveConsentsV2Url=function(){return"".concat(this.API.URI.SAVE_CONSENTS_V2,"/uw/").concat(1)},e.prototype.saveTagLoggerData=function(e){Ne(this.getGraphQLUri(),e,"",mt())},e}(),bt=function(){return{query:"{ clientLocation { countryCode countryName regionCode } }"}},mt=function(){return{credentials:"omit",headers:{Accept:"application/json","Access-Control-Allow-Origin":"*","X-Request-ID":ht()},mode:"cors"}},yt=function(e){var t=e.dataTransferObjects,n=e.consentMeta,i=e.consentString;return{query:"mutation saveConsents($consents: [NewCreateConsentInput], $consentMeta: ConsentMeta, $consentString: ConsentString)\n      {\n        saveConsents(consents: $consents, consentMeta: $consentMeta, consentString: $consentString) { data { consentId } }\n      }",variables:{consentMeta:n,consents:Ct(t),consentString:i}}},St=function(e){return{operationName:"saveTagLoggerData",query:"mutation saveTagLoggerData($settingsId: String, $source: String, $targets: [String])\n        {\n          saveTagLoggerData(settingsId: $settingsId, source: $source, targets: $targets)\n        }",variables:{settingsId:e.settingsId,source:e.source,targets:e.targets}}},Ct=function(e){return e.map((function(e){return{action:e.consent.action,appVersion:e.applicationVersion,consentStatus:e.consent.status?"1":"0",consentTemplateId:e.service.id,consentTemplateVersion:e.service.version,controllerId:e.settings.controllerId,language:e.settings.language,processorId:e.service.processorId,referrerControllerId:e.settings.referrerControllerId,settingsId:e.settings.id,settingsVersion:e.settings.version,updatedBy:e.consent.type}}))};!function(e){e[e.NO=0]="NO",e[e.YES=1]="YES",e[e.NOT_SET=2]="NOT_SET"}(pt||(pt={}));var wt,Et=function(){function e(){this.isBotEnabled=!1,this.isBot=pt.NOT_SET}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.isBot=pt.NOT_SET},e.prototype.isRobot=function(){if(this.isBot===pt.NOT_SET)if(this.isBotEnabled){var e=window.navigator.userAgent,t=new RegExp("bingbot/|BingPreview/|DuckDuckBot/|Google Page Speed Insights|Google PP|Google Search Console|Google Web Preview|Googlebot/|Googlebot-Image/|Googlebot-Mobile/|Googlebot-News|Googlebot-Video/|Google-SearchByImage|Google-Structured-Data-Testing-Tool|Chrome-Lighthouse|YahooSeeker|YahooCacheSystem|Yahoo! Site Explorer Feed Validator|Yahoo! Slurp|Slurp/","i");this.isBot=t.test(e)?pt.YES:pt.NO}else this.isBot=pt.NO;return this.isBot===pt.YES},e}(),Tt=["B1Hk_zoTX","ByzZ5EsOsZX","dqFgQeZH","LykAT-gy","twMyStLkn","pxiRY9112","UekC8ye4S","DHS2sEi4b","S1_9Vsuj-Q","dyHOCwp5Y"],It=["HkocEodjb7","87JYasXPF"],At=function(){function e(){this.dataLayerNames=[],this.windowEventNames=[],this.dataLayer=new Map,this.blockDataLayerPush=!1}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.prototype.setBlockDataLayerPush=function(e){this.blockDataLayerPush=e},e.prototype.shouldBlockDataLayerPush=function(){return this.blockDataLayerPush},e.resetInstance=function(){e.instance.dataLayerNames=[],e.instance.windowEventNames=[],e.instance.dataLayer=new Map},e.prototype.init=function(e){var t=this;e.forEach((function(e){e.type===d.DATA_LAYER?t.dataLayerNames=k(e.names,[]):e.type===d.WINDOW_EVENT&&(t.windowEventNames=k(e.names,[]))}))},e.prototype.setDataLayer=function(e,t){this.dataLayer.set(t,e)},e.prototype.getDataLayer=function(){return this.dataLayer},e.prototype.dispatch=function(e,t,n){N(e)&&(this.pushEventsToDataLayer(e,t,n),this.dispatchWindowEvents(e,n))},e.prototype.isValidDataLayer=function(e){return window[e]&&(Array.isArray(window[e])||Object.prototype.hasOwnProperty.call(window[e],"push"))},e.prototype.pushEventsToDataLayer=function(e,t,n){var i=this;N(this.dataLayerNames)&&this.dataLayerNames.forEach((function(s){if(window[s]=k(window[s],[]),!i.isValidDataLayer(s))throw Error("DataLayer: ".concat(s," is not of a valid type!"));if(t&&"dataLayer"===s){var o=!1,r=!1,a=!1,c=!1,l=!1;Nt("set","developer_id.dOThhZD",!0),e.forEach((function(e){var t=e.service.id,n=e.consent,i=n.status,s=n.type,r=n.action;It.includes(t)&&("explicit"===s||"implicit"===s&&"onNonEURegion"===r)&&(o=i,l=!0),Tt.includes(t)&&("explicit"===s||"implicit"===s&&"onNonEURegion"===r)&&(c=!0,l=!0,i||(a=!0))})),(c&&!a||o)&&(r=!0),l&&Nt("consent","update",{ad_storage:r?"granted":"denied",analytics_storage:o?"granted":"denied"}),Nt("set","ads_data_redaction",!r)}window[s].push(xt(e,n)),i.setDataLayer(window[s],s),i.shouldBlockDataLayerPush()||"explicit"===e[0].consent.type&&e.forEach((function(e){e.consent.status||window[s].push({event:"".concat(e.service.name," EXPLICIT_DENY")})}))}))},e.prototype.dispatchWindowEvents=function(e,t){if(N(this.windowEventNames)){var n=xt(e,t);this.windowEventNames.forEach((function(e){var t=new window.CustomEvent(e,{detail:n});window.dispatchEvent(t)}))}},e}(),xt=function(e,t){var n={action:null!=t?t:e[0].consent.action,event:"consent_status",type:e[0].consent.type};return e.forEach((function(e){var t;n=y(y({},n),((t={})[e.service.name]=e.consent.status,t))})),n},Nt=function(){window.dataLayer.push(arguments)},Lt="en",kt="https://api.usercentrics.eu/tcf2/",Ot="https://config.eu.usercentrics.eu/tcf2/",Dt="[LANG].json",Rt="en-v2.json",Pt=864e5,Ut=1,Ft=365,Vt=["onEssentialChange","onInitialPageLoad","onNonEURegion","onSessionRestored"];!function(e){e.TEXT_JAVASCRIPT="text/javascript",e.TEXT_PLAIN="text/plain"}(wt||(wt={}));var Mt,Bt,$t,jt,Ht,Gt,zt=function(){function e(){}return e.enableScriptsForServicesWithConsent=function(t){var n=e.getDisabledScripts();Array.prototype.forEach.call(n,(function(n){e.disabledScriptHasConsent(t,n)&&e.enableScript(n)}))},e.getDisabledScripts=function(){return document.querySelectorAll("script[".concat("data-usercentrics",'][type="').concat(wt.TEXT_PLAIN,'"]'))},e.disabledScriptHasConsent=function(e,t){return e.some((function(e){return e.name===t.getAttribute("data-usercentrics")}))},e.enableScript=function(t){var n,i,s;i=t.src?e.createSrcScriptTag(t):e.createInlineScriptTag(t),(s=(n=t).parentNode)&&s.replaceChild(i,n)},e.createSrcScriptTag=function(t){var n=e.cloneScriptTag(t);return n.removeAttribute("data-usercentrics"),n.type=wt.TEXT_JAVASCRIPT,n},e.createInlineScriptTag=function(t){var n=e.cloneScriptTag(t);n.removeAttribute("data-usercentrics");var i=document.createTextNode(t.text);return n.appendChild(i),n.type=wt.TEXT_JAVASCRIPT,n},e.cloneScriptTag=function(e){var t=document.createElement("script");return Array.from(e.attributes).forEach((function(e){t.setAttribute(e.name,e.value)})),t},e}(),Wt=function(e,t,n){var i,s;this.anyDomain=e.anyDomain||"any domain (ex. first party cookie)",this.cookieRefresh=(null==t?void 0:t.COOKIE_REFRESH)||(null===(i=null==n?void 0:n.labels)||void 0===i?void 0:i.COOKIE_REFRESH)||"Cookie Refresh",this.cookieStorage=(null==t?void 0:t.COOKIE_STORAGE)||(null===(s=null==n?void 0:n.labels)||void 0===s?void 0:s.COOKIE_STORAGE)||"Cookie Storage",this.day=e.day,this.days=e.days,this.description=e.storageInformationDescription||"Below you can see the longest potential duration for storage on a device, as set when using the cookie method of storage and if there are any other methods used.",this.domain=e.domain||"Domain",this.duration=e.duration||"Duration",this.error=e.informationLoadingNotPossible||"Sorry; we could not load the required information.",this.hour=e.hour,this.hours=e.hours,this.identifier=e.identifier||"Identifier",this.loading=e.loadingStorageInformation||"Loading storage information",this.maximumAge=e.maximumAgeCookieStorage||"Maximum age of cookie storage",this.minute=e.minute,this.minutes=e.minutes,this.month=e.month,this.months=e.months,this.multipleDomains=e.multipleDomains||"multiple subdomains may exist",this.name=e.name||"Name",this.no=e.no||"no",this.nonCookieStorage=e.nonCookieStorage||"Non-cookie storage",this.purposes=e.purposes||"Purposes",this.second=e.second||"second",this.seconds=e.seconds||"seconds",this.session=e.session||"Session",this.storedInformation=e.storedInformation||"Stored Information",this.storedInformationDescription=e.storedInformationDescription||"This service uses different means of storing information on a user’s device as listed below.",this.title=e.storageInformation||"Storage Information",this.titleDetailed=e.detailedStorageInformation||"Detailed Storage Information",this.tryAgain=e.tryAgain||"Try again?",this.type=e.type||"Type",this.year=e.year,this.years=e.years,this.yes=e.yes||"yes"},qt=function(e,t){var n=e.defaultConsentStatus;return{history:[],status:!!(null==t?void 0:t.isEssential)||n}},Jt=function(e,t,n){var i;this.deviceStorage=null;var s=null==n?void 0:n.find((function(t){return e.templateId===t.templateId&&e.version===t.version})),o=(null==t?void 0:t.legalBasis)&&e.legalBasisList?e.legalBasisList.reduce((function(e,n){return(null==t?void 0:t.legalBasis[n])?E(E([],w(e),!1),[null==t?void 0:t.legalBasis[n]],!1):e}),[]):[];this.description=function(e,t){return e.description||(null==t?void 0:t.descriptionOfService)||(null==t?void 0:t.description)||""}(e,s),this.deviceStorage=k(null==s?void 0:s.deviceStorage,null),this.id=e.templateId,this.legalBasis=s&&!e.disableLegalBasis?function(e,t){var n=e.legalBasisList,i=e.legalGround;return t.length>0?t:function(e,t){return N(e)?e:[t]}(n,i)}(s,o):[],this.name=(null===(i=e._meta)||void 0===i?void 0:i.name)||(null==s?void 0:s.dataProcessor)||(null==s?void 0:s.dataProcessors[0])||""},Kt=function(e){function t(t,n,i,s){var o,r,a,c,l,d,u=e.call(this)||this,h=t.labels;return u.ariaLabels=(null==i?void 0:i.labelsAria)||be,u.categories=n.categories.map((function(e){return{description:e.description,label:e.label,slug:e.categorySlug}})),u.cookieInformation=new Wt(h,null,i),u.general={back:(null===(o=null==i?void 0:i.labels)||void 0===o?void 0:o.BACK)||"Back",consentGiven:h.accepted,consentNotGiven:h.denied,consentType:h.consentType,controllerId:(null===(r=null==i?void 0:i.labels)||void 0===r?void 0:r.CID_TITLE)||"Controller ID",copied:h.copied,copy:h.copy,date:h.date,decision:h.decision,details:(null===(a=null==i?void 0:i.labels)||void 0===a?void 0:a.DETAILS)||"Details",explicit:h.explicit,implicit:h.implicit,implicitNo:h.noImplicit,implicitYes:h.yesImplicit,privacyButton:h.btnChipName,showLess:h.readLess,showMore:h.btnBannerReadMore||h.showMore,subservice:(null===(c=null==i?void 0:i.labels)||void 0===c?void 0:c.SUB_SERVICE)||"Subservice",subservices:(null===(l=null==i?void 0:i.labels)||void 0===l?void 0:l.SUB_SERVICES)||"Subservices",subservicesDescription:(null===(d=null==i?void 0:i.labels)||void 0===d?void 0:d.SUB_SERVICES_DESCRIPTION)||"Below you can find all the services that are subordinate to this service. The current consent status of this service applies to all subservices."},u.links={cookiePolicy:{ariaLabel:be.cookiePolicyButton,label:k(h.cookiePolicyLinkText,""),url:t.cookiePolicyUrl},imprint:{ariaLabel:be.imprintButton,label:h.imprintLinkText||null,url:t.imprintUrl},privacyPolicy:{ariaLabel:be.privacyPolicyButton,label:h.privacyPolicyLinkText,url:t.privacyPolicyUrl}},u.poweredBy={label:"Powered by",partnerUrlLabel:k(h.partnerPoweredByLinkText,null),urlLabel:"Usercentrics Consent Management"},u.service={dataCollected:{description:h.dataCollectedInfo,title:h.dataCollectedList},dataDistribution:{processingLocationDescription:h.locationofProcessingInfo,processingLocationTitle:h.locationOfProcessing,thirdPartyCountriesDescription:h.transferToThirdCountriesInfo,thirdPartyCountriesTitle:h.transferToThirdCountries},dataProtectionOfficer:{description:h.dataProtectionOfficerInfo,title:h.dataProtectionOfficer},dataPurposes:{description:h.dataPurposesInfo,title:h.dataPurposes},dataRecipients:{description:h.dataRecipientsListInfo,title:h.dataRecipientsList},descriptionTitle:h.descriptionOfService,history:{description:null,title:h.history},legalBasis:{description:h.legalBasisInfo,title:h.legalBasisList},processingCompanyTitle:h.processingCompany,retentionPeriod:{description:h.retentionPeriodInfo,title:h.retentionPeriod},technologiesUsed:{description:h.technologiesUsedInfo,title:h.technologiesUsed},urls:{cookiePolicyTitle:h.cookiePolicyInfo,optOutTitle:h.optOut,privacyPolicyTitle:h.policyOf}},u.services=n.consentTemplates.reduce((function(e,t){var n=new Jt(t,i,s);return E(E([],w(e),!1),[n],!1)}),[]),u}return o(t,e),t}((function(){this.ariaLabels=be})),Yt=function(e){function t(t,n,i,s){var o=e.call(this,t,n,i,s)||this;return o.buttons={optOutNotice:t.ccpa.optOutNoticeLabel||"Do not sell my personal information",save:t.ccpa.btnSave||"okay",showSecondLayer:t.labels.btnMore},o.firstLayer={description:{default:t.ccpa.firstLayerDescription||"",short:t.ccpa.firstLayerMobileDescription||"",shortDesktop:t.ccpa.firstLayerShortMessage||"",shortMobile:t.ccpa.firstLayerMobileDescription||""},title:t.ccpa.firstLayerTitle||""},o.secondLayer={categoryTab:t.secondLayer.tabsCategoriesLabel,description:t.ccpa.secondLayerDescription||"",serviceTab:t.secondLayer.tabsServicesLabel,title:t.ccpa.secondLayerTitle||""},o}return o(t,e),t}(Kt),Qt=function(e,t){var n;this.acceptAllImplicitlyOutsideEU=e.displayOnlyForEU,this.consentAPIv2=k(e.consentAPIv2,!1),this.consentSharingIFrameIsActive=e.consentSharingIFrameIsActive,this.dataExchangeSettings=e.dataExchangeOnPage.reduce((function(e,t){return t.type===$.DATA_LAYER?e.push({names:t.names,type:d.DATA_LAYER}):t.type===$.WINDOW_EVENT&&e.push({names:t.names,type:d.WINDOW_EVENT}),e}),[]),this.googleConsentMode=e.googleConsentMode,this.id=e.settingsId,this.isCcpaEnabled=(null===(n=e.ccpa)||void 0===n?void 0:n.isActive)||!1,this.isEmbeddingsEnabled=!0,this.isTagLoggerActive=e.tagLoggerIsActive,this.isTcfEnabled=e.tcf2Enabled||!1,this.language={available:e.languagesAvailable,selected:t},this.reshowBanner=k(e.reshowBanner,-1),this.showFirstLayerOnVersionChange=e.showInitialViewForVersionChange.map((function(e){switch(e){case H.MAJOR:return u.MAJOR;case H.MINOR:return u.MINOR;default:case H.PATCH:return u.PATCH}})),this.version=e.version},Xt=function(e){function t(t,n,i,s){var o,r=e.call(this,t,n,i,s)||this;return r.buttons={acceptAll:t.labels.btnAcceptAll,cnilDeny:(null===(o=null==i?void 0:i.labels)||void 0===o?void 0:o.CNIL_DENY_LINK_TEXT)||"Continuer sans accepter",denyAll:t.labels.btnDeny,save:t.labels.btnSave,showSecondLayer:t.labels.btnMore},r.firstLayer={description:{default:t.bannerMessage||"",short:t.bannerMobileDescription||"",shortDesktop:t.firstLayer.shortMessage||"",shortMobile:t.bannerMobileDescription||""},title:k(t.labels.firstLayerTitle,"Privacy Settings")},r.secondLayer={acceptButtonLabel:t.secondLayer.acceptButtonText,categoryTab:t.secondLayer.tabsCategoriesLabel,denyButtonLabel:t.secondLayer.denyButtonText,description:t.labels.titleCorner,serviceTab:t.secondLayer.tabsServicesLabel,title:t.labels.headerCorner},r}return o(t,e),t}(Kt),Zt=["AT","BE","BG","CY","CZ","DE","DK","EE","ES","FI","FR","GR","HR","HU","IE","IT","LT","LU","LV","MT","NL","PL","PT","RO","SE","SI","SK"],en=function(){function e(){this.apiInstance=_t.getInstance(),this.userCountryData={}}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.userCountryData={}},e.prototype.setUserCountryData=function(e){this.userCountryData=e},e.prototype.getUserCountryData=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return L(this.userCountryData)?[3,2]:[4,this.apiInstance.fetchUserCountry()];case 1:e=t.sent(),this.setUserCountryData(tn(e)),t.label=2;case 2:return[2,this.userCountryData]}}))}))},e.prototype.getIsUserInCalifornia=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){return[2,this.getIsUserInUS("CA")]}))}))},e.prototype.getIsUserInEU=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return[4,this.getUserCountryData()];case 1:return e=t.sent(),[2,I(Zt,e.code.toUpperCase())]}}))}))},e.prototype.getIsUserInUS=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return[4,this.getUserCountryData()];case 1:return[2,"US"===(t=n.sent()).code&&(!e||t.regionCode===e)]}}))}))},e.mapUserCountryData=function(e){return{countryCode:e.code,countryName:e.name,regionCode:e.regionCode}},e}(),tn=function(e){return{code:e.countryCode,name:e.countryName,regionCode:e.regionCode}},nn=function(e){this.cookieMaxAgeSeconds=null,this.cookieRefresh=null,this.dataCollected=[],this.dataDistribution=null,this.dataProtectionOfficer=null,this.dataPurposes=[],this.dataRecipients=[],this.deviceStorageDisclosureUrl=null,this.language=null,this.processingCompany=null,this.retentionPeriodDescription=null,this.technologiesUsed=[],this.urls=null,this.usesCookies=null,this.usesNonCookieAccess=null,this.cookieMaxAgeSeconds=k(null==e?void 0:e.cookieMaxAgeSeconds,null),this.cookieRefresh=k(null==e?void 0:e.cookieRefresh,null),this.dataCollected=e?sn(e,j.DATA_COLLECTED_LIST):[],this.dataDistribution=e?rn(e):null,this.dataProtectionOfficer=k(null==e?void 0:e.dataProtectionOfficer,null),this.dataPurposes=e?on(e):[],this.dataRecipients=e?sn(e,j.DATA_RECIPIENTS_LIST):[],this.deviceStorageDisclosureUrl=k(null==e?void 0:e.deviceStorageDisclosureUrl,null),this.language=e?an(e):null,this.processingCompany=e?cn(e):null,this.retentionPeriodDescription=e?ln(e):null,this.technologiesUsed=e?sn(e,j.TECHNOLOGY_USED):[],this.usesCookies=k(null==e?void 0:e.usesCookies,null),this.usesNonCookieAccess=k(null==e?void 0:e.usesNonCookieAccess,null),this.urls=e?dn(e):null},sn=function(e,t){var n;return N(e[t])?e[t]:(null===(n=e[t])||void 0===n?void 0:n.length)>0?[e[t]]:[]},on=function(e){var t=sn(e,j.DATA_PURPOSES_LIST);return N(t)?t:e.dataPurposes},rn=function(e){return{processingLocation:e.locationOfProcessing,thirdPartyCountries:e.thirdCountryTransfer}},an=function(e){return{available:e.languagesAvailable,selected:e.language}},cn=function(e){return{address:e.addressOfProcessingCompany,dataProtectionOfficer:e.dataProtectionOfficer,name:e.nameOfProcessingCompany||e.processingCompany}},ln=function(e){var t;return e.retentionPeriodDescription||(null===(t=e.retentionPeriodList)||void 0===t?void 0:t[0])||""},dn=function(e){return{cookiePolicy:e.cookiePolicyURL,dataProcessingAgreement:e.linkToDpa,optOut:e.optOutUrl,privacyPolicy:e.privacyPolicyURL||e.policyOfProcessorUrl}},un=function(e){function t(t,n,i,s){var o,r=e.call(this,t,n,i,s)||this,a=t.labels,c=t.tcf2;return r.cookieInformation.purposes=c.labelsPurposes,r.buttons={acceptAll:c.buttonsAcceptAllLabel,denyAll:c.buttonsDenyAllLabel,manageSettings:c.linksManageSettingsLabel,save:c.buttonsSaveLabel,showVendorTab:c.linksVendorListLinkLabel},r.firstLayer={description:{additionalInfo:c.firstLayerAdditionalInfo||null,dataSharedOutsideEUText:c.showDataSharedOutsideEUText&&c.dataSharedOutsideEUText?c.dataSharedOutsideEUText:null,default:c.firstLayerDescription,resurfaceNote:c.firstLayerNoteResurface||null},disclaimer:{serviceScope:c.firstLayerNoteService},title:c.firstLayerTitle},r.secondLayer={dataSharedOutsideEU:{text:(null===(o=null==i?void 0:i.labels)||void 0===o?void 0:o.VENDORS_OUTSIDE_EU)||null,title:a.transferToThirdCountries},description:c.secondLayerDescription,purposesTab:c.tabsPurposeLabel,title:c.secondLayerTitle,vendorsTab:c.tabsVendorsLabel},r.titles={features:c.labelsFeatures,iabVendors:c.labelsIabVendors,nonIabPurposes:c.labelsNonIabPurposes,nonIabVendors:c.labelsNonIabVendors,purposes:c.labelsPurposes},r.toggles={consent:t.tcf2.togglesConsentToggleLabel,legitimateInterest:t.tcf2.togglesLegIntToggleLabel,specialFeaturesToggle:{offLabel:t.tcf2.togglesSpecialFeaturesToggleOff,onLabel:t.tcf2.togglesSpecialFeaturesToggleOn}},r.vendor={features:c.vendorFeatures,legitimateInterest:c.vendorLegitimateInterestPurposes,privacyPolicy:a.privacyPolicyLinkText,purposes:c.vendorPurpose,specialFeatures:c.vendorSpecialFeatures,specialPurposes:c.vendorSpecialPurposes,toggleAll:c.labelsActivateAllVendors},r}return o(t,e),t}(Kt),hn=function(){function e(){this.aggregatedServices=[],this.allLegacyServicesHaveName=!1,this.isVariantLoaded=!1,this.isAggregatorLoaded=!1,this.language="",this.translations=null,this.botInstance=Et.getInstance(),this.locationInstance=en.getInstance(),this._core=null,this._coreJson=null,this._data=null,this._dpsJson=null,this._labels=null,this._legacySettings=null,this._ui=null,this.controllerIdInstance=ft.getInstance(),this.acceptAllImplicitlyOnInit=null}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.allLegacyServicesHaveName=!1,e.instance.core=null,e.instance.data=null,e.instance.labels=null,e.instance.legacySettings=null,e.instance.ui=null,e.instance.dpsJson=null,e.instance.coreJson=null},Object.defineProperty(e.prototype,"core",{get:function(){return this._core},set:function(e){this._core=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"coreJson",{get:function(){return this._coreJson},set:function(e){this._coreJson=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"data",{get:function(){return this._data},set:function(e){this._data=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"dpsJson",{get:function(){return this._dpsJson},set:function(e){this._dpsJson=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"labels",{get:function(){return this._labels},set:function(e){this._labels=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"legacySettings",{get:function(){return this._legacySettings},set:function(e){this._legacySettings=e},enumerable:!1,configurable:!0}),Object.defineProperty(e.prototype,"ui",{get:function(){return this._ui},set:function(e){this._ui=e},enumerable:!1,configurable:!0}),e.prototype.init=function(e,t,n){return S(this,void 0,void 0,(function(){return C(this,(function(i){return this.language=n,this.core=new Qt(e,n),this.coreJson=e,this.dpsJson=t,this.isAggregatorLoaded=!1,this.allLegacyServicesHaveName=this.checkIfServiceNameExists(t.consentTemplates),this.isAggregatorLoaded=!1,[2]}))}))},e.prototype.initData=function(e,t,i,s){return void 0===i&&(i=!0),void 0===s&&(s=!1),S(this,void 0,void 0,(function(){var o,r,a,c,l,d=this;return C(this,(function(u){switch(u.label){case 0:if(r=(o=this).coreJson,a=o.dpsJson,c=o.legacySettings,!r||!a)return[2];switch(l=this.controllerIdInstance.value,e){case 0:return[3,1];case 2:return[3,3];case 1:return[3,5]}return[3,7];case 1:return[4,n.e(746).then(n.bind(n,746)).then((function(e){var t=new(0,e.default)(r,a,l);d.data=t}))];case 2:return u.sent(),[3,8];case 3:return c?[4,n.e(5495).then(n.bind(n,5495)).then((function(e){var t=e.default;return S(d,void 0,void 0,(function(){var e,n;return C(this,(function(o){switch(o.label){case 0:return(e=this.getDataTransferSettings())&&r.tcf2?(n=new t(c,r.tcf2,a,e,l,this.language),this.data=n,i?[4,n.init(s)]:[3,2]):[3,2];case 1:o.sent(),o.label=2;case 2:return[2]}}))}))}))]:[2];case 4:return u.sent(),[3,8];case 5:return[4,n.e(7963).then(n.bind(n,7963)).then((function(e){var n=new(0,e.default)(a,l,t);d.data=n}))];case 6:return u.sent(),[3,8];case 7:console.error("Usercentrics: Unknown variant"),u.label=8;case 8:return this.isVariantLoaded=!0,[2]}}))}))},e.prototype.checkIfServiceNameExists=function(e){return e.every((function(e){var t;return null!=(null===(t=e._meta)||void 0===t?void 0:t.name)}))},e.prototype.initLabels=function(e,t,n){var i=this.dpsJson,s=this.legacySettings;if(s&&this.core&&i)switch(e){case 0:var o=new Yt(s,i,t,n);this.labels=o;break;case 1:var r=new Xt(s,i,t,n);this.labels=r;break;case 2:var a=new un(s,i,t,n);this.labels=a;break;default:console.error("Usercentrics: Unknown variant")}else console.error("Usercentrics: You have to call the init method before!")},e.prototype.initUI=function(e,t){return S(this,void 0,void 0,(function(){var i,s,o,r=this;return C(this,(function(a){switch(a.label){case 0:return s=(i=this).coreJson,o=i.legacySettings,s?2!==e?[3,2]:[4,n.e(2243).then(n.bind(n,2243)).then((function(e){var t=new(0,e.default)(s);r.ui=t}))]:[2];case 1:return a.sent(),[2];case 2:if(!o)return[2];switch(t){case 0:return[3,3];case 1:return[3,5];case 2:return[3,7]}return[3,9];case 3:return[4,n.e(8733).then(n.bind(n,8733)).then((function(e){var t=new(0,e.default)(s,o);r.ui=t}))];case 4:return a.sent(),[3,10];case 5:return[4,n.e(3527).then(n.bind(n,3527)).then((function(e){var t=new(0,e.default)(s,o);r.ui=t}))];case 6:return a.sent(),[3,10];case 7:return[4,n.e(1867).then(n.bind(n,1867)).then((function(e){var t=new(0,e.default)(s,o);r.ui=t}))];case 8:return a.sent(),[3,10];case 9:console.error("Usercentrics: Unknown variant"),a.label=10;case 10:return[2]}}))}))},e.prototype.getCcpaData=function(){return oe(this.data)?this.data:null},e.prototype.getDefaultData=function(){return function(e){return null!=e&&!oe(e)&&!re(e)}(this.data)?this.data:null},e.prototype.getTcfData=function(){return re(this.data)?this.data:null},e.prototype.getCcpaLabels=function(){return function(e){var t;return null!=e&&null!=(null===(t=e.buttons)||void 0===t?void 0:t.optOutNotice)}(this.labels)?this.labels:null},e.prototype.getDefaultLabels=function(){return function(e){var t;return null!=e&&null!=(null===(t=e.buttons)||void 0===t?void 0:t.showSecondLayer)}(this.labels)?this.labels:null},e.prototype.getTcfLabels=function(){return function(e){return null!=e&&null!=e.vendor}(this.labels)?this.labels:null},e.prototype.getCcpaUI=function(){return ae(this.ui)?this.ui:null},e.prototype.getDefaultUI=function(){return le(this.ui)?this.ui:null},e.prototype.getTcfUI=function(){return ce(this.ui)?this.ui:null},e.prototype.getDataExchangeSettings=function(){return this.core?this.core.dataExchangeSettings:[]},e.prototype.getCategoriesData=function(){return this.data?this.data.categories:[]},e.prototype.getCategoriesBaseData=function(){var e=this;return this.data?this.data.categories.map((function(t){return{isEssential:t.isEssential,isHidden:t.isHidden,services:e.getServicesBaseInfo(),slug:t.slug}})):[]},e.prototype.getCategoriesLabels=function(){return this.labels?this.labels.categories:[]},e.prototype.getCategoriesDataAndLabels=function(){return function(e,t,n){return e.reduce((function(e,i){var s=t.find((function(e){return e.slug===i.slug}));return s?E(E([],w(e),!1),[y(y(y({},s),i),{services:se(i.services,n)})],!1):e}),[])}(this.getCategoriesData(),this.getCategoriesLabels(),this.getServicesLabels())},e.prototype.getCategoriesBaseInfo=function(){return this.getCategoriesDataAndLabels()},e.prototype.getCategoriesFullInfo=function(e,t){return S(this,void 0,void 0,(function(){return C(this,(function(n){switch(n.label){case 0:return this.isAggregatorLoaded?[3,2]:[4,this.extendServices(e,t)];case 1:n.sent(),n.label=2;case 2:return[2,this.getCategoriesDataAndLabels()]}}))}))},e.prototype.getCategoryBySlug=function(e){return this.getCategoriesDataAndLabels().find((function(t){return t.slug===e}))},e.prototype.getDataTransferSettings=function(e){return this.core?{controllerId:this.controllerIdInstance.value,id:this.core.id,selectedLanguage:this.core.language.selected,version:e||this.core.version}:null},e.prototype.getEssentialCategories=function(){return this.getCategoriesDataAndLabels().reduce((function(e,t){return t.isEssential?E(E([],w(e),!1),[t],!1):e}),[])},e.prototype.getEssentialCategoriesData=function(){return this.getCategoriesData().reduce((function(e,t){return t.isEssential?E(E([],w(e),!1),[t],!1):e}),[])},e.prototype.getNonEssentialCategories=function(){return this.getCategoriesDataAndLabels().reduce((function(e,t){return t.isEssential?e:E(E([],w(e),!1),[t],!1)}),[])},e.prototype.getNonEssentialCategoriesData=function(){return this.getCategoriesData().reduce((function(e,t){return t.isEssential?e:E(E([],w(e),!1),[t],!1)}),[])},e.prototype.getGoogleConsentMode=function(){return!!this.core&&this.core.googleConsentMode},e.prototype.getServicesLabels=function(){return this.labels?this.labels.services:[]},e.prototype.getServicesData=function(){return this.getCategoriesData().reduce((function(e,t){return E(E([],w(e),!1),w(t.services),!1)}),[])},e.prototype.getServicesDataAndLabels=function(){var e=this.getServicesData();return se(e,this.getServicesLabels())},e.prototype.getServicesBaseInfo=function(){var e,t;return e=this.mapBaseServices(this.getServicesData()),t=this.getServicesLabels(),e.reduce((function(e,n){var i=t.find((function(e){return e.id===n.id}));return E(E([],w(e),!1),[y(y({},n),i||ie)],!1)}),[])},e.prototype.getServicesFullInfo=function(e,t){return S(this,void 0,void 0,(function(){return C(this,(function(n){switch(n.label){case 0:return this.isAggregatorLoaded?[3,2]:[4,this.extendServices(e,t)];case 1:n.sent(),n.label=2;case 2:return[2,this.getServicesDataAndLabels()]}}))}))},e.prototype.getServicesFromCategories=function(e){return e.reduce((function(e,t){return e.concat(t.services)}),[])},e.prototype.getServicesWithConsent=function(){return this.getServicesDataAndLabels().reduce((function(e,t){return t.consent.status?E(E([],w(e),!1),[t],!1):e}),[])},e.prototype.areAllServicesAccepted=function(){return this.getServicesData().every((function(e){return e.consent.status}))},e.prototype.areAllVendorsAndPurposesAccepted=function(){var e=this.getTcfData();return!!e&&e.areAllPurposesAccepted()&&e.areAllVendorsAccepted()},e.prototype.extendServices=function(e,t){return S(this,void 0,void 0,(function(){var n,i;return C(this,(function(s){switch(s.label){case 0:return(n=this.dpsJson)?(this.isAggregatorLoaded=!0,[4,this.fetchServices(n)]):[2];case 1:return(i=s.sent())&&0!==i.length?(this.aggregatedServices=i,this.initLabels(e,t,i),this.data&&(this.data.categories=this.data.categories.map((function(e){var t=n.categories.find((function(t){return t.categorySlug===e.slug}));return y(y({},e),{services:e.services.map((function(e){if(n.consentTemplates.find((function(t){return t.templateId===e.id}))&&t){var s=null==i?void 0:i.find((function(t){return e.id===t.templateId&&e.version===t.version})),o=new nn(s);return y(y({},e),o)}return e}))})}))),[2]):[2]}}))}))},e.prototype.isCcpaEnabled=function(){var e;return(null===(e=this.core)||void 0===e?void 0:e.isCcpaEnabled)||!1},e.prototype.isCcpaAvailable=function(){var e;if(this.isCcpaEnabled()&&null!=(null===(e=this.coreJson)||void 0===e?void 0:e.ccpa))switch(this.coreJson.ccpa.region){case M.US:return this.locationInstance.getIsUserInUS();case M.US_CA_ONLY:return this.locationInstance.getIsUserInCalifornia();default:return Promise.resolve(!0)}return Promise.resolve(!1)},e.prototype.isCrossDomainEnabled=function(){var e;return(null===(e=this.core)||void 0===e?void 0:e.consentSharingIFrameIsActive)||!1},e.prototype.isTcfEnabled=function(){var e;return(null===(e=this.core)||void 0===e?void 0:e.isTcfEnabled)||!1},e.prototype.isTcfAvailable=function(){var e;return this.isTcfEnabled()&&null!=(null===(e=this.coreJson)||void 0===e?void 0:e.tcf2)},e.prototype.isTagLoggerActive=function(){var e;return(null===(e=this.core)||void 0===e?void 0:e.isTagLoggerActive)||!1},e.prototype.mergeServicesIntoExistingCategories=function(e){return this.getCategoriesDataAndLabels().map((function(t){return y(y({},t),{services:t.services.map((function(t){return e.find((function(e){return e.id===t.id}))||t}))})}))},e.prototype.mergeServicesDataIntoExistingCategories=function(e){return this.getCategoriesData().map((function(t){return y(y({},t),{services:t.services.map((function(t){return e.find((function(e){return e.id===t.id}))||t}))})}))},e.prototype.setCategories=function(e){this.data&&(this.data.categories=e)},e.prototype.setControllerId=function(e){this.data&&(this.data.controllerId=e),re(this.data)&&this.data.updateControllerId(e)},e.prototype.updateServicesLanguage=function(e){this.data&&this.data.categories.map((function(t){return y(y({},t),{services:t.services.map((function(t){return y(y({},t),{language:y(y({},t.language),{selected:e})})}))})}))},e.prototype.shouldAcceptAllImplicitlyOnInit=function(){var e,t;return S(this,void 0,void 0,(function(){var n,i,s,o,r,a;return C(this,(function(c){switch(c.label){case 0:return null!==this.acceptAllImplicitlyOnInit?[2,this.acceptAllImplicitlyOnInit]:(n=this,(o=this.botInstance.isRobot())?[3,2]:[4,this.isCcpaAvailable()]);case 1:o=c.sent(),c.label=2;case 2:return(s=o)?[3,5]:(r=null===(e=this.core)||void 0===e?void 0:e.acceptAllImplicitlyOutsideEU)?[4,this.locationInstance.getIsUserInEU()]:[3,4];case 3:r=!c.sent(),c.label=4;case 4:s=r,c.label=5;case 5:return(i=s)?[3,8]:(a=this.isTcfAvailable())?[4,null===(t=this.getTcfData())||void 0===t?void 0:t.getGdprApplies()]:[3,7];case 6:a=!c.sent(),c.label=7;case 7:i=a,c.label=8;case 8:return n.acceptAllImplicitlyOnInit=i,[2,this.acceptAllImplicitlyOnInit]}}))}))},e.prototype.shouldShowFirstLayerOnVersionChange=function(){var e=tt.fetchSettingsVersion();if(this.core&&e&&N(this.core.showFirstLayerOnVersionChange)){var t=this.core.version.split("."),n=e.split(".");return I(this.core.showFirstLayerOnVersionChange,u.MAJOR)&&t[0]!==n[0]||I(this.core.showFirstLayerOnVersionChange,u.MINOR)&&t[1]!==n[1]||I(this.core.showFirstLayerOnVersionChange,u.PATCH)&&t[2]!==n[2]}return!1},e.prototype.getUpdatedServicesWithConsent=function(e){return this.getServicesDataAndLabels().map((function(t){if(!t.isEssential){var n=t;return n.consent.status=e===l.TRUE,n}return t}))},e.prototype.getUpdatedServicesDataWithConsent=function(e){return this.getServicesData().map((function(t){if(!t.isEssential){var n=t;return n.consent.status=e===l.TRUE,n}return t}))},e.prototype.getUpdatedServicesWithDecisions=function(e){return this.getServicesDataAndLabels().map((function(t){var n=e.find((function(e){return e.serviceId===t.id})),i=t;return i.consent.status=t.isEssential||(n?n.status:t.consent.status),i}))},e.prototype.getUpdatedServicesDataWithDecisions=function(e){return this.getServicesData().map((function(t){var n=e.find((function(e){return e.serviceId===t.id})),i=t;return i.consent.status=t.isEssential||(n?n.status:t.consent.status),i}))},e.prototype.updateDataTransferSettings=function(e){var t=e.controllerId,n=e.id,i=e.selectedLanguage,s=e.version;this.core&&this.data&&(this.data.controllerId=t,this.core.id=n,this.core.language.selected=i,this.core.version=s)},e.prototype.isTcfHistoryV2Disabled=function(){return!!re(this.data)&&!0===this.data.tcfv2HistoryDisabled},e.prototype.getTCFPurposeOneTreatment=function(){return re(this.data)&&this.data.purposeOneTreatment||!1},e.prototype.getTCFStackIds=function(){return re(this.data)?this.data.stackIds:[]},e.prototype.getTCFVendorIds=function(){return re(this.data)?this.data.vendorIds:[]},e.prototype.getTCFDisclosedVendorsSegmentString=function(){var e;return null===(e=this.getTcfData())||void 0===e?void 0:e.getTCFDisclosedVendorsSegmentString()},e.prototype.injectTCString=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){return(t=this.getTcfData())?[2,t.injectTCString(e)]:[2,!1]}))}))},e.prototype.fetchServices=function(e){return S(this,void 0,void 0,(function(){var t,n,i,s;return C(this,(function(o){switch(o.label){case 0:return(t=vt(e.consentTemplates)).length?(n=_t.getInstance(),i=Et.getInstance(),s=[],i.isRobot()?[3,2]:[4,n.fetchAggregatedServices(t)]):[2,null];case 1:s=o.sent(),o.label=2;case 2:return[2,s]}}))}))},e.prototype.mapBaseServices=function(e){return e.map((function(e){return{categorySlug:e.categorySlug,consent:e.consent,fetchSubServices:e.fetchSubServices,id:e.id,isEssential:e.isEssential,isHidden:e.isHidden,processorId:e.processorId,subServices:e.subServices,subServicesLength:e.subServicesLength,version:e.version}}))},e}(),pn=function(){function e(){this.useOnlySettingsV2=!1,this.apiInstance=_t.getInstance(),this.controllerIdInstance=ft.getInstance(),this.eventDispatcherInstance=At.getInstance(),this.settingsV2=hn.getInstance(),this.botInstance=Et.getInstance()}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){delete e.instance.userSessionData},e.prototype.execute=function(e,t,n,i,s){var o,r=this.settingsV2.getDataTransferSettings();if(r){var a=e.map((function(e){return O(r,e,n,i)})),c=fn(t,a);if(!this.botInstance.isRobot()&&(this.apiInstance.saveConsents({consentString:s,dataTransferObjects:a}),null===(o=this.settingsV2.core)||void 0===o?void 0:o.consentAPIv2)){var l=this.mapDataTransferObjectsV2(r,e,n,s);this.apiInstance.saveConsentsV2(l)}this.settingsV2.setCategories(this.settingsV2.mergeServicesDataIntoExistingCategories(c));var d=this.settingsV2.getServicesDataAndLabels();tt.saveSettings(tt.mapSettings(r,d),d),zt.enableScriptsForServicesWithConsent(this.settingsV2.getServicesWithConsent()),this.eventDispatcherInstance.dispatch(a,this.settingsV2.getGoogleConsentMode())}},e.prototype.getMergedServicesAndSettingsFromStorage=function(e){var t=e,n=tt.fetchSettings();if(n&&t){var i=this.settingsV2.getServicesFromCategories(this.settingsV2.getEssentialCategories()),s=this.settingsV2.getServicesFromCategories(this.settingsV2.getEssentialCategoriesData()),o=this.settingsV2.getServicesFromCategories(this.settingsV2.getNonEssentialCategories()),r=this.settingsV2.getServicesFromCategories(this.settingsV2.getNonEssentialCategoriesData()),a=this.getMergedAndUpdatedEssentialServices(i,n),c=this.getMergedAndUpdatedEssentialServices(s,n),l=this.getMergedNonEssentialServices(o,n),d=this.getMergedNonEssentialServices(r,n);return n.controllerId!==this.controllerIdInstance.value&&(this.controllerIdInstance.value=n.controllerId,t.controllerId=n.controllerId,re(t)&&t.updateControllerId(n.controllerId)),{dataTransferSettings:this.settingsV2.getDataTransferSettings(),mergedServicesData:c.mergedEssentialServices.concat(d),mergedServicesV2:a.mergedEssentialServices.concat(l),mergedSettingsData:t,updatedEssentialServicesV2:a.updatedEssentialServices}}return{dataTransferSettings:null,mergedServicesData:[],mergedServicesV2:[],mergedSettingsData:t,updatedEssentialServicesV2:[]}},e.prototype.getLatestConsentType=function(e){return e.length>0?e[e.length-1].type:"implicit"},e.prototype.getLatestConsentAction=function(e){return e.length>0?e[e.length-1].action:"onInitialPageLoad"},e.prototype.setUserSessionData=function(e){this.userSessionData=e},e.prototype.mergeServicesAndSettings=function(e,t,n,i){var s,o=this;if(!n)return[];if(N(i)){var r=i.map((function(e){return O(n,e,"onEssentialChange",o.getLatestConsentType(e.consent.history))})),a=fn(t,r),c=gn(e,a);if(this.apiInstance.saveConsents({dataTransferObjects:r}),null===(s=this.settingsV2.core)||void 0===s?void 0:s.consentAPIv2){var l=this.mapDataTransferObjectsV2(n,i,"onEssentialChange");this.apiInstance.saveConsentsV2(l)}this.settingsV2.setCategories(this.settingsV2.mergeServicesDataIntoExistingCategories(a)),tt.saveSettings(tt.mapSettings(n,c),c)}else this.settingsV2.setCategories(this.settingsV2.mergeServicesDataIntoExistingCategories(t)),tt.saveSettings(tt.mapSettings(n,e),e);return e.map((function(e){return O(n,e,o.getLatestConsentAction(e.consent.history),o.getLatestConsentType(e.consent.history))}))},e.prototype.restoreUserSession=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return this.controllerIdInstance.value&&this.controllerIdInstance.needsSessionRestore?[4,this.getCrossDeviceSessionData(this.controllerIdInstance.value)]:[3,2];case 1:t=n.sent(),n.label=2;case 2:if(!t&&this.userSessionData&&(t=y({},this.userSessionData)),!t&&window.ucMobileSdk&&"function"==typeof window.ucMobileSdk.getUserSessionData)try{(null==(t=JSON.parse(window.ucMobileSdk.getUserSessionData(),(function(e,t){if("timestamp"===e){var n=t.toString();return-1!==n.indexOf(".")?1e3*Number(n):Number(n)}return t})))?void 0:t.consents)&&(null==t?void 0:t.consents.length)&&!t.consents.every((function(e){return e.action}))&&(t.consents=t.consents.map((function(e){return y(y({},e),{action:"onMobileSessionRestore"})})),this.restoreAction="onMobileSessionRestore")}catch(e){}return t||!Ye.isCrossDomainAvailable()?[3,4]:[4,this.getCrossDomainSessionData()];case 3:t=n.sent(),n.label=4;case 4:return t&&t.controllerId?[2,this.restoreData(t,e)]:(this.controllerIdInstance.needsSessionRestore=!1,[2,!1])}}))}))},e.prototype.getCrossDomainSessionData=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return[4,Ye.getCrossDomainSessionData().catch((function(){return console.warn(Fe.CROSS_DOMAIN_DATA_NOT_AVAILABLE),{}}))];case 1:return[2,e.sent()]}}))}))},e.prototype.getCrossDeviceSessionData=function(e){return S(this,void 0,void 0,(function(){var t,n,i,s,o;return C(this,(function(r){switch(r.label){case 0:return[4,this.apiInstance.fetchUserConsents().catch((function(){return console.warn(Ue.CROSS_DEVICE_DATA_NOT_AVAILABLE),[]}))];case 1:return t=r.sent(),n=["dWLDa0s-m","VkvM9IcSA","Zdgjo9gQh","r2tAWzO7","GVl-ixMH"],i=this.apiInstance.getSettingsId(),s=null,this.settingsV2.isTcfAvailable()?-1===n.indexOf(i)?[3,3]:[4,this.apiInstance.fetchUserTcfData().catch((function(){return console.warn(Ue.CROSS_DEVICE_TCF_DATA_NOT_AVAILABLE),null}))]:[3,7];case 2:return s=r.sent(),[3,5];case 3:return this.settingsV2.isTcfHistoryV2Disabled()?[3,5]:[4,this.apiInstance.fetchUserTcfDataV2().catch((function(){return console.warn(Ue.CROSS_DEVICE_TCF_DATA_NOT_AVAILABLE),null}))];case 4:s=r.sent(),r.label=5;case 5:return s||!Ye.isCrossDomainAvailable()?[3,7]:[4,this.getCrossDomainSessionData()];case 6:(o=r.sent())&&o.tcf&&o.controllerId===e&&(s=o.tcf),r.label=7;case 7:return[2,y({consents:t,controllerId:e,language:this.apiInstance.getJsonFileLanguage()},null!==s&&{tcf:s})]}}))}))},e.prototype.restoreData=function(e,t){var n;return S(this,void 0,void 0,(function(){var i,s,o,r,a,c,l,d,u,h,p,f,g,v,_,b,m,y,S=this;return C(this,(function(C){return i=e.controllerId,s=e.consents,o=e.tcf,r=e.ccpa,a=this.settingsV2.core,c=this.getDataFacadeServices(t),o&&o.tcString&&(tt.saveTCFData(o),c.length||tt.setUserActionPerformed()),l=this.settingsV2.getCcpaData(),r&&r.ccpaString&&l&&(l.setIsOptedOut(r.ccpaString),tt.setCcpaString(r.ccpaString),r.timestamp?tt.setCcpaTimeStamp(r):tt.clearCcpaData(),tt.setUserActionPerformed()),!i||!N(s)&&c.length||(d=_n(s),u=bn(s),!N(u)&&c.length)?[2,!1]:(h=[],p=[],u.forEach((function(e){var t=c.findIndex((function(t){return t.id===e.templateId}));if(t>-1){var n=c[t],i=n;i.consent.status=e.status;var s=p.findIndex((function(e){return e.id===n.id}));-1===s?p.push(i):p[s]=i,c[t]=i;var o=S.settingsV2.getDataTransferSettings(e.settingsVersion);o&&h.push(O(o,i,e.action,e.updatedBy,{timestamp:"string"==typeof e.timestamp?S.resolveTimestamp(e.timestamp):e.timestamp}))}})),this.settingsV2.data&&(this.settingsV2.data.controllerId=i),f=void 0,g=void 0,a&&u.length&&(g=R(u.map((function(e){return e.settingsVersion}))).sort(J)).length&&(f=g[g.length-1]),v=fn(c,h),_=this.settingsV2.getDataTransferSettings(f),(b=this.settingsV2.data)&&_&&i&&i!==tt.fetchControllerId()&&(m=p.map((function(e){return O(_,e,"onSessionRestored","implicit",{referrerControllerId:b.controllerId})})),this.restoreAction="onSessionRestored",this.apiInstance.saveConsents({dataTransferObjects:m}),(null===(n=this.settingsV2.core)||void 0===n?void 0:n.consentAPIv2)&&(y=this.mapDataTransferObjectsV2(_,p,"onSessionRestored"),this.apiInstance.saveConsentsV2(y))),i===tt.fetchControllerId()&&(this.restoreAction="onInitialPageLoad"),_&&tt.saveSettings(tt.mapSettings(_,v),v),N(d)&&tt.setUserActionPerformed(),[2,!0])}))}))},e.prototype.mapDataTransferObjectsV2=function(e,t,n,i){var s=t.map((function(e){return{consentStatus:e.consent.status,consentTemplateId:e.id,consentTemplateVersion:e.version}})),o="",r="";if(this.settingsV2.isTcfEnabled()){var a=tt.fetchTCFData(),c=a.tcString,l=a.timestamp,d=a.vendors,u=a.vendorsDisclosed;o=k(o?null==i?void 0:i.TCF2:c,""),r=JSON.stringify({timestamp:l,vendors:d,vendorsDisclosed:u})}else this.settingsV2.isCcpaEnabled()&&(o=k(null==i?void 0:i.CCPA,""));return{action:n,appVersion:A().replace("SDK-",""),consentMeta:r,consents:s,consentString:o,controllerId:e.controllerId,language:e.selectedLanguage,settingsId:e.id,settingsVersion:e.version}},e.prototype.getDataFacadeServices=function(e){var t=this.settingsV2.checkIfServiceNameExists,n=e.categories,i=e.consentTemplates;if(i.length>0&&t(i))return i.map((function(e){var t,i=n.find((function(t){return t.categorySlug===e.categorySlug}));return{consent:qt(e,i),id:e.templateId,name:(null===(t=e._meta)||void 0===t?void 0:t.name)||"",processorId:"".concat(ot(ht())),version:e.version}}));var s=this.settingsV2.getServicesDataAndLabels();return s.length>0?s.map((function(e){return{consent:e.consent,id:e.id,name:e.name,processorId:e.processorId,version:e.version}})):[]},e.prototype.getMergedAndUpdatedEssentialServices=function(e,t){var n=[];return{mergedEssentialServices:e.map((function(e){var i,s=null===(i=t.services)||void 0===i?void 0:i.find((function(t){return t.id===e.id}));if(s){var o=e;return o.consent.history=s.history,o.consent.status=!0,o.processorId=s.processorId,s.status||n.push(o),o}return e})),updatedEssentialServices:n}},e.prototype.getMergedNonEssentialServices=function(e,t){return e.map((function(e){var n,i,s=null===(n=t.services)||void 0===n?void 0:n.find((function(t){return t.id===e.id}));if(s)return(o=e).consent.history=s.history,o.consent.status=s.status,o.processorId=s.processorId,o;if(0===e.consent.history.length){var o=e,r=null===(i=t.services)||void 0===i?void 0:i.find((function(e){return e.history.length>0}));return o.consent.history=[{action:"onInitialPageLoad",language:e.language?e.language.selected:"en",status:e.consent.status,timestamp:(new Date).getTime(),type:"implicit",versions:r&&r.history.length>0?r.history[0].versions:{application:"",service:e.version,settings:""}}],o}return e}))},e.prototype.resolveTimestamp=function(e){return 10===e.length?1e3*parseInt(e,10):parseInt(e,10)},e}(),fn=function(e,t){return e.map((function(e){var n=t.filter((function(t){return t.service.id===e.id}));if(N(n)){var i=e.consent.history,s=i.length+n.length,o=s<=3?i:i.slice(s-3),r=e;return r.consent.history=E(E([],w(o),!1),w(n.map((function(e){return vn(e)}))),!1),r}return e}))},gn=function(e,t){return e.reduce((function(e,n){var i=t.find((function(e){return e.id===n.id}));return i?E(E([],w(e),!1),[y(y({},n),{consent:i.consent})],!1):E([],w(e),!1)}),[])},vn=function(e){return{action:e.consent.action,language:e.settings.language,status:e.consent.status,timestamp:e.timestamp,type:e.consent.type,versions:{application:e.applicationVersion,service:e.service.version,settings:e.settings.version}}},_n=function(e){return e.filter((function(e){return!Vt.includes(e.action)}))},bn=function(e){return e.filter((function(e){return"onSessionRestored"!==e.action}))},mn=function(){function e(){this.primaryLanguage="",this.apiInstance=_t.getInstance()}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.prototype.setPrimaryLanguage=function(e){this.primaryLanguage=e},e.prototype.getPrimaryLanguage=function(){return this.primaryLanguage},e.prototype.resolveLanguage=function(){return S(this,void 0,void 0,(function(){var e,t,n,i,s;return C(this,(function(o){switch(o.label){case 0:return[4,this.apiInstance.fetchAvailableLanguages()];case 1:return e=o.sent(),(t=Cn(e,this.primaryLanguage))?(this.apiInstance.setJsonFileLanguage(t),[2]):(n=tt.fetchLanguage(),(t=Cn(e,n))?(this.apiInstance.setJsonFileLanguage(t),[2]):(i=Sn(e))?(this.apiInstance.setJsonFileLanguage(i),[2]):(s=yn(e))?(this.apiInstance.setJsonFileLanguage(s),[2]):e.length>0?(this.apiInstance.setJsonFileLanguage(e[0]),[2]):(this.apiInstance.setJsonFileLanguage("en"),[2]))}}))}))},e}(),yn=function(e){var t=window.navigator;if(N(t.languages))for(var n=0;n<t.languages.length;n+=1){var i=Cn(e,t.languages[n]);if(i)return i}var s=null!=t.language?t.language:t.userLanguage;return Cn(e,s)},Sn=function(e){var t=document.documentElement.lang;return t?Cn(e,t):null},Cn=function(e,t){if(t){var n=t.toLowerCase().replace("-","_");if(I(e,n))return n;var i=t.slice(0,2);if(I(e,i))return i}return null},wn=function(){function e(){this.needsSessionRestore=!1,this.apiInstance=_t.getInstance(),this.locationInstance=en.getInstance()}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){delete e.instance.noShow},e.prototype.unsetNoShow=function(){delete this.noShow},e.prototype.getIsUsingNoShow=function(){return void 0!==this.noShow},e.prototype.getNoShow=function(){return!0===this.noShow},e.prototype.setNoShow=function(e){this.noShow=e},e.prototype.resolveSettingsId=function(){return S(this,void 0,void 0,(function(){var e,t,n,i,s,o,r,a;return C(this,(function(c){switch(c.label){case 0:return[4,this.apiInstance.fetchRuleset()];case 1:return e=c.sent(),n="",i=e.location,s=e.rules,o=e.defaultRule,r=o.settingsId,a=o.noShow,i&&i.code&&(t=i.regionCode&&s.find((function(e){var t;return null===(t=e.locations)||void 0===t?void 0:t.includes(i.regionCode)}))||s.find((function(e){var t;return null===(t=e.locations)||void 0===t?void 0:t.includes(i.code)})),this.locationInstance.setUserCountryData(i),tt.setUserCountryResponse(en.mapUserCountryData(i))),this.unsetNoShow(),t?(n=t.settingsId,void 0!==t.noShow&&this.setNoShow(!0===t.noShow)):(n=r,this.setNoShow(!0===a)),[2,{noShow:this.getNoShow(),settingsId:n}]}}))}))},e}(),En=function(){function e(){this.initOptions=null,this.isFirstTimePageVisit=!0,this.selectedLayer=null,this.shouldAcceptAllImplicitly=null,this.shouldShowFirstLayerOnVersionChange=!1,this.variant=null,this.ampInstance=Ee.getInstance(),this.botInstance=Et.getInstance(),this.settingsV2=hn.getInstance(),this.rulesetInstance=wn.getInstance(),this.apiInstance=_t.getInstance()}return e.getInstance=function(){return e.instance||(e.instance=new e),e.instance},e.resetInstance=function(){e.instance.selectedLayer=null,e.instance.variant=null,e.instance.shouldAcceptAllImplicitly=null,e.instance.initOptions=null},e.prototype.init=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return this.initOptions=e,this.isFirstTimePageVisit=this.isFirstTimeVisit(),null!==this.shouldAcceptAllImplicitly?[3,2]:(t=this,[4,this.settingsV2.shouldAcceptAllImplicitlyOnInit()]);case 1:t.shouldAcceptAllImplicitly=n.sent(),n.label=2;case 2:return this.shouldShowFirstLayerOnVersionChange=this.settingsV2.shouldShowFirstLayerOnVersionChange(),[2]}}))}))},e.prototype.isFirstTimeVisit=function(){return!tt.settingsExist()||this.botInstance.isRobot()},e.prototype.shouldShowNone=function(){return S(this,void 0,void 0,(function(){var e,t;return C(this,(function(n){switch(n.label){case 0:return e=0===this.variant,null!==this.shouldAcceptAllImplicitly?[3,2]:(t=this,[4,this.settingsV2.shouldAcceptAllImplicitlyOnInit()]);case 1:t.shouldAcceptAllImplicitly=n.sent(),n.label=2;case 2:return this.apiInstance.getRulesetId()&&this.rulesetInstance.getIsUsingNoShow()?[2,this.rulesetInstance.getNoShow()]:[2,this.shouldAcceptAllImplicitly&&!e]}}))}))},e.prototype.shouldShowFirstLayer=function(e){var t,n,i,s,o,r;return S(this,void 0,void 0,(function(){var a,c,l,d,u;return C(this,(function(h){if(a=this.ampInstance.isAmpEnabled(),c=0===this.variant,l=(null===(t=e.ccpa)||void 0===t?void 0:t.showOnPageLoad)||!1,d=c?l:!this.shouldAcceptAllImplicitly,!(null===(n=this.initOptions)||void 0===n?void 0:n.suppressCmpDisplay)&&(d&&this.isFirstTimePageVisit||this.shouldShowFirstLayerOnVersionChange||!tt.fetchUserActionPerformed()&&(!c||l)||a))return[2,!0];switch(this.variant){case 0:if(!(null===(i=this.initOptions)||void 0===i?void 0:i.suppressCmpDisplay)&&this.shouldShowFirstLayerForCcpa(null===(s=e.ccpa)||void 0===s?void 0:s.reshowAfterDays))return[2,!0];break;case 2:if(u=this.settingsV2.getTcfData(),!(null===(o=this.initOptions)||void 0===o?void 0:o.suppressCmpDisplay)&&(null==u?void 0:u.shouldResurfaceUI()))return[2,!0];break;default:if(!(null===(r=this.initOptions)||void 0===r?void 0:r.suppressCmpDisplay)&&this.shouldForceReshowGDPRBanner())return[2,!0]}return[2,!1]}))}))},e.prototype.shouldForceReshowGDPRBanner=function(){var e=this.settingsV2.core;if(!e)return!1;var t,n=e.reshowBanner,i=this.settingsV2.getServicesData().reduce((function(e,t){return E(E([],w(e),!1),w(t.consent.history),!1)}),[]).filter((function(e){return["onAcceptAllServices","onDenyAllServices","onUpdateServices"].indexOf(e.action)>-1})).sort((function(e,t){return t.timestamp-e.timestamp}));if(n>0&&i.length>0){var s=new Date(i[0].timestamp);return s.setMonth(s.getMonth()+n),t=s,(new Date).getTime()-t.getTime()>=0}return!1},e.prototype.shouldShowPrivacyButton=function(e){var t=window.location.href,n=!e.privacyButtonUrls||0===e.privacyButtonUrls.contains.length;return e.privacyButtonUrls&&e.privacyButtonUrls.contains.length>0&&e.privacyButtonUrls.contains.some((function(e){return t.includes(e)}))&&(n=!0),e.privacyButtonIsVisible&&n},e.prototype.resolveUiVariant=function(e){return S(this,void 0,void 0,(function(){return C(this,(function(t){switch(t.label){case 0:return null!==this.variant?[2,this.variant]:[4,this.settingsV2.isCcpaAvailable()];case 1:return t.sent()?this.variant=0:this.variant=e?2:1,[2,this.variant]}}))}))},e.prototype.resolveUiInitialLayer=function(e){return S(this,void 0,void 0,(function(){return C(this,(function(t){switch(t.label){case 0:return[4,this.shouldShowNone()];case 1:return t.sent()?[2,1]:[4,this.shouldShowFirstLayer(e)];case 2:return t.sent()?[2,0]:this.shouldShowPrivacyButton(e)?[2,2]:[2,1]}}))}))},e.prototype.resolveUIOptions=function(e){return S(this,void 0,void 0,(function(){var t,n,i;return C(this,(function(s){switch(s.label){case 0:return t=this.ampInstance.isAmpEnabled(),null!==this.variant?[3,2]:(n=this,[4,this.resolveUiVariant(e.tcf2Enabled)]);case 1:n.variant=s.sent(),s.label=2;case 2:return 0!==this.variant&&tt.clearCcpa(),2!==this.variant&&tt.clearTcf(),i=this,[4,this.resolveUiInitialLayer(e)];case 3:return i.selectedLayer=s.sent(),[2,{ampEnabled:t,initialLayer:this.selectedLayer,variant:this.variant}]}}))}))},e.prototype.shouldShowFirstLayerForCcpa=function(e){void 0===e&&(e=365);var t,n=this.settingsV2.legacySettings;return!!n&&(n.ccpa.reshowCMP&&((t=tt.getCcpaData())?((new Date).getTime()-t.timestamp)/864e5:0)>e)},e}(),Tn=function(e,t){console.warn("".concat(e," is deprecated. Please use ").concat(t," instead."))},In=Object.freeze({initialize:function({modulePath:e=".",importFunctionName:t="__import__"}={}){try{self[t]=new Function("u","return import(u)")}catch(n){const i=new URL(e,location),s=e=>{URL.revokeObjectURL(e.src),e.remove()};self[t]=e=>new Promise(((n,o)=>{const r=new URL(e,i);if(self[t].moduleMap[r])return n(self[t].moduleMap[r]);const a=new Blob([`import * as m from '${r}';`,`${t}.moduleMap['${r}']=m;`],{type:"text/javascript"}),c=Object.assign(document.createElement("script"),{type:"module",src:URL.createObjectURL(a),onerror(){o(new Error(`Failed to import: ${e}`)),s(c)},onload(){n(self[t].moduleMap[r]),s(c)}});document.head.appendChild(c)})),self[t].moduleMap={}}}}),An=function(e){if(e&&e.source&&e.source.postMessage){var t="string"==typeof e.data,n=e.data;if(t)try{n=JSON.parse(e.data)}catch(e){return}if("object"===i(n)&&n.__tcfapiCall){var s=n.__tcfapiCall;window.__tcfapi(s.command,s.version,(function(n,i){var o={__tcfapiReturn:{returnValue:n,success:i,callId:s.callId}},r=t?JSON.stringify(o):o;try{e.source.postMessage(r,"*")}catch(e){}}),s.parameter)}}},xn=[],Nn=function(e,t,n,i){if(!e)return xn;switch(e){case"ping":"function"==typeof n&&n(!0,!1,"stub");break;case"pending":return xn;default:xn.push([e,t,n,i])}},Ln=function(){"undefined"!=typeof window&&(window.__tcfapi||!function(){for(var e=window,t=!1;e;){try{if(e.frames.__tcfapiLocator){t=!0;break}}catch(e){}if(e===window.top){t=!1;break}e=e.parent}return t}()&&(q((function(){return!!window.document.body}),"").then((function(){var e=window.document.createElement("iframe");e.style.cssText="display:none",e.name="__tcfapiLocator",window.document.body.appendChild(e)})),1)&&(window.addEventListener("message",An,!1),window.__tcfapi=Nn))};!function(e){e.ACCEPT_ALL_SERVICES="onAcceptAllServices",e.DENY_ALL_SERVICES="onDenyAllServices",e.ESSENTIAL_CHANGE="onEssentialChange",e.INITIAL_PAGE_LOAD="onInitialPageLoad",e.NON_EU_REGION="onNonEURegion",e.SESSION_RESTORED="onSessionRestored",e.TCF_STRING_CHANGE="onTcfStringChange",e.UPDATE_SERVICES="onUpdateServices",e.MOBILE_SESSION_RESTORED="onMobileSessionRestore"}(Mt||(Mt={})),function(e){e.EXPLICIT="explicit",e.IMPLICIT="implicit"}(Bt||(Bt={})),function(e){e[e.UNDEFINED=0]="UNDEFINED",e[e.CMP_SHOWN=1]="CMP_SHOWN",e[e.ACCEPT_ALL=2]="ACCEPT_ALL",e[e.DENY_ALL=3]="DENY_ALL",e[e.SAVE=4]="SAVE",e[e.ACCEPT_ALL_L1=5]="ACCEPT_ALL_L1",e[e.DENY_ALL_L1=6]="DENY_ALL_L1",e[e.SAVE_L1=7]="SAVE_L1",e[e.ACCEPT_ALL_L2=8]="ACCEPT_ALL_L2",e[e.DENY_ALL_L2=9]="DENY_ALL_L2",e[e.SAVE_L2=10]="SAVE_L2",e[e.COOKIE_POLICY_LINK=11]="COOKIE_POLICY_LINK",e[e.IMPRINT_LINK=12]="IMPRINT_LINK",e[e.MORE_INFORMATION_LINK=13]="MORE_INFORMATION_LINK",e[e.PRIVACY_POLICY_LINK=14]="PRIVACY_POLICY_LINK",e[e.CCPA_TOGGLES_ON=15]="CCPA_TOGGLES_ON",e[e.CCPA_TOGGLES_OFF=16]="CCPA_TOGGLES_OFF"}($t||($t={})),function(e){e.API_NAME="__uspapi",e.GET_USP_DATA="getUSPData"}(jt||(jt={})),function(e){e[e.FIRST_LAYER=0]="FIRST_LAYER",e[e.NONE=1]="NONE",e[e.PRIVACY_BUTTON=2]="PRIVACY_BUTTON",e[e.SECOND_LAYER=3]="SECOND_LAYER"}(Ht||(Ht={})),function(e){e[e.CCPA=0]="CCPA",e[e.DEFAULT=1]="DEFAULT",e[e.TCF=2]="TCF"}(Gt||(Gt={})),void 0!==In&&In.initialize({modulePath:"/dir"});var kn=function(){function e(e,t){var n;if(this.ampInstance=Ee.getInstance(),this.apiInstance=_t.getInstance(),this.botInstance=Et.getInstance(),this.controllerIdInstance=ft.getInstance(),this.dataFacadeInstance=pn.getInstance(),this.eventDispatcherInstance=At.getInstance(),this.initOptions={},this.languageInstance=mn.getInstance(),this.locationInstance=en.getInstance(),this.settingsV2=hn.getInstance(),this.uiInstance=En.getInstance(),this.domains=null,this.rulesetRule={noShow:!0,settingsId:""},t&&(this.initOptions=t),this.apiInstance.setEuMode(!0===(null==t?void 0:t.euMode)),this.domains=(n=window.UC_UI_DOMAINS)?Object.entries(n).reduce((function(e,t){var n,i,s=t[0],o=t[1];return"/"===o.slice(-1)?y(y({},e),((n={})[s]=o.slice(0,-1),n)):y(y({},e),((i={})[s]=o,i))}),{aggregator:"",app:"",cdn:"",consents:"",crossDomainConsentSharingIFrame:"",graphql:"",trackingEvent:""}):null,this.apiInstance.setDomains(!0===(null==t?void 0:t.sandboxEnv),this.domains),(null==t?void 0:t.createTcfApiStub)&&(this.apiInstance.fetchUserCountry(),Ln()),(null==t?void 0:t.useRulesetId)?this.apiInstance.setRulesetId(e):this.apiInstance.setSettingsId(e),this.controllerIdInstance.value="",(null==t?void 0:t.controllerId)&&(this.controllerIdInstance.value=t.controllerId),(null==t?void 0:t.language)&&this.languageInstance.setPrimaryLanguage(t.language),(null==t?void 0:t.settingsCache)&&this.apiInstance.setJsonCacheBustingString(t.settingsCache),(null==t?void 0:t.version)&&this.apiInstance.setJsonFileVersion(t.version),(null==t?void 0:t.userCountryData)&&"object"===i(t.userCountryData)&&Object.keys(t.userCountryData).every((function(e){return"string"==typeof e}))&&this.locationInstance.setUserCountryData(t.userCountryData),(null==t?void 0:t.userSessionData)&&this.dataFacadeInstance.setUserSessionData(t.userSessionData),(null==t?void 0:t.ampEnabled)&&this.ampInstance.setIsAmpEnabled(!0),(null==t?void 0:t.blockDataLayerPush)&&this.eventDispatcherInstance.setBlockDataLayerPush(!0),(null==t?void 0:t.storeServiceIdToNameMapping)&&(Storage.prototype.storeServiceIdToNameMapping=!0),(null==t?void 0:t.useOnlySettingsV2)&&(this.initOptions.useOnlySettingsV2=!0),(null==t?void 0:t.disableTracking)&&(this.initOptions.disableTracking=!0),(null==t?void 0:t.disableServerConsents)&&this.apiInstance.setDisableServerConsents(!0),(null==t?void 0:t.disableServerConsents)&&(null==t?void 0:t.controllerId))throw new Error("Usercentrics: disableServerConsents and controllerId should not be present at the same time in the InitOptions!");this.initOptions.prefetchServices=k(null==t?void 0:t.prefetchServices,!0),this.setTrackingPixel=this.setTrackingPixel.bind(this)}return e.prototype.init=function(){return S(this,void 0,void 0,(function(){var e,t,i,s,o,r,a,c,l,d,u,h,p,f,g=this;return C(this,(function(v){switch(v.label){case 0:return tt.getInstance().init(),this.apiInstance.getRulesetId()?(e=this,[4,wn.getInstance().resolveSettingsId()]):[3,2];case 1:e.rulesetRule=v.sent(),this.apiInstance.setSettingsId(this.rulesetRule.settingsId),v.label=2;case 2:return tt.clearOnNewSettingsId(this.apiInstance.getSettingsId()),tt.migrateLegacySettings(this.apiInstance.getSettingsId()),this.controllerIdInstance.init(),[4,this.languageInstance.resolveLanguage()];case 3:v.sent(),t=null,i=null,s=null,o=function(){return S(g,void 0,void 0,(function(){return C(this,(function(e){return s?[2,s]:[2,this.loadSettings()]}))}))},v.label=4;case 4:return v.trys.push([4,7,,9]),[4,this.apiInstance.fetchDpsJson()];case 5:return i=v.sent(),[4,this.apiInstance.fetchCoreJson()];case 6:return t=v.sent(),[3,9];case 7:return v.sent(),[4,o()];case 8:return s=v.sent(),t=function(e){return{buttonDisplayLocation:e.buttonDisplayLocation,buttonPrivacyCloseIcon:e.buttonPrivacyCloseIcon,buttonPrivacyOpenIconUrl:e.buttonPrivacyOpenIconUrl,ccpa:(i=e.ccpa,{iabAgreementExists:i.iabAgreementExists,isActive:i.isActive,region:i.region,reshowAfterDays:i.reshowAfterDays,showOnPageLoad:i.showOnPageLoad}),consentSharingIFrameIsActive:e.consentSharingIFrameIsActive,customization:(n=e.customization,n?{color:n.color?{primary:n.color.primary,privacyButtonBackground:n.color.privacyButtonBackground,privacyButtonIcon:n.color.privacyButtonIcon}:null}:n),dataExchangeOnPage:e.dataExchangeOnPage,displayOnlyForEU:e.displayOnlyForEU,enableBotDetection:e.enableBotDetection,googleConsentMode:e.googleConsentMode,interactionAnalytics:e.interactionAnalytics,languagesAvailable:e.languagesAvailable,privacyButtonIsVisible:e.privacyButtonIsVisible,privacyButtonUrls:e.privacyButtonUrls,reshowBanner:e.reshowBanner,settingsId:e.settingsId,showInitialViewForVersionChange:e.showInitialViewForVersionChange,tagLoggerIsActive:e.tagLoggerIsActive,tcf2:(t=e.tcf2,{resurfaceIABLegalBasisChanged:t.resurfaceIABLegalBasisChanged,resurfacePeriodEnded:t.resurfacePeriodEnded,resurfacePurposeChanged:t.resurfacePurposeChanged,resurfaceVendorAdded:t.resurfaceVendorAdded}),tcf2Enabled:e.tcf2Enabled,version:e.version};var t,n,i}(s),i=we(s),[3,9];case 9:if(!t||!i)throw new Error;return this.botInstance.isBotEnabled=t.enableBotDetection,!t.consentSharingIFrameIsActive||this.botInstance.isRobot()?[3,11]:[4,Ye.init({useEuCdn:this.initOptions.euMode||!1},this.domains).then((function(){return S(g,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return Ye.setCrossDomainId(this.apiInstance.getSettingsId()),Ye.setIsCrossDomainAvailable(!0),Ye.setUseEuCdn(this.initOptions.euMode||!1),this.languageInstance.getPrimaryLanguage()?[3,3]:[4,Ye.getCrossDomainLanguage().catch((function(){return console.warn(Fe.CROSS_DOMAIN_LANGUAGE_NOT_AVAILABLE),""}))];case 1:return e=t.sent(),[4,this.changeLanguage(e)];case 2:t.sent(),t.label=3;case 3:return[2]}}))}))})).catch((function(e){Ye.setIsCrossDomainAvailable(!1),Ye.removeIFrame("uc-cross-domain-bridge"),console.warn(Fe.CROSS_DOMAIN_FEATURE_NOT_AVAILABLE,e)}))];case 10:v.sent(),v.label=11;case 11:return this.botInstance.isRobot()?this.initOptions.suppressCmpDisplay=!0:this.initOptions.disableTracking||this.addTrackingPixel(this.apiInstance.getSettingsId(),!0===this.initOptions.euMode),r=this.initOptions.useOnlySettingsV2,a=this.apiInstance.getJsonFileLanguage(),[4,this.settingsV2.init(t,i,a)];case 12:return v.sent(),[4,this.uiInstance.resolveUiVariant(t.tcf2Enabled)];case 13:return c=v.sent(),r?[3,15]:[4,o()];case 14:return s=v.sent(),[3,16];case 15:this.dataFacadeInstance.useOnlySettingsV2=r,v.label=16;case 16:return[4,this.settingsV2.initData(c,[],!1,!0===this.initOptions.euMode)];case 17:return v.sent(),[4,this.apiInstance.fetchTranslations()];case 18:return l=v.sent(),!this.initOptions.prefetchServices&&this.settingsV2.allLegacyServicesHaveName?[3,20]:[4,this.settingsV2.extendServices(c,l)];case 19:return v.sent(),this.apiInstance.resetAggregatedServicesCache(),[3,21];case 20:this.settingsV2.initLabels(c,l),v.label=21;case 21:return[4,this.dataFacadeInstance.restoreUserSession(i)];case 22:return d=v.sent(),[4,this.uiInstance.init(this.initOptions)];case 23:return v.sent(),u=this.settingsV2.getTcfData(),re(this.settingsV2.data)&&u?[4,this.settingsV2.data.init(!0===this.initOptions.euMode)]:[3,25];case 24:v.sent(),v.label=25;case 25:return h=[],tt.settingsExist()&&(h=this.processStorageServicesAndSettings(this.settingsV2.data)),[4,this.uiInstance.resolveUIOptions(t)];case 26:return p=v.sent(),f=p.initialLayer,[4,this.settingsV2.initUI(f,c)];case 27:return v.sent(),u?0!==f||this.botInstance.isRobot()?[3,29]:[4,u.setUIAsOpen()]:[3,31];case 28:return v.sent(),[3,31];case 29:return[4,u.setUIAsClosed()];case 30:v.sent(),v.label=31;case 31:return this.botInstance.isRobot()||2!==c?[3,33]:[4,o()];case 32:s=v.sent(),v.label=33;case 33:return!this.settingsV2.isTagLoggerActive()||this.botInstance.isRobot()?[3,35]:[4,n.e(2659).then(n.bind(n,2659)).then((function(e){(new(0,e.default)).initTagLogger()}))];case 34:v.sent(),v.label=35;case 35:return this.eventDispatcherInstance.init(this.settingsV2.getDataExchangeSettings()),[4,this.updateStorage(h,d)];case 36:return v.sent(),[2,p]}}))}))},e.prototype.acceptAllForTCF=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return(t=this.settingsV2.getTcfData())?[4,t.acceptAllDisclosed(e)]:[3,2];case 1:n.sent(),n.label=2;case 2:return[2]}}))}))},e.prototype.acceptAllServices=function(e){return void 0===e&&(e="explicit"),S(this,void 0,void 0,(function(){return C(this,(function(t){switch(t.label){case 0:return this.dataFacadeInstance.execute(this.settingsV2.getUpdatedServicesWithConsent(l.TRUE),this.settingsV2.getUpdatedServicesDataWithConsent(l.TRUE),"onAcceptAllServices",e),[4,this.saveUserActionPerformed()];case 1:return t.sent(),[2]}}))}))},e.prototype.changeLanguage=function(e){var t;return S(this,void 0,void 0,(function(){var n,i,s,o,r,a,c,l,d,u,h,p,f,g,v,_,b;return C(this,(function(m){switch(m.label){case 0:return n=null===(t=this.settingsV2.core)||void 0===t?void 0:t.language.available,i=n&&n.some((function(t){return t===e})),s=e!==this.apiInstance.getJsonFileLanguage()&&i,o=this.settingsV2,r=o.core,a=o.data,s&&a&&r?(this.apiInstance.setJsonFileLanguage(e),this.apiInstance.resetTranslationsCache(),this.settingsV2.language=e,[4,this.loadSettings()]):[3,12];case 1:c=m.sent(),l=null,m.label=2;case 2:return m.trys.push([2,4,,5]),[4,this.apiInstance.fetchDpsJson()];case 3:return l=m.sent(),[3,5];case 4:return m.sent(),l=we(c),[3,5];case 5:return this.settingsV2.dpsJson=l,d=this.uiInstance,u=d.selectedLayer,h=d.variant,[4,this.apiInstance.fetchTranslations()];case 6:return p=m.sent(),null===h||null===u||null==l?[3,10]:!this.settingsV2.isAggregatorLoaded&&this.settingsV2.checkIfServiceNameExists(l.consentTemplates)?[3,8]:[4,this.settingsV2.extendServices(h,p)];case 7:return m.sent(),[3,9];case 8:this.settingsV2.initLabels(h,p),m.label=9;case 9:this.apiInstance.resetAggregatedServicesCache(),m.label=10;case 10:return this.settingsV2.updateServicesLanguage(e),f=this.dataFacadeInstance.getMergedServicesAndSettingsFromStorage(a),g=f.mergedServicesV2,v=f.mergedServicesData,_=f.mergedSettingsData,r.language.selected=e,_.categories=this.settingsV2.mergeServicesDataIntoExistingCategories(v),this.settingsV2.data=_,(b=this.settingsV2.getDataTransferSettings())&&tt.saveSettings(tt.mapSettings(b,g),g),re(_)?[4,_.changeLanguage(e)]:[3,12];case 11:m.sent(),m.label=12;case 12:return[2]}}))}))},e.prototype.denyAllForTCF=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return(t=this.settingsV2.getTcfData())?[4,t.denyAllDisclosed(e)]:[3,2];case 1:n.sent(),n.label=2;case 2:return[2]}}))}))},e.prototype.denyAllServices=function(e){return void 0===e&&(e="explicit"),S(this,void 0,void 0,(function(){return C(this,(function(t){switch(t.label){case 0:return this.dataFacadeInstance.execute(this.settingsV2.getUpdatedServicesWithConsent(l.FALSE),this.settingsV2.getUpdatedServicesDataWithConsent(l.FALSE),"onDenyAllServices",e),[4,this.saveUserActionPerformed()];case 1:return t.sent(),[2]}}))}))},e.prototype.fetchIsUserInEU=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){return[2,this.locationInstance.getIsUserInEU()]}))}))},e.prototype.fetchUserCountry=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){return[2,this.locationInstance.getUserCountryData()]}))}))},e.prototype.getAbTestVariant=function(){return this.apiInstance.getAbTestVariant()},e.prototype.getCategories=function(){return this.initOptions.prefetchServices||Tn("getCategories","getCategoriesBaseInfo or getCategoriesFullInfo"),this.settingsV2.getCategoriesDataAndLabels()},e.prototype.getCategoriesBaseInfo=function(){return this.settingsV2.getCategoriesBaseInfo()},e.prototype.getCategoriesFullInfo=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return[4,this.apiInstance.fetchTranslations()];case 1:return e=t.sent(),[2,this.settingsV2.getCategoriesFullInfo(this.uiInstance.variant,e)]}}))}))},e.prototype.getCcpaOptOutStatus=function(){var e;return(null===(e=this.settingsV2.getCcpaData())||void 0===e?void 0:e.getIsOptedOut())||!1},e.prototype.saveOptOutForCcpa=function(e,t){return void 0===t&&(t="explicit"),S(this,void 0,void 0,(function(){var n,i;return C(this,(function(s){switch(s.label){case 0:return(n=this.settingsV2.getCcpaData())&&n.getIsOptedOut()!==e?(n.setCcpaStorage(e),i={consentAction:e?"onDenyAllServices":"onAcceptAllServices",consentStatus:e?l.FALSE:l.TRUE,consentString:{CCPA:tt.getCcpaString()}},this.dataFacadeInstance.execute(this.settingsV2.getUpdatedServicesWithConsent(i.consentStatus),this.settingsV2.getUpdatedServicesDataWithConsent(i.consentStatus),i.consentAction,t,i.consentString),[4,this.saveUserActionPerformed()]):[2];case 1:return s.sent(),[2]}}))}))},e.prototype.saveDefaultForCcpa=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return tt.setCcpaTimeStamp(),[4,this.saveUserActionPerformed()];case 1:return e.sent(),[2]}}))}))},e.prototype.getControllerId=function(){return this.controllerIdInstance.value},e.prototype.getServices=function(){return this.initOptions.prefetchServices||Tn("getServices","getServicesBaseInfo or getServicesFullInfo"),this.settingsV2.getServicesDataAndLabels()},e.prototype.getServicesBaseInfo=function(){return this.settingsV2.getServicesBaseInfo()},e.prototype.getServicesFullInfo=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return[4,this.apiInstance.fetchTranslations()];case 1:return e=t.sent(),[2,this.settingsV2.getServicesFullInfo(this.uiInstance.variant,e)]}}))}))},e.prototype.getSettings=function(){var e=this;Tn("getSettings","getSettingsCore and getControllerId");var t=this.settingsV2,n=t.core,i=t.data,s=t.legacySettings,o=t.translations;if(!n||!i||!s)throw new Error;return n&&i?{controllerId:i.controllerId,googleConsentMode:n.googleConsentMode,id:n.id,isCcpaEnabled:n.isCcpaEnabled,isTcfEnabled:n.isTcfEnabled,reshowBanner:n.reshowBanner,ui:function(){switch(e.uiInstance.variant){case 0:return function(e,t,n){return y(y({},Se(e,t)),{ariaLabels:be,buttons:{optOutNotice:{isHidden:t.ccpa.removeDoNotSellToggle,label:t.ccpa.optOutNoticeLabel||"Do not sell my personal information"},save:{label:t.ccpa.btnSave||"okay"},showSecondLayer:{isEnabled:!0,label:t.labels.btnMore,url:t.moreInfoButtonUrl||null}},firstLayer:{description:{default:t.ccpa.firstLayerDescription||"",short:t.ccpa.firstLayerMobileDescription||"",shortDesktop:t.ccpa.firstLayerShortMessage||"",shortMobile:t.ccpa.firstLayerMobileDescription||"",showShortDescriptionOnDesktop:!0===t.ccpa.firstLayerUseShortMessage,showShortDescriptionOnMobile:t.ccpa.firstLayerMobileDescriptionIsActive},isLanguageSelectorEnabled:!Y(t.ccpa.firstLayerHideLanguageSwitch,!t.showLanguageDropdown),isOverlayEnabled:Z(t),title:t.ccpa.firstLayerTitle||"",variant:t.ccpa.firstLayerVariant||"BANNER"},labels:ye(t,n),secondLayer:{description:t.ccpa.secondLayerDescription||"",isLanguageSelectorEnabled:!Y(t.ccpa.secondLayerHideLanguageSwitch,!t.showLanguageDropdown),isOverlayEnabled:ee(t),side:t.ccpa.secondLayerSide||"LEFT",tabs:{categories:{isEnabled:k(t.secondLayer.tabsCategoriesIsEnabled,!0),label:t.secondLayer.tabsCategoriesLabel},services:{isEnabled:k(t.secondLayer.tabsServicesIsEnabled,!0),label:t.secondLayer.tabsServicesLabel}},title:t.ccpa.secondLayerTitle||"",variant:t.ccpa.secondLayerVariant||"CENTER"}})}(n,s,o);case 2:return function(e,t,n){return y(y({},Se(e,t)),{ariaLabels:be,buttons:{acceptAll:{label:t.tcf2.buttonsAcceptAllLabel},denyAll:{isEnabled:t.tcf2.buttonsDenyAllIsEnabled,label:t.tcf2.buttonsDenyAllLabel},manageSettings:{label:t.tcf2.linksManageSettingsLabel},save:{isEnabled:!t.tcf2.firstLayerHideToggles||!t.tcf2.secondLayerHideToggles,label:t.tcf2.buttonsSaveLabel},showVendorTab:{label:t.tcf2.linksVendorListLinkLabel}},firstLayer:{description:{additionalInfo:t.tcf2.firstLayerAdditionalInfo||null,default:t.tcf2.firstLayerDescription,resurfaceNote:t.tcf2.firstLayerNoteResurface||null},disclaimer:{serviceScope:t.tcf2.firstLayerNoteService},hideButtonDeny:Y(t.tcf2.firstLayerHideButtonDeny,!t.tcf2.buttonsDenyAllIsEnabled),hideNonIabPurposes:t.tcf2.hideNonIabOnFirstLayer,hideToggles:t.tcf2.firstLayerHideToggles,isOverlayEnabled:Z(t),showDescriptions:t.tcf2.firstLayerShowDescriptions,title:t.tcf2.firstLayerTitle},labels:Ce(t,t.tcf2,n),secondLayer:{description:t.tcf2.secondLayerDescription,hideButtonDeny:Y(t.tcf2.secondLayerHideButtonDeny,!t.tcf2.buttonsDenyAllIsEnabled),hideLegitimateInterestToggles:t.tcf2.hideLegitimateInterestToggles,hideToggles:t.tcf2.secondLayerHideToggles,isOverlayEnabled:ee(t),showToggleAllVendors:t.tcf2.vendorToggleAll,tabs:{purposes:{label:t.tcf2.tabsPurposeLabel},vendors:{label:t.tcf2.tabsVendorsLabel}},title:t.tcf2.secondLayerTitle},toggles:{consent:{label:t.tcf2.togglesConsentToggleLabel},legitimateInterest:{label:t.tcf2.togglesLegIntToggleLabel},specialFeaturesToggle:{offLabel:t.tcf2.togglesSpecialFeaturesToggleOff,onLabel:t.tcf2.togglesSpecialFeaturesToggleOn}}})}(n,s,o);default:return function(e,t,n){return y(y({},Se(e,t)),{ariaLabels:be,buttons:{acceptAll:{label:t.labels.btnAcceptAll},denyAll:{isEnabled:t.btnDenyIsVisible,label:t.labels.btnDeny},save:{label:t.labels.btnSave},showSecondLayer:{isEnabled:!0,label:t.labels.btnMore,url:t.moreInfoButtonUrl||null}},firstLayer:{description:{default:t.bannerMessage||"",short:t.bannerMobileDescription||"",shortDesktop:t.firstLayer.shortMessage||"",shortMobile:t.bannerMobileDescription||"",showShortDescriptionOnDesktop:!0===t.firstLayer.useShortMessage,showShortDescriptionOnMobile:t.bannerMobileDescriptionIsActive},hideButtonDeny:Y(t.firstLayer.hideButtonDeny,!t.btnDenyIsVisible),isCategoryTogglesEnabled:t.firstLayer.isCategoryTogglesEnabled,isLanguageSelectorEnabled:!Y(t.firstLayer.hideLanguageSwitch,!t.showLanguageDropdown),isOverlayEnabled:Z(t),showCnilDenyLink:t.firstLayer.closeOption===G.LINK,title:k(t.labels.firstLayerTitle,"Privacy Settings"),variant:k(t.firstLayer.variant,"BANNER")},labels:ye(t,n),secondLayer:{description:t.labels.titleCorner,hideButtonDeny:Y(t.secondLayer.hideButtonDeny,!t.btnDenyIsVisible),hideTogglesForServices:k(t.secondLayer.hideTogglesForServices,!1),isLanguageSelectorEnabled:!Y(t.secondLayer.hideLanguageSwitch,!t.showLanguageDropdown),isOverlayEnabled:ee(t),side:t.secondLayer.side||"LEFT",tabs:{categories:{isEnabled:k(t.secondLayer.tabsCategoriesIsEnabled,!0),label:t.secondLayer.tabsCategoriesLabel},services:{isEnabled:k(t.secondLayer.tabsServicesIsEnabled,!0),label:t.secondLayer.tabsServicesLabel}},title:t.labels.headerCorner,variant:t.secondLayer.variant||"CENTER"}})}(n,s,o)}}(),version:n.version}:{}},e.prototype.getSettingsCore=function(){var e=this.settingsV2.core;if(!e)throw new Error("Usercentrics: You have to call the init method before!");return e},e.prototype.getSettingsLabels=function(){var e=this.settingsV2.labels;if(!e)throw new Error("Usercentrics: You have to call the init method before!");return e},e.prototype.getSettingsData=function(){var e=this.settingsV2.data;if(!e)throw new Error("Usercentrics: You have to call the init method before!");return e},e.prototype.getSettingsUI=function(){var e=this.settingsV2.ui;if(!e)throw new Error("Usercentrics: You have to call the init method before!");return e},e.prototype.getAriaLabels=function(){var e;return(null===(e=this.settingsV2.labels)||void 0===e?void 0:e.ariaLabels)||be},e.prototype.getTCFData=function(){var e=this.settingsV2.getTcfData();return e?e.getTCFData():null},e.prototype.getTCFDisclosedVendorsSegmentString=function(){return this.settingsV2.getTCFDisclosedVendorsSegmentString()},e.prototype.injectTCString=function(e){return this.settingsV2.injectTCString(e)},e.prototype.setTCFUIAsClosed=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return(e=this.settingsV2.getTcfData())?[4,e.setUIAsClosed()]:[3,2];case 1:t.sent(),t.label=2;case 2:return[2]}}))}))},e.prototype.setTCFUIAsOpen=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return(e=this.settingsV2.getTcfData())?[4,e.setUIAsOpen()]:[3,2];case 1:t.sent(),t.label=2;case 2:return[2]}}))}))},e.prototype.updateChoicesForTCF=function(e,t){return S(this,void 0,void 0,(function(){var n;return C(this,(function(i){switch(i.label){case 0:return(n=this.settingsV2.getTcfData())?[4,n.updateChoices(e,t)]:[3,2];case 1:i.sent(),i.label=2;case 2:return[2]}}))}))},e.prototype.areAllConsentsAccepted=function(){return this.settingsV2.isTcfAvailable()?this.settingsV2.areAllVendorsAndPurposesAccepted()&&this.settingsV2.areAllServicesAccepted():this.settingsV2.areAllServicesAccepted()},e.prototype.restoreUserSession=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return this.controllerIdInstance.value=e,this.controllerIdInstance.needsSessionRestore=!0,this.settingsV2.setControllerId(e),(t=this.settingsV2.dpsJson)?[4,this.dataFacadeInstance.restoreUserSession(t)]:[3,2];case 1:n.sent()&&this.enableServicesScripts(this.processStorageServicesAndSettings(this.settingsV2.data),this.settingsV2.getGoogleConsentMode(),"onSessionRestored"),n.label=2;case 2:return[2]}}))}))},e.prototype.clearStorage=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return[4,tt.clearAll()];case 1:return e.sent(),[2]}}))}))},e.prototype.postMessageAmp=function(e,t,n){return S(this,void 0,void 0,(function(){var i,s,o,l,d,u,h,p,f=this;return C(this,(function(g){switch(g.label){case 0:return i=this.settingsV2.isTcfAvailable(),[4,this.settingsV2.isCcpaAvailable()];case 1:return s=g.sent(),o=function(){var e=f.settingsV2.getTcfData();return i&&(null==e?void 0:e.getTCString)?e.getTCString():s?tt.getCcpaString():""},l=function(){return S(f,void 0,void 0,(function(){var e,t,n,o;return C(this,(function(r){switch(r.label){case 0:return o=this.settingsV2.getTcfData(),i&&o?(e=c.TCF_V2,[4,o.getGdprApplies()]):[3,2];case 1:return t=r.sent(),n=this.settingsV2.getTCFPurposeOneTreatment(),[3,3];case 2:s&&(e=c.CCPA),r.label=3;case 3:return[2,y({consentStringType:e},i&&{gdprApplies:t,purposeOne:n})]}}))}))},u=[{action:t,type:e}],(h=e===r.CONSENT_RESPONSE&&t!==a.DISMISS&&(s||i))?(p={},[4,l()]):[3,3];case 2:p.consentMetadata=g.sent(),p.info=o(),h=p,g.label=3;case 3:return d=y.apply(void 0,[y.apply(void 0,u.concat([h])),n&&{initialHeight:n}]),[2,new Promise((function(e,t){try{window.parent.postMessage(y({},d),"*"),e()}catch(e){t(e)}}))]}}))}))},e.prototype.acceptAllAmp=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return[4,this.postMessageAmp(r.CONSENT_RESPONSE,a.ACCEPT)];case 1:return e.sent(),[2]}}))}))},e.prototype.denyAllAmp=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return[4,this.postMessageAmp(r.CONSENT_RESPONSE,a.REJECT)];case 1:return e.sent(),[2]}}))}))},e.prototype.saveTCFDataAmp=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return t=e.every((function(e){return e.status})),0===e.length||t?[4,this.postMessageAmp(r.CONSENT_RESPONSE,a.ACCEPT)]:[3,2];case 1:return n.sent(),[3,4];case 2:return[4,this.postMessageAmp(r.CONSENT_RESPONSE,a.REJECT)];case 3:n.sent(),n.label=4;case 4:return[2]}}))}))},e.prototype.dismissAmp=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return[4,this.postMessageAmp(r.CONSENT_RESPONSE,a.DISMISS)];case 1:return e.sent(),[2]}}))}))},e.prototype.enterFullscreenAmp=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){return[2,this.postMessageAmp(r.CONSENT_UI,a.FULLSCREEN)]}))}))},e.prototype.uiReadyAmp=function(){return S(this,void 0,void 0,(function(){var e,t,n;return C(this,(function(i){return e=this.settingsV2.labels,t="60vh",e&&(n=e.firstLayer.description.default.length,window.screen.height>700&&n<=250&&(t="50vh")),[2,this.postMessageAmp(r.CONSENT_UI,a.READY,t)]}))}))},e.prototype.saveUserActionPerformed=function(){return S(this,void 0,void 0,(function(){return C(this,(function(e){switch(e.label){case 0:return tt.setUserActionPerformed(),this.uiInstance.selectedLayer?[4,this.settingsV2.initUI(this.uiInstance.selectedLayer,this.uiInstance.variant)]:[3,2];case 1:e.sent(),e.label=2;case 2:return[2]}}))}))},e.prototype.updateServices=function(e,t){return void 0===t&&(t="explicit"),S(this,void 0,void 0,(function(){var n,i;return C(this,(function(s){switch(s.label){case 0:return n=this.settingsV2.getUpdatedServicesWithDecisions(e),i=this.settingsV2.getUpdatedServicesDataWithDecisions(e),N(n)&&this.dataFacadeInstance.execute(n,i,"onUpdateServices",t),[4,this.saveUserActionPerformed()];case 1:return s.sent(),[2]}}))}))},e.prototype.updateLayer=function(e){return S(this,void 0,void 0,(function(){var t;return C(this,(function(n){switch(n.label){case 0:return t=this.uiInstance.selectedLayer,this.uiInstance.selectedLayer=e,e===t?[2]:[4,this.settingsV2.initUI(e,this.uiInstance.variant)];case 1:return n.sent(),3!==e?[3,3]:[4,this.loadServices()];case 2:n.sent(),n.label=3;case 3:return[2]}}))}))},e.prototype.loadServices=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return this.settingsV2.isAggregatorLoaded||!this.uiInstance.selectedLayer?[2]:[4,this.apiInstance.fetchTranslations()];case 1:return e=t.sent(),[4,this.settingsV2.extendServices(this.uiInstance.variant,e)];case 2:return t.sent(),this.apiInstance.resetAggregatedServicesCache(),[2]}}))}))},e.prototype.loadSettings=function(){return S(this,void 0,void 0,(function(){var e;return C(this,(function(t){switch(t.label){case 0:return[4,this.apiInstance.fetchSettingsJson()];case 1:return e=t.sent(),this.settingsV2.legacySettings=e,[2,e]}}))}))},e.prototype.updateStorage=function(e,t){return S(this,void 0,void 0,(function(){var n;return C(this,(function(i){switch(i.label){case 0:return this.uiInstance.isFirstTimeVisit()?[4,this.settingsV2.shouldAcceptAllImplicitlyOnInit()]:[3,2];case 1:return i.sent()?this.dataFacadeInstance.execute(this.settingsV2.getUpdatedServicesWithConsent(l.TRUE),this.settingsV2.getUpdatedServicesDataWithConsent(l.TRUE),"onNonEURegion",this.botInstance.isRobot()?"explicit":"implicit"):this.dataFacadeInstance.execute(this.settingsV2.getServicesDataAndLabels(),this.settingsV2.getServicesData(),"onInitialPageLoad","implicit"),[3,3];case 2:n=null!=e?e:this.processStorageServicesAndSettings(this.settingsV2.data),this.enableServicesScripts(n,this.settingsV2.getGoogleConsentMode(),t?this.dataFacadeInstance.restoreAction:"onInitialPageLoad"),i.label=3;case 3:return[2]}}))}))},e.prototype.enableScriptsForServicesWithConsent=function(){zt.enableScriptsForServicesWithConsent(this.settingsV2.getServicesWithConsent())},e.prototype.setTrackingPixel=function(e){var t;!this.initOptions.disableTracking&&(null===(t=this.settingsV2.coreJson)||void 0===t?void 0:t.interactionAnalytics)&&this.apiInstance.setTrackingPixel(e,this.getControllerId())},e.prototype.addTrackingPixel=function(e,t){void 0===t&&(t=!1);var n=new Image,i=this.domains&&""!==this.domains.app?"".concat(this.domains.app,"/session/1px.png"):"https://app.usercentrics.eu/session/1px.png",s=t?"https://app.eu.usercentrics.eu/session/1px.png":i;n.src="".concat(s,"?settingsId=").concat(e)},e.prototype.processStorageServicesAndSettings=function(e){if(!e)return[];var t=this.dataFacadeInstance.getMergedServicesAndSettingsFromStorage(e),n=t.dataTransferSettings,i=t.mergedServicesData,s=t.mergedServicesV2,o=t.updatedEssentialServicesV2;return this.dataFacadeInstance.mergeServicesAndSettings(s,i,n,o)},e.prototype.enableServicesScripts=function(e,t,n){zt.enableScriptsForServicesWithConsent(this.settingsV2.getServicesWithConsent()),this.eventDispatcherInstance.dispatch(e,t,n)},e}()},5512:(e,t,n)=>{var i={"./bg-BG.js":[7236,7236],"./bg.js":[1577,1577],"./cs-CZ.js":[9622,9622],"./cs.js":[3151,3151],"./de-DE.js":[1892,1892],"./de.js":[8976,8976],"./en-AU.js":[497,497],"./en-GB.js":[6033,6033],"./en-US.js":[2535,2535],"./en.js":[6797,6797],"./es-ES.js":[1974,1974],"./es.js":[2729,2729],"./fr-BE.js":[7658,7658],"./fr-FR.js":[5433,5433],"./fr.js":[2781,2781],"./hu-HU.js":[7638,7638],"./hu.js":[5859,5859],"./it-IT.js":[8363,8363],"./it.js":[4218,4218],"./nl-BE.js":[5222,5222],"./nl-NL.js":[9432,9432],"./nl.js":[9148,9148],"./pl-PL.js":[5235,5235],"./pl.js":[3457,3457],"./ro-RO.js":[4833,4833],"./ro.js":[6434,6434],"./ru-RU.js":[7049,7049],"./ru.js":[3637,3637],"./sk-SK.js":[537,537],"./sk.js":[8789,8789],"./uk-UA.js":[1921,1921],"./uk.js":[8567,8567],"./zh.js":[3122,3122]};function s(e){if(!n.o(i,e))return Promise.resolve().then((()=>{var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=i[e],s=t[0];return n.e(t[1]).then((()=>n(s)))}s.keys=()=>Object.keys(i),s.id=5512,e.exports=s},7731:(e,t,n)=>{var i={"./bg-BG.js":[7335,7335],"./bg.js":[6703,6703],"./cs-CZ.js":[715,715],"./cs.js":[1234,1234],"./de-DE.js":[1312,1312],"./de.js":[4412,4412],"./en-AU.js":[3026,3026],"./en-GB.js":[4711,4711],"./en-US.js":[3718,3718],"./en.js":[1673,1673],"./es-ES.js":[5650,5650],"./es.js":[6712,6712],"./fr-BE.js":[5112,5112],"./fr-FR.js":[2908,2908],"./fr.js":[1136,1136],"./hu-HU.js":[9695,9695],"./hu.js":[1089,1089],"./id-ID.js":[658,658],"./id.js":[6074,6074],"./it-IT.js":[6944,6944],"./it.js":[2734,2734],"./nl-BE.js":[4045,4045],"./nl-NL.js":[2522,2522],"./nl.js":[4875,4875],"./pl-PL.js":[1451,1451],"./pl.js":[7286,7286],"./ro-RO.js":[6483,6483],"./ro.js":[485,485],"./ru-RU.js":[4573,4573],"./ru.js":[479,479],"./sk-SK.js":[4051,4051],"./sk.js":[394,394],"./uk-UA.js":[3604,3604],"./uk.js":[3029,3029],"./zh.js":[5539,5539]};function s(e){if(!n.o(i,e))return Promise.resolve().then((()=>{var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=i[e],s=t[0];return n.e(t[1]).then((()=>n(s)))}s.keys=()=>Object.keys(i),s.id=7731,e.exports=s},6979:(e,t,n)=>{"use strict";n.d(t,{d:()=>s});const i=Symbol.for("lion::SingletonManagerClassStorage");const s=new class{constructor(){this._map=window[i]?window[i]:window[i]=new Map}set(e,t){this.has(e)||this._map.set(e,t)}get(e){return this._map.get(e)}has(e){return this._map.has(e)}}},641:()=>{},7206:(e,t,n)=>{"use strict";n.d(t,{oi:()=>N,iv:()=>A,$m:()=>I});var i=n(2105),s=n(4557);function o(e,t){const{element:{content:n},parts:i}=e,s=document.createTreeWalker(n,133,null,!1);let o=a(i),r=i[o],c=-1,l=0;const d=[];let u=null;for(;s.nextNode();){c++;const e=s.currentNode;for(e.previousSibling===u&&(u=null),t.has(e)&&(d.push(e),null===u&&(u=e)),null!==u&&l++;void 0!==r&&r.index===c;)r.index=null!==u?-1:r.index-l,o=a(i,o),r=i[o]}d.forEach((e=>e.parentNode.removeChild(e)))}const r=e=>{let t=11===e.nodeType?0:1;const n=document.createTreeWalker(e,133,null,!1);for(;n.nextNode();)t++;return t},a=(e,t=-1)=>{for(let n=t+1;n<e.length;n++){const t=e[n];if((0,s.pC)(t))return n}return-1};var c=n(8952),l=n(7630),d=n(1622);n(4971);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const u=(e,t)=>`${e}--${t}`;let h=!0;void 0===window.ShadyCSS?h=!1:void 0===window.ShadyCSS.prepareTemplateDom&&(console.warn("Incompatible ShadyCSS version detected. Please update to at least @webcomponents/webcomponentsjs@2.0.2 and @webcomponents/shadycss@1.3.1."),h=!1);const p=e=>t=>{const n=u(t.type,e);let i=l.r.get(n);void 0===i&&(i={stringsArray:new WeakMap,keyString:new Map},l.r.set(n,i));let o=i.stringsArray.get(t.strings);if(void 0!==o)return o;const r=t.strings.join(s.Jw);if(o=i.keyString.get(r),void 0===o){const n=t.getTemplateElement();h&&window.ShadyCSS.prepareTemplateDom(n,e),o=new s.YS(t,n),i.keyString.set(r,o)}return i.stringsArray.set(t.strings,o),o},f=["html","svg"],g=new Set,v=(e,t,n)=>{g.add(e);const i=n?n.element:document.createElement("template"),s=t.querySelectorAll("style"),{length:c}=s;if(0===c)return void window.ShadyCSS.prepareTemplateStyles(i,e);const d=document.createElement("style");for(let e=0;e<c;e++){const t=s[e];t.parentNode.removeChild(t),d.textContent+=t.textContent}(e=>{f.forEach((t=>{const n=l.r.get(u(t,e));void 0!==n&&n.keyString.forEach((e=>{const{element:{content:t}}=e,n=new Set;Array.from(t.querySelectorAll("style")).forEach((e=>{n.add(e)})),o(e,n)}))}))})(e);const h=i.content;n?function(e,t,n=null){const{element:{content:i},parts:s}=e;if(null==n)return void i.appendChild(t);const o=document.createTreeWalker(i,133,null,!1);let c=a(s),l=0,d=-1;for(;o.nextNode();)for(d++,o.currentNode===n&&(l=r(t),n.parentNode.insertBefore(t,n));-1!==c&&s[c].index===d;){if(l>0){for(;-1!==c;)s[c].index+=l,c=a(s,c);return}c=a(s,c)}}(n,d,h.firstChild):h.insertBefore(d,h.firstChild),window.ShadyCSS.prepareTemplateStyles(i,e);const p=h.querySelector("style");if(window.ShadyCSS.nativeShadow&&null!==p)t.insertBefore(p.cloneNode(!0),t.firstChild);else if(n){h.insertBefore(d,h.firstChild);const e=new Set;e.add(d),o(n,e)}};window.JSCompiler_renameProperty=(e,t)=>e;const _={toAttribute(e,t){switch(t){case Boolean:return e?"":null;case Object:case Array:return null==e?e:JSON.stringify(e)}return e},fromAttribute(e,t){switch(t){case Boolean:return null!==e;case Number:return null===e?null:Number(e);case Object:case Array:return JSON.parse(e)}return e}},b=(e,t)=>t!==e&&(t==t||e==e),m={attribute:!0,type:String,converter:_,reflect:!1,hasChanged:b},y="finalized";class S extends HTMLElement{constructor(){super(),this.initialize()}static get observedAttributes(){this.finalize();const e=[];return this._classProperties.forEach(((t,n)=>{const i=this._attributeNameForProperty(n,t);void 0!==i&&(this._attributeToPropertyMap.set(i,n),e.push(i))})),e}static _ensureClassProperties(){if(!this.hasOwnProperty(JSCompiler_renameProperty("_classProperties",this))){this._classProperties=new Map;const e=Object.getPrototypeOf(this)._classProperties;void 0!==e&&e.forEach(((e,t)=>this._classProperties.set(t,e)))}}static createProperty(e,t=m){if(this._ensureClassProperties(),this._classProperties.set(e,t),t.noAccessor||this.prototype.hasOwnProperty(e))return;const n="symbol"==typeof e?Symbol():`__${e}`,i=this.getPropertyDescriptor(e,n,t);void 0!==i&&Object.defineProperty(this.prototype,e,i)}static getPropertyDescriptor(e,t,n){return{get(){return this[t]},set(i){const s=this[e];this[t]=i,this.requestUpdateInternal(e,s,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this._classProperties&&this._classProperties.get(e)||m}static finalize(){const e=Object.getPrototypeOf(this);if(e.hasOwnProperty(y)||e.finalize(),this.finalized=!0,this._ensureClassProperties(),this._attributeToPropertyMap=new Map,this.hasOwnProperty(JSCompiler_renameProperty("properties",this))){const e=this.properties,t=[...Object.getOwnPropertyNames(e),..."function"==typeof Object.getOwnPropertySymbols?Object.getOwnPropertySymbols(e):[]];for(const n of t)this.createProperty(n,e[n])}}static _attributeNameForProperty(e,t){const n=t.attribute;return!1===n?void 0:"string"==typeof n?n:"string"==typeof e?e.toLowerCase():void 0}static _valueHasChanged(e,t,n=b){return n(e,t)}static _propertyValueFromAttribute(e,t){const n=t.type,i=t.converter||_,s="function"==typeof i?i:i.fromAttribute;return s?s(e,n):e}static _propertyValueToAttribute(e,t){if(void 0===t.reflect)return;const n=t.type,i=t.converter;return(i&&i.toAttribute||_.toAttribute)(e,n)}initialize(){this._updateState=0,this._updatePromise=new Promise((e=>this._enableUpdatingResolver=e)),this._changedProperties=new Map,this._saveInstanceProperties(),this.requestUpdateInternal()}_saveInstanceProperties(){this.constructor._classProperties.forEach(((e,t)=>{if(this.hasOwnProperty(t)){const e=this[t];delete this[t],this._instanceProperties||(this._instanceProperties=new Map),this._instanceProperties.set(t,e)}}))}_applyInstanceProperties(){this._instanceProperties.forEach(((e,t)=>this[t]=e)),this._instanceProperties=void 0}connectedCallback(){this.enableUpdating()}enableUpdating(){void 0!==this._enableUpdatingResolver&&(this._enableUpdatingResolver(),this._enableUpdatingResolver=void 0)}disconnectedCallback(){}attributeChangedCallback(e,t,n){t!==n&&this._attributeToProperty(e,n)}_propertyToAttribute(e,t,n=m){const i=this.constructor,s=i._attributeNameForProperty(e,n);if(void 0!==s){const e=i._propertyValueToAttribute(t,n);if(void 0===e)return;this._updateState=8|this._updateState,null==e?this.removeAttribute(s):this.setAttribute(s,e),this._updateState=-9&this._updateState}}_attributeToProperty(e,t){if(8&this._updateState)return;const n=this.constructor,i=n._attributeToPropertyMap.get(e);if(void 0!==i){const e=n.getPropertyOptions(i);this._updateState=16|this._updateState,this[i]=n._propertyValueFromAttribute(t,e),this._updateState=-17&this._updateState}}requestUpdateInternal(e,t,n){let i=!0;if(void 0!==e){const s=this.constructor;n=n||s.getPropertyOptions(e),s._valueHasChanged(this[e],t,n.hasChanged)?(this._changedProperties.has(e)||this._changedProperties.set(e,t),!0!==n.reflect||16&this._updateState||(void 0===this._reflectingProperties&&(this._reflectingProperties=new Map),this._reflectingProperties.set(e,n))):i=!1}!this._hasRequestedUpdate&&i&&(this._updatePromise=this._enqueueUpdate())}requestUpdate(e,t){return this.requestUpdateInternal(e,t),this.updateComplete}async _enqueueUpdate(){this._updateState=4|this._updateState;try{await this._updatePromise}catch(e){}const e=this.performUpdate();return null!=e&&await e,!this._hasRequestedUpdate}get _hasRequestedUpdate(){return 4&this._updateState}get hasUpdated(){return 1&this._updateState}performUpdate(){if(!this._hasRequestedUpdate)return;this._instanceProperties&&this._applyInstanceProperties();let e=!1;const t=this._changedProperties;try{e=this.shouldUpdate(t),e?this.update(t):this._markUpdated()}catch(t){throw e=!1,this._markUpdated(),t}e&&(1&this._updateState||(this._updateState=1|this._updateState,this.firstUpdated(t)),this.updated(t))}_markUpdated(){this._changedProperties=new Map,this._updateState=-5&this._updateState}get updateComplete(){return this._getUpdateComplete()}_getUpdateComplete(){return this._updatePromise}shouldUpdate(e){return!0}update(e){void 0!==this._reflectingProperties&&this._reflectingProperties.size>0&&(this._reflectingProperties.forEach(((e,t)=>this._propertyToAttribute(t,this[t],e))),this._reflectingProperties=void 0),this._markUpdated()}updated(e){}firstUpdated(e){}}S.finalized=!0;const C=Element.prototype;C.msMatchesSelector||C.webkitMatchesSelector;
/**
@license
Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/
const w=window.ShadowRoot&&(void 0===window.ShadyCSS||window.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,E=Symbol();class T{constructor(e,t){if(t!==E)throw new Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e}get styleSheet(){return void 0===this._styleSheet&&(w?(this._styleSheet=new CSSStyleSheet,this._styleSheet.replaceSync(this.cssText)):this._styleSheet=null),this._styleSheet}toString(){return this.cssText}}const I=e=>new T(String(e),E),A=(e,...t)=>{const n=t.reduce(((t,n,i)=>t+(e=>{if(e instanceof T)return e.cssText;if("number"==typeof e)return e;throw new Error(`Value passed to 'css' function must be a 'css' function result: ${e}. Use 'unsafeCSS' to pass non-literal values, but\n            take care to ensure page security.`)})(n)+e[i+1]),e[0]);return new T(n,E)};
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
(window.litElementVersions||(window.litElementVersions=[])).push("2.4.0");const x={};class N extends S{static getStyles(){return this.styles}static _getUniqueStyles(){if(this.hasOwnProperty(JSCompiler_renameProperty("_styles",this)))return;const e=this.getStyles();if(Array.isArray(e)){const t=(e,n)=>e.reduceRight(((e,n)=>Array.isArray(n)?t(n,e):(e.add(n),e)),n),n=t(e,new Set),i=[];n.forEach((e=>i.unshift(e))),this._styles=i}else this._styles=void 0===e?[]:[e];this._styles=this._styles.map((e=>{if(e instanceof CSSStyleSheet&&!w){const t=Array.prototype.slice.call(e.cssRules).reduce(((e,t)=>e+t.cssText),"");return I(t)}return e}))}initialize(){super.initialize(),this.constructor._getUniqueStyles(),this.renderRoot=this.createRenderRoot(),window.ShadowRoot&&this.renderRoot instanceof window.ShadowRoot&&this.adoptStyles()}createRenderRoot(){return this.attachShadow({mode:"open"})}adoptStyles(){const e=this.constructor._styles;0!==e.length&&(void 0===window.ShadyCSS||window.ShadyCSS.nativeShadow?w?this.renderRoot.adoptedStyleSheets=e.map((e=>e instanceof CSSStyleSheet?e:e.styleSheet)):this._needsShimAdoptedStyleSheets=!0:window.ShadyCSS.ScopingShim.prepareAdoptedCssText(e.map((e=>e.cssText)),this.localName))}connectedCallback(){super.connectedCallback(),this.hasUpdated&&void 0!==window.ShadyCSS&&window.ShadyCSS.styleElement(this)}update(e){const t=this.render();super.update(e),t!==x&&this.constructor.render(t,this.renderRoot,{scopeName:this.localName,eventContext:this}),this._needsShimAdoptedStyleSheets&&(this._needsShimAdoptedStyleSheets=!1,this.constructor._styles.forEach((e=>{const t=document.createElement("style");t.textContent=e.cssText,this.renderRoot.appendChild(t)})))}render(){return x}}N.finalized=!0,N.render=(e,t,n)=>{if(!n||"object"!=typeof n||!n.scopeName)throw new Error("The `scopeName` option is required.");const s=n.scopeName,o=c.L.has(t),r=h&&11===t.nodeType&&!!t.host,a=r&&!g.has(s),l=a?document.createDocumentFragment():t;if((0,c.s)(e,l,Object.assign({templateFactory:p(s)},n)),a){const e=c.L.get(l);c.L.delete(l);const n=e.value instanceof d.R?e.value.template:void 0;v(s,l,n),(0,i.r4)(t,t.firstChild),t.appendChild(l),c.L.set(t,e)}!o&&r&&window.ShadyCSS.styleElement(t.host)}},5158:(e,t,n)=>{"use strict";n.d(t,{vFN:()=>h.IngDialogFrame,jWr:()=>me,oiW:()=>u.oi,fNQ:()=>u.fN,Nrd:()=>b.Nr,H9s:()=>b.H9,ivY:()=>u.iv,YKG:()=>m.YK,Aip:()=>m.Ai,Dn$:()=>m.Dn,fQ4:()=>m.fQ,jhU:()=>m.jh,sMY:()=>m.sM,dyc:()=>u.dy,ciZ:()=>p.ci,QNj:()=>b.QN,WkE:()=>C,$y2:()=>b.$y,AuR:()=>u.Au});n(9258);var i=n(6979);"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:void 0!==n.g?n.g:"undefined"!=typeof self&&self;function s(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var o,r={exports:{}};o=function(){return function(e){var t={};function n(i){if(t[i])return t[i].exports;var s=t[i]={i,l:!1,exports:{}};return e[i].call(s.exports,s,s.exports,n),s.l=!0,s.exports}return n.m=e,n.c=t,n.d=function(e,t,i){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:i})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var i=Object.create(null);if(n.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var s in e)n.d(i,s,function(t){return e[t]}.bind(null,s));return i},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s="./index.js")}({"./index.js":
/*!******************!*\
	  !*** ./index.js ***!
	  \******************/
/*! no static exports found */function(e,t,n){e.exports=n(/*! ./lib/axios */"./lib/axios.js")},"./lib/adapters/xhr.js":
/*!*****************************!*\
	  !*** ./lib/adapters/xhr.js ***!
	  \*****************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js"),s=n(/*! ./../core/settle */"./lib/core/settle.js"),o=n(/*! ./../helpers/cookies */"./lib/helpers/cookies.js"),r=n(/*! ./../helpers/buildURL */"./lib/helpers/buildURL.js"),a=n(/*! ../core/buildFullPath */"./lib/core/buildFullPath.js"),c=n(/*! ./../helpers/parseHeaders */"./lib/helpers/parseHeaders.js"),l=n(/*! ./../helpers/isURLSameOrigin */"./lib/helpers/isURLSameOrigin.js"),d=n(/*! ../defaults/transitional */"./lib/defaults/transitional.js"),u=n(/*! ../core/AxiosError */"./lib/core/AxiosError.js"),h=n(/*! ../cancel/CanceledError */"./lib/cancel/CanceledError.js"),p=n(/*! ../helpers/parseProtocol */"./lib/helpers/parseProtocol.js");e.exports=function(e){return new Promise((function(t,n){var f,g=e.data,v=e.headers,_=e.responseType;function b(){e.cancelToken&&e.cancelToken.unsubscribe(f),e.signal&&e.signal.removeEventListener("abort",f)}i.isFormData(g)&&i.isStandardBrowserEnv()&&delete v["Content-Type"];var m=new XMLHttpRequest;if(e.auth){var y=e.auth.username||"",S=e.auth.password?unescape(encodeURIComponent(e.auth.password)):"";v.Authorization="Basic "+btoa(y+":"+S)}var C=a(e.baseURL,e.url);function w(){if(m){var i="getAllResponseHeaders"in m?c(m.getAllResponseHeaders()):null,o={data:_&&"text"!==_&&"json"!==_?m.response:m.responseText,status:m.status,statusText:m.statusText,headers:i,config:e,request:m};s((function(e){t(e),b()}),(function(e){n(e),b()}),o),m=null}}if(m.open(e.method.toUpperCase(),r(C,e.params,e.paramsSerializer),!0),m.timeout=e.timeout,"onloadend"in m?m.onloadend=w:m.onreadystatechange=function(){m&&4===m.readyState&&(0!==m.status||m.responseURL&&0===m.responseURL.indexOf("file:"))&&setTimeout(w)},m.onabort=function(){m&&(n(new u("Request aborted",u.ECONNABORTED,e,m)),m=null)},m.onerror=function(){n(new u("Network Error",u.ERR_NETWORK,e,m,m)),m=null},m.ontimeout=function(){var t=e.timeout?"timeout of "+e.timeout+"ms exceeded":"timeout exceeded",i=e.transitional||d;e.timeoutErrorMessage&&(t=e.timeoutErrorMessage),n(new u(t,i.clarifyTimeoutError?u.ETIMEDOUT:u.ECONNABORTED,e,m)),m=null},i.isStandardBrowserEnv()){var E=(e.withCredentials||l(C))&&e.xsrfCookieName?o.read(e.xsrfCookieName):void 0;E&&(v[e.xsrfHeaderName]=E)}"setRequestHeader"in m&&i.forEach(v,(function(e,t){void 0===g&&"content-type"===t.toLowerCase()?delete v[t]:m.setRequestHeader(t,e)})),i.isUndefined(e.withCredentials)||(m.withCredentials=!!e.withCredentials),_&&"json"!==_&&(m.responseType=e.responseType),"function"==typeof e.onDownloadProgress&&m.addEventListener("progress",e.onDownloadProgress),"function"==typeof e.onUploadProgress&&m.upload&&m.upload.addEventListener("progress",e.onUploadProgress),(e.cancelToken||e.signal)&&(f=function(e){m&&(n(!e||e&&e.type?new h:e),m.abort(),m=null)},e.cancelToken&&e.cancelToken.subscribe(f),e.signal&&(e.signal.aborted?f():e.signal.addEventListener("abort",f))),g||(g=null);var T=p(C);T&&-1===["http","https","file"].indexOf(T)?n(new u("Unsupported protocol "+T+":",u.ERR_BAD_REQUEST,e)):m.send(g)}))}},"./lib/axios.js":
/*!**********************!*\
	  !*** ./lib/axios.js ***!
	  \**********************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./utils */"./lib/utils.js"),s=n(/*! ./helpers/bind */"./lib/helpers/bind.js"),o=n(/*! ./core/Axios */"./lib/core/Axios.js"),r=n(/*! ./core/mergeConfig */"./lib/core/mergeConfig.js"),a=function e(t){var n=new o(t),a=s(o.prototype.request,n);return i.extend(a,o.prototype,n),i.extend(a,n),a.create=function(n){return e(r(t,n))},a}(n(/*! ./defaults */"./lib/defaults/index.js"));a.Axios=o,a.CanceledError=n(/*! ./cancel/CanceledError */"./lib/cancel/CanceledError.js"),a.CancelToken=n(/*! ./cancel/CancelToken */"./lib/cancel/CancelToken.js"),a.isCancel=n(/*! ./cancel/isCancel */"./lib/cancel/isCancel.js"),a.VERSION=n(/*! ./env/data */"./lib/env/data.js").version,a.toFormData=n(/*! ./helpers/toFormData */"./lib/helpers/toFormData.js"),a.AxiosError=n(/*! ../lib/core/AxiosError */"./lib/core/AxiosError.js"),a.Cancel=a.CanceledError,a.all=function(e){return Promise.all(e)},a.spread=n(/*! ./helpers/spread */"./lib/helpers/spread.js"),a.isAxiosError=n(/*! ./helpers/isAxiosError */"./lib/helpers/isAxiosError.js"),e.exports=a,e.exports.default=a},"./lib/cancel/CancelToken.js":
/*!***********************************!*\
	  !*** ./lib/cancel/CancelToken.js ***!
	  \***********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./CanceledError */"./lib/cancel/CanceledError.js");function s(e){if("function"!=typeof e)throw new TypeError("executor must be a function.");var t;this.promise=new Promise((function(e){t=e}));var n=this;this.promise.then((function(e){if(n._listeners){var t,i=n._listeners.length;for(t=0;t<i;t++)n._listeners[t](e);n._listeners=null}})),this.promise.then=function(e){var t,i=new Promise((function(e){n.subscribe(e),t=e})).then(e);return i.cancel=function(){n.unsubscribe(t)},i},e((function(e){n.reason||(n.reason=new i(e),t(n.reason))}))}s.prototype.throwIfRequested=function(){if(this.reason)throw this.reason},s.prototype.subscribe=function(e){this.reason?e(this.reason):this._listeners?this._listeners.push(e):this._listeners=[e]},s.prototype.unsubscribe=function(e){if(this._listeners){var t=this._listeners.indexOf(e);-1!==t&&this._listeners.splice(t,1)}},s.source=function(){var e;return{token:new s((function(t){e=t})),cancel:e}},e.exports=s},"./lib/cancel/CanceledError.js":
/*!*************************************!*\
	  !*** ./lib/cancel/CanceledError.js ***!
	  \*************************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../core/AxiosError */"./lib/core/AxiosError.js");function s(e){i.call(this,null==e?"canceled":e,i.ERR_CANCELED),this.name="CanceledError"}n(/*! ../utils */"./lib/utils.js").inherits(s,i,{__CANCEL__:!0}),e.exports=s},"./lib/cancel/isCancel.js":
/*!********************************!*\
	  !*** ./lib/cancel/isCancel.js ***!
	  \********************************/
/*! no static exports found */function(e,t,n){e.exports=function(e){return!(!e||!e.__CANCEL__)}},"./lib/core/Axios.js":
/*!***************************!*\
	  !*** ./lib/core/Axios.js ***!
	  \***************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js"),s=n(/*! ../helpers/buildURL */"./lib/helpers/buildURL.js"),o=n(/*! ./InterceptorManager */"./lib/core/InterceptorManager.js"),r=n(/*! ./dispatchRequest */"./lib/core/dispatchRequest.js"),a=n(/*! ./mergeConfig */"./lib/core/mergeConfig.js"),c=n(/*! ./buildFullPath */"./lib/core/buildFullPath.js"),l=n(/*! ../helpers/validator */"./lib/helpers/validator.js"),d=l.validators;function u(e){this.defaults=e,this.interceptors={request:new o,response:new o}}u.prototype.request=function(e,t){"string"==typeof e?(t=t||{}).url=e:t=e||{},(t=a(this.defaults,t)).method?t.method=t.method.toLowerCase():this.defaults.method?t.method=this.defaults.method.toLowerCase():t.method="get";var n=t.transitional;void 0!==n&&l.assertOptions(n,{silentJSONParsing:d.transitional(d.boolean),forcedJSONParsing:d.transitional(d.boolean),clarifyTimeoutError:d.transitional(d.boolean)},!1);var i=[],s=!0;this.interceptors.request.forEach((function(e){"function"==typeof e.runWhen&&!1===e.runWhen(t)||(s=s&&e.synchronous,i.unshift(e.fulfilled,e.rejected))}));var o,c=[];if(this.interceptors.response.forEach((function(e){c.push(e.fulfilled,e.rejected)})),!s){var u=[r,void 0];for(Array.prototype.unshift.apply(u,i),u=u.concat(c),o=Promise.resolve(t);u.length;)o=o.then(u.shift(),u.shift());return o}for(var h=t;i.length;){var p=i.shift(),f=i.shift();try{h=p(h)}catch(e){f(e);break}}try{o=r(h)}catch(e){return Promise.reject(e)}for(;c.length;)o=o.then(c.shift(),c.shift());return o},u.prototype.getUri=function(e){e=a(this.defaults,e);var t=c(e.baseURL,e.url);return s(t,e.params,e.paramsSerializer)},i.forEach(["delete","get","head","options"],(function(e){u.prototype[e]=function(t,n){return this.request(a(n||{},{method:e,url:t,data:(n||{}).data}))}})),i.forEach(["post","put","patch"],(function(e){function t(t){return function(n,i,s){return this.request(a(s||{},{method:e,headers:t?{"Content-Type":"multipart/form-data"}:{},url:n,data:i}))}}u.prototype[e]=t(),u.prototype[e+"Form"]=t(!0)})),e.exports=u},"./lib/core/AxiosError.js":
/*!********************************!*\
	  !*** ./lib/core/AxiosError.js ***!
	  \********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../utils */"./lib/utils.js");function s(e,t,n,i,s){Error.call(this),this.message=e,this.name="AxiosError",t&&(this.code=t),n&&(this.config=n),i&&(this.request=i),s&&(this.response=s)}i.inherits(s,Error,{toJSON:function(){return{message:this.message,name:this.name,description:this.description,number:this.number,fileName:this.fileName,lineNumber:this.lineNumber,columnNumber:this.columnNumber,stack:this.stack,config:this.config,code:this.code,status:this.response&&this.response.status?this.response.status:null}}});var o=s.prototype,r={};["ERR_BAD_OPTION_VALUE","ERR_BAD_OPTION","ECONNABORTED","ETIMEDOUT","ERR_NETWORK","ERR_FR_TOO_MANY_REDIRECTS","ERR_DEPRECATED","ERR_BAD_RESPONSE","ERR_BAD_REQUEST","ERR_CANCELED"].forEach((function(e){r[e]={value:e}})),Object.defineProperties(s,r),Object.defineProperty(o,"isAxiosError",{value:!0}),s.from=function(e,t,n,r,a,c){var l=Object.create(o);return i.toFlatObject(e,l,(function(e){return e!==Error.prototype})),s.call(l,e.message,t,n,r,a),l.name=e.name,c&&Object.assign(l,c),l},e.exports=s},"./lib/core/InterceptorManager.js":
/*!****************************************!*\
	  !*** ./lib/core/InterceptorManager.js ***!
	  \****************************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js");function s(){this.handlers=[]}s.prototype.use=function(e,t,n){return this.handlers.push({fulfilled:e,rejected:t,synchronous:!!n&&n.synchronous,runWhen:n?n.runWhen:null}),this.handlers.length-1},s.prototype.eject=function(e){this.handlers[e]&&(this.handlers[e]=null)},s.prototype.forEach=function(e){i.forEach(this.handlers,(function(t){null!==t&&e(t)}))},e.exports=s},"./lib/core/buildFullPath.js":
/*!***********************************!*\
	  !*** ./lib/core/buildFullPath.js ***!
	  \***********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../helpers/isAbsoluteURL */"./lib/helpers/isAbsoluteURL.js"),s=n(/*! ../helpers/combineURLs */"./lib/helpers/combineURLs.js");e.exports=function(e,t){return e&&!i(t)?s(e,t):t}},"./lib/core/dispatchRequest.js":
/*!*************************************!*\
	  !*** ./lib/core/dispatchRequest.js ***!
	  \*************************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js"),s=n(/*! ./transformData */"./lib/core/transformData.js"),o=n(/*! ../cancel/isCancel */"./lib/cancel/isCancel.js"),r=n(/*! ../defaults */"./lib/defaults/index.js"),a=n(/*! ../cancel/CanceledError */"./lib/cancel/CanceledError.js");function c(e){if(e.cancelToken&&e.cancelToken.throwIfRequested(),e.signal&&e.signal.aborted)throw new a}e.exports=function(e){return c(e),e.headers=e.headers||{},e.data=s.call(e,e.data,e.headers,e.transformRequest),e.headers=i.merge(e.headers.common||{},e.headers[e.method]||{},e.headers),i.forEach(["delete","get","head","post","put","patch","common"],(function(t){delete e.headers[t]})),(e.adapter||r.adapter)(e).then((function(t){return c(e),t.data=s.call(e,t.data,t.headers,e.transformResponse),t}),(function(t){return o(t)||(c(e),t&&t.response&&(t.response.data=s.call(e,t.response.data,t.response.headers,e.transformResponse))),Promise.reject(t)}))}},"./lib/core/mergeConfig.js":
/*!*********************************!*\
	  !*** ./lib/core/mergeConfig.js ***!
	  \*********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../utils */"./lib/utils.js");e.exports=function(e,t){t=t||{};var n={};function s(e,t){return i.isPlainObject(e)&&i.isPlainObject(t)?i.merge(e,t):i.isPlainObject(t)?i.merge({},t):i.isArray(t)?t.slice():t}function o(n){return i.isUndefined(t[n])?i.isUndefined(e[n])?void 0:s(void 0,e[n]):s(e[n],t[n])}function r(e){if(!i.isUndefined(t[e]))return s(void 0,t[e])}function a(n){return i.isUndefined(t[n])?i.isUndefined(e[n])?void 0:s(void 0,e[n]):s(void 0,t[n])}function c(n){return n in t?s(e[n],t[n]):n in e?s(void 0,e[n]):void 0}var l={url:r,method:r,data:r,baseURL:a,transformRequest:a,transformResponse:a,paramsSerializer:a,timeout:a,timeoutMessage:a,withCredentials:a,adapter:a,responseType:a,xsrfCookieName:a,xsrfHeaderName:a,onUploadProgress:a,onDownloadProgress:a,decompress:a,maxContentLength:a,maxBodyLength:a,beforeRedirect:a,transport:a,httpAgent:a,httpsAgent:a,cancelToken:a,socketPath:a,responseEncoding:a,validateStatus:c};return i.forEach(Object.keys(e).concat(Object.keys(t)),(function(e){var t=l[e]||o,s=t(e);i.isUndefined(s)&&t!==c||(n[e]=s)})),n}},"./lib/core/settle.js":
/*!****************************!*\
	  !*** ./lib/core/settle.js ***!
	  \****************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./AxiosError */"./lib/core/AxiosError.js");e.exports=function(e,t,n){var s=n.config.validateStatus;n.status&&s&&!s(n.status)?t(new i("Request failed with status code "+n.status,[i.ERR_BAD_REQUEST,i.ERR_BAD_RESPONSE][Math.floor(n.status/100)-4],n.config,n.request,n)):e(n)}},"./lib/core/transformData.js":
/*!***********************************!*\
	  !*** ./lib/core/transformData.js ***!
	  \***********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js"),s=n(/*! ../defaults */"./lib/defaults/index.js");e.exports=function(e,t,n){var o=this||s;return i.forEach(n,(function(n){e=n.call(o,e,t)})),e}},"./lib/defaults/index.js":
/*!*******************************!*\
	  !*** ./lib/defaults/index.js ***!
	  \*******************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../utils */"./lib/utils.js"),s=n(/*! ../helpers/normalizeHeaderName */"./lib/helpers/normalizeHeaderName.js"),o=n(/*! ../core/AxiosError */"./lib/core/AxiosError.js"),r=n(/*! ./transitional */"./lib/defaults/transitional.js"),a=n(/*! ../helpers/toFormData */"./lib/helpers/toFormData.js"),c={"Content-Type":"application/x-www-form-urlencoded"};function l(e,t){!i.isUndefined(e)&&i.isUndefined(e["Content-Type"])&&(e["Content-Type"]=t)}var d,u={transitional:r,adapter:(("undefined"!=typeof XMLHttpRequest||"undefined"!=typeof process&&"[object process]"===Object.prototype.toString.call(process))&&(d=n(/*! ../adapters/xhr */"./lib/adapters/xhr.js")),d),transformRequest:[function(e,t){if(s(t,"Accept"),s(t,"Content-Type"),i.isFormData(e)||i.isArrayBuffer(e)||i.isBuffer(e)||i.isStream(e)||i.isFile(e)||i.isBlob(e))return e;if(i.isArrayBufferView(e))return e.buffer;if(i.isURLSearchParams(e))return l(t,"application/x-www-form-urlencoded;charset=utf-8"),e.toString();var n,o=i.isObject(e),r=t&&t["Content-Type"];if((n=i.isFileList(e))||o&&"multipart/form-data"===r){var c=this.env&&this.env.FormData;return a(n?{"files[]":e}:e,c&&new c)}return o||"application/json"===r?(l(t,"application/json"),function(e,t,n){if(i.isString(e))try{return(t||JSON.parse)(e),i.trim(e)}catch(e){if("SyntaxError"!==e.name)throw e}return(n||JSON.stringify)(e)}(e)):e}],transformResponse:[function(e){var t=this.transitional||u.transitional,n=t&&t.silentJSONParsing,s=t&&t.forcedJSONParsing,r=!n&&"json"===this.responseType;if(r||s&&i.isString(e)&&e.length)try{return JSON.parse(e)}catch(e){if(r){if("SyntaxError"===e.name)throw o.from(e,o.ERR_BAD_RESPONSE,this,null,this.response);throw e}}return e}],timeout:0,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",maxContentLength:-1,maxBodyLength:-1,env:{FormData:n(/*! ./env/FormData */"./lib/helpers/null.js")},validateStatus:function(e){return e>=200&&e<300},headers:{common:{Accept:"application/json, text/plain, */*"}}};i.forEach(["delete","get","head"],(function(e){u.headers[e]={}})),i.forEach(["post","put","patch"],(function(e){u.headers[e]=i.merge(c)})),e.exports=u},"./lib/defaults/transitional.js":
/*!**************************************!*\
	  !*** ./lib/defaults/transitional.js ***!
	  \**************************************/
/*! no static exports found */function(e,t,n){e.exports={silentJSONParsing:!0,forcedJSONParsing:!0,clarifyTimeoutError:!1}},"./lib/env/data.js":
/*!*************************!*\
	  !*** ./lib/env/data.js ***!
	  \*************************/
/*! no static exports found */function(e,t){e.exports={version:"0.27.2"}},"./lib/helpers/bind.js":
/*!*****************************!*\
	  !*** ./lib/helpers/bind.js ***!
	  \*****************************/
/*! no static exports found */function(e,t,n){e.exports=function(e,t){return function(){for(var n=new Array(arguments.length),i=0;i<n.length;i++)n[i]=arguments[i];return e.apply(t,n)}}},"./lib/helpers/buildURL.js":
/*!*********************************!*\
	  !*** ./lib/helpers/buildURL.js ***!
	  \*********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js");function s(e){return encodeURIComponent(e).replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%20/g,"+").replace(/%5B/gi,"[").replace(/%5D/gi,"]")}e.exports=function(e,t,n){if(!t)return e;var o;if(n)o=n(t);else if(i.isURLSearchParams(t))o=t.toString();else{var r=[];i.forEach(t,(function(e,t){null!=e&&(i.isArray(e)?t+="[]":e=[e],i.forEach(e,(function(e){i.isDate(e)?e=e.toISOString():i.isObject(e)&&(e=JSON.stringify(e)),r.push(s(t)+"="+s(e))})))})),o=r.join("&")}if(o){var a=e.indexOf("#");-1!==a&&(e=e.slice(0,a)),e+=(-1===e.indexOf("?")?"?":"&")+o}return e}},"./lib/helpers/combineURLs.js":
/*!************************************!*\
	  !*** ./lib/helpers/combineURLs.js ***!
	  \************************************/
/*! no static exports found */function(e,t,n){e.exports=function(e,t){return t?e.replace(/\/+$/,"")+"/"+t.replace(/^\/+/,""):e}},"./lib/helpers/cookies.js":
/*!********************************!*\
	  !*** ./lib/helpers/cookies.js ***!
	  \********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js");e.exports=i.isStandardBrowserEnv()?{write:function(e,t,n,s,o,r){var a=[];a.push(e+"="+encodeURIComponent(t)),i.isNumber(n)&&a.push("expires="+new Date(n).toGMTString()),i.isString(s)&&a.push("path="+s),i.isString(o)&&a.push("domain="+o),!0===r&&a.push("secure"),document.cookie=a.join("; ")},read:function(e){var t=document.cookie.match(new RegExp("(^|;\\s*)("+e+")=([^;]*)"));return t?decodeURIComponent(t[3]):null},remove:function(e){this.write(e,"",Date.now()-864e5)}}:{write:function(){},read:function(){return null},remove:function(){}}},"./lib/helpers/isAbsoluteURL.js":
/*!**************************************!*\
	  !*** ./lib/helpers/isAbsoluteURL.js ***!
	  \**************************************/
/*! no static exports found */function(e,t,n){e.exports=function(e){return/^([a-z][a-z\d+\-.]*:)?\/\//i.test(e)}},"./lib/helpers/isAxiosError.js":
/*!*************************************!*\
	  !*** ./lib/helpers/isAxiosError.js ***!
	  \*************************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js");e.exports=function(e){return i.isObject(e)&&!0===e.isAxiosError}},"./lib/helpers/isURLSameOrigin.js":
/*!****************************************!*\
	  !*** ./lib/helpers/isURLSameOrigin.js ***!
	  \****************************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js");e.exports=i.isStandardBrowserEnv()?function(){var e,t=/(msie|trident)/i.test(navigator.userAgent),n=document.createElement("a");function s(e){var i=e;return t&&(n.setAttribute("href",i),i=n.href),n.setAttribute("href",i),{href:n.href,protocol:n.protocol?n.protocol.replace(/:$/,""):"",host:n.host,search:n.search?n.search.replace(/^\?/,""):"",hash:n.hash?n.hash.replace(/^#/,""):"",hostname:n.hostname,port:n.port,pathname:"/"===n.pathname.charAt(0)?n.pathname:"/"+n.pathname}}return e=s(window.location.href),function(t){var n=i.isString(t)?s(t):t;return n.protocol===e.protocol&&n.host===e.host}}():function(){return!0}},"./lib/helpers/normalizeHeaderName.js":
/*!********************************************!*\
	  !*** ./lib/helpers/normalizeHeaderName.js ***!
	  \********************************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../utils */"./lib/utils.js");e.exports=function(e,t){i.forEach(e,(function(n,i){i!==t&&i.toUpperCase()===t.toUpperCase()&&(e[t]=n,delete e[i])}))}},"./lib/helpers/null.js":
/*!*****************************!*\
	  !*** ./lib/helpers/null.js ***!
	  \*****************************/
/*! no static exports found */function(e,t){e.exports=null},"./lib/helpers/parseHeaders.js":
/*!*************************************!*\
	  !*** ./lib/helpers/parseHeaders.js ***!
	  \*************************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ./../utils */"./lib/utils.js"),s=["age","authorization","content-length","content-type","etag","expires","from","host","if-modified-since","if-unmodified-since","last-modified","location","max-forwards","proxy-authorization","referer","retry-after","user-agent"];e.exports=function(e){var t,n,o,r={};return e?(i.forEach(e.split("\n"),(function(e){if(o=e.indexOf(":"),t=i.trim(e.substr(0,o)).toLowerCase(),n=i.trim(e.substr(o+1)),t){if(r[t]&&s.indexOf(t)>=0)return;r[t]="set-cookie"===t?(r[t]?r[t]:[]).concat([n]):r[t]?r[t]+", "+n:n}})),r):r}},"./lib/helpers/parseProtocol.js":
/*!**************************************!*\
	  !*** ./lib/helpers/parseProtocol.js ***!
	  \**************************************/
/*! no static exports found */function(e,t,n){e.exports=function(e){var t=/^([-+\w]{1,25})(:?\/\/|:)/.exec(e);return t&&t[1]||""}},"./lib/helpers/spread.js":
/*!*******************************!*\
	  !*** ./lib/helpers/spread.js ***!
	  \*******************************/
/*! no static exports found */function(e,t,n){e.exports=function(e){return function(t){return e.apply(null,t)}}},"./lib/helpers/toFormData.js":
/*!***********************************!*\
	  !*** ./lib/helpers/toFormData.js ***!
	  \***********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../utils */"./lib/utils.js");e.exports=function(e,t){t=t||new FormData;var n=[];function s(e){return null===e?"":i.isDate(e)?e.toISOString():i.isArrayBuffer(e)||i.isTypedArray(e)?"function"==typeof Blob?new Blob([e]):Buffer.from(e):e}return function e(o,r){if(i.isPlainObject(o)||i.isArray(o)){if(-1!==n.indexOf(o))throw Error("Circular reference detected in "+r);n.push(o),i.forEach(o,(function(n,o){if(!i.isUndefined(n)){var a,c=r?r+"."+o:o;if(n&&!r&&"object"==typeof n)if(i.endsWith(o,"{}"))n=JSON.stringify(n);else if(i.endsWith(o,"[]")&&(a=i.toArray(n)))return void a.forEach((function(e){!i.isUndefined(e)&&t.append(c,s(e))}));e(n,c)}})),n.pop()}else t.append(r,s(o))}(e),t}},"./lib/helpers/validator.js":
/*!**********************************!*\
	  !*** ./lib/helpers/validator.js ***!
	  \**********************************/
/*! no static exports found */function(e,t,n){var i=n(/*! ../env/data */"./lib/env/data.js").version,s=n(/*! ../core/AxiosError */"./lib/core/AxiosError.js"),o={};["object","boolean","number","function","string","symbol"].forEach((function(e,t){o[e]=function(n){return typeof n===e||"a"+(t<1?"n ":" ")+e}}));var r={};o.transitional=function(e,t,n){function o(e,t){return"[Axios v"+i+"] Transitional option '"+e+"'"+t+(n?". "+n:"")}return function(n,i,a){if(!1===e)throw new s(o(i," has been removed"+(t?" in "+t:"")),s.ERR_DEPRECATED);return t&&!r[i]&&(r[i]=!0,console.warn(o(i," has been deprecated since v"+t+" and will be removed in the near future"))),!e||e(n,i,a)}},e.exports={assertOptions:function(e,t,n){if("object"!=typeof e)throw new s("options must be an object",s.ERR_BAD_OPTION_VALUE);for(var i=Object.keys(e),o=i.length;o-- >0;){var r=i[o],a=t[r];if(a){var c=e[r],l=void 0===c||a(c,r,e);if(!0!==l)throw new s("option "+r+" must be "+l,s.ERR_BAD_OPTION_VALUE)}else if(!0!==n)throw new s("Unknown option "+r,s.ERR_BAD_OPTION)}},validators:o}},"./lib/utils.js":
/*!**********************!*\
	  !*** ./lib/utils.js ***!
	  \**********************/
/*! no static exports found */function(e,t,n){var i,s=n(/*! ./helpers/bind */"./lib/helpers/bind.js"),o=Object.prototype.toString,r=(i=Object.create(null),function(e){var t=o.call(e);return i[t]||(i[t]=t.slice(8,-1).toLowerCase())});function a(e){return e=e.toLowerCase(),function(t){return r(t)===e}}function c(e){return Array.isArray(e)}function l(e){return void 0===e}var d=a("ArrayBuffer");function u(e){return null!==e&&"object"==typeof e}function h(e){if("object"!==r(e))return!1;var t=Object.getPrototypeOf(e);return null===t||t===Object.prototype}var p=a("Date"),f=a("File"),g=a("Blob"),v=a("FileList");function _(e){return"[object Function]"===o.call(e)}var b=a("URLSearchParams");function m(e,t){if(null!=e)if("object"!=typeof e&&(e=[e]),c(e))for(var n=0,i=e.length;n<i;n++)t.call(null,e[n],n,e);else for(var s in e)Object.prototype.hasOwnProperty.call(e,s)&&t.call(null,e[s],s,e)}var y,S=(y="undefined"!=typeof Uint8Array&&Object.getPrototypeOf(Uint8Array),function(e){return y&&e instanceof y});e.exports={isArray:c,isArrayBuffer:d,isBuffer:function(e){return null!==e&&!l(e)&&null!==e.constructor&&!l(e.constructor)&&"function"==typeof e.constructor.isBuffer&&e.constructor.isBuffer(e)},isFormData:function(e){var t="[object FormData]";return e&&("function"==typeof FormData&&e instanceof FormData||o.call(e)===t||_(e.toString)&&e.toString()===t)},isArrayBufferView:function(e){return"undefined"!=typeof ArrayBuffer&&ArrayBuffer.isView?ArrayBuffer.isView(e):e&&e.buffer&&d(e.buffer)},isString:function(e){return"string"==typeof e},isNumber:function(e){return"number"==typeof e},isObject:u,isPlainObject:h,isUndefined:l,isDate:p,isFile:f,isBlob:g,isFunction:_,isStream:function(e){return u(e)&&_(e.pipe)},isURLSearchParams:b,isStandardBrowserEnv:function(){return("undefined"==typeof navigator||"ReactNative"!==navigator.product&&"NativeScript"!==navigator.product&&"NS"!==navigator.product)&&"undefined"!=typeof window&&"undefined"!=typeof document},forEach:m,merge:function e(){var t={};function n(n,i){h(t[i])&&h(n)?t[i]=e(t[i],n):h(n)?t[i]=e({},n):c(n)?t[i]=n.slice():t[i]=n}for(var i=0,s=arguments.length;i<s;i++)m(arguments[i],n);return t},extend:function(e,t,n){return m(t,(function(t,i){e[i]=n&&"function"==typeof t?s(t,n):t})),e},trim:function(e){return e.trim?e.trim():e.replace(/^\s+|\s+$/g,"")},stripBOM:function(e){return 65279===e.charCodeAt(0)&&(e=e.slice(1)),e},inherits:function(e,t,n,i){e.prototype=Object.create(t.prototype,i),e.prototype.constructor=e,n&&Object.assign(e.prototype,n)},toFlatObject:function(e,t,n){var i,s,o,r={};t=t||{};do{for(s=(i=Object.getOwnPropertyNames(e)).length;s-- >0;)r[o=i[s]]||(t[o]=e[o],r[o]=!0);e=Object.getPrototypeOf(e)}while(e&&(!n||n(e,t))&&e!==Object.prototype);return t},kindOf:r,kindOfTest:a,endsWith:function(e,t,n){e=String(e),(void 0===n||n>e.length)&&(n=e.length),n-=t.length;var i=e.indexOf(t,n);return-1!==i&&i===n},toArray:function(e){if(!e)return null;var t=e.length;if(l(t))return null;for(var n=new Array(t);t-- >0;)n[t]=e[t];return n},isTypedArray:S,isFileList:v}}})},r.exports=o();const a=s(r.exports);class c{constructor(e){var t,n;if(this.__config={lang:document.documentElement.getAttribute("lang"),languageHeader:!0,cancelable:!1,cancelPreviousOnNewRequest:!1,...e},this.proxy=a.create(this.__config),this.__setupInterceptors(),this.requestInterceptors=[],this.requestErrorInterceptors=[],this.responseErrorInterceptors=[],this.responseInterceptors=[],this.requestDataTransformers=[],this.requestDataErrorTransformers=[],this.responseDataErrorTransformers=[],this.responseDataTransformers=[],this.__isInterceptorsSetup=!1,this.__config.languageHeader&&this.requestInterceptors.push((t=this.__config.lang,e=>{const n=e;if("string"==typeof t&&""!==t){"object"!=typeof n.headers&&(n.headers={});const e={headers:{"Accept-Language":t,...n.headers}};return{...n,...e}}return n})),this.__config.cancelable&&this.requestInterceptors.push(function(e){const t=[];return n=>{const i=a.CancelToken.source();return t.push(i),e.cancel=(e="Operation canceled by the user.")=>{t.forEach((t=>t.cancel(e)))},{...n,cancelToken:i.token}}}(this)),this.__config.cancelPreviousOnNewRequest&&this.requestInterceptors.push(function(){let e;return t=>{e&&e.cancel("Concurrent requests not allowed.");const n=a.CancelToken.source();return e=n,{...t,cancelToken:n.token}}}()),this.__config.jsonPrefix){const e=(n=this.__config.jsonPrefix,e=>{let t=e;if("string"==typeof t){n.length>0&&0===t.indexOf(n)&&(t=t.substring(n.length));try{t=JSON.parse(t)}catch(e){}}return t});this.responseDataTransformers.push(e)}}set options(e){this.__config=e}get options(){return this.__config}request(e,t){return this.proxy.request.apply(this,[e,{...this.__config,...t}])}cancel(e){}get(e,t){return this.proxy.get.apply(this,[e,{...this.__config,...t}])}delete(e,t){return this.proxy.delete.apply(this,[e,{...this.__config,...t}])}head(e,t){return this.proxy.head.apply(this,[e,{...this.__config,...t}])}post(e,t,n){return this.proxy.post.apply(this,[e,t,{...this.__config,...n}])}put(e,t,n){return this.proxy.put.apply(this,[e,t,{...this.__config,...n}])}patch(e,t,n){return this.proxy.patch.apply(this,[e,t,{...this.__config,...n}])}__setupInterceptors(){this.proxy.interceptors.request.use((e=>{const t=this.__setupTransformers(e);return this.requestInterceptors.reduce(((e,t)=>t(e)),t)}),(e=>(this.requestErrorInterceptors.forEach((t=>t(e))),Promise.reject(e)))),this.proxy.interceptors.response.use((e=>this.responseInterceptors.reduce(((e,t)=>t(e)),e)),(e=>(this.responseErrorInterceptors.forEach((t=>t(e))),Promise.reject(e))))}__setupTransformers(e){const t=e.transformRequest[0].bind(a),n=e.transformResponse[0].bind(a);return{...e,transformRequest:(e,n)=>{try{const i=this.requestDataTransformers.reduce(((e,t)=>t(e,n)),e);return t(i,n)}catch(e){throw this.requestDataErrorTransformers.forEach((t=>t(e))),e}},transformResponse:e=>{try{const t=n(e);return this.responseDataTransformers.reduce(((e,t)=>t(e)),t)}catch(e){throw this.responseDataErrorTransformers.forEach((t=>t(e))),e}}}}}let l=i.d.get("@lion/ajax::ajax::0.3.x")||new c;var d;d=i.d.get("ing-web::ajax::2.x")||new class extends c{constructor(e){super({jsonPrefix:")]}',",...e})}},l=d;n(9861);var u=n(9566),h=n(4084),p=n(8519),f=n(813),g=n(194);(0,f.o)(i.d.get("ing-web::localize::2.x")||new g.$({autoLoadOnLocaleChange:!0,fallbackLocale:"en-GB"})),function(e){e.setDatePostProcessorForLocale({locale:"cs-CZ",postProcessor:e=>e.split(" ").join("")}),e.setNumberPostProcessorForLocale({locale:"es-ES",postProcessor:e=>{const t=e.split(",")[0];return Number(t)&&4===t.length?[e.slice(0,1),".",e.slice(1)].join(""):e}})}(f.N);var v=n(1940),_=n(1447);(0,v.o)(i.d.get("ing-web::overlays::2.x")||new _.v);var b=n(3371),m=n(170),y=n(332),S=n(9047);const C=y.y5`
  .link {
    text-decoration: none;
    border-bottom: 1px solid ${b.QN};
    color: ${b.QN};
  }

  .link:visited {
    color: ${b.zf};
    border-bottom-color: ${b.zf};
  }

  .link:focus,
  .link:visited:focus {
    ${(0,S.i)()}
    outline: none;
    border-bottom-color: transparent;
  }

  .link:hover {
    background-color: ${b.Hd};
  }

  .link:visited:hover {
    background-color: ${b.vj};
  }

  .link:active {
    color: ${b.QN};
    border-bottom-color: transparent;
    background-color: transparent;
  }

  .link:visited:active {
    color: ${b.zf};
    border-bottom-color: transparent;
    background-color: transparent;
  }
`;var w=n(5554),E=n(7206),T=n(4971),I=n(1077),A=n(4459),x=n(3320),N=n(3515);const L=[Node.DOCUMENT_POSITION_PRECEDING,Node.DOCUMENT_POSITION_CONTAINS,Node.DOCUMENT_POSITION_CONTAINS|Node.DOCUMENT_POSITION_PRECEDING];function k(e,{reverse:t}={}){const n=e.filter((e=>e));return n.sort(((e,t)=>{const n=e.compareDocumentPosition(t);return L.includes(n)?N.n.isIE11?-1:1:N.n.isIE11?1:-1})),t&&n.reverse(),n}class O{constructor(e){this.type="unparseable",this.viewValue=e}toString(){return JSON.stringify({type:this.type,viewValue:this.viewValue})}}const D=(0,I.S)((e=>class extends e{constructor(){super(),this._parentFormGroup=void 0}connectedCallback(){super.connectedCallback(),this.dispatchEvent(new CustomEvent("form-element-register",{detail:{element:this},bubbles:!0}))}disconnectedCallback(){super.disconnectedCallback(),this._parentFormGroup&&this._parentFormGroup.removeFormElement(this)}}));const R=(0,I.S)((e=>class extends(D((0,A.f)((0,x.J)(e)))){static get properties(){return{name:{type:String,reflect:!0},readOnly:{type:Boolean,attribute:"readonly",reflect:!0},label:String,helpText:{type:String,attribute:"help-text"},modelValue:{attribute:!1},_ariaLabelledNodes:{attribute:!1},_ariaDescribedNodes:{attribute:!1},_repropagationRole:{attribute:!1},_isRepropagationEndpoint:{attribute:!1}}}get label(){return this.__label||this._labelNode&&this._labelNode.textContent||""}set label(e){const t=this.label;this.__label=e,this.requestUpdate("label",t)}get helpText(){return this.__helpText||this._helpTextNode&&this._helpTextNode.textContent||""}set helpText(e){const t=this.helpText;this.__helpText=e,this.requestUpdate("helpText",t)}get fieldName(){return this.__fieldName||this.label||this.name||""}set fieldName(e){this.__fieldName=e}get slots(){return{...super.slots,label:()=>{const e=document.createElement("label");return e.textContent=this.label,e},"help-text":()=>{const e=document.createElement("div");return e.textContent=this.helpText,e}}}get _inputNode(){return this.__getDirectSlotChild("input")}get _labelNode(){return this.__getDirectSlotChild("label")}get _helpTextNode(){return this.__getDirectSlotChild("help-text")}get _feedbackNode(){return this.__getDirectSlotChild("feedback")}constructor(){super(),this.name="",this.readOnly=!1,this.label="",this.helpText="",this._inputId=`${this.localName}-${Math.random().toString(36).substr(2,10)}`,this._ariaLabelledNodes=[],this._ariaDescribedNodes=[],this._repropagationRole="child",this._isRepropagationEndpoint=!1,this.addEventListener("model-value-changed",this.__repropagateChildrenValues),this._onLabelClick=this._onLabelClick.bind(this)}connectedCallback(){super.connectedCallback(),this._enhanceLightDomClasses(),this._enhanceLightDomA11y(),this._triggerInitialModelValueChangedEvent(),this._labelNode&&this._labelNode.addEventListener("click",this._onLabelClick)}disconnectedCallback(){super.disconnectedCallback(),this._labelNode&&this._labelNode.removeEventListener("click",this._onLabelClick)}updated(e){super.updated(e),e.has("_ariaLabelledNodes")&&this.__reflectAriaAttr("aria-labelledby",this._ariaLabelledNodes,this.__reorderAriaLabelledNodes),e.has("_ariaDescribedNodes")&&this.__reflectAriaAttr("aria-describedby",this._ariaDescribedNodes,this.__reorderAriaDescribedNodes),e.has("label")&&this._labelNode&&(this._labelNode.textContent=this.label),e.has("helpText")&&this._helpTextNode&&(this._helpTextNode.textContent=this.helpText),e.has("name")&&this.dispatchEvent(new CustomEvent("form-element-name-changed",{detail:{oldName:e.get("name"),newName:this.name},bubbles:!0}))}_triggerInitialModelValueChangedEvent(){this._dispatchInitialModelValueChangedEvent()}_enhanceLightDomClasses(){this._inputNode&&this._inputNode.classList.add("form-control")}_enhanceLightDomA11y(){const{_inputNode:e,_labelNode:t,_helpTextNode:n,_feedbackNode:i}=this;e&&(e.id=e.id||this._inputId),t&&(t.setAttribute("for",this._inputId),this.addToAriaLabelledBy(t,{idPrefix:"label"})),n&&this.addToAriaDescribedBy(n,{idPrefix:"help-text"}),i&&(this.addEventListener("focusin",(()=>{i.setAttribute("aria-live","polite")})),this.addEventListener("focusout",(()=>{i.setAttribute("aria-live","assertive")})),this.addToAriaDescribedBy(i,{idPrefix:"feedback"})),this._enhanceLightDomA11yForAdditionalSlots()}_enhanceLightDomA11yForAdditionalSlots(e=["prefix","suffix","before","after"]){e.forEach((e=>{const t=this.__getDirectSlotChild(e);t&&(t.hasAttribute("data-label")&&this.addToAriaLabelledBy(t,{idPrefix:e}),t.hasAttribute("data-description")&&this.addToAriaDescribedBy(t,{idPrefix:e}))}))}__reflectAriaAttr(e,t,n){if(this._inputNode){if(n){const e=t.filter((e=>this.contains(e))),n=t.filter((e=>!this.contains(e)));t=[...k(e),...n]}const i=t.map((e=>e.id)).join(" ");this._inputNode.setAttribute(e,i)}}render(){return T.dy`
        <div class="form-field__group-one">${this._groupOneTemplate()}</div>
        <div class="form-field__group-two">${this._groupTwoTemplate()}</div>
      `}_groupOneTemplate(){return T.dy` ${this._labelTemplate()} ${this._helpTextTemplate()} `}_groupTwoTemplate(){return T.dy` ${this._inputGroupTemplate()} ${this._feedbackTemplate()} `}_labelTemplate(){return T.dy`
        <div class="form-field__label">
          <slot name="label"></slot>
        </div>
      `}_helpTextTemplate(){return T.dy`
        <small class="form-field__help-text">
          <slot name="help-text"></slot>
        </small>
      `}_inputGroupTemplate(){return T.dy`
        <div class="input-group">
          ${this._inputGroupBeforeTemplate()}
          <div class="input-group__container">
            ${this._inputGroupPrefixTemplate()} ${this._inputGroupInputTemplate()}
            ${this._inputGroupSuffixTemplate()}
          </div>
          ${this._inputGroupAfterTemplate()}
        </div>
      `}_inputGroupBeforeTemplate(){return T.dy`
        <div class="input-group__before">
          <slot name="before"></slot>
        </div>
      `}_inputGroupPrefixTemplate(){return Array.from(this.children).find((e=>"prefix"===e.slot))?T.dy`
            <div class="input-group__prefix">
              <slot name="prefix"></slot>
            </div>
          `:T.Ld}_inputGroupInputTemplate(){return T.dy`
        <div class="input-group__input">
          <slot name="input"></slot>
        </div>
      `}_inputGroupSuffixTemplate(){return Array.from(this.children).find((e=>"suffix"===e.slot))?T.dy`
            <div class="input-group__suffix">
              <slot name="suffix"></slot>
            </div>
          `:T.Ld}_inputGroupAfterTemplate(){return T.dy`
        <div class="input-group__after">
          <slot name="after"></slot>
        </div>
      `}_feedbackTemplate(){return T.dy`
        <div class="form-field__feedback">
          <slot name="feedback"></slot>
        </div>
      `}_isEmpty(e=this.modelValue){let t=e;if(this.modelValue instanceof O&&(t=this.modelValue.viewValue),"object"==typeof t&&null!==t&&!(t instanceof Date))return!Object.keys(t).length;const n="number"==typeof t&&(0===t||Number.isNaN(t));return!t&&!n&&!("boolean"==typeof t&&!1===t)}static get styles(){return[E.iv`
          /**********************
            {block} .form-field
           ********************/

          :host {
            display: block;
          }

          :host([hidden]) {
            display: none;
          }

          :host([disabled]) {
            pointer-events: none;
          }

          :host([disabled]) .form-field__label ::slotted(*),
          :host([disabled]) .form-field__help-text ::slotted(*) {
            color: var(--disabled-text-color, #767676);
          }

          /***********************
            {block} .input-group
           *********************/

          .input-group__container {
            display: flex;
          }

          .input-group__input {
            flex: 1;
            display: flex;
          }

          /***** {state} :disabled *****/
          :host([disabled]) .input-group ::slotted([slot='input']) {
            color: var(--disabled-text-color, #767676);
          }

          /***********************
            {block} .form-control
           **********************/

          .input-group__container > .input-group__input ::slotted(.form-control) {
            flex: 1 1 auto;
            margin: 0; /* remove input margin in Safari */
            font-size: 100%; /* normalize default input font-size */
          }
        `]}_getAriaDescriptionElements(){return[this._helpTextNode,this._feedbackNode]}addToAriaLabelledBy(e,{idPrefix:t="",reorder:n=!0}={}){e.id=e.id||`${t}-${this._inputId}`,this._ariaLabelledNodes.includes(e)||(this._ariaLabelledNodes=[...this._ariaLabelledNodes,e],this.__reorderAriaLabelledNodes=Boolean(n))}removeFromAriaLabelledBy(e){this._ariaLabelledNodes.includes(e)&&(this._ariaLabelledNodes.splice(this._ariaLabelledNodes.indexOf(e),1),this._ariaLabelledNodes=[...this._ariaLabelledNodes],this.__reorderAriaLabelledNodes=!1)}addToAriaDescribedBy(e,{idPrefix:t="",reorder:n=!0}={}){e.id=e.id||`${t}-${this._inputId}`,this._ariaDescribedNodes.includes(e)||(this._ariaDescribedNodes=[...this._ariaDescribedNodes,e],this.__reorderAriaDescribedNodes=Boolean(n))}removeFromAriaDescribedBy(e){this._ariaDescribedNodes.includes(e)&&(this._ariaDescribedNodes.splice(this._ariaDescribedNodes.indexOf(e),1),this._ariaDescribedNodes=[...this._ariaDescribedNodes],this.__reorderAriaLabelledNodes=!1)}__getDirectSlotChild(e){return Array.from(this.children).find((t=>t.slot===e))}_dispatchInitialModelValueChangedEvent(){"child"!==this._repropagationRole&&(this.__repropagateChildrenInitialized=!0,this.dispatchEvent(new CustomEvent("model-value-changed",{bubbles:!0,detail:{formPath:[this],initialize:!0,isTriggeredByUser:!1}})))}_onBeforeRepropagateChildrenValues(e){}__repropagateChildrenValues(e){this._onBeforeRepropagateChildrenValues(e);const t=e.detail&&e.detail.element||e.target,n=this._isRepropagationEndpoint||"choice-group"===this._repropagationRole;if(t===this)return;e.stopImmediatePropagation();const i="child"!==this._repropagationRole&&!this.__repropagateChildrenInitialized,s=e.detail&&e.detail.initialize;if(i||s)return;if(!this._repropagationCondition(t))return;let o=[];n||(o=e.detail&&e.detail.formPath||[t]);const r=[...o,this];this.dispatchEvent(new CustomEvent("model-value-changed",{bubbles:!0,detail:{formPath:r,isTriggeredByUser:Boolean(e.detail?.isTriggeredByUser)}}))}_repropagationCondition(e){return Boolean(e)}_onLabelClick(){}}));class P{constructor(){this.__running=!1,this.__queue=[]}add(e){this.__queue.push(e),this.__running||(this.complete=new Promise((e=>{this.__callComplete=e})),this.__run())}async __run(){this.__running=!0,await this.__queue[0](),this.__queue.shift(),this.__queue.length>0?this.__run():(this.__running=!1,this.__callComplete&&this.__callComplete())}}const U=(0,I.S)((e=>class extends e{constructor(){super(),this.__SyncUpdatableNamespace={}}firstUpdated(e){super.firstUpdated(e),this.__syncUpdatableInitialize()}connectedCallback(){super.connectedCallback(),this.__SyncUpdatableNamespace.connected=!0}disconnectedCallback(){super.disconnectedCallback(),this.__SyncUpdatableNamespace.connected=!1}static __syncUpdatableHasChanged(e,t,n){const i=this._classProperties;return i.get(e)&&i.get(e).hasChanged?i.get(e).hasChanged(t,n):t!==n}__syncUpdatableInitialize(){const e=this.__SyncUpdatableNamespace,t=this.constructor;e.initialized=!0,e.queue&&Array.from(e.queue).forEach((e=>{t.__syncUpdatableHasChanged(e,this[e],void 0)&&this.updateSync(e,void 0)}))}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),this.__SyncUpdatableNamespace=this.__SyncUpdatableNamespace||{};const n=this.__SyncUpdatableNamespace,i=this.constructor;n.initialized?i.__syncUpdatableHasChanged(e,this[e],t)&&this.updateSync(e,t):(n.queue=n.queue||new Set,n.queue.add(e))}updateSync(e,t){}}));class F extends E.oi{static get properties(){return{feedbackData:{attribute:!1}}}_messageTemplate({message:e}){return e}updated(e){super.updated(e),this.feedbackData&&this.feedbackData[0]?(this.setAttribute("type",this.feedbackData[0].type),this.currentType=this.feedbackData[0].type,window.clearTimeout(this.removeMessage),"success"===this.currentType&&(this.removeMessage=window.setTimeout((()=>{this.removeAttribute("type"),this.feedbackData=[]}),3e3))):"success"!==this.currentType&&this.removeAttribute("type")}render(){return T.dy`
      ${this.feedbackData&&this.feedbackData.map((({message:e,type:t,validator:n})=>T.dy`
          ${this._messageTemplate({message:e,type:t,validator:n})}
        `))}
    `}}class V{constructor(e,t){this.__fakeExtendsEventTarget(),this.__param=e,this.__config=t||{},this.type=t&&t.type||"error"}static get validatorName(){return""}static get async(){return!1}execute(e,t,n){if(!this.constructor.validatorName)throw new Error("A validator needs to have a name! Please set it via \"static get validatorName() { return 'IsCat'; }\"");return!0}set param(e){this.__param=e,this.dispatchEvent&&this.dispatchEvent(new Event("param-changed"))}get param(){return this.__param}set config(e){this.__config=e,this.dispatchEvent&&this.dispatchEvent(new Event("config-changed"))}get config(){return this.__config}async _getMessage(e){const t=this.constructor,n={name:t.validatorName,type:this.type,params:this.param,config:this.config,...e};if(this.config.getMessage){if("function"==typeof this.config.getMessage)return this.config.getMessage(n);throw new Error("You must provide a value for getMessage of type 'function', you provided a value of type: "+typeof this.config.getMessage)}return t.getMessage(n)}static async getMessage(e){return`Please configure an error message for "${this.name}" by overriding "static async getMessage()"`}onFormControlConnect(e){}onFormControlDisconnect(e){}abortExecution(){}__fakeExtendsEventTarget(){const e=document.createDocumentFragment();this.addEventListener=(t,n,i)=>e.addEventListener(t,n,i),this.removeEventListener=(t,n,i)=>e.removeEventListener(t,n,i),this.dispatchEvent=t=>e.dispatchEvent(t)}}class M extends V{executeOnResults({regularValidationResult:e,prevValidationResult:t,prevShownValidationResult:n,validators:i}){return!0}}class B extends V{static get validatorName(){return"Required"}static get _compatibleRoles(){return["combobox","gridcell","input","listbox","radiogroup","select","spinbutton","textarea","textbox","tree"]}static get _compatibleTags(){return["input","select","textarea"]}onFormControlConnect({_inputNode:e}){if(e){const t=e.getAttribute("role")||"",n=e.tagName.toLowerCase(),i=this.constructor;(i._compatibleRoles.includes(t)||i._compatibleTags.includes(n))&&e.setAttribute("aria-required","true")}}onFormControlDisconnect({_inputNode:e}){e&&e.removeAttribute("aria-required")}}function $(e=[],t=[]){return e.filter((e=>!t.includes(e))).concat(t.filter((t=>!e.includes(t))))}const j=(0,I.S)((e=>class extends(R(U((0,A.f)((0,x.J)((0,w.f)(e)))))){static get scopedElements(){return{...super.constructor.scopedElements,"lion-validation-feedback":F}}static get properties(){return{validators:{attribute:!1},hasFeedbackFor:{attribute:!1},shouldShowFeedbackFor:{attribute:!1},showsFeedbackFor:{type:Array,attribute:"shows-feedback-for",reflect:!0,converter:{fromAttribute:e=>e.split(","),toAttribute:e=>e.join(",")}},validationStates:{attribute:!1},isPending:{type:Boolean,attribute:"is-pending",reflect:!0},defaultValidators:{attribute:!1},_visibleMessagesAmount:{attribute:!1},__childModelValueChanged:{attribute:!1}}}static get validationTypes(){return["error"]}get slots(){const e=this.constructor;return{...super.slots,feedback:()=>{const t=document.createElement(e.getScopedTagName("lion-validation-feedback"));return t.setAttribute("data-tag-name","lion-validation-feedback"),t}}}get _allValidators(){return[...this.validators,...this.defaultValidators]}constructor(){super(),this.hasFeedbackFor=[],this.showsFeedbackFor=[],this.shouldShowFeedbackFor=[],this.validationStates={},this.isPending=!1,this.validators=[],this.defaultValidators=[],this._visibleMessagesAmount=1,this.__syncValidationResult=[],this.__asyncValidationResult=[],this.__validationResult=[],this.__prevValidationResult=[],this.__prevShownValidationResult=[],this.__childModelValueChanged=!1,this.__onValidatorUpdated=this.__onValidatorUpdated.bind(this),this._updateFeedbackComponent=this._updateFeedbackComponent.bind(this)}connectedCallback(){super.connectedCallback(),f.N.addEventListener("localeChanged",this._updateFeedbackComponent)}disconnectedCallback(){super.disconnectedCallback(),f.N.removeEventListener("localeChanged",this._updateFeedbackComponent)}firstUpdated(e){super.firstUpdated(e),this.__validateInitialized=!0,this.validate(),"child"!==this._repropagationRole&&this.addEventListener("model-value-changed",(()=>{this.__childModelValueChanged=!0}))}updateSync(e,t){if(super.updateSync(e,t),"validators"===e?(this.__setupValidators(),this.validate({clearCurrentResult:!0})):"modelValue"===e&&this.validate({clearCurrentResult:!0}),["touched","dirty","prefilled","focused","submitted","hasFeedbackFor","filled"].includes(e)&&this._updateShouldShowFeedbackFor(),"showsFeedbackFor"===e){this._inputNode&&this._inputNode.setAttribute("aria-invalid",`${this._hasFeedbackVisibleFor("error")}`);const e=$(this.showsFeedbackFor,t);e.length>0&&this.dispatchEvent(new Event("showsFeedbackForChanged",{bubbles:!0})),e.forEach((e=>{var t;this.dispatchEvent(new Event(`showsFeedbackFor${t=e,t.charAt(0).toUpperCase()+t.slice(1)}Changed`,{bubbles:!0}))}))}if("shouldShowFeedbackFor"===e){$(this.shouldShowFeedbackFor,t).length>0&&this.dispatchEvent(new Event("shouldShowFeedbackForChanged",{bubbles:!0}))}}async validate({clearCurrentResult:e}={}){if(this.disabled)return this.__clearValidationResults(),this.__finishValidation({source:"sync",hasAsync:!0}),void this._updateFeedbackComponent();this.__validateInitialized&&(this.__prevValidationResult=this.__validationResult,e&&this.__clearValidationResults(),await this.__executeValidators())}async __executeValidators(){this.validateComplete=new Promise((e=>{this.__validateCompleteResolve=e}));const e=this.modelValue instanceof O?this.modelValue.viewValue:this.modelValue,t=this._allValidators.find((e=>e instanceof B));if(this.__isEmpty(e))return t&&(this.__syncValidationResult=[t]),void this.__finishValidation({source:"sync"});const n=this._allValidators.filter((e=>!(e instanceof M||e instanceof B))),i=n.filter((e=>!e.constructor.async)),s=n.filter((e=>e.constructor.async));this.__executeSyncValidators(i,e,{hasAsync:Boolean(s.length)}),await this.__executeAsyncValidators(s,e)}__executeSyncValidators(e,t,{hasAsync:n}){e.length&&(this.__syncValidationResult=e.filter((e=>e.execute(t,e.param,{node:this})))),this.__finishValidation({source:"sync",hasAsync:n})}async __executeAsyncValidators(e,t){if(e.length){this.isPending=!0;const n=e.map((e=>e.execute(t,e.param,{node:this}))),i=await Promise.all(n);this.__asyncValidationResult=i.map(((t,n)=>e[n])).filter(((e,t)=>i[t])),this.__finishValidation({source:"async"}),this.isPending=!1}}__executeResultValidators(e){return this._allValidators.filter((e=>!e.constructor.async&&e instanceof M)).filter((t=>t.executeOnResults({regularValidationResult:e,prevValidationResult:this.__prevValidationResult,prevShownValidationResult:this.__prevShownValidationResult})))}__finishValidation({source:e,hasAsync:t}){const n=[...this.__syncValidationResult,...this.__asyncValidationResult],i=this.__executeResultValidators(n);this.__validationResult=[...i,...n];const s=this.constructor.validationTypes.reduce(((e,t)=>({...e,[t]:{}})),{});this.__validationResult.forEach((e=>{s[e.type]||(s[e.type]={});const t=e.constructor;s[e.type][t.validatorName]=!0})),this.validationStates=s,this.hasFeedbackFor=[...new Set(this.__validationResult.map((e=>e.type)))],this.dispatchEvent(new Event("validate-performed",{bubbles:!0})),"async"!==e&&t||this.__validateCompleteResolve&&this.__validateCompleteResolve()}__clearValidationResults(){this.__syncValidationResult=[],this.__asyncValidationResult=[]}__onValidatorUpdated(e){"param-changed"!==e.type&&"config-changed"!==e.type||this.validate()}__setupValidators(){const e=["param-changed","config-changed"];this.__prevValidators&&this.__prevValidators.forEach((t=>{e.forEach((e=>{t.removeEventListener&&t.removeEventListener(e,this.__onValidatorUpdated)})),t.onFormControlDisconnect(this)})),this._allValidators.forEach((t=>{if(!(t instanceof V)){const e=`Validators array only accepts class instances of Validator. Type "${Array.isArray(t)?"array":typeof t}" found. This may be caused by having multiple installations of @lion/form-core.`;throw console.error(e,this),new Error(e)}if(-1===this.constructor.validationTypes.indexOf(t.type)){const e=t.constructor,n=`This component does not support the validator type "${t.type}" used in "${e.validatorName}". You may change your validators type or add it to the components "static get validationTypes() {}".`;throw console.error(n,this),new Error(n)}e.forEach((e=>{t.addEventListener&&t.addEventListener(e,this.__onValidatorUpdated)})),t.onFormControlConnect(this)})),this.__prevValidators=this._allValidators}__isEmpty(e){return"function"==typeof this._isEmpty?this._isEmpty(e):null===this.modelValue||void 0===this.modelValue||""===this.modelValue}async __getFeedbackMessages(e){let t=await this.fieldName;return Promise.all(e.map((async e=>{e.config.fieldName&&(t=await e.config.fieldName);return{message:await e._getMessage({modelValue:this.modelValue,formControl:this,fieldName:t}),type:e.type,validator:e}})))}_updateFeedbackComponent(){const{_feedbackNode:e}=this;e&&(this.__feedbackQueue||(this.__feedbackQueue=new P),this.showsFeedbackFor.length>0?this.__feedbackQueue.add((async()=>{this.__prioritizedResult=this._prioritizeAndFilterFeedback({validationResult:this.__validationResult}),this.__prioritizedResult.length>0&&(this.__prevShownValidationResult=this.__prioritizedResult);const t=await this.__getFeedbackMessages(this.__prioritizedResult);e.feedbackData=t.length?t:[]})):this.__feedbackQueue.add((async()=>{e.feedbackData=[]})),this.feedbackComplete=this.__feedbackQueue.complete)}_showFeedbackConditionFor(e,t){return!0}get _feedbackConditionMeta(){return{modelValue:this.modelValue,el:this}}feedbackCondition(e,t=this._feedbackConditionMeta,n=this._showFeedbackConditionFor.bind(this)){return n(e,t)}_hasFeedbackVisibleFor(e){return this.hasFeedbackFor&&this.hasFeedbackFor.includes(e)&&this.shouldShowFeedbackFor&&this.shouldShowFeedbackFor.includes(e)}updated(e){if(super.updated(e),e.has("shouldShowFeedbackFor")||e.has("hasFeedbackFor")){const e=this.constructor;this.showsFeedbackFor=e.validationTypes.map((e=>this._hasFeedbackVisibleFor(e)?e:void 0)).filter(Boolean),this._updateFeedbackComponent()}if(e.has("__childModelValueChanged")&&this.__childModelValueChanged&&(this.validate({clearCurrentResult:!0}),this.__childModelValueChanged=!1),e.has("validationStates")){const t=e.get("validationStates");t&&Object.entries(this.validationStates).forEach((([e,n])=>{t[e]&&JSON.stringify(n)!==JSON.stringify(t[e])&&this.dispatchEvent(new CustomEvent(`${e}StateChanged`,{detail:n}))}))}}_updateShouldShowFeedbackFor(){const e=this.constructor.validationTypes.map((e=>this.feedbackCondition(e,this._feedbackConditionMeta,this._showFeedbackConditionFor.bind(this))?e:void 0)).filter(Boolean);JSON.stringify(this.shouldShowFeedbackFor)!==JSON.stringify(e)&&(this.shouldShowFeedbackFor=e)}_prioritizeAndFilterFeedback({validationResult:e}){const t=this.constructor.validationTypes;return e.filter((e=>this.feedbackCondition(e.type,this._feedbackConditionMeta,this._showFeedbackConditionFor.bind(this)))).sort(((e,n)=>t.indexOf(e.type)-t.indexOf(n.type))).slice(0,this._visibleMessagesAmount)}})),H=(0,I.S)((e=>class extends(j(R(e))){static get properties(){return{formattedValue:{attribute:!1},serializedValue:{attribute:!1},formatOptions:{attribute:!1}}}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),"modelValue"===e&&this.modelValue!==t&&this._onModelValueChanged({modelValue:this.modelValue},{modelValue:t}),"serializedValue"===e&&this.serializedValue!==t&&this._calculateValues({source:"serialized"}),"formattedValue"===e&&this.formattedValue!==t&&this._calculateValues({source:"formatted"})}get value(){return this._inputNode&&this._inputNode.value||this.__value||""}set value(e){this._inputNode?(this._inputNode.value=e,this.__value=void 0):this.__value=e}preprocessor(e){return e}parser(e,t){return e}formatter(e,t){return e}serializer(e){return void 0!==e?e:""}deserializer(e){return void 0===e?"":e}_calculateValues({source:e}={source:null}){this.__preventRecursiveTrigger||(this.__preventRecursiveTrigger=!0,"model"!==e&&("serialized"===e?this.modelValue=this.deserializer(this.serializedValue):"formatted"===e&&(this.modelValue=this._callParser())),"formatted"!==e&&(this.formattedValue=this._callFormatter()),"serialized"!==e&&(this.serializedValue=this.serializer(this.modelValue)),this._reflectBackFormattedValueToUser(),this.__preventRecursiveTrigger=!1)}_callParser(e=this.formattedValue){if(""===e)return"";if("string"!=typeof e)return;const t=this.parser(e,this.formatOptions);return void 0!==t?t:new O(e)}_callFormatter(){return this._isHandlingUserInput&&this.hasFeedbackFor&&this.hasFeedbackFor.length&&this.hasFeedbackFor.includes("error")&&this._inputNode?this._inputNode?this.value:void 0:this.modelValue instanceof O?this.modelValue.viewValue:this.formatter(this.modelValue,this.formatOptions)}_onModelValueChanged(...e){this._calculateValues({source:"model"}),this._dispatchModelValueChangedEvent(...e)}_dispatchModelValueChangedEvent(...e){this.dispatchEvent(new CustomEvent("model-value-changed",{bubbles:!0,detail:{formPath:[this],isTriggeredByUser:Boolean(this._isHandlingUserInput)}}))}_syncValueUpwards(){this.__isHandlingComposition||(this.value=this.preprocessor(this.value));const e=this.formattedValue;this.modelValue=this._callParser(this.value),e===this.formattedValue&&this.__prevViewValue!==this.value&&this._calculateValues(),this.__prevViewValue=this.value}_reflectBackFormattedValueToUser(){this._reflectBackOn()&&(this.value=void 0!==this.formattedValue?this.formattedValue:"")}_reflectBackOn(){return!this._isHandlingUserInput}_proxyInputEvent(){this.dispatchEvent(new Event("user-input-changed",{bubbles:!0}))}_onUserInputChanged(){this._isHandlingUserInput=!0,this._syncValueUpwards(),this._isHandlingUserInput=!1}__onCompositionEvent({type:e}){"compositionstart"===e?this.__isHandlingComposition=!0:"compositionend"===e&&(this.__isHandlingComposition=!1,this._syncValueUpwards())}constructor(){super(),this.formatOn="change",this.formatOptions={},this.formattedValue=void 0,this.serializedValue=void 0,this._isPasting=!1,this._isHandlingUserInput=!1,this.__prevViewValue="",this.__onCompositionEvent=this.__onCompositionEvent.bind(this),this.addEventListener("user-input-changed",this._onUserInputChanged),this.addEventListener("paste",this.__onPaste),this._reflectBackFormattedValueToUser=this._reflectBackFormattedValueToUser.bind(this),this._reflectBackFormattedValueDebounced=()=>{setTimeout(this._reflectBackFormattedValueToUser)}}__onPaste(){this._isPasting=!0,this.formatOptions.mode="pasted",setTimeout((()=>{this._isPasting=!1,this.formatOptions.mode="auto"}))}connectedCallback(){super.connectedCallback(),void 0===this.modelValue&&this._syncValueUpwards(),this._reflectBackFormattedValueToUser(),this._inputNode&&(this._inputNode.addEventListener(this.formatOn,this._reflectBackFormattedValueDebounced),this._inputNode.addEventListener("input",this._proxyInputEvent),this._inputNode.addEventListener("compositionstart",this.__onCompositionEvent),this._inputNode.addEventListener("compositionend",this.__onCompositionEvent))}disconnectedCallback(){super.disconnectedCallback(),this._inputNode&&(this._inputNode.removeEventListener("input",this._proxyInputEvent),this._inputNode.removeEventListener(this.formatOn,this._reflectBackFormattedValueDebounced),this._inputNode.removeEventListener("compositionstart",this.__onCompositionEvent),this._inputNode.removeEventListener("compositionend",this.__onCompositionEvent))}})),G=(e,t={})=>e.value!==t.value||e.checked!==t.checked,z=(0,I.S)((e=>class extends(H(e)){static get properties(){return{checked:{type:Boolean,reflect:!0},disabled:{type:Boolean,reflect:!0},modelValue:{type:Object,hasChanged:G},choiceValue:{type:Object}}}get choiceValue(){return this.modelValue.value}set choiceValue(e){this.requestUpdate("choiceValue",this.choiceValue),this.modelValue.value!==e&&(this.modelValue={value:e,checked:this.modelValue.checked})}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),"modelValue"===e?this.modelValue.checked!==this.checked&&this.__syncModelCheckedToChecked(this.modelValue.checked):"checked"===e&&this.modelValue.checked!==this.checked&&this.__syncCheckedToModel(this.checked)}firstUpdated(e){super.firstUpdated(e),e.has("checked")&&this.__syncCheckedToInputElement()}updated(e){super.updated(e),e.has("modelValue")&&this.__syncCheckedToInputElement(),e.has("name")&&this._parentFormGroup&&this._parentFormGroup.name!==this.name&&this._syncNameToParentFormGroup()}constructor(){super(),this.modelValue={value:"",checked:!1},this.disabled=!1,this._preventDuplicateLabelClick=this._preventDuplicateLabelClick.bind(this),this._toggleChecked=this._toggleChecked.bind(this)}static get styles(){return[...super.styles||[],E.iv`
          :host {
            display: flex;
            flex-wrap: wrap;
          }

          :host([hidden]) {
            display: none;
          }

          .choice-field__graphic-container {
            display: none;
          }
          .choice-field__help-text {
            display: block;
            flex-basis: 100%;
          }
        `]}render(){return T.dy`
        <slot name="input"></slot>
        <div class="choice-field__graphic-container">${this._choiceGraphicTemplate()}</div>
        <div class="choice-field__label">
          <slot name="label"></slot>
        </div>
        <small class="choice-field__help-text">
          <slot name="help-text"></slot>
        </small>
        ${this._afterTemplate()}
      `}_choiceGraphicTemplate(){return T.Ld}_afterTemplate(){return T.Ld}connectedCallback(){super.connectedCallback(),this._labelNode&&this._labelNode.addEventListener("click",this._preventDuplicateLabelClick),this.addEventListener("user-input-changed",this._toggleChecked)}disconnectedCallback(){super.disconnectedCallback(),this._labelNode&&this._labelNode.removeEventListener("click",this._preventDuplicateLabelClick),this.removeEventListener("user-input-changed",this._toggleChecked)}_preventDuplicateLabelClick(e){const t=e=>{e.stopImmediatePropagation(),this._inputNode.removeEventListener("click",t)};this._inputNode.addEventListener("click",t)}_toggleChecked(e){this.disabled||(this._isHandlingUserInput=!0,this.checked=!this.checked,this._isHandlingUserInput=!1)}_syncNameToParentFormGroup(){this._parentFormGroup.tagName.includes(this.tagName)&&(this.name=this._parentFormGroup?.name||"")}__syncModelCheckedToChecked(e){this.checked=e}__syncCheckedToModel(e){this.modelValue={value:this.choiceValue,checked:e}}__syncCheckedToInputElement(){this._inputNode&&(this._inputNode.checked=this.checked)}_proxyInputEvent(){}_onModelValueChanged({modelValue:e},t){let n;t&&t.modelValue&&(n=t.modelValue),this.constructor._classProperties.get("modelValue").hasChanged(e,n)&&super._onModelValueChanged({modelValue:e})}parser(){return this.modelValue}formatter(e){return e&&void 0!==e.value?e.value:e}clear(){this.checked=!1}_isEmpty(){return!this.checked}_syncValueUpwards(){}})),W=window,q=new WeakMap;const J=(0,I.S)((e=>class extends e{static get properties(){return{focused:{type:Boolean,reflect:!0},focusedVisible:{type:Boolean,reflect:!0,attribute:"focused-visible"}}}constructor(){super(),this.focused=!1,this.focusedVisible=!1}connectedCallback(){super.connectedCallback(),this.__registerEventsForFocusMixin()}disconnectedCallback(){super.disconnectedCallback(),this.__teardownEventsForFocusMixin()}focus(){this._focusableNode?.focus()}blur(){this._focusableNode?.blur()}get _focusableNode(){return this._inputNode||document.createElement("input")}__onFocus(){if(this.focused=!0,"function"==typeof W.applyFocusVisiblePolyfill)this.focusedVisible=this._focusableNode.hasAttribute("data-focus-visible-added");else try{this.focusedVisible=this._focusableNode.matches(":focus-visible")}catch(e){this.focusedVisible=!1}}__onBlur(){this.focused=!1,this.focusedVisible=!1}__registerEventsForFocusMixin(){var e;e=this.getRootNode(),W.applyFocusVisiblePolyfill&&!q.has(e)&&(W.applyFocusVisiblePolyfill(e),q.set(e,void 0)),this.__redispatchFocus=e=>{e.stopPropagation(),this.dispatchEvent(new Event("focus"))},this._focusableNode.addEventListener("focus",this.__redispatchFocus),this.__redispatchBlur=e=>{e.stopPropagation(),this.dispatchEvent(new Event("blur"))},this._focusableNode.addEventListener("blur",this.__redispatchBlur),this.__redispatchFocusin=e=>{e.stopPropagation(),this.__onFocus(),this.dispatchEvent(new Event("focusin",{bubbles:!0,composed:!0}))},this._focusableNode.addEventListener("focusin",this.__redispatchFocusin),this.__redispatchFocusout=e=>{e.stopPropagation(),this.__onBlur(),this.dispatchEvent(new Event("focusout",{bubbles:!0,composed:!0}))},this._focusableNode.addEventListener("focusout",this.__redispatchFocusout)}__teardownEventsForFocusMixin(){this._focusableNode.removeEventListener("focus",this.__redispatchFocus),this._focusableNode.removeEventListener("blur",this.__redispatchBlur),this._focusableNode.removeEventListener("focusin",this.__redispatchFocusin),this._focusableNode.removeEventListener("focusout",this.__redispatchFocusout)}})),K=(0,I.S)((e=>class extends(R(e)){static get properties(){return{touched:{type:Boolean,reflect:!0},dirty:{type:Boolean,reflect:!0},filled:{type:Boolean,reflect:!0},prefilled:{attribute:!1},submitted:{attribute:!1}}}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),"touched"===e&&this.touched!==t&&this._onTouchedChanged(),"modelValue"===e&&(this.filled=!this._isEmpty()),"dirty"===e&&this.dirty!==t&&this._onDirtyChanged()}constructor(){super(),this.touched=!1,this.dirty=!1,this.prefilled=!1,this.filled=!1,this._leaveEvent="blur",this._valueChangedEvent="model-value-changed",this._iStateOnLeave=this._iStateOnLeave.bind(this),this._iStateOnValueChange=this._iStateOnValueChange.bind(this)}connectedCallback(){super.connectedCallback(),this.addEventListener(this._leaveEvent,this._iStateOnLeave),this.addEventListener(this._valueChangedEvent,this._iStateOnValueChange),this.initInteractionState()}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(this._leaveEvent,this._iStateOnLeave),this.removeEventListener(this._valueChangedEvent,this._iStateOnValueChange)}initInteractionState(){this.dirty=!1,this.prefilled=!this._isEmpty()}_iStateOnLeave(){this.touched=!0,this.prefilled=!this._isEmpty()}_iStateOnValueChange(){this.dirty=!0}resetInteractionState(){this.touched=!1,this.submitted=!1,this.dirty=!1,this.prefilled=!this._isEmpty()}_onTouchedChanged(){this.dispatchEvent(new Event("touched-changed",{bubbles:!0,composed:!0}))}_onDirtyChanged(){this.dispatchEvent(new Event("dirty-changed",{bubbles:!0,composed:!0}))}_showFeedbackConditionFor(e,t){return t.touched&&t.dirty||t.prefilled||t.submitted}get _feedbackConditionMeta(){return{...super._feedbackConditionMeta,submitted:this.submitted,touched:this.touched,dirty:this.dirty,filled:this.filled,prefilled:this.prefilled}}}));class Y extends(R(K(J(H(j((0,x.J)(E.oi))))))){firstUpdated(e){super.firstUpdated(e),this._initialModelValue=this.modelValue}connectedCallback(){super.connectedCallback(),this._onChange=this._onChange.bind(this),this._inputNode.addEventListener("change",this._onChange),this.classList.add("form-field")}disconnectedCallback(){super.disconnectedCallback(),this._inputNode.removeEventListener("change",this._onChange)}resetInteractionState(){super.resetInteractionState(),this.submitted=!1}reset(){this.modelValue=this._initialModelValue,this.resetInteractionState()}clear(){this.modelValue=""}_onChange(){this.dispatchEvent(new Event("user-input-changed",{bubbles:!0}))}get _feedbackConditionMeta(){return{...super._feedbackConditionMeta,focused:this.focused}}get _focusableNode(){return this._inputNode}}var Q=n(5538);class X extends((0,Q.b)(E.oi)){static get properties(){return{role:{type:String,reflect:!0},checked:{type:Boolean,reflect:!0}}}static get styles(){return[E.iv`
        :host {
          display: inline-block;
          position: relative;
          width: 36px;
          height: 16px;
          outline: 0;
        }

        :host([hidden]) {
          display: none;
        }

        .btn {
          position: relative;
          height: 100%;
          outline: 0;
        }

        :host(:focus:not([disabled])) .switch-button__thumb {
          /* if you extend, please overwrite */
          outline: 2px solid #bde4ff;
        }

        .switch-button__track {
          background: #eee;
          width: 100%;
          height: 100%;
        }

        .switch-button__thumb {
          background: #ccc;
          width: 50%;
          height: 100%;
          position: absolute;
          top: 0;
        }

        :host([checked]) .switch-button__thumb {
          right: 0;
        }
      `]}render(){return T.dy`
      <div class="btn">
        <div class="switch-button__track"></div>
        <div class="switch-button__thumb"></div>
      </div>
    `}constructor(){super(),this.value="",this.role="switch",this.checked=!1,this._toggleChecked=this._toggleChecked.bind(this),this.__handleKeydown=this.__handleKeydown.bind(this),this.__handleKeyup=this.__handleKeyup.bind(this)}connectedCallback(){super.connectedCallback(),this.setAttribute("aria-checked",`${this.checked}`),this.addEventListener("click",this._toggleChecked),this.addEventListener("keydown",this.__handleKeydown),this.addEventListener("keyup",this.__handleKeyup)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("click",this._toggleChecked),this.removeEventListener("keydown",this.__handleKeydown),this.removeEventListener("keyup",this.__handleKeyup)}_toggleChecked(){this.disabled||(this.focus(),this.checked=!this.checked)}__checkedStateChange(){this.dispatchEvent(new Event("checked-changed",{composed:!0,bubbles:!0})),this.setAttribute("aria-checked",`${this.checked}`)}__handleKeydown(e){32===e.keyCode&&e.preventDefault()}__handleKeyup(e){-1!==[32,13].indexOf(e.keyCode)&&this._toggleChecked()}updated(e){e.has("disabled")&&this.setAttribute("aria-disabled",`${this.disabled}`)}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),this.isConnected&&"checked"===e&&this.checked!==t&&this.__checkedStateChange()}}class Z extends((0,w.f)(z(Y))){static get styles(){return[...super.styles,E.iv`
        :host([hidden]) {
          display: none;
        }

        :host([disabled]) {
          color: #adadad;
        }
      `]}static get scopedElements(){return{...super.scopedElements,"lion-switch-button":X}}get _inputNode(){return Array.from(this.children).find((e=>"input"===e.slot))}get slots(){return{...super.slots,input:()=>{const e=document.createElement(this.constructor.getScopedTagName("lion-switch-button"));return e.setAttribute("data-tag-name","lion-switch-button"),e}}}render(){return T.dy`
      <div class="form-field__group-one">${this._groupOneTemplate()}</div>
      <div class="form-field__group-two">${this._groupTwoTemplate()}</div>
    `}_groupOneTemplate(){return T.dy`${this._labelTemplate()} ${this._helpTextTemplate()} ${this._feedbackTemplate()}`}_groupTwoTemplate(){return T.dy`${this._inputGroupTemplate()}`}constructor(){super(),this.role="switch",this.checked=!1,this.__handleButtonSwitchCheckedChanged=this.__handleButtonSwitchCheckedChanged.bind(this)}connectedCallback(){super.connectedCallback(),this._inputNode&&this._inputNode.addEventListener("checked-changed",this.__handleButtonSwitchCheckedChanged),this._labelNode&&this._labelNode.addEventListener("click",this._toggleChecked),this._syncButtonSwitch()}disconnectedCallback(){this._inputNode&&this._inputNode.removeEventListener("checked-changed",this.__handleButtonSwitchCheckedChanged),this._labelNode&&this._labelNode.removeEventListener("click",this._toggleChecked)}updated(e){super.updated(e),this._syncButtonSwitch()}_isEmpty(){return!1}__handleButtonSwitchCheckedChanged(){this._isHandlingUserInput=!0,this.checked=this._inputNode.checked,this._isHandlingUserInput=!1}_syncButtonSwitch(){this._inputNode.disabled=this.disabled}_onLabelClick(){this.disabled||this._inputNode.focus()}}class ee extends M{constructor(...e){super(...e),this.type="success"}executeOnResults({regularValidationResult:e,prevShownValidationResult:t}){const n=e=>"error"===e.type||"warning"===e.type,i=!!e.filter(n).length,s=!!t.filter(n).length;return!i&&s}}var te=n(3009),ne=n(7279),ie=n(5104),se=n(451);class oe extends((0,y.fN)(F)){static get scopedElements(){return{...super.scopedElements,"ing-icon":ie.O}}static get properties(){return{feedbackData:{type:Object}}}static get styles(){return[super.styles||[],y.y5`
        :host {
          display: block;
        }

        :host([hidden]) {
          display: none;
        }

        .container {
          display: flex;
          margin-top: 4px;
        }

        .icon {
          width: 20px;
          height: 20px;
          flex-shrink: 0;
          margin-top: 2px;
        }

        .text {
          flex-grow: 1;
          ${(0,m.fQ)()};
          color: ${b.H9};
          padding-left: 8px;
        }

        .visually-hidden {
          ${(0,se.X)()}
        }
      `]}connectedCallback(){super.connectedCallback(),this.setAttribute("aria-live","polite")}__capitalize(e){return"string"!=typeof e?"":e.charAt(0).toUpperCase()+e.slice(1)}_messageTemplate({message:e,type:t}){return y.dy`
      <div id="container" class="container">
        ${e?y.dy`
              <ing-icon
                id="icon"
                class="icon"
                icon-id="ing:filledin-notification:notification${"info"===t?"Information":this.__capitalize(t)}"
              ></ing-icon>
              <span id="text" class="text"> ${e} </span>
            `:y.dy``}
      </div>
    `}}const re=(0,u.SV)((e=>class extends e{static _isPrefilled(e){let t=e;if(e instanceof O&&(t=e.viewValue),"object"==typeof t&&null!==t&&!(t instanceof Date))return!!Object.keys(t).length;const n="number"==typeof t&&(0===t||Number.isNaN(t));return!!t||n||"boolean"==typeof t&&!1===t}})),ae=(0,u.SV)((e=>class extends e{static _isPrefilled(e){return e.checked}})),ce=(0,u.SV)((e=>class extends((0,te.l)(R((0,u.JO)(e)))){static get properties(){return{displayOptional:{type:Boolean,reflect:!0,attribute:"display-optional"}}}static get styles(){return[super.styles,y.y5`
          .form-field__label ::slotted(.form-field__label-optional) {
            color: ${b.Nr};
          }
        `]}static get localizeNamespaces(){return[{"ing-field":e=>{switch(e){case"bg-BG":return n.e(7335).then(n.bind(n,7335));case"bg":return n.e(6703).then(n.bind(n,6703));case"cs-CZ":return n.e(715).then(n.bind(n,715));case"cs":return n.e(1234).then(n.bind(n,1234));case"de-DE":return n.e(1312).then(n.bind(n,1312));case"de":return n.e(4412).then(n.bind(n,4412));case"en-AU":return n.e(3026).then(n.bind(n,3026));case"en-GB":return n.e(4711).then(n.bind(n,4711));case"en-US":return n.e(3718).then(n.bind(n,3718));case"en-PH":case"en":return n.e(1673).then(n.bind(n,1673));case"es-ES":return n.e(5650).then(n.bind(n,5650));case"es":return n.e(6712).then(n.bind(n,6712));case"fr-BE":return n.e(5112).then(n.bind(n,5112));case"fr-FR":return n.e(2908).then(n.bind(n,2908));case"fr":return n.e(1136).then(n.bind(n,1136));case"hu-HU":return n.e(9695).then(n.bind(n,9695));case"hu":return n.e(1089).then(n.bind(n,1089));case"id-ID":return n.e(658).then(n.bind(n,658));case"id":return n.e(6074).then(n.bind(n,6074));case"it-IT":return n.e(6944).then(n.bind(n,6944));case"it":return n.e(2734).then(n.bind(n,2734));case"nl-BE":return n.e(4045).then(n.bind(n,4045));case"nl-NL":return n.e(2522).then(n.bind(n,2522));case"nl":return n.e(4875).then(n.bind(n,4875));case"pl-PL":return n.e(1451).then(n.bind(n,1451));case"pl":return n.e(7286).then(n.bind(n,7286));case"ro-RO":return n.e(6483).then(n.bind(n,6483));case"ro":return n.e(485).then(n.bind(n,485));case"ru-RU":return n.e(4573).then(n.bind(n,4573));case"ru":return n.e(479).then(n.bind(n,479));case"sk-SK":return n.e(4051).then(n.bind(n,4051));case"sk":return n.e(394).then(n.bind(n,394));case"uk-UA":return n.e(3604).then(n.bind(n,3604));case"uk":return n.e(3029).then(n.bind(n,3029));case"zh-CN":case"zh":return n.e(5539).then(n.bind(n,5539));default:return n(7731)(`./${e}.js`)}}},...super.localizeNamespaces]}get slots(){return{...super.slots,"_label-optional":()=>{if(this.displayOptional){const e=document.createElement("span");return e.classList.add("form-field__label-optional"),this.addToAriaLabelledBy(e,{idPrefix:"label-optional"}),e}}}}constructor(){super(),this.displayOptional=!1}firstUpdated(e){super.firstUpdated(e),this.displayOptional&&(this.__getDirectSlotChild("_label-optional").textContent=`(${f.N.msg("ing-field:optional")})`)}_labelTemplate(){return u.dy`
        <div class="form-field__label">
          <slot name="label"></slot>
          <slot name="_label-optional"></slot>
        </div>
      `}})),le=["default","wide-right","wide-left"],de=le.join(", "),ue=(0,u.SV)((e=>class extends e{static get properties(){return{layout:{type:String,reflect:!0}}}constructor(){super(),this.__layout="default"}set layout(e){const t=this.__layout;if(-1===le.indexOf(e))throw new Error(`Given Layout "${e}" is invalid. Valid values are ${de}.`);this.__layout=e,this.requestUpdate("layout",t)}get layout(){return this.__layout}})),he=y.y5`
  :host([layout^='wide-']:not([inline]):not([type='hidden'])) {
    display: flex;
    justify-content: center;
  }

  :host([layout^='wide-']:not([inline])) .form-field__group-one {
    width: 288px;
    flex: none;
    padding-top: 8px;
    margin-right: 12px;
  }

  :host([layout='wide-right']:not([inline])) .form-field__group-one {
    text-align: right;
  }

  :host([layout='wide-left']:not([inline])) .form-field__group-one {
    text-align: left;
  }

  :host([layout^='wide-']:not([inline])) .form-field__group-two {
    flex: auto;
    margin-left: 12px;
  }
`,pe=b.zx,fe=b.F8,ge=b.Nr,ve=(0,u.SV)((e=>class extends((0,u.fN)(re(ce(ue(j((0,u.JO)((0,te.l)(e)))))))){static get scopedElements(){return{...super.scopedElements,"ing-validation-feedback":oe}}static get properties(){return{...super.properties,disableHelpText:{type:Boolean,attribute:"disable-help-text"},labelSrOnly:{type:Boolean,attribute:"label-sr-only",reflect:!0},inline:{type:Boolean,reflect:!0}}}get slots(){return{...super.slots,feedback:()=>{const e=this.constructor,t=document.createElement(e.getScopedTagName("ing-validation-feedback"));return t.setAttribute("data-tag-name","ing-validation-feedback"),t},"help-text":()=>{if(!this.disableHelpText)return super.slots["help-text"]()}}}static get validationTypes(){return["error","warning","info","success"]}static get styles(){return[super.styles?super.styles:[],he,y.y5`
          /*************************
            {block} .form-field
           ********************/

          :host {
            display: block;
            margin-bottom: ${ne.nu};
          }

          :host([type='hidden']) {
            display: none;
          }

          :host([inline]:not(:last-of-type)) {
            margin-right: ${ne.nu};
          }

          /*********************************
            {element} .form-field__label  */
          .form-field__label {
            display: block;
          }

          .form-field__label ::slotted(*) {
            color: ${b.H9};
            ${(0,m.fQ)()};
            margin-bottom: ${ne.hM};
          }

          :host([disabled]) .form-field__label ::slotted(*) {
            color: ${pe};
            border-color: ${fe};
          }

          :host([label-sr-only]) .form-field__label {
            ${(0,se.X)()}
          }

          /**************************************
            {element} .form-field__help-text  */

          .form-field__help-text ::slotted(*:not(:empty)) {
            display: block;
            color: ${b.Nr};
            ${(0,m.Ai)()};
            margin-bottom: ${ne.hM};
          }

          :host([disabled]) .form-field__help-text ::slotted(*) {
            color: ${pe};
            border-color: ${fe};
          }

          /************************
            {block} .input-group
           ********************/

          .input-group {
            display: flex;
            width: var(--ing-input-group-width);
          }

          /**************************************
            {element} .input-group__container  */

          .input-group__container {
            position: relative;
            display: flex;
            flex-wrap: wrap;
            align-items: stretch;
            width: var(--ing-input-element-width, 100%);
            border-radius: 4px;
            box-shadow: inset 0 2px 2px ${b.F8};
            background: white;
          }

          /**********************************
            {element} .input-group__input  */

          .input-group__input {
            display: flex;
            flex: 1;
          }

          /*************************
            {block} .form-control
           *********************/

          .input-group__container > .input-group__input ::slotted(.form-control) {
            ${(0,m.fQ)()};
            display: block;
            box-sizing: border-box;
            flex: 1 1 auto;
            width: 1%;
            height: 40px;
            border: 1px solid ${ge};
            border-radius: 0;
            border-right: none;
            border-left: none;
            color: ${b.H9};
            background-clip: padding-box;
            background: transparent;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
            padding: ${ne.dl} ${ne.nu};
          }

          .input-group__container > .input-group__input:first-child ::slotted(.form-control) {
            border-top-left-radius: 4px;
            border-bottom-left-radius: 4px;
            border-left: 1px solid ${ge};
          }

          .input-group__container > .input-group__input:last-child ::slotted(.form-control) {
            border-top-right-radius: 4px;
            border-bottom-right-radius: 4px;
            border-right: 1px solid ${ge};
          }

          :host([disabled]) .input-group__container > .input-group__input ::slotted(.form-control) {
            color: ${pe};
            border-color: ${fe};
            background-color: ${b.ix};
          }

          :host([disabled]) .input-group__container {
            box-shadow: none;
          }

          /*******************************************************************
            {element} .input-group__prefix, {element} .input-group__suffix  */

          .input-group__prefix,
          .input-group__suffix {
            display: flex;
          }

          .input-group__prefix ::slotted(*),
          .input-group__suffix ::slotted(*) {
            display: flex;
            align-items: center;
            text-align: center;
            line-height: 1.5;
            white-space: nowrap;
            background: transparent;
            border: 1px solid ${ge};
            fill: ${b.$y};
            padding: 6px ${ne.nu};
            margin-bottom: 0;
          }

          .input-group__container > .input-group__prefix ::slotted(*) {
            border-top-left-radius: 4px;
            border-bottom-left-radius: 4px;
            border-right: none;
            margin-right: -1px;
          }

          .input-group__container > .input-group__suffix ::slotted(*) {
            border-top-right-radius: 4px;
            border-bottom-right-radius: 4px;
            border-left: none;
            margin-left: -1px;
          }

          .input-group__container > .input-group__prefix ::slotted(button)::-moz-focus-inner,
          .input-group__container > .input-group__suffix ::slotted(button)::-moz-focus-inner {
            border: 0;
          }

          :host([disabled]) .input-group__container > .input-group__prefix ::slotted(*),
          :host([disabled]) .input-group__container > .input-group__suffix ::slotted(*) {
            color: ${pe};
            fill: ${fe};
            border-color: ${fe};
          }

          /*****  {state} :error  *****/

          :host([shows-feedback-for~='error'])
            .input-group__container
            > .input-group__input
            > ::slotted(.form-control) {
            border: 1px solid ${b.Q6};
          }

          /*****  {state} :focus  *****/

          .input-group__container > .input-group__prefix ::slotted(*:focus),
          .input-group__container > .input-group__suffix ::slotted(*:focus) {
            outline: none;
            box-shadow: 0 0 8px ${b.vv};
            border: 1px solid ${b.Bt};
            border-left: 1px solid ${ge};
          }

          :host([focused]) .input-group__container > .input-group__input ::slotted(.form-control) {
            outline: none;
            box-shadow: 0 0 8px ${b.vv};
            border: 1px solid ${b.Bt};
            z-index: 1;
          }

          /*****  {state} :read-only  *****/

          .input-group__container > .input-group__input > ::slotted(*[readonly]) {
            background-color: ${b.YM};
            border: 1px solid ${ge};
          }

          :host([readonly]) .input-group__container > .input-group__prefix ::slotted(*),
          :host([readonly]) .input-group__container > .input-group__suffix ::slotted(*) {
            background-color: ${b.YM};
            color: ${pe};
            fill: ${pe};
            border-color: ${ge};
          }

          /*******************************************************************
            {element} .input-group__before, {element} .input-group__after  */

          .input-group__before,
          .input-group__after {
            display: flex;
          }

          .input-group__before ::slotted(*),
          .input-group__after ::slotted(*) {
            color: ${b.H9};
            align-self: center;
            line-height: 1.5;
          }

          .input-group__before ::slotted(*) {
            margin-right: ${ne.dl};
          }

          .input-group__after ::slotted(*) {
            margin-left: ${ne.dl};
          }

          /** reset native button styles across browsers */
          :host ::slotted(button[slot='before']),
          :host ::slotted(button[slot='after']),
          :host ::slotted(button[slot='prefix']),
          :host ::slotted(button[slot='suffix']) {
            margin: 0;
          }
        `]}constructor(){super(),this.inline=!1,this.disableHelpText=!1,this.labelSrOnly=!1,this._isUserProvidedLabel="",this.defaultValidators.push(new ee)}connectedCallback(){super.connectedCallback(),this._isUserProvidedLabel=this.label}firstUpdated(e){if(super.firstUpdated(e),this.inline){const e=this._parentFormGroup;e.updateComplete.then((()=>{e.alignFormGroupOne(this._getAlignmentAxis())}))}}_helpTextTemplate(){return this.disableHelpText||!super._helpTextTemplate?u.dy`${u.Ld}`:super._helpTextTemplate()}_getAlignmentAxis(){const e=this.shadowRoot?.querySelector(".input-group");if(e){const t=e.offsetHeight;let n=0;return e.getClientRects()[0]&&this.getClientRects()[0]&&(n=e.getClientRects()[0].y-this.getClientRects()[0].y),n+.5*t}return 0}})),_e=y.y5`20px`;class be extends X{static get styles(){return[...super.styles,y.y5`
        :host {
          height: 40px;
        }
        .btn {
          position: relative;
          top: 10px;
          height: 20px;
          background: transparent;
        }

        .switch-button__track {
          position: relative;
          top: 2px;
          background: ${b.YM};
          border: 1px solid ${b.Nr};
          height: 16px;
          padding: 2px 0;
          border-radius: 10px;
          box-sizing: border-box;
          transition: border-color 300ms cubic-bezier(0.4, 0, 0.2, 1),
            background 300ms cubic-bezier(0.4, 0, 0.2, 1);
        }

        .switch-button__thumb {
          background: ${b.ix};
          border: 1px solid ${b.Nr};
          box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.12),
            0 1px 5px 0 rgba(0, 0, 0, 0.2);
          width: ${_e};
          height: ${_e};
          left: 0px;
          border-radius: 10px;
          box-sizing: border-box;

          transition: border-color 300ms cubic-bezier(0.4, 0, 0.2, 1),
            box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1), left 300ms cubic-bezier(0.4, 0, 0.2, 1);
        }

        :host(:focus) .btn {
          outline: none;
        }

        :host(:focus) .switch-button__thumb {
          border: 1px solid ${b.Bt};
          box-shadow: 0 0 8px ${b.vv};
        }

        :host(:hover) .btn {
          background: transparent;
        }

        :host(:active) .btn,
        :host([active]) .btn {
          background: transparent;
        }

        :host([checked]) .switch-button__track {
          border: 1px solid ${b.d1};
          background: ${b.d1};
        }

        :host([checked]) .switch-button__thumb {
          right: auto;
          left: calc(100% - ${_e});
        }

        :host([disabled]) .switch-button__track {
          border: 1px solid ${b.F8};
          background: ${b.YM};
        }

        :host([disabled][checked]) .switch-button__track {
          border: 1px solid ${b.pw};
          background: ${b.pw};
        }

        :host([disabled]) .switch-button__thumb {
          border: 1px solid ${b.F8};
          box-shadow: none;
        }

        :host(:focus:not([disabled])) .switch-button__thumb {
          outline: 0;
        }
      `]}}class me extends((0,y.fN)(ae((0,y.JO)(ve(Z))))){static get scopedElements(){return{...super.scopedElements,"ing-switch-button":be}}get slots(){return{...super.slots,input:()=>{const e=this.createScopedElement(this.constructor.getScopedTagName("ing-switch-button"));return e.setAttribute("data-tag-name","ing-switch-button"),e}}}static get styles(){return[...super.styles,y.iv`
        :host {
          display: flex;
          flex-direction: row;
          min-width: 288px;
        }

        .form-field__group-one {
          flex: 1;
        }

        .input-group__container {
          box-shadow: none;
          display: block;
        }

        .input-group__container {
          background: transparent;
        }

        .input-group__container > .input-group__input:last-child ::slotted(.form-control) {
          display: block;
          border: 0;
          border-radius: 0;
          padding: 0 0 0 12px;
          box-shadow: none;
          width: 48px;
          top: -8px;
        }

        :host([focused]) .input-group__container > .input-group__input ::slotted(.form-control) {
          outline: none;
          box-shadow: none;
          border: 0;
        }

        :host([layout^='wide-']) .input-group__container > .input-group__input {
          width: 36px;
        }

        :host([layout^='wide-']) .form-field__group-one {
          padding-top: 0;
        }

        :host([layout^='wide-'])
          .input-group__container
          > .input-group__input:last-child
          ::slotted(.form-control) {
          padding: 0;
        }
      `]}_groupOneTemplate(){return"wide-right"===this.layout||"wide-left"===this.layout?y.dy`${this._labelTemplate()} ${this._helpTextTemplate()}`:y.dy`${this._labelTemplate()} ${this._helpTextTemplate()} ${this._feedbackTemplate()}`}_groupTwoTemplate(){return"wide-right"===this.layout||"wide-left"===this.layout?y.dy`${this._inputGroupTemplate()} ${this._feedbackTemplate()}`:y.dy`${this._inputGroupTemplate()}`}_showFeedbackConditionFor(e,t){return"info"===e||super._showFeedbackConditionFor(e,t)}}},332:(e,t,n)=>{"use strict";n.d(t,{oi:()=>D,fN:()=>P,JO:()=>$,$o:()=>T,iv:()=>m,y5:()=>_,dy:()=>y,$m:()=>k});var i=n(7229),s=n(4971);
/**
 * @license
 * Copyright (c) 2021 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const o=1,r=2,a=3,c=4,l=5;class d{constructor(e){this.type=r,this.options=e.options,this.legacyPart=e}get parentNode(){return this.legacyPart.startNode.parentNode}get startNode(){return this.legacyPart.startNode}get endNode(){return this.legacyPart.endNode}}class u{constructor(e){this.legacyPart=e,this.type=e instanceof s.sL?a:o}get options(){}get name(){return this.legacyPart.committer.name}get element(){return this.legacyPart.committer.element}get strings(){return this.legacyPart.committer.strings}get tagName(){return this.element.tagName}}class h{constructor(e){this.type=c,this.legacyPart=e}get options(){}get name(){return this.legacyPart.name}get element(){return this.legacyPart.element}get strings(){return this.legacyPart.strings}get tagName(){return this.element.tagName}}class p{constructor(e){this.type=l,this.legacyPart=e}get options(){}get name(){return this.legacyPart.eventName}get element(){return this.legacyPart.element}get strings(){}get tagName(){return this.element.tagName}handleEvent(e){this.legacyPart.handleEvent(e)}}var f=n(9566);const g=(0,f.SV)((e=>{class t extends((0,f.fN)(e)){createScopedElement(e){const t=Object.keys(this.constructor.scopedElements).includes(e)?this.getScopedTagName(e):e;return document.createElement(t)}}return t})),v={};v.cssHybrid=f.iv,v.html2Hybrid=f.dy,v.css=f.iv,v.html=f.dy,v.nothing=f.Ld,v.asyncAppend=f.lZ,v.asyncReplace=f.EJ,v.cache=f.Fs,v.classMap=f.$o,v.guard=f.lo,v.ifDefined=f.o5,v.repeat=f.rx,v.styleMap=f.Ve,v.unsafeHTML=f.Au,v.unsafeCSS=f.$m,v.until=f.C4,v.LitElement=f.oi,v.ScopedElementsMixin=g,v.unsafeHTML=f.Au,v.render=f.sY,v.svg=f.YP,v.directive=function(e){const t=new WeakMap;return(0,i.X)(((...n)=>i=>{const o=t.get(i);let r,a;void 0===o?(r=function(e){if(e instanceof s.nt)return new d(e);if(e instanceof s.K1)return new p(e);if(e instanceof s.JG)return new h(e);if(e instanceof s.sL||e instanceof s._l)return new u(e);throw new Error("Unknown part type")}(i),a=new e(r),t.set(i,[r,a])):(r=o[0],a=o[1]),i.setValue(a.update(r,n)),i.commit()}))},v.Directive=class{constructor(e){}update(e,t){return this.render(...t)}},v.dedupeMixin=f.SV,v.SlotMixin=f.JO,v.DelegateMixin=f.Cn,v.UpdateStylesMixin=f.dr,v.isPrimitive=s.pt,v.isTemplateResult=function(e){return Boolean(e&&e.processor&&e.values)},v.removeNodes=f.r4;const{cssHybrid:_,html2Hybrid:b,css:m,html:y,nothing:S,asyncAppend:C,asyncReplace:w,cache:E,classMap:T,guard:I,ifDefined:A,repeat:x,styleMap:N,unsafeHTML:L,unsafeCSS:k,until:O,LitElement:D,isTemplateResult:R,ScopedElementsMixin:P,render:U,svg:F,directive:V,Directive:M,dedupeMixin:B,SlotMixin:$,DelegateMixin:j,UpdateStylesMixin:H,isPrimitive:G}=v},9258:(e,t,n)=>{"use strict";n.d(t,{vH:()=>m,TD:()=>h});var i=n(332),s=n(2005),o=n(5104),r=n(2993);const a=i.y5`
  .button-unstyled {
    font: inherit;
    font-size: ${r.D0};
    margin: 0;
    border: 0;
    outline: 0;
    padding: 0;
    color: inherit;
    background-color: transparent;
    text-align: left;
    white-space: normal;
    overflow: visible;

    user-select: none;
    -moz-user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    -webkit-tap-highlight-color: transparent;
  }

  /* prevents press effect on IE */
  .button-unstyled > * {
    position: relative;
  }

  .button-unstyled:active {
    background: none;
    outline: none;
    padding: 0;
  }

  .button-unstyled::-moz-focus-inner {
    border: 0;
  }
`;var c=n(9047),l=n(170),d=n(3371),u=n(7279);class h extends((0,i.fN)(s.W)){static get scopedElements(){return{"ing-icon":o.O}}static get properties(){return{expanded:{type:Boolean,reflect:!0}}}static get styles(){return[a,...super.styles,i.y5`
        :host {
          ${(0,l.Dn)()}
          display: flex;
          justify-content: space-between;
          align-self: center;
          align-items: flex-start;
          background-color: ${d.ix};
          border-radius: 0;
          border-width: 0;
          padding: ${u.dl} ${u.o7};
        }

        :host(:focus),
        :host([text]:active:focus),
        :host([text][active]:focus) {
          ${(0,c.i)()}
          border-radius: 0;
        }

        :host(:active) {
          border-radius: 0;
          padding: ${u.dl} ${u.o7};
        }

        .icon {
          fill: ${d.Nr};
          margin-top: ${u.hM};
          flex-shrink: 0;
          width: 16px;
          height: 16px;
        }

        slot[name='_button'] {
          display: none;
        }

        /* because of IE11 we need to use hover normally and then reset for touch devices */
        :host(:hover) {
          background-color: ${d.CQ};
          border-radius: 0;
        }
        :host([text]:focus:hover) {
          ${(0,c.i)()}
          border-radius: 0;
        }

        @media (hover: none) and (pointer: coarse) {
          :host(:hover) {
            background-color: inherit;
          }
          :host([text]:focus:hover) {
            box-shadow: none;
          }
        }
      `]}constructor(){super(),this.expanded=!1}connectedCallback(){super.connectedCallback(),this.setAttribute("type","button"),this.setAttribute("text",""),this.setAttribute("grey","")}_afterTemplate(){return i.dy`
      <ing-icon
        icon-id="ing:filledin-characters:${this.expanded?"minus":"plus"}"
        class="icon"
      ></ing-icon>
    `}}var p=n(7206),f=n(4971);const g=e=>{const t=e.firstElementChild;t&&t.removeAttribute("focused")},v=e=>{e.removeAttribute("expanded");const t=e.firstElementChild;t&&(t.removeAttribute("expanded"),t.setAttribute("aria-expanded","false"))},_=e=>{e.removeAttribute("expanded")};class b extends p.oi{static get properties(){return{focusedIndex:{type:Number},expanded:{type:Array}}}static get styles(){return[p.iv`
        .accordion {
          display: flex;
          flex-direction: column;
        }

        .accordion ::slotted([slot='invoker']) {
          margin: 0;
        }

        .accordion ::slotted([slot='invoker'][expanded]) {
          font-weight: bold;
        }

        .accordion ::slotted([slot='content']) {
          margin: 0;
          visibility: hidden;
          display: none;
        }

        .accordion ::slotted([slot='content'][expanded]) {
          visibility: visible;
          display: block;
        }
      `]}render(){return f.dy`
      <div class="accordion">
        <slot name="invoker"></slot>
        <slot name="content"></slot>
      </div>
    `}constructor(){super(),this.styles={},this.__store=[],this.__focusedIndex=-1,this.__expanded=[]}firstUpdated(e){super.firstUpdated(e),this.__setupSlots()}__setupSlots(){const e=this.shadowRoot?.querySelector("slot[name=invoker]"),t=()=>{this.__cleanStore(),this.__setupStore(),this.__updateFocused(),this.__updateExpanded()};e&&e.addEventListener("slotchange",t)}__setupStore(){const e=Array.from(this.querySelectorAll('[slot="invoker"]')),t=Array.from(this.querySelectorAll('[slot="content"]'));e.length!==t.length&&console.warn(`The amount of invokers (${e.length}) doesn't match the amount of contents (${t.length}).`),e.forEach(((e,n)=>{const i={uid:Math.random().toString(36).substr(2,10),index:n,invoker:e,content:t[n],clickHandler:this.__createInvokerClickHandler(n),keydownHandler:this.__handleInvokerKeydown.bind(this)};(({element:e,uid:t,index:n})=>{e.style.setProperty("order",`${n+1}`),e.setAttribute("id",`content-${t}`),e.setAttribute("aria-labelledby",`invoker-${t}`)})({element:i.content,...i}),(({element:e,uid:t,index:n,clickHandler:i,keydownHandler:s})=>{e.style.setProperty("order",`${n+1}`);const o=e.firstElementChild;o&&(o.setAttribute("id",`invoker-${t}`),o.setAttribute("aria-controls",`content-${t}`),o.addEventListener("click",i),o.addEventListener("keydown",s))})({element:i.invoker,...i}),g(i.invoker),_(i.content),v(i.invoker),this.__store.push(i)}))}__cleanStore(){this.__store&&(this.__store.forEach((e=>{((e,t,n)=>{const i=e.firstElementChild;i&&(i.removeAttribute("id"),i.removeAttribute("aria-controls"),i.removeEventListener("click",t),i.removeEventListener("keydown",n))})(e.invoker,e.clickHandler,e.keydownHandler)})),this.__store=[])}__createInvokerClickHandler(e){return()=>{this.focusedIndex=e,this.__toggleExpanded(e)}}__handleInvokerKeydown(e){const t=e;switch(t.key){case"ArrowDown":case"ArrowRight":t.preventDefault(),this.focusedIndex+2<=this._pairCount&&(this.focusedIndex+=1);break;case"ArrowUp":case"ArrowLeft":t.preventDefault(),this.focusedIndex>=1&&(this.focusedIndex-=1);break;case"Home":t.preventDefault(),this.focusedIndex=0;break;case"End":t.preventDefault(),this.focusedIndex=this._pairCount-1}}set focusedIndex(e){const t=this.__focusedIndex;this.__focusedIndex=e,this.__updateFocused(),this.dispatchEvent(new Event("focused-changed")),this.requestUpdate("focusedIndex",t)}get focusedIndex(){return this.__focusedIndex}get _pairCount(){return this.__store.length}set expanded(e){const t=this.__expanded;this.__expanded=e,this.__updateExpanded(),this.dispatchEvent(new Event("expanded-changed")),this.requestUpdate("expanded",t)}get expanded(){return this.__expanded}__updateFocused(){if(!this.__store||!this.__store[this.focusedIndex])return;const e=Array.from(this.children).find((e=>"invoker"===e.slot&&e.firstElementChild?.hasAttribute("focused")));e&&g(e);const{invoker:t}=this.__store[this.focusedIndex];t&&(e=>{const t=e.firstElementChild;t&&(t.focus(),t.setAttribute("focused","true"))})(t)}__updateExpanded(){this.__store&&this.__store.forEach(((e,t)=>{-1!==this.expanded.indexOf(t)?((e=>{e.setAttribute("expanded","true");const t=e.firstElementChild;t&&(t.setAttribute("expanded","true"),t.setAttribute("aria-expanded","true"))})(e.invoker),e.content.setAttribute("expanded","true")):(v(e.invoker),_(e.content))}))}__toggleExpanded(e){const{expanded:t}=this,n=t.indexOf(e);-1===n?t.push(e):t.splice(n,1),this.expanded=t}}class m extends b{static get styles(){return[...super.styles,i.y5`
        :host {
          display: block;
          border-bottom: 1px solid ${d.zx};
        }

        :host .accordion ::slotted([slot='invoker']) {
          border-top: 1px solid ${d.zx};
          margin: 0;
        }
      `]}}},2005:(e,t,n)=>{"use strict";n.d(t,{W:()=>b});var i=n(5538),s=n(3320),o=n(7206),r=n(4971),a=n(3515);const c=e=>" "===e.key||"Enter"===e.key,l=e=>" "===e.key;class d extends((0,i.b)((0,s.J)(o.oi))){static get properties(){return{role:{type:String,reflect:!0},active:{type:Boolean,reflect:!0},type:{type:String,reflect:!0}}}render(){return r.dy`
      ${this._beforeTemplate()}
      <div class="button-content" id="${this._buttonId}"><slot></slot></div>
      ${this._afterTemplate()}
      <slot name="_button"></slot>
    `}_beforeTemplate(){return r.dy``}_afterTemplate(){return r.dy``}static get styles(){return[o.iv`
        :host {
          position: relative;
          display: inline-flex;
          box-sizing: border-box;
          vertical-align: middle;
          line-height: 24px;
          background: #eee; /* minimal styling to make it recognizable as btn */
          padding: 8px; /* padding to fix with min-height */
          outline: none; /* focus style handled below */
          cursor: default; /* /* we should always see the default arrow, never a caret */
          user-select: none;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
        }

        :host::before {
          content: '';

          /* center vertically and horizontally */
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);

          /* touch area (comes into play when button height goes below this one) */
          /* src = https://www.smashingmagazine.com/2012/02/finger-friendly-design-ideal-mobile-touchscreen-target-sizes/ */
          min-height: 40px;
          min-width: 40px;
          width: 100%;
          height: 100%;
        }

        .button-content {
          display: flex;
          align-items: center;
          justify-content: center;
        }

        :host ::slotted(button) {
          position: absolute;
          top: 0;
          left: 0;
          clip: rect(0 0 0 0);
          clip-path: inset(50%);
          overflow: hidden;
          white-space: nowrap;
          height: 1px;
          width: 1px;
          padding: 0; /* reset default agent styles */
          border: 0; /* reset default agent styles */
        }

        /* Show focus styles on keyboard focus. */
        :host(:focus:not([disabled])),
        :host(:focus-visible) {
          /* if you extend, please overwrite */
          outline: 2px solid #bde4ff;
        }

        /* Hide focus styles if they're not needed, for example,
        when an element receives focus via the mouse. */
        :host(:focus:not(:focus-visible)) {
          outline: 0;
        }

        :host(:hover) {
          /* if you extend, please overwrite */
          background: #f4f6f7;
        }

        :host(:active), /* keep native :active to render quickly where possible */
        :host([active]) /* use custom [active] to fix IE11 */ {
          /* if you extend, please overwrite */
          background: gray;
        }

        :host([hidden]) {
          display: none;
        }

        :host([disabled]) {
          pointer-events: none;
          /* if you extend, please overwrite */
          background: lightgray;
          color: #adadad;
          fill: #adadad;
        }
      `]}get _nativeButtonNode(){return Array.from(this.children).find((e=>"_button"===e.slot))}get slots(){return{...super.slots,_button:()=>{const e=document.createElement("button");return e.setAttribute("tabindex","-1"),e.setAttribute("aria-hidden","true"),e}}}constructor(){super(),this.role="button",this.type="submit",this.active=!1,this.__setupDelegationInConstructor(),this._buttonId=`button-${Math.random().toString(36).substr(2,10)}`,a.n.isIE11&&this.updateComplete.then((()=>{this.hasAttribute("aria-labelledby")||this.setAttribute("aria-labelledby",this._buttonId)})),this.__submitAndResetHelperButton=document.createElement("button"),this.__preventEventLeakage=this.__preventEventLeakage.bind(this)}connectedCallback(){super.connectedCallback(),this.__setupEvents(),this.updateComplete.then((()=>{this.__setupSubmitAndResetHelperOnConnected()}))}disconnectedCallback(){super.disconnectedCallback(),this.__teardownEvents(),this.__teardownSubmitAndResetHelperOnDisconnected()}updated(e){if(super.updated(e),e.has("type")){const e=this._nativeButtonNode;e&&(e.type=this.type)}e.has("disabled")&&this.setAttribute("aria-disabled",`${this.disabled}`)}async __clickDelegationHandler(e){this._form||await this.updateComplete,"submit"!==this.type&&"reset"!==this.type||e.target!==this||!this._form||(this.__submitAndResetHelperButton.type=this.type,this._form.appendChild(this.__submitAndResetHelperButton),this.__submitAndResetHelperButton.click(),this._form.removeChild(this.__submitAndResetHelperButton))}__setupDelegationInConstructor(){this.addEventListener("click",this.__clickDelegationHandler,!0)}__setupEvents(){this.addEventListener("mousedown",this.__mousedownHandler),this.addEventListener("keydown",this.__keydownHandler),this.addEventListener("keyup",this.__keyupHandler)}__teardownEvents(){this.removeEventListener("mousedown",this.__mousedownHandler),this.removeEventListener("keydown",this.__keydownHandler),this.removeEventListener("keyup",this.__keyupHandler),this.removeEventListener("click",this.__clickDelegationHandler)}__mousedownHandler(){this.active=!0;const e=()=>{this.active=!1,document.removeEventListener("mouseup",e),this.removeEventListener("mouseup",e)};document.addEventListener("mouseup",e),this.addEventListener("mouseup",e)}__keydownHandler(e){if(this.active||!c(e))return void(l(e)&&e.preventDefault());l(e)&&e.preventDefault(),this.active=!0;const t=e=>{c(e)&&(this.active=!1,document.removeEventListener("keyup",t,!0))};document.addEventListener("keyup",t,!0)}__keyupHandler(e){if(c(e)){if(e.srcElement&&e.srcElement!==this)return;this.click()}}__preventEventLeakage(e){e.target===this.__submitAndResetHelperButton&&e.stopImmediatePropagation()}__setupSubmitAndResetHelperOnConnected(){this._form=this._nativeButtonNode.form,this._form&&this._form.addEventListener("click",this.__preventEventLeakage)}__teardownSubmitAndResetHelperOnDisconnected(){this._form&&this._form.removeEventListener("click",this.__preventEventLeakage)}}var u=n(332),h=n(9047),p=n(451),f=n(170),g=n(3371);const v=u.y5`
  :host {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    min-height: 16px;
    outline: 0;
    ${(0,f.jh)()};
    border: 1px solid ${g.$y};
    border-radius: 8px;
    padding: 6px 15px 8px 15px;
    background-color: ${g.$y};
    color: ${g.ix};
    position: relative;
  }

  :host([font16]) {
    padding-top: 2px;
    padding-bottom: 2px;
  }

  :host([font14]) {
    padding-top: 4px;
    padding-bottom: 4px;
  }

  :host([font12]) {
    padding-top: 6px;
    padding-bottom: 6px;
  }

  :host([elevated]) {
    box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.12), 0 6px 6px 0 rgba(0, 0, 0, 0.24);
  }

  ::slotted(button) {
    ${(0,p.X)()};
  }

  :host(:hover) {
    background-color: ${g.$y};
  }

  :host(:focus:not([disabled])) {
    outline: none;
  }

  :host([font16]) {
    ${(0,f.Dn)()};
    padding: 4px 11px 6px 11px;
  }

  :host([font14]) {
    ${(0,f.pA)()};
    padding: 5px 9px;
  }

  :host([font12]) {
    ${(0,f.j2)()};
    padding: 5px 7px;
  }

  :host([text][icon-only]) ::slotted(*),
  ::slotted([slot='icon-before']),
  ::slotted([slot='icon-after']) {
    width: 24px;
    height: 24px;
  }

  :host([text][icon-only]) {
    padding: 9px;
  }

  :host([text][icon-only]:hover) {
    box-shadow: none;
  }

  ::slotted([slot='icon-before']),
  ::slotted([slot='icon-after']) {
    fill: ${g.ix};
  }

  ::slotted([slot='icon-before']) {
    margin-right: 8px;
    flex-shrink: 0;
  }

  ::slotted([slot='icon-after']) {
    margin-left: 8px;
    flex-shrink: 0;
  }

  :host([text][icon-only][icon20]) ::slotted(*),
  :host([font16]) ::slotted([slot='icon-before']),
  :host([font16]) ::slotted([slot='icon-after']) {
    width: 20px;
    height: 20px;
  }

  :host([text][icon-only][icon20]) {
    padding: 7px;
  }

  :host([text][icon-only][icon20]) .click-area {
    margin: -3px;
  }

  :host([text][icon-only][icon16]) ::slotted(*),
  :host([font14]) ::slotted([slot='icon-before']),
  :host([font14]) ::slotted([slot='icon-after']) {
    width: 16px;
    height: 16px;
  }

  :host([text][icon-only][icon16]) {
    padding: 7px;
  }

  :host([text][icon-only][icon16]) .click-area {
    margin: -5px;
  }

  :host([indigo]) {
    background-color: ${g.QN};
    border-color: ${g.QN};
  }

  :host([sky]) {
    background-color: ${g.Bt};
    border-color: ${g.Bt};
  }

  :host([grey]) {
    background-color: ${g.F8};
    border-color: ${g.F8};
    color: ${g.H9};
  }

  :host([inverted]) {
    background-color: ${g.ix};
    border-color: ${g.ix};
    color: ${g.H9};
  }

  :host([inverted]) ::slotted([slot='icon-before']),
  :host([inverted]) ::slotted([slot='icon-after']) {
    fill: ${g.H9};
  }

  :host([grey]) ::slotted([slot='icon-before']),
  :host([grey]) ::slotted([slot='icon-after']) {
    fill: ${g.H9};
  }

  :host(:hover) {
    box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.12), 0 8px 8px 0 rgba(0, 0, 0, 0.24);
  }

  :host([elevated]:focus) {
    box-shadow: 0 0 8px #9fcaea, 0 0 0 1px #559bd1, 0 0 6px 0 rgba(0, 0, 0, 0.12),
      0 6px 6px 0 rgba(0, 0, 0, 0.24);
  }

  :host([elevated]:focus:hover),
  :host([elevated]:focus:active),
  :host([elevated]:focus[active]) {
    box-shadow: 0 0 8px #9fcaea, 0 0 0 1px #559bd1, 0 0 12px 0 rgba(0, 0, 0, 0.12),
      0 12px 12px 0 rgba(0, 0, 0, 0.24);
  }

  :host([elevated]:hover),
  :host([elevated]:active),
  :host([elevated][active]) {
    box-shadow: 0 0 12px 0 rgba(0, 0, 0, 0.12), 0 12px 12px 0 rgba(0, 0, 0, 0.24);
  }

  :host(:active:not([inverted])),
  :host([active]:not([inverted])) {
    opacity: 0.8; /* should be color variant so text color stays the same */
  }

  :host([inverted]:active),
  :host([inverted][active]) {
    background-color: ${g.F8};
    border-color: ${g.F8};
  }

  :host(:focus) {
    ${(0,h.i)()};
    border-color: ${g.Bt};
    border-radius: 8px;
  }

  :host(:hover:focus),
  :host(:active:focus),
  :host([active]:focus) {
    box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.12), 0 8px 8px 0 rgba(0, 0, 0, 0.24), 0 0 8px ${g.vv},
      0 0 0 1px ${g.Bt};
  }

  :host([inverted]:focus) {
    ${(0,h.Y)()};
    border-color: ${g.CQ};
    border-radius: 8px;
  }

  :host([inverted]:hover:focus),
  :host([inverted]:active:focus),
  :host([inverted][active]:focus) {
    box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.12), 0 8px 8px 0 rgba(0, 0, 0, 0.24), 0 0 8px ${g.CQ},
      0 0 0 1px ${g.CQ};
  }

  :host([text]) {
    background-color: transparent;
    border-color: transparent;
    color: ${g.QN};
  }

  :host([text]) ::slotted([slot='icon-before']),
  :host([text]) ::slotted([slot='icon-after']) {
    fill: ${g.QN};
  }

  :host([text][grey]) {
    color: ${g.H9};
  }

  :host([text][grey]) ::slotted([slot='icon-before']),
  :host([text][grey]) ::slotted([slot='icon-after']) {
    fill: ${g.H9};
  }

  :host([text][orange]) {
    color: ${g.$y};
  }

  :host([text][orange]) ::slotted([slot='icon-before']),
  :host([text][orange]) ::slotted([slot='icon-after']) {
    fill: ${g.$y};
  }

  :host([text][inverted]) {
    background-color: transparent;
    border-color: transparent;
    color: ${g.ix};
  }

  :host([text][inverted]) ::slotted([slot='icon-before']),
  :host([text][inverted]) ::slotted([slot='icon-after']) {
    fill: ${g.ix};
  }

  :host([text]:hover) {
    box-shadow: none;
    border-color: ${g.QN};
  }

  :host([text][grey]:hover) {
    border-color: ${g.H9};
  }

  :host([text][orange]:hover) {
    border-color: ${g.$y};
  }

  :host([text][inverted]:hover) {
    border-color: ${g.ix};
  }

  :host([text]:active),
  :host([text][active]) {
    opacity: 1;
    background-color: ${g.Hd};
    border-color: ${g.QN};
  }

  :host([text][grey]:active),
  :host([text][grey][active]) {
    background-color: ${g.F8};
    border-color: ${g.H9};
  }

  :host([text][orange]:active),
  :host([text][orange][active]) {
    background-color: rgba(255, 98, 0, 0.2);
    border-color: ${g.$y};
  }

  :host([text][inverted]:active),
  :host([text][inverted][active]) {
    opacity: 0.8;
    background-color: rgba(255, 255, 255, 0.2);
    border-color: ${g.ix};
  }

  :host([text]:hover:focus),
  :host([text]:active:focus),
  :host([text][active]:focus) {
    ${(0,h.i)()};
    border-color: ${g.Bt};
    border-radius: 8px;
  }

  :host([text][inverted]:focus),
  :host([text][inverted]:hover:focus),
  :host([text][inverted]:active:focus),
  :host([text][inverted][active]:focus) {
    ${(0,h.Y)()};
    border-color: ${g.CQ};
    border-radius: 8px;
  }

  :host([outline]) {
    background-color: transparent;
    color: ${g.$y};
  }

  :host([outline]) ::slotted([slot='icon-before']),
  :host([outline]) ::slotted([slot='icon-after']) {
    fill: ${g.$y};
  }

  :host([outline][indigo]) {
    color: ${g.QN};
  }

  :host([outline][indigo]) ::slotted([slot='icon-before']),
  :host([outline][indigo]) ::slotted([slot='icon-after']) {
    fill: ${g.QN};
  }

  :host([outline][sky]) {
    color: ${g.Bt};
  }

  :host([outline][sky]) ::slotted([slot='icon-before']),
  :host([outline][sky]) ::slotted([slot='icon-after']) {
    fill: ${g.Bt};
  }

  :host([outline][grey]) {
    color: ${g.Nr};
  }

  :host([outline][grey]) ::slotted([slot='icon-before']),
  :host([outline][grey]) ::slotted([slot='icon-after']) {
    fill: ${g.Nr};
  }

  :host([outline][inverted]) {
    color: ${g.ix};
  }

  :host([outline][inverted]) ::slotted([slot='icon-before']),
  :host([outline][inverted]) ::slotted([slot='icon-after']) {
    fill: ${g.ix};
  }

  :host([outline]:hover) {
    box-shadow: none;
    background-color: ${g.$y};
    color: ${g.ix};
  }

  :host([outline]:hover) ::slotted([slot='icon-before']),
  :host([outline]:hover) ::slotted([slot='icon-after']) {
    fill: ${g.ix};
  }

  :host([outline][indigo]:hover) {
    background-color: ${g.QN};
  }

  :host([outline][sky]:hover) {
    background-color: ${g.Bt};
  }

  :host([outline][grey]:hover) {
    background-color: ${g.F8};
    color: ${g.H9};
  }

  :host([outline][grey]:hover) ::slotted([slot='icon-before']),
  :host([outline][grey]:hover) ::slotted([slot='icon-after']) {
    fill: ${g.H9};
  }

  :host([outline][inverted]:hover) {
    background-color: ${g.ix};
    color: ${g.$y};
    border-color: ${g.ix};
  }

  :host([outline][inverted]:hover) ::slotted([slot='icon-before']),
  :host([outline][inverted]:hover) ::slotted([slot='icon-after']) {
    fill: ${g.$y};
  }

  :host([outline][indigo][inverted]:hover) {
    color: ${g.QN};
  }

  :host([outline][indigo][inverted]:hover) ::slotted([slot='icon-before']),
  :host([outline][indigo][inverted]:hover) ::slotted([slot='icon-after']) {
    fill: ${g.QN};
  }

  :host([outline][sky][inverted]:hover) {
    color: ${g.Bt};
  }

  :host([outline][sky][inverted]:hover) ::slotted([slot='icon-before']),
  :host([outline][sky][inverted]:hover) ::slotted([slot='icon-after']) {
    fill: ${g.Bt};
  }

  :host([outline]:active),
  :host([outline][active]) {
    background-color: ${g.$y};
    color: ${g.ix};
    border-color: ${g.$y};
  }

  :host([outline]:active) ::slotted([slot='icon-before']),
  :host([outline]:active) ::slotted([slot='icon-after']),
  :host([outline][active]) ::slotted([slot='icon-before']),
  :host([outline][active]) ::slotted([slot='icon-after']) {
    fill: ${g.ix};
  }

  :host([outline][indigo]:active),
  :host([outline][indigo][active]) {
    background-color: ${g.QN};
    border-color: ${g.QN};
  }

  :host([outline][sky]:active),
  :host([outline][sky][active]) {
    background-color: ${g.Bt};
    border-color: ${g.Bt};
  }

  :host([outline][grey]:active),
  :host([outline][grey][active]) {
    background-color: ${g.F8};
    color: ${g.H9};
    border-color: ${g.F8};
  }

  :host([outline][grey]:active) ::slotted([slot='icon-before']),
  :host([outline][grey]:active) ::slotted([slot='icon-after']),
  :host([outline][grey][active]) ::slotted([slot='icon-before']),
  :host([outline][grey][active]) ::slotted([slot='icon-after']) {
    fill: ${g.H9};
  }

  :host([outline][inverted]:active),
  :host([outline][inverted][active]) {
    opacity: 0.8;
    background-color: ${g.ix};
    color: ${g.$y};
    border-color: ${g.ix};
  }

  :host([outline][inverted]:active) ::slotted([slot='icon-before']),
  :host([outline][inverted]:active) ::slotted([slot='icon-after']),
  :host([outline][inverted][active]) ::slotted([slot='icon-before']),
  :host([outline][inverted][active]) ::slotted([slot='icon-after']) {
    fill: ${g.$y};
  }

  :host([outline][indigo][inverted]:active),
  :host([outline][indigo][inverted][active]) {
    color: ${g.QN};
  }

  :host([outline][indigo][inverted]:active) ::slotted([slot='icon-before']),
  :host([outline][indigo][inverted]:active) ::slotted([slot='icon-after']),
  :host([outline][indigo][inverted][active]) ::slotted([slot='icon-before']),
  :host([outline][indigo][inverted][active]) ::slotted([slot='icon-after']) {
    fill: ${g.QN};
  }

  :host([outline][sky][inverted]:active),
  :host([outline][sky][inverted][active]) {
    color: ${g.Bt};
  }

  :host([outline][sky][inverted]:active) ::slotted([slot='icon-before']),
  :host([outline][sky][inverted]:active) ::slotted([slot='icon-after']),
  :host([outline][sky][inverted][active]) ::slotted([slot='icon-before']),
  :host([outline][sky][inverted][active]) ::slotted([slot='icon-after']) {
    fill: ${g.Bt};
  }

  :host([outline]:hover:focus),
  :host([outline]:active:focus),
  :host([outline][active]:focus) {
    ${(0,h.i)()};
    border-color: ${g.Bt};
    border-radius: 8px;
  }

  :host([outline][inverted]:focus),
  :host([outline][inverted]:hover:focus),
  :host([outline][inverted]:active:focus),
  :host([outline][inverted][active]:focus) {
    ${(0,h.Y)()};
    border-color: ${g.CQ};
    border-radius: 8px;
  }

  :host([text][icon-only]) {
    background-color: transparent;
    border-color: transparent;
    fill: ${g.$y};
  }

  :host([text][icon-only][grey]) {
    fill: ${g.Nr};
  }

  :host([text][icon-only][inverted]) {
    fill: ${g.ix};
  }

  :host([text][icon-only]:hover) {
    border-color: ${g.$y};
    fill: ${g.$y};
  }

  :host([text][icon-only][grey]:hover) {
    border-color: ${g.Nr};
    fill: ${g.Nr};
  }

  :host([text][icon-only][inverted]:hover) {
    border-color: ${g.ix};
    fill: ${g.ix};
  }

  :host([text][icon-only]:active),
  :host([text][icon-only][active]) {
    box-shadow: none;
    background-color: rgba(255, 98, 0, 0.15);
    border-color: ${g.$y};
    fill: ${g.$y};
  }

  :host([text][icon-only][grey]:active),
  :host([text][icon-only][grey][active]) {
    opacity: 1;
    background-color: ${g.F8};
    border-color: ${g.Nr};
    fill: ${g.Nr};
  }

  :host([text][icon-only][inverted]:active),
  :host([text][icon-only][inverted][active]) {
    box-shadow: none;
    background-color: rgba(255, 255, 255, 0.4);
    border-color: ${g.ix};
    fill: ${g.ix};
  }

  :host([text][icon-only]:hover:focus),
  :host([text][icon-only]:active:focus),
  :host([text][icon-only][active]:focus) {
    ${(0,h.i)()};
    border-color: ${g.Bt};
    border-radius: 8px;
  }

  :host([text][icon-only][inverted]:focus),
  :host([text][icon-only][inverted]:hover:focus),
  :host([text][icon-only][inverted]:active:focus),
  :host([text][icon-only][inverted][active]:focus) {
    ${(0,h.Y)()};
    border-color: ${g.CQ};
    border-radius: 8px;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  :host([disabled]) {
    background-color: transparent;
  }

  :host([disabled]:not([inverted])) {
    color: ${g.F8};
    border-color: ${g.zx};
  }

  :host([disabled][inverted]) {
    color: rgba(255, 255, 255, 0.4);
    border-color: rgba(255, 255, 255, 0.4);
  }

  :host([disabled][icon-only]:not([inverted])),
  :host([disabled]:not([inverted])) ::slotted([slot='icon-before']),
  :host([disabled]:not([inverted])) ::slotted([slot='icon-after']) {
    fill: ${g.F8};
  }

  :host([disabled][icon-only][inverted]),
  :host([disabled][inverted]) ::slotted([slot='icon-before']),
  :host([disabled][inverted]) ::slotted([slot='icon-after']) {
    fill: rgba(255, 255, 255, 0.4);
  }

  :host([text][disabled]) {
    border-color: transparent;
  }
`,_=window;class b extends d{static get styles(){return[...super.styles,v]}_beforeTemplate(){return u.dy`<slot name="icon-before"></slot>`}_afterTemplate(){return u.dy`<slot name="icon-after"></slot>`}async __clickDelegationHandler(e){if(_.Polymer&&_.Polymer.Gestures&&_.Polymer.Gestures.resetMouseCanceller)try{_.Polymer.Gestures.resetMouseCanceller()}catch(e){}super.__clickDelegationHandler(e)}}},9861:(e,t,n)=>{"use strict";n.d(t,{W:()=>i.W});var i=n(2005)},9566:(e,t,n)=>{"use strict";n.d(t,{Cn:()=>O,oi:()=>P.oi,fN:()=>U.f,JO:()=>F.J,dr:()=>D,lZ:()=>o,EJ:()=>a,Fs:()=>d,$o:()=>p,iv:()=>P.iv,SV:()=>k.S,lo:()=>g,dy:()=>i.dy,o5:()=>_,Ld:()=>i.Ld,r4:()=>i.r4,sY:()=>i.sY,rx:()=>T,Ve:()=>A,YP:()=>i.YP,$m:()=>P.$m,Au:()=>L,C4:()=>R.C});var i=n(4971),s=function(e){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var t,n=e[Symbol.asyncIterator];return n?n.call(e):(e="function"==typeof __values?__values(e):e[Symbol.iterator](),t={},i("next"),i("throw"),i("return"),t[Symbol.asyncIterator]=function(){return this},t);function i(n){t[n]=e[n]&&function(t){return new Promise((function(i,s){(function(e,t,n,i){Promise.resolve(i).then((function(t){e({value:t,done:n})}),t)})(i,s,(t=e[n](t)).done,t.value)}))}}};const o=(0,i.XM)(((e,t)=>async n=>{var o,r;if(!(n instanceof i.nt))throw new Error("asyncAppend can only be used in text bindings");if(e===n.value)return;let a;n.value=e;let c=0;try{for(var l,d=s(e);!(l=await d.next()).done;){let s=l.value;if(n.value!==e)break;0===c&&n.clear(),void 0!==t&&(s=t(s,c));let o=n.startNode;void 0!==a&&(o=(0,i.IW)(),a.endNode=o,n.endNode.parentNode.insertBefore(o,n.endNode)),a=new i.nt(n.options),a.insertAfterNode(o),a.setValue(s),a.commit(),c++}}catch(e){o={error:e}}finally{try{l&&!l.done&&(r=d.return)&&await r.call(d)}finally{if(o)throw o.error}}}));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
var r=function(e){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var t,n=e[Symbol.asyncIterator];return n?n.call(e):(e="function"==typeof __values?__values(e):e[Symbol.iterator](),t={},i("next"),i("throw"),i("return"),t[Symbol.asyncIterator]=function(){return this},t);function i(n){t[n]=e[n]&&function(t){return new Promise((function(i,s){(function(e,t,n,i){Promise.resolve(i).then((function(t){e({value:t,done:n})}),t)})(i,s,(t=e[n](t)).done,t.value)}))}}};const a=(0,i.XM)(((e,t)=>async n=>{var s,o;if(!(n instanceof i.nt))throw new Error("asyncReplace can only be used in text bindings");if(e===n.value)return;const a=new i.nt(n.options);n.value=e;let c=0;try{for(var l,d=r(e);!(l=await d.next()).done;){let i=l.value;if(n.value!==e)break;0===c&&(n.clear(),a.appendIntoPart(n)),void 0!==t&&(i=t(i,c)),a.setValue(i),a.commit(),c++}}catch(e){s={error:e}}finally{try{l&&!l.done&&(o=d.return)&&await o.call(d)}finally{if(s)throw s.error}}}));var c=n(1622);
/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const l=new WeakMap,d=(0,i.XM)((e=>t=>{if(!(t instanceof i.nt))throw new Error("cache can only be used in text bindings");let n=l.get(t);void 0===n&&(n=new WeakMap,l.set(t,n));const s=t.value;if(s instanceof c.R){if(e instanceof i.js&&s.template===t.options.templateFactory(e))return void t.setValue(e);{let e=n.get(s.template);void 0===e&&(e={instance:s,nodes:document.createDocumentFragment()},n.set(s.template,e)),(0,i.V)(e.nodes,t.startNode.nextSibling,t.endNode)}}if(e instanceof i.js){const i=t.options.templateFactory(e),s=n.get(i);void 0!==s&&(t.setValue(s.nodes),t.commit(),t.value=s.instance)}t.setValue(e)}));
/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
class u{constructor(e){this.classes=new Set,this.changed=!1,this.element=e;const t=(e.getAttribute("class")||"").split(/\s+/);for(const e of t)this.classes.add(e)}add(e){this.classes.add(e),this.changed=!0}remove(e){this.classes.delete(e),this.changed=!0}commit(){if(this.changed){let e="";this.classes.forEach((t=>e+=t+" ")),this.element.setAttribute("class",e)}}}const h=new WeakMap,p=(0,i.XM)((e=>t=>{if(!(t instanceof i._l)||t instanceof i.sL||"class"!==t.committer.name||t.committer.parts.length>1)throw new Error("The `classMap` directive must be used in the `class` attribute and must be the only part in the attribute.");const{committer:n}=t,{element:s}=n;let o=h.get(t);void 0===o&&(s.setAttribute("class",n.strings.join(" ")),h.set(t,o=new Set));const r=s.classList||new u(s);o.forEach((t=>{t in e||(r.remove(t),o.delete(t))}));for(const t in e){const n=e[t];n!=o.has(t)&&(n?(r.add(t),o.add(t)):(r.remove(t),o.delete(t)))}"function"==typeof r.commit&&r.commit()})),f=new WeakMap,g=(0,i.XM)(((e,t)=>n=>{const i=f.get(n);if(Array.isArray(e)){if(Array.isArray(i)&&i.length===e.length&&e.every(((e,t)=>e===i[t])))return}else if(i===e&&(void 0!==e||f.has(n)))return;n.setValue(t()),f.set(n,Array.isArray(e)?Array.from(e):e)})),v=new WeakMap,_=(0,i.XM)((e=>t=>{const n=v.get(t);if(void 0===e&&t instanceof i._l){if(void 0!==n||!v.has(t)){const e=t.committer.name;t.committer.element.removeAttribute(e)}}else e!==n&&t.setValue(e);v.set(t,e)})),b=(e,t)=>{const n=e.startNode.parentNode,s=void 0===t?e.endNode:t.startNode,o=n.insertBefore((0,i.IW)(),s);n.insertBefore((0,i.IW)(),s);const r=new i.nt(e.options);return r.insertAfterNode(o),r},m=(e,t)=>(e.setValue(t),e.commit(),e),y=(e,t,n)=>{const s=e.startNode.parentNode,o=n?n.startNode:e.endNode,r=t.endNode.nextSibling;r!==o&&(0,i.V)(s,t.startNode,r,o)},S=e=>{(0,i.r4)(e.startNode.parentNode,e.startNode,e.endNode.nextSibling)},C=(e,t,n)=>{const i=new Map;for(let s=t;s<=n;s++)i.set(e[s],s);return i},w=new WeakMap,E=new WeakMap,T=(0,i.XM)(((e,t,n)=>{let s;return void 0===n?n=t:void 0!==t&&(s=t),t=>{if(!(t instanceof i.nt))throw new Error("repeat can only be used in text bindings");const o=w.get(t)||[],r=E.get(t)||[],a=[],c=[],l=[];let d,u,h=0;for(const t of e)l[h]=s?s(t,h):h,c[h]=n(t,h),h++;let p=0,f=o.length-1,g=0,v=c.length-1;for(;p<=f&&g<=v;)if(null===o[p])p++;else if(null===o[f])f--;else if(r[p]===l[g])a[g]=m(o[p],c[g]),p++,g++;else if(r[f]===l[v])a[v]=m(o[f],c[v]),f--,v--;else if(r[p]===l[v])a[v]=m(o[p],c[v]),y(t,o[p],a[v+1]),p++,v--;else if(r[f]===l[g])a[g]=m(o[f],c[g]),y(t,o[f],o[p]),f--,g++;else if(void 0===d&&(d=C(l,g,v),u=C(r,p,f)),d.has(r[p]))if(d.has(r[f])){const e=u.get(l[g]),n=void 0!==e?o[e]:null;if(null===n){const e=b(t,o[p]);m(e,c[g]),a[g]=e}else a[g]=m(n,c[g]),y(t,n,o[p]),o[e]=null;g++}else S(o[f]),f--;else S(o[p]),p++;for(;g<=v;){const e=b(t,a[v+1]);m(e,c[g]),a[g++]=e}for(;p<=f;){const e=o[p++];null!==e&&S(e)}w.set(t,a),E.set(t,l)}})),I=new WeakMap,A=(0,i.XM)((e=>t=>{if(!(t instanceof i._l)||t instanceof i.sL||"style"!==t.committer.name||t.committer.parts.length>1)throw new Error("The `styleMap` directive must be used in the style attribute and must be the only part in the attribute.");const{committer:n}=t,{style:s}=n.element;let o=I.get(t);void 0===o&&(s.cssText=n.strings.join(" "),I.set(t,o=new Set)),o.forEach((t=>{t in e||(o.delete(t),-1===t.indexOf("-")?s[t]=null:s.removeProperty(t))}));for(const t in e)o.add(t),-1===t.indexOf("-")?s[t]=e[t]:s.setProperty(t,e[t])}));var x=n(3602);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const N=new WeakMap,L=(0,i.XM)((e=>t=>{if(!(t instanceof i.nt))throw new Error("unsafeHTML can only be used in text bindings");const n=N.get(t);if(void 0!==n&&(0,x.pt)(e)&&e===n.value&&t.value===n.fragment)return;const s=document.createElement("template");s.innerHTML=e;const o=document.importNode(s.content,!0);t.setValue(o),N.set(t,{value:e,fragment:o})}));var k=n(1077);const O=(0,k.S)((e=>class extends e{constructor(){super(),this.__eventsQueue=[],this.__propertiesQueue={},this.__setupPropertyDelegation()}get delegations(){return{target:()=>{},events:[],methods:[],properties:[],attributes:[]}}connectedCallback(){super.connectedCallback(),this._connectDelegateMixin()}updated(e){super.updated(e),this._connectDelegateMixin()}addEventListener(e,t,n){this.delegations.events.indexOf(e)>-1?this.delegationTarget?this.delegationTarget.addEventListener(e,t,n):this.__eventsQueue.push({type:e,handler:t}):super.addEventListener(e,t,n)}setAttribute(e,t){this.delegations.attributes.indexOf(e)>-1?(this.delegationTarget&&this.delegationTarget.setAttribute(e,t),super.removeAttribute(e)):super.setAttribute(e,t)}removeAttribute(e){this.delegations.attributes.indexOf(e)>-1&&this.delegationTarget&&this.delegationTarget.removeAttribute(e),super.removeAttribute(e)}_connectDelegateMixin(){this.__connectedDelegateMixin||(this.delegationTarget||(this.delegationTarget=this.delegations.target()),this.delegationTarget&&(this.__emptyEventListenerQueue(),this.__emptyPropertiesQueue(),this.__initialAttributeDelegation(),this.__connectedDelegateMixin=!0))}__setupPropertyDelegation(){this.delegations.properties.concat(this.delegations.methods).forEach((e=>{Object.defineProperty(this,e,{get(){const t=this.delegationTarget;return t?"function"==typeof t[e]?t[e].bind(t):t[e]:this.__propertiesQueue[e]?this.__propertiesQueue[e]:this.getAttribute(e)},set(t){if(this.delegationTarget){const n=this.delegationTarget[e];this.delegationTarget[e]=t,"function"==typeof this.triggerObserversFor&&this.triggerObserversFor(e,t,n)}else this.__propertiesQueue[e]=t}})}))}__initialAttributeDelegation(){this.delegations.attributes.forEach((e=>{const t=this.getAttribute(e);"string"==typeof t&&(this.delegationTarget.setAttribute(e,t),super.removeAttribute(e))}))}__emptyEventListenerQueue(){this.__eventsQueue.forEach((e=>{this.delegationTarget.addEventListener(e.type,e.handler,e.opts)}))}__emptyPropertiesQueue(){Object.keys(this.__propertiesQueue).forEach((e=>{this.delegationTarget[e]=this.__propertiesQueue[e]}))}})),D=(0,k.S)((e=>class extends e{updateStyles(e){const t=(this.getAttribute("style")||this.getAttribute("data-style")||"").split(";").reduce(((e,t)=>{const n=t.split(":");return 2===n.length&&(e[n[0]]=n[1]),e}),{}),n={...t,...e};let i="";if("object"!=typeof ShadyCSS||ShadyCSS.nativeShadow)Object.keys(n).forEach((e=>{i+=`${e}: ${n[e]};`})),this.setAttribute("style",i);else{const e={};Object.keys(n).forEach((t=>{-1===t.indexOf("--")?i+=`${t}:${n[t]};`:e[t]=n[t]})),this.setAttribute("style",i),ShadyCSS.styleSubtree(this,e)}}}));var R=n(7345),P=n(7206),U=n(5554),F=n(3320)},4084:(e,t,n)=>{"use strict";n.r(t),n.d(t,{IngDialog:()=>T,IngDialogFrame:()=>q,IngDialogFrameSimple:()=>G,validVariations:()=>W});var i=n(7206),s=n(4971),o=n(1077);var r=n(1940);function a(){let e=document.activeElement||document.body;for(;e&&e.shadowRoot&&e.shadowRoot.activeElement;)e=e.shadowRoot.activeElement;return e}const c=({visibility:e,display:t})=>"hidden"!==e&&"none"!==t;function l(e,t){const n=Math.max(e.tabIndex,0),i=Math.max(t.tabIndex,0);return 0===n||0===i?i>n:n>i}function d(e){const t=e.length;if(t<2)return e;const n=Math.ceil(t/2);return function(e,t){const n=[];for(;e.length>0&&t.length>0;)l(e[0],t[0])?n.push(t.shift()):n.push(e.shift());return[...n,...e,...t]}(d(e.slice(0,n)),d(e.slice(n)))}const u="matches"in Element.prototype?"matches":"msMatchesSelector";function h(e){return function(e){return e[u]("input, select, textarea, button, object")?e[u](":not([disabled])"):e[u]("a[href], area[href], iframe, [tabindex], [contentEditable]")}(e)?Number(e.getAttribute("tabindex")||0):-1}function p(e){return e.nodeType===Node.ELEMENT_NODE&&("slot"===e.localName||function(e){return!!(e&&e.isConnected&&c(e.style)&&c(window.getComputedStyle(e))&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length))}(e))}function f(e,t){if(!p(e))return!1;const n=e,i=h(n);let s=i>0;i>=0&&t.push(n);const o=function(e){if("slot"===e.localName)return e.assignedNodes({flatten:!0});const{children:t}=e.shadowRoot||e;return t||[]}(n);for(let e=0;e<o.length;e+=1)s=f(o[e],t)||s;return s}function g(e){const t=[];return f(e,t)?d(t):t}function v(e,t){let n=e.contains(t);if(n)return!0;return!!(e instanceof HTMLElement&&e.shadowRoot&&(n=v(e.shadowRoot,t),n))||(function e(i){for(let s=0;s<i.children.length;s+=1){const o=i.children[s];if(o.shadowRoot&&v(o.shadowRoot,t)){n=!0;break}o.children.length>0&&e(o)}}(e),n)}const _=9;function b(e){const t=g(e),n=t.find((e=>e.hasAttribute("autofocus")))||e;let i,s;function o(t){t.keyCode===_&&function(e,t){const n=g(e);let i;i=n.length>=2?[n[0],n[n.length-1]]:1===n.length?[n[0],n[0]]:[e,e],t.shiftKey&&i.reverse();const[s,o]=i,r=a();r===e||n.includes(r)&&o!==r||(t.preventDefault(),s.focus())}(e,t)}function r({resetToRoot:n=!1}={}){if(v(e,a()))return;let s;s=n?e:t[i.compareDocumentPosition(document.activeElement)===Node.DOCUMENT_POSITION_PRECEDING?0:t.length-1],s&&s.focus()}function c(){window.removeEventListener("focusin",c),r()}function l(){setTimeout((()=>{v(e,a())||r({resetToRoot:!0})})),window.addEventListener("focusin",c)}return n===e&&(e.tabIndex=-1,e.style.setProperty("outline","none")),n.focus(),window.addEventListener("keydown",o),window.addEventListener("focusout",l),function t(){i=document.createElement("div"),i.style.display="none",i.setAttribute("data-is-tab-detection-element",""),e.insertBefore(i,e.children[0]),s=new MutationObserver((n=>{for(const i of n)if("childList"===i.type){const n=!Array.from(e.children).find((e=>e.hasAttribute("data-is-tab-detection-element"))),o=Array.from(i.addedNodes).find((e=>e instanceof HTMLElement&&e.hasAttribute("data-is-tab-detection-element")));n&&!o&&(s.disconnect(),t())}})),s.observe(e,{childList:!0})}(),{disconnect:function(){window.removeEventListener("keydown",o),window.removeEventListener("focusin",c),window.removeEventListener("focusout",l),s.disconnect(),Array.from(e.children).includes(i)&&e.removeChild(i),e.style.removeProperty("outline")}}}const m="global-overlays__overlay-container",y=window.CSS&&CSS.number;class S extends class{constructor(){const e=document.createDocumentFragment();this.addEventListener=(t,n,i)=>e.addEventListener(t,n,i),this.removeEventListener=(t,n,i)=>e.removeEventListener(t,n,i),this.dispatchEvent=t=>e.dispatchEvent(t)}}{constructor(e={},t=r.V){if(super(),this.manager=t,this.__sharedConfig=e,this._defaultConfig={placementMode:void 0,contentNode:e.contentNode,contentWrapperNode:e.contentWrapperNode,invokerNode:e.invokerNode,backdropNode:e.backdropNode,referenceNode:void 0,elementToFocusAfterHide:e.invokerNode,inheritsReferenceWidth:"none",hasBackdrop:!1,isBlocking:!1,preventsScroll:!1,trapsKeyboardFocus:!1,hidesOnEsc:!1,hidesOnOutsideEsc:!1,hidesOnOutsideClick:!1,isTooltip:!1,invokerRelation:"description",handlesAccessibility:!1,popperConfig:{placement:"top",strategy:"absolute",modifiers:[{name:"preventOverflow",enabled:!0,options:{boundariesElement:"viewport",padding:8}},{name:"flip",options:{boundariesElement:"viewport",padding:16}},{name:"offset",enabled:!0,options:{offset:[0,8]}},{name:"arrow",enabled:!1}]},viewportConfig:{placement:"center"}},this.manager.add(this),this._contentId=`overlay-content--${Math.random().toString(36).substr(2,10)}`,this.__originalAttrs=new Map,this._defaultConfig.contentNode){if(!this._defaultConfig.contentNode.isConnected)throw new Error('[OverlayController] Could not find a render target, since the provided contentNode is not connected to the DOM. Make sure that it is connected, e.g. by doing "document.body.appendChild(contentNode)", before passing it on.');this.__isContentNodeProjected=Boolean(this._defaultConfig.contentNode.assignedSlot)}this.updateConfig(e),this.__hasActiveTrapsKeyboardFocus=!1,this.__hasActiveBackdrop=!0,this.__backdropNodeToBeTornDown=void 0,this.__escKeyHandler=this.__escKeyHandler.bind(this)}get invoker(){return this.invokerNode}get content(){return this.contentWrapperNode}get placementMode(){return this.config?.placementMode}get invokerNode(){return this.config?.invokerNode}get referenceNode(){return this.config?.referenceNode}get contentNode(){return this.config?.contentNode}get contentWrapperNode(){return this.__contentWrapperNode||this.config?.contentWrapperNode}get backdropNode(){return this.__backdropNode||this.config?.backdropNode}get elementToFocusAfterHide(){return this.__elementToFocusAfterHide||this.config?.elementToFocusAfterHide}get hasBackdrop(){return!!this.backdropNode||this.config?.hasBackdrop}get isBlocking(){return this.config?.isBlocking}get preventsScroll(){return this.config?.preventsScroll}get trapsKeyboardFocus(){return this.config?.trapsKeyboardFocus}get hidesOnEsc(){return this.config?.hidesOnEsc}get hidesOnOutsideClick(){return this.config?.hidesOnOutsideClick}get hidesOnOutsideEsc(){return this.config?.hidesOnOutsideEsc}get inheritsReferenceWidth(){return this.config?.inheritsReferenceWidth}get handlesAccessibility(){return this.config?.handlesAccessibility}get isTooltip(){return this.config?.isTooltip}get invokerRelation(){return this.config?.invokerRelation}get popperConfig(){return this.config?.popperConfig}get viewportConfig(){return this.config?.viewportConfig}get _renderTarget(){return"global"===this.placementMode?this.manager.globalRootNode:this.__isContentNodeProjected?this.__originalContentParent?.getRootNode().host:this.__originalContentParent}get _referenceNode(){return this.referenceNode||this.invokerNode}set elevation(e){this.contentWrapperNode&&(this.contentWrapperNode.style.zIndex=e),this.backdropNode&&(this.backdropNode.style.zIndex=e)}get elevation(){return Number(this.contentWrapperNode?.style.zIndex)}updateConfig(e){this.teardown(),this.__prevConfig=this.config||{},this.config={...this._defaultConfig,...this.__sharedConfig,...e,popperConfig:{...this._defaultConfig.popperConfig||{},...this.__sharedConfig.popperConfig||{},...e.popperConfig||{},modifiers:[...this._defaultConfig.popperConfig&&this._defaultConfig.popperConfig.modifiers||[],...this.__sharedConfig.popperConfig&&this.__sharedConfig.popperConfig.modifiers||[],...e.popperConfig&&e.popperConfig.modifiers||[]]}},this.__validateConfiguration(this.config),this._init({cfgToAdd:e}),this.__elementToFocusAfterHide=void 0}__validateConfiguration(e){if(!e.placementMode)throw new Error('[OverlayController] You need to provide a .placementMode ("global"|"local")');if(!["global","local"].includes(e.placementMode))throw new Error(`[OverlayController] "${e.placementMode}" is not a valid .placementMode, use ("global"|"local")`);if(!e.contentNode)throw new Error("[OverlayController] You need to provide a .contentNode");if(this.__isContentNodeProjected&&!e.contentWrapperNode)throw new Error("[OverlayController] You need to provide a .contentWrapperNode when .contentNode is projected");if(e.isTooltip&&"local"!==e.placementMode)throw new Error('[OverlayController] .isTooltip should be configured with .placementMode "local"');if(e.isTooltip&&!e.handlesAccessibility)throw new Error("[OverlayController] .isTooltip only takes effect when .handlesAccessibility is enabled")}_init({cfgToAdd:e}){this.__initContentWrapperNode({cfgToAdd:e}),this.__initConnectionTarget(),"local"===this.placementMode&&(S.popperModule||(S.popperModule=async function(){return n.e(3877).then(n.bind(n,3877))}())),this._handleFeatures({phase:"init"})}__initConnectionTarget(){if(this.contentWrapperNode!==this.__prevConfig?.contentWrapperNode&&("global"!==this.config?.placementMode&&this.__isContentNodeProjected||this.contentWrapperNode.appendChild(this.contentNode)),this._renderTarget)if(this.__isContentNodeProjected&&"local"===this.placementMode)this._renderTarget.appendChild(this.contentNode);else{const e=this._renderTarget===this.contentWrapperNode.parentNode,t=this.contentWrapperNode.contains(this._renderTarget);e||t||this._renderTarget.appendChild(this.contentWrapperNode)}}__initContentWrapperNode({cfgToAdd:e}){this.config?.contentWrapperNode&&"local"===this.placementMode?this.__contentWrapperNode=this.config.contentWrapperNode:this.__contentWrapperNode=document.createElement("div"),this.contentWrapperNode.style.cssText="",this.contentWrapperNode.style.display="none","absolute"===getComputedStyle(this.contentNode).position&&(this.contentNode.style.position="static"),this.__isContentNodeProjected&&this.contentWrapperNode.isConnected?this.__originalContentParent=this.contentWrapperNode.parentNode:e.contentNode&&e.contentNode.isConnected&&(this.__originalContentParent=this.contentNode?.parentNode)}_handleZIndex({phase:e}){if("local"===this.placementMode&&"setup"===e){const e=Number(getComputedStyle(this.contentNode).zIndex);(e<1||Number.isNaN(e))&&(this.contentWrapperNode.style.zIndex="1")}}__setupTeardownAccessibility({phase:e}){"init"===e?(this.__storeOriginalAttrs(this.contentNode,["role","id"]),this.invokerNode&&this.__storeOriginalAttrs(this.invokerNode,["aria-expanded","aria-labelledby","aria-describedby"]),this.contentNode.id||this.contentNode.setAttribute("id",this._contentId),this.isTooltip?(this.invokerNode&&this.invokerNode.setAttribute("label"===this.invokerRelation?"aria-labelledby":"aria-describedby",this._contentId),this.contentNode.setAttribute("role","tooltip")):(this.invokerNode&&this.invokerNode.setAttribute("aria-expanded",`${this.isShown}`),this.contentNode.getAttribute("role")||this.contentNode.setAttribute("role","dialog"))):"teardown"===e&&this.__restoreOriginalAttrs()}__storeOriginalAttrs(e,t){const n={};t.forEach((t=>{n[t]=e.getAttribute(t)})),this.__originalAttrs.set(e,n)}__restoreOriginalAttrs(){for(const[e,t]of this.__originalAttrs)Object.entries(t).forEach((([t,n])=>{null!==n?e.setAttribute(t,n):e.removeAttribute(t)}));this.__originalAttrs.clear()}get isShown(){return Boolean("none"!==this.contentWrapperNode.style.display)}async show(e=this.elementToFocusAfterHide){if(this._showComplete&&await this._showComplete,this._showComplete=new Promise((e=>{this._showResolve=e})),this.manager&&this.manager.show(this),this.isShown)return void this._showResolve();const t=new CustomEvent("before-show",{cancelable:!0});this.dispatchEvent(t),t.defaultPrevented||(this.contentWrapperNode.style.display="",this._keepBodySize({phase:"before-show"}),await this._handleFeatures({phase:"show"}),this._keepBodySize({phase:"show"}),await this._handlePosition({phase:"show"}),this.__elementToFocusAfterHide=e,this.dispatchEvent(new Event("show")),await this._transitionShow({backdropNode:this.backdropNode,contentNode:this.contentNode})),this._showResolve()}async _handlePosition({phase:e}){if("global"===this.placementMode){const t="show"===e?"add":"remove",n=`global-overlays__overlay-container--${this.viewportConfig.placement}`;this.contentWrapperNode.classList[t](m),this.contentWrapperNode.classList[t](n),this.contentNode.classList[t]("global-overlays__overlay")}else"local"===this.placementMode&&"show"===e&&(await this.__createPopperInstance(),this._popper.forceUpdate())}_keepBodySize({phase:e}){switch(e){case"before-show":this.__bodyClientWidth=document.body.clientWidth,this.__bodyClientHeight=document.body.clientHeight,this.__bodyMarginRightInline=document.body.style.marginRight,this.__bodyMarginBottomInline=document.body.style.marginBottom;break;case"show":{if(window.getComputedStyle){const e=window.getComputedStyle(document.body);this.__bodyMarginRight=parseInt(e.getPropertyValue("margin-right"),10),this.__bodyMarginBottom=parseInt(e.getPropertyValue("margin-bottom"),10)}else this.__bodyMarginRight=0,this.__bodyMarginBottom=0;const e=document.body.clientWidth-this.__bodyClientWidth,t=document.body.clientHeight-this.__bodyClientHeight,n=this.__bodyMarginRight+e,i=this.__bodyMarginBottom+t;y?(document.body.attributeStyleMap.set("margin-right",CSS.px(n)),document.body.attributeStyleMap.set("margin-bottom",CSS.px(i))):(document.body.style.marginRight=`${n}px`,document.body.style.marginBottom=`${i}px`);break}case"hide":document.body.style.marginRight=this.__bodyMarginRightInline||"",document.body.style.marginBottom=this.__bodyMarginBottomInline||""}}async hide(){if(this._hideComplete=new Promise((e=>{this._hideResolve=e})),this.manager&&this.manager.hide(this),!this.isShown)return void this._hideResolve();const e=new CustomEvent("before-hide",{cancelable:!0});this.dispatchEvent(e),e.defaultPrevented||(await this._transitionHide({backdropNode:this.backdropNode,contentNode:this.contentNode}),this.contentWrapperNode.style.display="none",this._handleFeatures({phase:"hide"}),this._keepBodySize({phase:"hide"}),this.dispatchEvent(new Event("hide")),this._restoreFocus()),this._hideResolve()}async transitionHide(e){}async _transitionHide(e){if(await this.transitionHide({backdropNode:this.backdropNode,contentNode:this.contentNode}),e.backdropNode){e.backdropNode.classList.remove(`${this.placementMode}-overlays__backdrop--animation-in`);let t=()=>{};e.backdropNode.classList.add(`${this.placementMode}-overlays__backdrop--animation-out`),this.__backdropAnimation=new Promise((n=>{t=()=>{e.backdropNode&&(e.backdropNode.classList.remove(`${this.placementMode}-overlays__backdrop--animation-out`),e.backdropNode.classList.remove(`${this.placementMode}-overlays__backdrop--visible`),e.backdropNode.removeEventListener("animationend",t)),n(void 0)}})),e.backdropNode.addEventListener("animationend",t)}}async transitionShow(e){}async _transitionShow(e){await this.transitionShow({backdropNode:this.backdropNode,contentNode:this.contentNode}),e.backdropNode&&e.backdropNode.classList.add(`${this.placementMode}-overlays__backdrop--animation-in`)}_restoreFocus(){const{activeElement:e}=this.__contentWrapperNode.getRootNode();e&&this.__contentWrapperNode.contains(e)&&(this.elementToFocusAfterHide?this.elementToFocusAfterHide.focus():e.blur())}async toggle(){return this.isShown?this.hide():this.show()}_handleFeatures({phase:e}){this._handleZIndex({phase:e}),this.preventsScroll&&this._handlePreventsScroll({phase:e}),this.isBlocking&&this._handleBlocking({phase:e}),this.hasBackdrop&&this._handleBackdrop({phase:e}),this.trapsKeyboardFocus&&this._handleTrapsKeyboardFocus({phase:e}),this.hidesOnEsc&&this._handleHidesOnEsc({phase:e}),this.hidesOnOutsideEsc&&this._handleHidesOnOutsideEsc({phase:e}),this.hidesOnOutsideClick&&this._handleHidesOnOutsideClick({phase:e}),this.handlesAccessibility&&this._handleAccessibility({phase:e}),this.inheritsReferenceWidth&&this._handleInheritsReferenceWidth()}_handlePreventsScroll({phase:e}){switch(e){case"show":this.manager.requestToPreventScroll();break;case"hide":this.manager.requestToEnableScroll()}}_handleBlocking({phase:e}){switch(e){case"show":this.manager.requestToShowOnly(this);break;case"hide":this.manager.retractRequestToShowOnly(this)}}get hasActiveBackdrop(){return this.__hasActiveBackdrop}_handleBackdrop({phase:e}){switch(e){case"init":{this.backdropNode||(this.__backdropNode=document.createElement("div"),this.backdropNode.slot="backdrop",this.backdropNode.classList.add(`${this.placementMode}-overlays__backdrop`));let e=this.contentNode.parentNode,t=this.contentNode;"global"===this.placementMode&&(e=this.contentWrapperNode.parentElement,t=this.contentWrapperNode),e.insertBefore(this.backdropNode,t);break}case"show":this.backdropNode.classList.add(`${this.placementMode}-overlays__backdrop--visible`),this.__hasActiveBackdrop=!0;break;case"hide":if(!this.backdropNode)return;this.__hasActiveBackdrop=!1;break;case"teardown":if(!this.backdropNode||!this.backdropNode.parentNode)return;this.__backdropAnimation?(this.__backdropNodeToBeTornDown=this.backdropNode,this.__backdropAnimation.then((()=>{this.__backdropNodeToBeTornDown&&this.__backdropNodeToBeTornDown.parentNode&&this.__backdropNodeToBeTornDown.parentNode.removeChild(this.__backdropNodeToBeTornDown)}))):this.backdropNode.parentNode.removeChild(this.backdropNode),this.__backdropNode=void 0}}get hasActiveTrapsKeyboardFocus(){return this.__hasActiveTrapsKeyboardFocus}_handleTrapsKeyboardFocus({phase:e}){"show"===e?this.enableTrapsKeyboardFocus():"hide"!==e&&"teardown"!==e||this.disableTrapsKeyboardFocus()}enableTrapsKeyboardFocus(){this.__hasActiveTrapsKeyboardFocus||(this.manager&&this.manager.disableTrapsKeyboardFocusForAll(),this._containFocusHandler=b(this.contentNode),this.__hasActiveTrapsKeyboardFocus=!0,this.manager&&this.manager.informTrapsKeyboardFocusGotEnabled(this.placementMode))}disableTrapsKeyboardFocus({findNewTrap:e=!0}={}){this.__hasActiveTrapsKeyboardFocus&&(this._containFocusHandler&&(this._containFocusHandler.disconnect(),this._containFocusHandler=void 0),this.__hasActiveTrapsKeyboardFocus=!1,this.manager&&this.manager.informTrapsKeyboardFocusGotDisabled({disabledCtrl:this,findNewTrap:e}))}__escKeyHandler(e){return"Escape"===e.key&&this.hide()}_handleHidesOnEsc({phase:e}){"show"===e?(this.contentNode.addEventListener("keyup",this.__escKeyHandler),this.invokerNode&&this.invokerNode.addEventListener("keyup",this.__escKeyHandler)):"hide"===e&&(this.contentNode.removeEventListener("keyup",this.__escKeyHandler),this.invokerNode&&this.invokerNode.removeEventListener("keyup",this.__escKeyHandler))}_handleHidesOnOutsideEsc({phase:e}){"show"===e?(this.__escKeyHandler=e=>"Escape"===e.key&&this.hide(),document.addEventListener("keyup",this.__escKeyHandler)):"hide"===e&&document.removeEventListener("keyup",this.__escKeyHandler)}_handleInheritsReferenceWidth(){if(!this._referenceNode||"global"===this.placementMode)return;const e=`${this._referenceNode.getBoundingClientRect().width}px`;switch(this.inheritsReferenceWidth){case"max":this.contentWrapperNode.style.maxWidth=e;break;case"full":this.contentWrapperNode.style.width=e;break;case"min":this.contentWrapperNode.style.minWidth=e,this.contentWrapperNode.style.width="auto"}}_handleHidesOnOutsideClick({phase:e}){const t="show"===e?"addEventListener":"removeEventListener";if("show"===e){let e=!1,t=!1;this.__onInsideMouseDown=()=>{e=!0},this.__onInsideMouseUp=()=>{t=!0},this.__onDocumentMouseUp=()=>{setTimeout((()=>{e||t||this.hide(),e=!1,t=!1}))}}this.contentWrapperNode[t]("mousedown",this.__onInsideMouseDown,!0),this.contentWrapperNode[t]("mouseup",this.__onInsideMouseUp,!0),this.invokerNode&&(this.invokerNode[t]("mousedown",this.__onInsideMouseDown,!0),this.invokerNode[t]("mouseup",this.__onInsideMouseUp,!0)),document.documentElement[t]("mouseup",this.__onDocumentMouseUp,!0)}_handleAccessibility({phase:e}){"init"!==e&&"teardown"!==e||this.__setupTeardownAccessibility({phase:e}),this.invokerNode&&!this.isTooltip&&this.invokerNode.setAttribute("aria-expanded",`${"show"===e}`)}teardown(){this._handleFeatures({phase:"teardown"}),"global"===this.placementMode&&this.__isContentNodeProjected&&this.__originalContentParent.appendChild(this.contentNode),this._teardownContentWrapperNode()}_teardownContentWrapperNode(){"global"===this.placementMode&&this.contentWrapperNode&&this.contentWrapperNode.parentNode&&this.contentWrapperNode.parentNode.removeChild(this.contentWrapperNode)}async __createPopperInstance(){if(this._popper&&(this._popper.destroy(),this._popper=void 0),void 0!==S.popperModule){const{createPopper:e}=await S.popperModule;this._popper=e(this._referenceNode,this.contentWrapperNode,{...this.config?.popperConfig})}}}function C(e,t){if("object"!=typeof e||"object"!=typeof e)return e===t;const n=Object.keys(e),i=Object.keys(t);if(n.length!==i.length)return!1;return n.every((n=>C(e[n],t[n])))}S.popperModule=void 0;const w=(0,o.S)((e=>class extends e{static get properties(){return{opened:{type:Boolean,reflect:!0}}}constructor(){super(),this.opened=!1,this.__needsSetup=!0,this.config={},this.toggle=this.toggle.bind(this),this.open=this.open.bind(this),this.close=this.close.bind(this)}get config(){return this.__config}set config(e){const t=!C(this.config,e);this._overlayCtrl&&t&&this._overlayCtrl.updateConfig(e),this.__config=e,this._overlayCtrl&&t&&this.__syncToOverlayController()}requestUpdateInternal(e,t){super.requestUpdateInternal(e,t),"opened"===e&&this.opened!==t&&this.dispatchEvent(new Event("opened-changed"))}_defineOverlay({contentNode:e,invokerNode:t,referenceNode:n,backdropNode:i,contentWrapperNode:s}){const o=this._defineOverlayConfig()||{};return new S({contentNode:e,invokerNode:t,referenceNode:n,backdropNode:i,contentWrapperNode:s,...o,...this.config,popperConfig:{...o.popperConfig||{},...this.config.popperConfig||{},modifiers:[...o.popperConfig?.modifiers||[],...this.config.popperConfig?.modifiers||[]]}})}_defineOverlayConfig(){return{placementMode:"local"}}updated(e){super.updated(e),e.has("opened")&&this._overlayCtrl&&!this.__blockSyncToOverlayCtrl&&this.__syncToOverlayController()}_setupOpenCloseListeners(){this.__closeEventInContentNodeHandler=e=>{e.stopPropagation(),this._overlayCtrl.hide()},this._overlayContentNode&&this._overlayContentNode.addEventListener("close-overlay",this.__closeEventInContentNodeHandler)}_teardownOpenCloseListeners(){this._overlayContentNode&&this._overlayContentNode.removeEventListener("close-overlay",this.__closeEventInContentNodeHandler)}connectedCallback(){super.connectedCallback(),this.__needsSetup=!0,this.updateComplete.then((()=>{this.__needsSetup&&this._setupOverlayCtrl(),this.__needsSetup=!1}))}disconnectedCallback(){super.disconnectedCallback&&super.disconnectedCallback(),this._overlayCtrl&&this._teardownOverlayCtrl()}get _overlayInvokerNode(){return Array.from(this.children).find((e=>"invoker"===e.slot))}get _overlayReferenceNode(){}get _overlayBackdropNode(){return Array.from(this.children).find((e=>"backdrop"===e.slot))}get _overlayContentNode(){return this._cachedOverlayContentNode||(this._cachedOverlayContentNode=Array.from(this.children).find((e=>"content"===e.slot))||this.config.contentNode),this._cachedOverlayContentNode}get _overlayContentWrapperNode(){return this.shadowRoot.querySelector("#overlay-content-node-wrapper")}_setupOverlayCtrl(){this._overlayCtrl=this._defineOverlay({contentNode:this._overlayContentNode,contentWrapperNode:this._overlayContentWrapperNode,invokerNode:this._overlayInvokerNode,referenceNode:this._overlayReferenceNode,backdropNode:this._overlayBackdropNode}),this.__syncToOverlayController(),this.__setupSyncFromOverlayController(),this._setupOpenCloseListeners()}_teardownOverlayCtrl(){this._teardownOpenCloseListeners(),this.__teardownSyncFromOverlayController(),this._overlayCtrl.teardown()}async _setOpenedWithoutPropertyEffects(e){this.__blockSyncToOverlayCtrl=!0,this.opened=e,await this.updateComplete,this.__blockSyncToOverlayCtrl=!1}__setupSyncFromOverlayController(){this.__onOverlayCtrlShow=()=>{this.opened=!0},this.__onOverlayCtrlHide=()=>{this.opened=!1},this.__onBeforeShow=e=>{const t=new CustomEvent("before-opened",{cancelable:!0});this.dispatchEvent(t),t.defaultPrevented&&(this._setOpenedWithoutPropertyEffects(this._overlayCtrl.isShown),e.preventDefault())},this.__onBeforeHide=e=>{const t=new CustomEvent("before-closed",{cancelable:!0});this.dispatchEvent(t),t.defaultPrevented&&(this._setOpenedWithoutPropertyEffects(this._overlayCtrl.isShown),e.preventDefault())},this._overlayCtrl.addEventListener("show",this.__onOverlayCtrlShow),this._overlayCtrl.addEventListener("hide",this.__onOverlayCtrlHide),this._overlayCtrl.addEventListener("before-show",this.__onBeforeShow),this._overlayCtrl.addEventListener("before-hide",this.__onBeforeHide)}__teardownSyncFromOverlayController(){this._overlayCtrl.removeEventListener("show",this.__onOverlayCtrlShow),this._overlayCtrl.removeEventListener("hide",this.__onOverlayCtrlHide),this._overlayCtrl.removeEventListener("before-show",this.__onBeforeShow),this._overlayCtrl.removeEventListener("before-hide",this.__onBeforeHide)}__syncToOverlayController(){this.opened?this._overlayCtrl.show():this._overlayCtrl.hide()}async toggle(){await this._overlayCtrl.toggle()}async open(){await this._overlayCtrl.show()}async close(){await this._overlayCtrl.hide()}repositionOverlay(){const e=this._overlayCtrl;"local"===e.placementMode&&e._popper&&e._popper.update()}}));class E extends(w(i.oi)){constructor(){super(),this.__toggle=()=>{this.opened=!this.opened}}_defineOverlayConfig(){return{placementMode:"global",viewportConfig:{placement:"center"},hasBackdrop:!0,preventsScroll:!0,trapsKeyboardFocus:!0,hidesOnEsc:!0,handlesAccessibility:!0}}_setupOpenCloseListeners(){super._setupOpenCloseListeners(),this._overlayInvokerNode&&this._overlayInvokerNode.addEventListener("click",this.__toggle)}_teardownOpenCloseListeners(){super._teardownOpenCloseListeners(),this._overlayInvokerNode&&this._overlayInvokerNode.removeEventListener("click",this.__toggle)}render(){return s.dy`
      <slot name="invoker"></slot>
      <div id="overlay-content-node-wrapper">
        <slot name="content"></slot>
      </div>
    `}}class T extends E{}var I=n(3009),A=n(332),x=n(2005),N=n(5104);const L=(0,o.S)((e=>class extends(w(e)){static get properties(){return{hasArrow:{type:Boolean,reflect:!0,attribute:"has-arrow"}}}static get styles(){return[...super.styles||[],i.iv`
          :host {
            --tooltip-arrow-width: 12px;
            --tooltip-arrow-height: 8px;
          }

          .arrow svg {
            display: block;
          }

          .arrow {
            position: absolute;
            width: var(--tooltip-arrow-width);
            height: var(--tooltip-arrow-height);
          }

          .arrow__graphic {
            display: block;
          }

          [data-popper-placement^='top'] .arrow {
            bottom: calc(-1 * var(--tooltip-arrow-height));
          }

          [data-popper-placement^='bottom'] .arrow {
            top: calc(-1 * var(--tooltip-arrow-height));
          }

          [data-popper-placement^='bottom'] .arrow__graphic {
            transform: rotate(180deg);
          }

          [data-popper-placement^='left'] .arrow {
            right: calc(
              -1 * (var(--tooltip-arrow-height) +
                    (var(--tooltip-arrow-width) - var(--tooltip-arrow-height)) / 2)
            );
          }

          [data-popper-placement^='left'] .arrow__graphic {
            transform: rotate(270deg);
          }

          [data-popper-placement^='right'] .arrow {
            left: calc(
              -1 * (var(--tooltip-arrow-height) +
                    (var(--tooltip-arrow-width) - var(--tooltip-arrow-height)) / 2)
            );
          }

          [data-popper-placement^='right'] .arrow__graphic {
            transform: rotate(90deg);
          }

          :host(:not([has-arrow])) .arrow {
            display: none;
          }
        `]}constructor(){super(),this.hasArrow=!0,this.__setupRepositionCompletePromise()}render(){return s.dy`
        <slot name="invoker"></slot>
        <div id="overlay-content-node-wrapper">
          <slot name="content"></slot>
          ${this._arrowNodeTemplate()}
        </div>
      `}_arrowNodeTemplate(){return s.dy` <div class="arrow" data-popper-arrow>${this._arrowTemplate()}</div> `}_arrowTemplate(){return s.dy`
        <svg viewBox="0 0 12 8" class="arrow__graphic">
          <path d="M 0,0 h 12 L 6,8 z"></path>
        </svg>
      `}_defineOverlayConfig(){const e=super._defineOverlayConfig()||{};return this.hasArrow?{...e,popperConfig:{...this._getPopperArrowConfig(e.popperConfig)}}:e}_getPopperArrowConfig(e){return{...e||{},placement:"top",modifiers:[{name:"arrow",enabled:!0,options:{padding:8}},{name:"offset",enabled:!0,options:{offset:[0,8]}},...e&&e.modifiers||[]],onFirstUpdate:e=>{this.__syncFromPopperState(e)},afterWrite:e=>{this.__syncFromPopperState(e)}}}__setupRepositionCompletePromise(){this.repositionComplete=new Promise((e=>{this.__repositionCompleteResolver=e}))}get _arrowNode(){return this.shadowRoot.querySelector("[data-popper-arrow]")}__syncFromPopperState(e){e&&this._arrowNode&&e.placement!==this._arrowNode.placement&&(this.__repositionCompleteResolver(e.placement),this.__setupRepositionCompletePromise())}}));class k extends(L(w(i.oi))){static get properties(){return{invokerRelation:{type:String,attribute:"invoker-relation"}}}static get styles(){return[...super.styles,i.iv`
        :host {
          display: inline-block;
        }

        :host([hidden]) {
          display: none;
        }
      `]}constructor(){super(),this.hasArrow=!1,this.invokerRelation="description",this._mouseActive=!1,this._keyActive=!1}_defineOverlayConfig(){return{...super._defineOverlayConfig(),placementMode:"local",elementToFocusAfterHide:void 0,hidesOnEsc:!0,hidesOnOutsideEsc:!0,handlesAccessibility:!0,isTooltip:!0,invokerRelation:this.invokerRelation}}_hasDisabledInvoker(){return!(!this._overlayCtrl||!this._overlayCtrl.invoker)&&(this._overlayCtrl.invoker.disabled||"true"===this._overlayCtrl.invoker.getAttribute("aria-disabled"))}_setupOpenCloseListeners(){super._setupOpenCloseListeners(),this.__resetActive=this.__resetActive.bind(this),this._overlayCtrl.addEventListener("hide",this.__resetActive),this.addEventListener("mouseenter",this._showMouse),this.addEventListener("mouseleave",this._hideMouse),this._showKey=this._showKey.bind(this),this._overlayInvokerNode.addEventListener("focusin",this._showKey),this._hideKey=this._hideKey.bind(this),this._overlayInvokerNode.addEventListener("focusout",this._hideKey)}_teardownOpenCloseListeners(){super._teardownOpenCloseListeners(),this._overlayCtrl.removeEventListener("hide",this.__resetActive),this.removeEventListener("mouseenter",this._showMouse),this.removeEventListener("mouseleave",this._hideMouse),this._overlayInvokerNode.removeEventListener("focusin",this._showKey),this._overlayInvokerNode.removeEventListener("focusout",this._hideKey)}__resetActive(){this._mouseActive=!1,this._keyActive=!1}_showMouse(){this._keyActive||(this._mouseActive=!0,this._hasDisabledInvoker()||(this.opened=!0))}_hideMouse(){this._keyActive||(this.opened=!1)}_showKey(){this._mouseActive||(this._keyActive=!0,this._hasDisabledInvoker()||(this.opened=!0))}_hideKey(){this._mouseActive||(this.opened=!1)}}const O=new Map([["onCreate","onFirstUpdate"]]);function D(e){if(t=e,Array.isArray(t.modifiers)||t.strategy||t.onFirstUpdate||t.afterWrite)return e;var t;const n={};return Object.keys(e).forEach((t=>{if("modifiers"===t&&e.modifiers){const i=Object.keys(e.modifiers).map((t=>{const n={};return n.name=t,e.modifiers&&(n.options=e.modifiers[t],"enabled"in e.modifiers[t]&&(n.enabled=e.modifiers[t].enabled,delete n.options.enabled)),"string"==typeof n.options.offset&&(n.options.offset=n.options.offset.split(",").map((e=>Number(e.replace("px",""))||0))),n}));n[t]=i}else"positionFixed"===t?n.strategy=!0===e.positionFixed?"fixed":"absolute":O.has(t)?(n[O.get(t)]=e[t],delete n[t]):n[t]=e[t]})),n}var R=n(3371),P=n(2993);class U extends((0,A.fN)(k)){static get styles(){return[super.styles,A.y5`
        :host {
          --tooltip-arrow-width: 16px;
          --tooltip-arrow-height: 8px;
          fill: ${R.Nr};
        }

        :host ::slotted([slot='content']) {
          display: block;
          font-size: ${P.IP};
          color: ${R.ix};
          background-color: ${R.Nr};
          border-radius: 4px;
          padding: 2px 8px;
        }
      `]}constructor(){super(),this.hasArrow=!0,this.invokerRelation="label"}get config(){return super.config}set config(e){e.popperConfig&&(e.popperConfig=D(e.popperConfig)),super.config=e}_arrowTemplate(){return A.dy`
      <svg class="arrow__graphic" viewBox="0 0 16 8">
        <path
          d="M16,0 L10.0166133,7.01721836 C8.90530216,8.32531955 7.09884797,8.32694781 5.98407499,7.0218636 C5.98248447,7.01884255 5.98090672,7.01584578 5.97934072,7.01287286 L0,0"
        ></path>
      </svg>
    `}_showMouse(){this._keyActive||(this._mouseActive=!0,setTimeout((()=>{this._mouseActive&&(this.opened=!0)}),1e3))}_hideMouse(){this._keyActive||(this._mouseActive=!1,setTimeout((()=>{this._mouseActive||(this.opened=!1)}),1500))}}const F=A.y5`
  .tooltip {
    display: block;
    font-size: ${P.IP};
    color: ${R.ix};
    background-color: ${R.Nr};
    border-radius: 4px;
    padding: 2px 8px;
  }

  .tooltip[hidden] {
    display: none;
  }
`;var V=n(170);const M=new Map;M.set("0",0),M.set("600",600),M.set("720",720),M.set("840",840),M.set("1280",1280);var B=n(7279);const $=600,j=A.y5`
  ${F}

  .dialog-frame {
    display: flex;
    flex-direction: column;
    overflow: hidden;

    max-width: ${(0,A.$m)(600)}px;
    max-height: calc(100vh - 2 * ${(0,A.$m)(32)}px);

    background-color: ${R.ix};
    border-radius: 4px;
    box-shadow: 0 0 16px 0 rgba(0, 0, 0, 0.12), 0 16px 16px 0 rgba(0, 0, 0, 0.24);
    /* For a11y we focus the dialog on opening. This prevents blinking on touch devices. */
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    -webkit-tap-highlight-color: transparent;
  }

  /* wrapper is needed for IE11 */
  .dialog-frame__wrapper {
    display: flex; /* fixes content scroll */
    flex-direction: column; /* prevents max-width issues introduced by this wrapper */
  }

  .dialog-frame__header-container {
    border-bottom: 1px solid transparent;
  }

  .dialog-frame__header {
    display: flex;
    flex-shrink: 0;

    width: 100%;
    min-height: 64px;

    border-radius: 4px 4px 0 0;
    background-color: ${R.$y};
  }

  :host([top-bar-color='indigo']) .dialog-frame__header,
  :host([variation='indigo-19']) .dialog-frame__header,
  :host([variation='indigo-24']) .dialog-frame__header {
    background-color: ${R.QN};
  }

  :host([top-bar-color='sky']) .dialog-frame__header,
  :host([variation='sky-19']) .dialog-frame__header,
  :host([variation='sky-24']) .dialog-frame__header {
    background-color: ${R.Bt};
  }

  :host([top-bar-color='fuchsia']) .dialog-frame__header {
    background-color: ${R.zf};
  }

  :host([top-bar-color='white']) .dialog-frame__header,
  :host([variation='white-19']) .dialog-frame__header,
  :host([variation='white-24']) .dialog-frame__header,
  :host([variation='white-orange-19']) .dialog-frame__header,
  :host([variation='white-orange-24']) .dialog-frame__header {
    background-color: ${R.ix};
  }

  :host([top-bar-color='white'][has-scroll-borders]) .dialog-frame__header-container,
  :host([variation='white-19'][has-scroll-borders]) .dialog-frame__header-container,
  :host([variation='white-24'][has-scroll-borders]) .dialog-frame__header-container,
  :host([variation='white-orange-19'][has-scroll-borders]) .dialog-frame__header-container,
  :host([variation='white-orange-24'][has-scroll-borders]) .dialog-frame__header-container,
  :host([_has-header-after][has-scroll-borders]) .dialog-frame__header-container,
  :host([_top-bar-border-bottom]) .dialog-frame__header-container {
    border-bottom: 1px solid ${R.F8};
  }

  :host([top-bar-color='white']) .dialog-frame__header-content,
  :host([variation='white-19']) .dialog-frame__header-content,
  :host([variation='white-24']) .dialog-frame__header-content {
    color: ${R.H9};
  }

  :host([variation='white-orange-19']) .dialog-frame__header-content,
  :host([variation='white-orange-24']) .dialog-frame__header-content {
    color: ${R.$y};
  }

  .dialog-frame__header-content {
    ${(0,V.sM)()}
    flex-grow: 1;
    text-align: center;
    margin: ${(0,A.$m)(16)}px 0;
    color: ${R.ix};
  }

  .dialog-frame__header-button-placeholder {
    width: ${(0,A.$m)(56)}px;
    height: ${(0,A.$m)(64)}px;
  }

  .dialog-frame__header-button-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: ${(0,A.$m)(56)}px;
    height: ${(0,A.$m)(64)}px;
  }

  .dialog-frame__header-content--no-buttons {
    padding-left: ${(0,A.$m)(16)}px;
    padding-right: ${(0,A.$m)(16)}px;
  }

  /* header font19 */
  :host([top-bar-size='font19']) .dialog-frame__header,
  :host([variation='orange-19']) .dialog-frame__header,
  :host([variation='indigo-19']) .dialog-frame__header,
  :host([variation='sky-19']) .dialog-frame__header,
  :host([variation='white-19']) .dialog-frame__header,
  :host([variation='white-orange-19']) .dialog-frame__header {
    min-height: ${(0,A.$m)(40)}px;
  }

  :host([top-bar-size='font19']) .dialog-frame__header-content,
  :host([variation='orange-19']) .dialog-frame__header-content,
  :host([variation='indigo-19']) .dialog-frame__header-content,
  :host([variation='sky-19']) .dialog-frame__header-content,
  :host([variation='white-19']) .dialog-frame__header-content,
  :host([variation='white-orange-19']) .dialog-frame__header-content {
    ${(0,V.jh)()}
    margin-top: ${(0,A.$m)(6)}px;
    margin-bottom: ${(0,A.$m)(6)}px;
  }

  :host([top-bar-size='font19']) .dialog-frame__header-button-placeholder,
  :host([variation='orange-19']) .dialog-frame__header-button-placeholder,
  :host([variation='indigo-19']) .dialog-frame__header-button-placeholder,
  :host([variation='sky-19']) .dialog-frame__header-button-placeholder,
  :host([variation='white-19']) .dialog-frame__header-button-placeholder,
  :host([variation='white-orange-19']) .dialog-frame__header-button-placeholder {
    width: ${(0,A.$m)(46)}px;
    height: ${(0,A.$m)(40)}px;
  }

  :host([top-bar-size='font19']) .dialog-frame__header-button-container,
  :host([variation='orange-19']) .dialog-frame__header-button-container,
  :host([variation='indigo-19']) .dialog-frame__header-button-container,
  :host([variation='sky-19']) .dialog-frame__header-button-container,
  :host([variation='white-19']) .dialog-frame__header-button-container,
  :host([variation='white-orange-19']) .dialog-frame__header-button-container {
    width: ${(0,A.$m)(40)}px;
    height: ${(0,A.$m)(40)}px;
  }

  :host([top-bar-size='font19']) .dialog-frame__header-button-container-back,
  :host([variation='orange-19']) .dialog-frame__header-button-container-back,
  :host([variation='indigo-19']) .dialog-frame__header-button-container-back,
  :host([variation='sky-19']) .dialog-frame__header-button-container-back,
  :host([variation='white-19']) .dialog-frame__header-button-container-back,
  :host([variation='white-orange-19']) .dialog-frame__header-button-container-back {
    margin-right: ${(0,A.$m)(6)}px;
  }

  :host([top-bar-size='font19']) .dialog-frame__header-button-container-close,
  :host([variation='orange-19']) .dialog-frame__header-button-container-close,
  :host([variation='indigo-19']) .dialog-frame__header-button-container-close,
  :host([variation='sky-19']) .dialog-frame__header-button-container-close,
  :host([variation='white-19']) .dialog-frame__header-button-container-close,
  :host([variation='white-orange-19']) .dialog-frame__header-button-container-close {
    margin-left: ${(0,A.$m)(6)}px;
  }

  :host([top-bar-size='font19']) .dialog-frame__header-button,
  :host([variation='orange-19']) .dialog-frame__header-button,
  :host([variation='indigo-19']) .dialog-frame__header-button,
  :host([variation='sky-19']) .dialog-frame__header-button,
  :host([variation='white-19']) .dialog-frame__header-button,
  :host([variation='white-orange-19']) .dialog-frame__header-button {
    margin-top: 4px;
  }

  .dialog-frame__content {
    /* main is not supported by IE11, so we need to make a block element explicitly */
    display: block;
    height: 100%;
    overflow-y: auto;
    padding: ${B.o7};
  }

  :host([no-padding]) .dialog-frame__content,
  :host([no-padding]) .dialog-frame__footer {
    padding: 0;
  }

  .dialog-frame__footer {
    position: relative;
    padding: ${B.o7};
    box-sizing: border-box;
    margin-top: auto;
    flex-shrink: 0;
    border-top: 1px solid transparent;
  }

  :host([has-scroll-borders]) .dialog-frame__footer {
    border-top: 1px solid ${R.F8};
  }

  :host([scrolled-to-bottom]) .dialog-frame__footer {
    border-top: 1px solid transparent;
  }

  @media (max-height: ${(0,A.$m)($)}px) {
    .dialog-frame:not(.dialog-frame--simple) {
      max-height: calc(100vh - ${(0,A.$m)(64)}px);
    }
  }

  @media (max-width: ${(0,A.$m)($)}px) {
    :host,
    .dialog-frame__wrapper {
      width: 100%;
      height: 100%;
    }

    .dialog-frame:not(.dialog-frame--simple) {
      width: 100%;
      height: 100%;
      max-width: 100%;
      max-height: 100%;
      border-radius: 0;
    }

    .dialog-frame:not(.dialog-frame--simple) .dialog-frame__header {
      border-radius: 0;
    }
  }

  @media (max-width: ${(0,A.$m)(664)}px) {
    .dialog-frame.dialog-frame--simple {
      max-width: calc(100vw - ${(0,A.$m)(64)}px);
      margin: auto;
    }
  }

  :host([variation='bottom-sheet']) .dialog-frame {
    height: auto;
    max-height: calc(100% - ${B.mG});
    width: 100vw;
    max-width: none;
    margin-top: auto;
  }
`;const H=(0,n(9566).SV)((e=>class extends e{static get properties(){return{scrollTarget:{type:Object},scrolling:{type:Boolean,reflect:!0},scrolledToBottom:{type:Boolean,reflect:!0,attribute:"scrolled-to-bottom"},scrollTimeout:{type:Number},__scrollTimeoutID:{type:Number}}}constructor(){super(),this.scrolling=!1,this.scrollToBottom=!1,this.scrollTimeout=100,this.__handleTargetScroll=this.__handleTargetScroll.bind(this)}set scrollTarget(e){const t=this.__scrollTarget;t&&t.removeEventListener("scroll",this.__handleTargetScroll),this.__scrollTarget=e,e.addEventListener("scroll",this.__handleTargetScroll),this.requestUpdate("scrollTarget",t)}get scrollTarget(){return this.__scrollTarget}__handleTargetScroll(){this.scrollToBottom=this.scrollTarget.scrollTop+this.scrollTarget.offsetHeight>=this.scrollTarget.scrollHeight,this.scrolling||(this.scrolling=!0,this.dispatchEvent(new Event("scroll-start"))),this.__scrollTimeoutID&&window.clearTimeout(this.__scrollTimeoutID),this.__scrollTimeoutID=window.setTimeout((()=>{this.scrolling=!1,this.dispatchEvent(new Event("scroll-finish"))}),this.scrollTimeout),this.dispatchEvent(new Event("scroll-progress"))}}));class G extends(H(A.oi)){static get properties(){return{noPadding:{type:Boolean,attribute:"no-padding",reflect:!0},hasScrollBorders:{type:Boolean,attribute:"has-scroll-borders",reflect:!0}}}static get styles(){return[super.styles||[],j]}constructor(){super(),this.hasScrollBorders=!1,this._uniqueID=Math.random().toString(36).substr(2,10)}_contentTemplate(){return A.dy`<slot name="content"></slot>`}render(){return A.dy`
      <div class="dialog-frame__wrapper">
        <div class="dialog-frame dialog-frame--simple">
          <div class="dialog-frame__content">${this._contentTemplate()}</div>
        </div>
      </div>
    `}get _frameNode(){return this.shadowRoot?.querySelector(".dialog-frame")}connectedCallback(){super.connectedCallback(),this.getAttribute("role")||this.setAttribute("role","dialog"),this.getAttribute("aria-modal")||this.setAttribute("aria-modal","true"),this.getAttribute("aria-describedby")||this.setAttribute("aria-describedby",`dialogContent-${this._uniqueID}`)}firstUpdated(e){super.firstUpdated(e);const t=this.shadowRoot?.querySelector('slot[name="content"]');t&&t.addEventListener("slotchange",(()=>{this.querySelector('[slot="content"]').id=`dialogContent-${this._uniqueID}`})),this.scrollTarget=this.shadowRoot?.querySelector(".dialog-frame__content"),this.addEventListener("scroll-start",this.__scrollHandler)}__scrollHandler(){this.hasScrollBorders=!0,this.removeEventListener("scroll-start",this.__scrollHandler)}}const z=["font19","font24"],W=["orange-24","indigo-24","sky-24","white-24","white-orange-24","indigo-19","orange-19","sky-19","white-19","white-orange-19"];class q extends((0,A.fN)((0,I.l)(G))){static get scopedElements(){return{...super.scopedElements,"ing-button":x.W,"ing-icon":N.O,"ing-tooltip":U}}static get properties(){return{...super.properties,hasCloseButton:{type:Boolean,attribute:"has-close-button"},hasBackButton:{type:Boolean,attribute:"has-back-button"},_hasHeader:{type:Boolean},_hasHeaderAfter:{type:Boolean,attribute:"_has-header-after",reflect:!0},_hasFooter:{type:Boolean},variation:{type:String,reflect:!0},topBarColor:{type:String,attribute:"top-bar-color",reflect:!0},topBarSize:{type:String,attribute:"top-bar-size",reflect:!0},_topBarBorderBottom:{type:Boolean,attribute:"_top-bar-border-bottom",reflect:!0}}}static get localizeNamespaces(){return[{"ing-dialog-frame":e=>{switch(e){case"bg-BG":return n.e(7236).then(n.bind(n,7236));case"bg":return n.e(1577).then(n.bind(n,1577));case"cs-CZ":return n.e(9622).then(n.bind(n,9622));case"cs":return n.e(3151).then(n.bind(n,3151));case"de-DE":return n.e(1892).then(n.bind(n,1892));case"de":return n.e(8976).then(n.bind(n,8976));case"en-AU":return n.e(497).then(n.bind(n,497));case"en-GB":return n.e(6033).then(n.bind(n,6033));case"en-US":return n.e(2535).then(n.bind(n,2535));case"en-PH":case"en":return n.e(6797).then(n.bind(n,6797));case"es-ES":return n.e(1974).then(n.bind(n,1974));case"es":return n.e(2729).then(n.bind(n,2729));case"fr-BE":return n.e(7658).then(n.bind(n,7658));case"fr-FR":return n.e(5433).then(n.bind(n,5433));case"fr":return n.e(2781).then(n.bind(n,2781));case"hu-HU":return n.e(7638).then(n.bind(n,7638));case"hu":return n.e(5859).then(n.bind(n,5859));case"it-IT":return n.e(8363).then(n.bind(n,8363));case"it":return n.e(4218).then(n.bind(n,4218));case"nl-BE":return n.e(5222).then(n.bind(n,5222));case"nl-NL":return n.e(9432).then(n.bind(n,9432));case"nl":return n.e(9148).then(n.bind(n,9148));case"pl-PL":return n.e(5235).then(n.bind(n,5235));case"pl":return n.e(3457).then(n.bind(n,3457));case"ro-RO":return n.e(4833).then(n.bind(n,4833));case"ro":return n.e(6434).then(n.bind(n,6434));case"ru-RU":return n.e(7049).then(n.bind(n,7049));case"ru":return n.e(3637).then(n.bind(n,3637));case"sk-SK":return n.e(537).then(n.bind(n,537));case"sk":return n.e(8789).then(n.bind(n,8789));case"uk-UA":return n.e(1921).then(n.bind(n,1921));case"uk":return n.e(8567).then(n.bind(n,8567));case"zh-CN":case"zh":return n.e(3122).then(n.bind(n,3122));default:return n(5512)(`./${e}.js`)}}},...super.localizeNamespaces]}render(){return A.dy`
      <div class="dialog-frame__wrapper">
        <div class="dialog-frame" role="document">
          ${this._headerTemplate()}

          <div class="dialog-frame__content">${this._contentTemplate()}</div>

          ${this._footerTemplate()}
        </div>
      </div>
    `}set topBarSize(e){if(!z.includes(e))throw new Error("Please provide a valid top bar size, valid values are 'font19' & 'font24'.");this.__topBarSize=e,this.requestUpdate()}get topBarSize(){return this.__topBarSize}set variation(e){if(!W.includes(e))throw new Error(`Please provide a variation, valid values are ${W}.`);this.__variation=e,this.hasInvertedButton=e.match(/white-/),this.hasSize19=e.match(/19/),this.requestUpdate()}get variation(){return this.__variation}constructor(){super(),this._topBarBorderBottom=!1,this.hasBackButton=!1,this.hasCloseButton=!1,this.topBarColor="",this.__topBarColor="",this.__topBarSize="",this.__variation=""}connectedCallback(){super.connectedCallback(),this._hasHeader=!!this.querySelector("[slot=header]"),this._hasHeaderAfter=!!this.querySelector("[slot=header-after]"),this._hasFooter=!!this.querySelector("[slot=footer]"),this.getAttribute("role")||this.setAttribute("role","dialog"),this.getAttribute("aria-modal")||this.setAttribute("aria-modal","true"),!this.getAttribute("aria-labelledby")&&this._hasHeader&&this.setAttribute("aria-labelledby",this.id||`headerLabel-${this._uniqueID}`),this.getAttribute("aria-describedby")||this.setAttribute("aria-describedby",`dialogContent-${this._uniqueID}`)}firstUpdated(e){super.firstUpdated(e);const t=this.shadowRoot?.querySelector('slot[name="header"]');t&&t.addEventListener("slotchange",(()=>{const e=this.querySelector('[slot="header"]');e.id=e?.id||`headerLabel-${this._uniqueID}`})),this._frameNode.classList.remove("dialog-frame--simple")}_headerTemplate(){const e=(0,A.$o)({"dialog-frame__header-content":!0,"dialog-frame__header-content--no-buttons":!this.hasBackButton&&!this.hasCloseButton});return this._hasHeader?A.dy`
          <div class="dialog-frame__header-container">
            <div class="dialog-frame__header" id="header">
              ${this.hasBackButton?this._backButtonTemplate():this._headerButtonPlaceholderTemplate()}
              <h1 class="${e}"><slot name="header"></slot></h1>
              ${this.hasCloseButton?this._closeButtonTemplate():this._headerButtonPlaceholderTemplate()}
            </div>
            ${this._headerAfterTemplate()}
          </div>
        `:A.dy``}_headerAfterTemplate(){return this._hasHeaderAfter?A.dy`<slot name="header-after"></slot>`:A.dy``}_footerTemplate(){return this._hasFooter?A.dy`
          <div class="dialog-frame__footer">
            <slot name="footer"></slot>
          </div>
        `:A.dy``}_headerButtonPlaceholderTemplate(){return this.hasBackButton||this.hasCloseButton?A.dy`<div class="dialog-frame__header-button-placeholder"></div>`:A.dy``}_backButtonTemplate(){return A.dy`
      <div class="dialog-frame__header-button-container dialog-frame__header-button-container-back">
        <ing-tooltip .popperConfig=${{placement:"bottom"}}>
          <ing-button
            slot="invoker"
            text
            icon-only
            ?icon20=${"font19"===this.__topBarSize||this.hasSize19}
            ?inverted=${"white"!==this.topBarColor&&!this.hasInvertedButton}
            ?grey=${"white"===this.topBarColor||"white-19"===this.variation||"white-24"===this.variation}
            class="dialog-frame__header-button"
            aria-label="${this.msgLit("ing-dialog-frame:button_back")}"
            @click="${()=>this.dispatchEvent(new Event("back"))}"
          >
            <ing-icon
              class="dialog-frame__header-button-icon"
              icon-id="ing:outline-arrows:arrowLeft"
            ></ing-icon>
          </ing-button>
          <div slot="content" class="tooltip">${this.msgLit("ing-dialog-frame:button_back")}</div>
        </ing-tooltip>
      </div>
    `}_closeButtonTemplate(){return A.dy`
      <div
        class="dialog-frame__header-button-container  dialog-frame__header-button-container-close"
      >
        <ing-tooltip .popperConfig=${{placement:"bottom"}}>
          <ing-button
            slot="invoker"
            text
            icon-only
            ?icon20=${"font19"===this.__topBarSize||this.hasSize19}
            ?inverted=${"white"!==this.topBarColor&&!this.hasInvertedButton}
            ?grey=${"white"===this.topBarColor||"white-19"===this.variation||"white-24"===this.variation}
            class="dialog-frame__header-button"
            aria-label="${this.msgLit("ing-dialog-frame:button_close")}"
            @click="${()=>this.dispatchEvent(new Event("close-overlay"))}"
          >
            <ing-icon
              class="dialog-frame__header-button-icon"
              icon-id="ing:outline-characters:cross"
            ></ing-icon>
          </ing-button>
          <div slot="content" class="tooltip">${this.msgLit("ing-dialog-frame:button_close")}</div>
        </ing-tooltip>
      </div>
    `}}},5104:(e,t,n)=>{"use strict";n.d(t,{O:()=>c});var i=n(4971),s=n(7206),o=n(6495);class r extends s.oi{static get properties(){return{svg:{attribute:!1},ariaLabel:{type:String,attribute:"aria-label",reflect:!0},iconId:{type:String,attribute:"icon-id"},role:{type:String,attribute:"role",reflect:!0}}}static get styles(){return[s.iv`
        :host {
          box-sizing: border-box;
          display: inline-block;
          width: 1em;
          height: 1em;
        }

        :host([hidden]) {
          display: none;
        }

        :host:first-child {
          margin-left: 0;
        }

        :host:last-child {
          margin-right: 0;
        }

        ::slotted(svg) {
          display: block;
          width: 100%;
          height: 100%;
        }
      `]}constructor(){super(),this.role="img",this.ariaLabel="",this.iconId="",this.__svg=i.Ld}update(e){super.update(e),e.has("ariaLabel")&&this._onLabelChanged(),e.has("iconId")&&this._onIconIdChanged(e.get("iconId"))}render(){return i.dy`<slot></slot>`}connectedCallback(){this._onLabelChanged(),super.connectedCallback()}set svg(e){this.__svg=e,null==e?this._renderSvg(i.Ld):this._renderSvg(function(e){const t=e&&e.default?e.default:e;return"function"==typeof t?t(i.dy):t}(e))}get svg(){return this.__svg}_onLabelChanged(){this.ariaLabel?this.setAttribute("aria-hidden","false"):(this.setAttribute("aria-hidden","true"),this.removeAttribute("aria-label"))}_renderSvg(e){!function(e){if(!(e===i.Ld||e instanceof i.js))throw new Error('icon accepts only lit-html templates or functions like "tag => tag`<svg>...</svg>`"')}(e),(0,i.sY)(e,this),this.firstElementChild&&this.firstElementChild.setAttribute("aria-hidden","true")}get _iconManager(){return o.c}async _onIconIdChanged(e){if(this.iconId){const e=this.iconId,t=await this._iconManager.resolveIconForId(e);this.iconId===e&&(this.svg=t)}else e&&(this.svg=i.Ld)}}var a=n(6808);class c extends r{get _iconManager(){return a.c}}},6808:(e,t,n)=>{"use strict";n.d(t,{c:()=>s.c});var i=n(6979),s=n(6495),o=n(9058);(0,s.r)(i.d.get("ing-web::icons::2.x")||new o.t)},8519:(e,t,n)=>{"use strict";n.d(t,{OD:()=>i.O,ci:()=>s.c});var i=n(5104),s=n(6808)},9047:(e,t,n)=>{"use strict";n.d(t,{i:()=>o,Y:()=>r});var i=n(332),s=n(3371);const o=({borderRadius:e=i.y5`4px`}={})=>i.y5`
  border-radius: ${e};
  box-shadow: 0 0 8px ${s.vv}, 0 0 0 1px ${s.Bt};
`,r=({borderRadius:e=i.y5`4px`}={})=>i.y5`
  border-radius: ${e};
  box-shadow: 0 0 8px ${s.CQ}, 0 0 0 1px ${s.CQ};
`},451:(e,t,n)=>{"use strict";n.d(t,{X:()=>s});var i=n(9566);const s=()=>i.iv`
  position: absolute;
  top: 0;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(100%);
  clip: rect(1px, 1px, 1px, 1px);
  white-space: nowrap;
  border: 0;
  margin: 0;
  padding: 0;
`},170:(e,t,n)=>{"use strict";n.d(t,{sM:()=>r,jh:()=>a,fQ:()=>c,Dn:()=>l,Ai:()=>d,pA:()=>u,YK:()=>h,j2:()=>p});var i=n(332),s=n(2993);const o=({fontFamily:e,fontSize:t=s.D0,lineHeight:n=s.JM,fontWeight:o=i.y5`normal`}={})=>i.y5`
  ${(({fontFamily:e=s.I8}={})=>i.y5`
  font-family: ${e};
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
`)({fontFamily:e})}
  font-size: ${t};
  line-height: ${n};
  font-weight: ${o};
`,r=e=>(e=>o({fontSize:s.vs,lineHeight:s.ge,...e}))({fontWeight:i.y5`bold`,...e}),a=e=>(e=>o({fontSize:s.jX,lineHeight:s.DV,...e}))({fontWeight:i.y5`bold`,...e}),c=e=>o({fontSize:s.D0,lineHeight:s.nF,...e}),l=e=>c({fontWeight:i.y5`bold`,...e}),d=e=>o({fontSize:s.IP,lineHeight:s.Ne,...e}),u=e=>d({fontWeight:i.y5`bold`,...e}),h=e=>o({fontSize:s.Wd,lineHeight:s.zy,...e}),p=e=>h({fontWeight:i.y5`bold`,...e})},3371:(e,t,n)=>{"use strict";n.d(t,{$y:()=>s,ix:()=>o,H9:()=>r,Nr:()=>a,zx:()=>c,F8:()=>l,YM:()=>d,QN:()=>u,Hd:()=>h,Bt:()=>p,vv:()=>f,CQ:()=>g,zf:()=>v,vj:()=>_,d1:()=>b,pw:()=>m,Q6:()=>y});var i=n(332);const s=i.y5`#ff6200`,o=i.y5`#ffffff`,r=i.y5`#333333`,a=i.y5`#696969`,c=i.y5`#a8a8a8`,l=i.y5`#d9d9d9`,d=i.y5`#f0f0f0`,u=i.y5`#525199`,h=(i.y5`#9898c3`,i.y5`#cbcce1`,i.y5`#e6e5f0`),p=i.y5`#559bd1`,f=i.y5`#9fcaea`,g=i.y5`#cee5f5`,v=(i.y5`#e8f3fa`,i.y5`#ab0066`),_=(i.y5`#cd66a4`,i.y5`#e5b8d2`,i.y5`#f3dce9`),b=(i.y5`#d0d93c`,i.y5`#e3ea8f`,i.y5`#f1f5c8`,i.y5`#f8fae4`,i.y5`#349651`),m=(i.y5`#83c197`,i.y5`#c1e0cb`),y=(i.y5`#e1f0e6`,i.y5`#d70000`);i.y5`#349651`,i.y5`#545454`,i.y5`#767676`},7279:(e,t,n)=>{"use strict";n.d(t,{hM:()=>s,dl:()=>o,nu:()=>r,o7:()=>a,mG:()=>c});var i=n(332);i.y5`2px`;const s=i.y5`4px`,o=i.y5`8px`,r=i.y5`12px`,a=i.y5`16px`,c=(i.y5`20px`,i.y5`24px`,i.y5`32px`);i.y5`40px`,i.y5`48px`,i.y5`52px`,i.y5`56px`,i.y5`64px`,i.y5`72px`,i.y5`80px`},2993:(e,t,n)=>{"use strict";n.d(t,{I8:()=>s,vs:()=>o,jX:()=>r,D0:()=>a,IP:()=>c,Wd:()=>l,JM:()=>d,ge:()=>u,DV:()=>h,nF:()=>p,Ne:()=>f,zy:()=>g});var i=n(332);const s=i.y5`INGMe, arial, helvetica, sans-serif`,o=(i.y5`INGMeNarrow, INGMe, arial, helvetica, sans-serif`,i.y5`36px`,i.y5`32px`,i.y5`28px`,i.y5`24px`),r=i.y5`19px`,a=i.y5`16px`,c=i.y5`14px`,l=i.y5`12px`,d=(i.y5`48px`,i.y5`40px`,i.y5`36px`),u=i.y5`32px`,h=i.y5`28px`,p=i.y5`24px`,f=i.y5`20px`,g=i.y5`16px`;i.y5`568px`},7345:(e,t,n)=>{"use strict";n.d(t,{C:()=>a});var i=n(3602),s=n(4971);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const o=new WeakMap,r=2147483647,a=(0,s.XM)(((...e)=>t=>{let n=o.get(t);void 0===n&&(n={lastRenderedIndex:r,values:[]},o.set(t,n));const s=n.values;let a=s.length;n.values=e;for(let o=0;o<e.length&&!(o>n.lastRenderedIndex);o++){const c=e[o];if((0,i.pt)(c)||"function"!=typeof c.then){t.setValue(c),n.lastRenderedIndex=o;break}o<a&&c===s[o]||(n.lastRenderedIndex=r,a=0,Promise.resolve(c).then((e=>{const i=n.values.indexOf(c);i>-1&&i<n.lastRenderedIndex&&(n.lastRenderedIndex=i,t.setValue(e),t.commit())})))}}))},7229:(e,t,n)=>{"use strict";n.d(t,{X:()=>s,w:()=>o});
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const i=new WeakMap,s=e=>(...t)=>{const n=e(...t);return i.set(n,!0),n},o=e=>"function"==typeof e&&i.has(e)},2105:(e,t,n)=>{"use strict";n.d(t,{eC:()=>i,V:()=>s,r4:()=>o});
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const i="undefined"!=typeof window&&null!=window.customElements&&void 0!==window.customElements.polyfillWrapFlushCallback,s=(e,t,n=null,i=null)=>{for(;t!==n;){const n=t.nextSibling;e.insertBefore(t,i),t=n}},o=(e,t,n=null)=>{for(;t!==n;){const n=t.nextSibling;e.removeChild(t),t=n}}},5356:(e,t,n)=>{"use strict";n.d(t,{J:()=>i,L:()=>s});
/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const i={},s={}},3602:(e,t,n)=>{"use strict";n.d(t,{pt:()=>l,QG:()=>u,_l:()=>h,nt:()=>p,JG:()=>f,m:()=>g,sL:()=>v,K1:()=>b});var i=n(7229),s=n(2105),o=n(5356),r=n(1622),a=n(8817),c=n(4557);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const l=e=>null===e||!("object"==typeof e||"function"==typeof e),d=e=>Array.isArray(e)||!(!e||!e[Symbol.iterator]);class u{constructor(e,t,n){this.dirty=!0,this.element=e,this.name=t,this.strings=n,this.parts=[];for(let e=0;e<n.length-1;e++)this.parts[e]=this._createPart()}_createPart(){return new h(this)}_getValue(){const e=this.strings,t=e.length-1,n=this.parts;if(1===t&&""===e[0]&&""===e[1]){const e=n[0].value;if("symbol"==typeof e)return String(e);if("string"==typeof e||!d(e))return e}let i="";for(let s=0;s<t;s++){i+=e[s];const t=n[s];if(void 0!==t){const e=t.value;if(l(e)||!d(e))i+="string"==typeof e?e:String(e);else for(const t of e)i+="string"==typeof t?t:String(t)}}return i+=e[t],i}commit(){this.dirty&&(this.dirty=!1,this.element.setAttribute(this.name,this._getValue()))}}class h{constructor(e){this.value=void 0,this.committer=e}setValue(e){e===o.J||l(e)&&e===this.value||(this.value=e,(0,i.w)(e)||(this.committer.dirty=!0))}commit(){for(;(0,i.w)(this.value);){const e=this.value;this.value=o.J,e(this)}this.value!==o.J&&this.committer.commit()}}class p{constructor(e){this.value=void 0,this.__pendingValue=void 0,this.options=e}appendInto(e){this.startNode=e.appendChild((0,c.IW)()),this.endNode=e.appendChild((0,c.IW)())}insertAfterNode(e){this.startNode=e,this.endNode=e.nextSibling}appendIntoPart(e){e.__insert(this.startNode=(0,c.IW)()),e.__insert(this.endNode=(0,c.IW)())}insertAfterPart(e){e.__insert(this.startNode=(0,c.IW)()),this.endNode=e.endNode,e.endNode=this.startNode}setValue(e){this.__pendingValue=e}commit(){if(null===this.startNode.parentNode)return;for(;(0,i.w)(this.__pendingValue);){const e=this.__pendingValue;this.__pendingValue=o.J,e(this)}const e=this.__pendingValue;e!==o.J&&(l(e)?e!==this.value&&this.__commitText(e):e instanceof a.j?this.__commitTemplateResult(e):e instanceof Node?this.__commitNode(e):d(e)?this.__commitIterable(e):e===o.L?(this.value=o.L,this.clear()):this.__commitText(e))}__insert(e){this.endNode.parentNode.insertBefore(e,this.endNode)}__commitNode(e){this.value!==e&&(this.clear(),this.__insert(e),this.value=e)}__commitText(e){const t=this.startNode.nextSibling,n="string"==typeof(e=null==e?"":e)?e:String(e);t===this.endNode.previousSibling&&3===t.nodeType?t.data=n:this.__commitNode(document.createTextNode(n)),this.value=e}__commitTemplateResult(e){const t=this.options.templateFactory(e);if(this.value instanceof r.R&&this.value.template===t)this.value.update(e.values);else{const n=new r.R(t,e.processor,this.options),i=n._clone();n.update(e.values),this.__commitNode(i),this.value=n}}__commitIterable(e){Array.isArray(this.value)||(this.value=[],this.clear());const t=this.value;let n,i=0;for(const s of e)n=t[i],void 0===n&&(n=new p(this.options),t.push(n),0===i?n.appendIntoPart(this):n.insertAfterPart(t[i-1])),n.setValue(s),n.commit(),i++;i<t.length&&(t.length=i,this.clear(n&&n.endNode))}clear(e=this.startNode){(0,s.r4)(this.startNode.parentNode,e.nextSibling,this.endNode)}}class f{constructor(e,t,n){if(this.value=void 0,this.__pendingValue=void 0,2!==n.length||""!==n[0]||""!==n[1])throw new Error("Boolean attributes can only contain a single expression");this.element=e,this.name=t,this.strings=n}setValue(e){this.__pendingValue=e}commit(){for(;(0,i.w)(this.__pendingValue);){const e=this.__pendingValue;this.__pendingValue=o.J,e(this)}if(this.__pendingValue===o.J)return;const e=!!this.__pendingValue;this.value!==e&&(e?this.element.setAttribute(this.name,""):this.element.removeAttribute(this.name),this.value=e),this.__pendingValue=o.J}}class g extends u{constructor(e,t,n){super(e,t,n),this.single=2===n.length&&""===n[0]&&""===n[1]}_createPart(){return new v(this)}_getValue(){return this.single?this.parts[0].value:super._getValue()}commit(){this.dirty&&(this.dirty=!1,this.element[this.name]=this._getValue())}}class v extends h{}let _=!1;(()=>{try{const e={get capture(){return _=!0,!1}};window.addEventListener("test",e,e),window.removeEventListener("test",e,e)}catch(e){}})();class b{constructor(e,t,n){this.value=void 0,this.__pendingValue=void 0,this.element=e,this.eventName=t,this.eventContext=n,this.__boundHandleEvent=e=>this.handleEvent(e)}setValue(e){this.__pendingValue=e}commit(){for(;(0,i.w)(this.__pendingValue);){const e=this.__pendingValue;this.__pendingValue=o.J,e(this)}if(this.__pendingValue===o.J)return;const e=this.__pendingValue,t=this.value,n=null==e||null!=t&&(e.capture!==t.capture||e.once!==t.once||e.passive!==t.passive),s=null!=e&&(null==t||n);n&&this.element.removeEventListener(this.eventName,this.__boundHandleEvent,this.__options),s&&(this.__options=m(e),this.element.addEventListener(this.eventName,this.__boundHandleEvent,this.__options)),this.value=e,this.__pendingValue=o.J}handleEvent(e){"function"==typeof this.value?this.value.call(this.eventContext||this.element,e):this.value.handleEvent(e)}}const m=e=>e&&(_?{capture:e.capture,passive:e.passive,once:e.once}:e.capture)},8952:(e,t,n)=>{"use strict";n.d(t,{L:()=>r,s:()=>a});var i=n(2105),s=n(3602),o=n(7630);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const r=new WeakMap,a=(e,t,n)=>{let a=r.get(t);void 0===a&&((0,i.r4)(t,t.firstChild),r.set(t,a=new s.nt(Object.assign({templateFactory:o.t},n))),a.appendInto(t)),a.setValue(e),a.commit()}},7630:(e,t,n)=>{"use strict";n.d(t,{t:()=>s,r:()=>o});var i=n(4557);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */function s(e){let t=o.get(e.type);void 0===t&&(t={stringsArray:new WeakMap,keyString:new Map},o.set(e.type,t));let n=t.stringsArray.get(e.strings);if(void 0!==n)return n;const s=e.strings.join(i.Jw);return n=t.keyString.get(s),void 0===n&&(n=new i.YS(e,e.getTemplateElement()),t.keyString.set(s,n)),t.stringsArray.set(e.strings,n),n}const o=new Map},1622:(e,t,n)=>{"use strict";n.d(t,{R:()=>o});var i=n(2105),s=n(4557);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
class o{constructor(e,t,n){this.__parts=[],this.template=e,this.processor=t,this.options=n}update(e){let t=0;for(const n of this.__parts)void 0!==n&&n.setValue(e[t]),t++;for(const e of this.__parts)void 0!==e&&e.commit()}_clone(){const e=i.eC?this.template.element.content.cloneNode(!0):document.importNode(this.template.element.content,!0),t=[],n=this.template.parts,o=document.createTreeWalker(e,133,null,!1);let r,a=0,c=0,l=o.nextNode();for(;a<n.length;)if(r=n[a],(0,s.pC)(r)){for(;c<r.index;)c++,"TEMPLATE"===l.nodeName&&(t.push(l),o.currentNode=l.content),null===(l=o.nextNode())&&(o.currentNode=t.pop(),l=o.nextNode());if("node"===r.type){const e=this.processor.handleTextExpression(this.options);e.insertAfterNode(l.previousSibling),this.__parts.push(e)}else this.__parts.push(...this.processor.handleAttributeExpressions(l,r.name,r.strings,this.options));a++}else this.__parts.push(void 0),a++;return i.eC&&(document.adoptNode(e),customElements.upgrade(e)),e}}},8817:(e,t,n)=>{"use strict";n.d(t,{j:()=>a,C:()=>c});var i=n(2105),s=n(4557);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const o=window.trustedTypes&&trustedTypes.createPolicy("lit-html",{createHTML:e=>e}),r=` ${s.Jw} `;class a{constructor(e,t,n,i){this.strings=e,this.values=t,this.type=n,this.processor=i}getHTML(){const e=this.strings.length-1;let t="",n=!1;for(let i=0;i<e;i++){const e=this.strings[i],o=e.lastIndexOf("\x3c!--");n=(o>-1||n)&&-1===e.indexOf("--\x3e",o+1);const a=s.W5.exec(e);t+=null===a?e+(n?r:s.N):e.substr(0,a.index)+a[1]+a[2]+s.$E+a[3]+s.Jw}return t+=this.strings[e],t}getTemplateElement(){const e=document.createElement("template");let t=this.getHTML();return void 0!==o&&(t=o.createHTML(t)),e.innerHTML=t,e}}class c extends a{getHTML(){return`<svg>${super.getHTML()}</svg>`}getTemplateElement(){const e=super.getTemplateElement(),t=e.content,n=t.firstChild;return t.removeChild(n),(0,i.V)(t,n.firstChild),e}}},4557:(e,t,n)=>{"use strict";n.d(t,{Jw:()=>i,N:()=>s,$E:()=>r,YS:()=>a,pC:()=>l,IW:()=>d,W5:()=>u});
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const i=`{{lit-${String(Math.random()).slice(2)}}}`,s=`\x3c!--${i}--\x3e`,o=new RegExp(`${i}|${s}`),r="$lit$";class a{constructor(e,t){this.parts=[],this.element=t;const n=[],s=[],a=document.createTreeWalker(t.content,133,null,!1);let l=0,h=-1,p=0;const{strings:f,values:{length:g}}=e;for(;p<g;){const e=a.nextNode();if(null!==e){if(h++,1===e.nodeType){if(e.hasAttributes()){const t=e.attributes,{length:n}=t;let i=0;for(let e=0;e<n;e++)c(t[e].name,r)&&i++;for(;i-- >0;){const t=f[p],n=u.exec(t)[2],i=n.toLowerCase()+r,s=e.getAttribute(i);e.removeAttribute(i);const a=s.split(o);this.parts.push({type:"attribute",index:h,name:n,strings:a}),p+=a.length-1}}"TEMPLATE"===e.tagName&&(s.push(e),a.currentNode=e.content)}else if(3===e.nodeType){const t=e.data;if(t.indexOf(i)>=0){const i=e.parentNode,s=t.split(o),a=s.length-1;for(let t=0;t<a;t++){let n,o=s[t];if(""===o)n=d();else{const e=u.exec(o);null!==e&&c(e[2],r)&&(o=o.slice(0,e.index)+e[1]+e[2].slice(0,-r.length)+e[3]),n=document.createTextNode(o)}i.insertBefore(n,e),this.parts.push({type:"node",index:++h})}""===s[a]?(i.insertBefore(d(),e),n.push(e)):e.data=s[a],p+=a}}else if(8===e.nodeType)if(e.data===i){const t=e.parentNode;null!==e.previousSibling&&h!==l||(h++,t.insertBefore(d(),e)),l=h,this.parts.push({type:"node",index:h}),null===e.nextSibling?e.data="":(n.push(e),h--),p++}else{let t=-1;for(;-1!==(t=e.data.indexOf(i,t+1));)this.parts.push({type:"node",index:-1}),p++}}else a.currentNode=s.pop()}for(const e of n)e.parentNode.removeChild(e)}}const c=(e,t)=>{const n=e.length-t.length;return n>=0&&e.slice(n)===t},l=e=>-1!==e.index,d=()=>document.createComment(""),u=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/},4971:(e,t,n)=>{"use strict";n.d(t,{_l:()=>i._l,JG:()=>i.JG,K1:()=>i.K1,nt:()=>i.nt,sL:()=>i.sL,js:()=>o.j,IW:()=>d.IW,XM:()=>r.X,dy:()=>u,pt:()=>i.pt,Ld:()=>c.L,r4:()=>a.r4,sY:()=>l.s,V:()=>a.V,YP:()=>h});var i=n(3602);const s=new
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
class{handleAttributeExpressions(e,t,n,s){const o=t[0];if("."===o){return new i.m(e,t.slice(1),n).parts}if("@"===o)return[new i.K1(e,t.slice(1),s.eventContext)];if("?"===o)return[new i.JG(e,t.slice(1),n)];return new i.QG(e,t,n).parts}handleTextExpression(e){return new i.nt(e)}};var o=n(8817),r=n(7229),a=n(2105),c=n(5356),l=n(8952),d=(n(7630),n(1622),n(4557));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
"undefined"!=typeof window&&(window.litHtmlVersions||(window.litHtmlVersions=[])).push("1.4.1");const u=(e,...t)=>new o.j(e,t,"html",s),h=(e,...t)=>new o.C(e,t,"svg",s)}},i={};function s(e){var t=i[e];if(void 0!==t)return t.exports;var o=i[e]={exports:{}};return n[e](o,o.exports,s),o.exports}s.m=n,s.d=(e,t)=>{for(var n in t)s.o(t,n)&&!s.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},s.f={},s.e=e=>Promise.all(Object.keys(s.f).reduce(((t,n)=>(s.f[n](e,t),t)),[])),s.u=e=>"chunks/"+e+".js",s.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),s.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),e={},t="ing-feat-cookie-consent-de:",s.l=(n,i,o,r)=>{if(e[n])e[n].push(i);else{var a,c;if(void 0!==o)for(var l=document.getElementsByTagName("script"),d=0;d<l.length;d++){var u=l[d];if(u.getAttribute("src")==n||u.getAttribute("data-webpack")==t+o){a=u;break}}a||(c=!0,(a=document.createElement("script")).charset="utf-8",a.timeout=120,s.nc&&a.setAttribute("nonce",s.nc),a.setAttribute("data-webpack",t+o),a.src=n),e[n]=[i];var h=(t,i)=>{a.onerror=a.onload=null,clearTimeout(p);var s=e[n];if(delete e[n],a.parentNode&&a.parentNode.removeChild(a),s&&s.forEach((e=>e(i))),t)return t(i)},p=setTimeout(h.bind(null,void 0,{type:"timeout",target:a}),12e4);a.onerror=h.bind(null,a.onerror),a.onload=h.bind(null,a.onload),c&&document.head.appendChild(a)}},s.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},(()=>{var e;s.g.importScripts&&(e=s.g.location+"");var t=s.g.document;if(!e&&t&&(t.currentScript&&(e=t.currentScript.src),!e)){var n=t.getElementsByTagName("script");n.length&&(e=n[n.length-1].src)}if(!e)throw new Error("Automatic publicPath is not supported in this browser");e=e.replace(/#.*$/,"").replace(/\?.*$/,"").replace(/\/[^\/]+$/,"/"),s.p=e})(),(()=>{var e={179:0};s.f.j=(t,n)=>{var i=s.o(e,t)?e[t]:void 0;if(0!==i)if(i)n.push(i[2]);else{var o=new Promise(((n,s)=>i=e[t]=[n,s]));n.push(i[2]=o);var r=s.p+s.u(t),a=new Error;s.l(r,(n=>{if(s.o(e,t)&&(0!==(i=e[t])&&(e[t]=void 0),i)){var o=n&&("load"===n.type?"missing":n.type),r=n&&n.target&&n.target.src;a.message="Loading chunk "+t+" failed.\n("+o+": "+r+")",a.name="ChunkLoadError",a.type=o,a.request=r,i[1](a)}}),"chunk-"+t,t)}};var t=(t,n)=>{var i,o,[r,a,c]=n,l=0;if(r.some((t=>0!==e[t]))){for(i in a)s.o(a,i)&&(s.m[i]=a[i]);if(c)c(s)}for(t&&t(n);l<r.length;l++)o=r[l],s.o(e,o)&&e[o]&&e[o][0](),e[r[l]]=0},n=globalThis.webpackChunking_feat_cookie_consent_de=globalThis.webpackChunking_feat_cookie_consent_de||[];n.forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n))})(),(()=>{"use strict";var e=s(5158),t=s(5939);class n{constructor(e){this.UC=new t.a8(e)}async init(){const e=await this.UC.init();return this.labels=await this.UC.getSettingsLabels(),e.variant===t.ac.DEFAULT&&e.initialLayer===t.ab.FIRST_LAYER}async getCategories(){return this.categories||(this.categories=this.UC.getCategoriesFullInfo()),this.categories}async getServices(){return this.services||(this.services=this.UC.getServicesFullInfo()),this.services}getLabels(){return this.labels}}const i=e=>e`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" focusable="false"><path d="M7.30299376,5.14843024 C12.0196485,1.41085351 18.6437824,0.958659873 23.851451,4.01875696 C24.1911786,4.21724754 24.3439118,4.61820887 24.2191022,4.98392922 C24.0958025,5.35176963 24.0356987,5.73684849 24.0412065,6.12368896 C24.0309256,7.71742152 24.9785038,9.17032896 26.4656713,9.84108453 C26.6920867,9.94355299 26.8604527,10.1379267 26.9257787,10.3722651 C26.9911047,10.6066035 26.9467329,10.8570237 26.8045204,11.0566086 C25.7672386,12.4986566 25.4653911,14.322719 25.9851154,16.0082676 C26.5048397,17.6938162 27.7890456,19.0556983 29.4712623,19.7052768 C29.891491,19.8710829 30.1028492,20.3292174 29.9507337,20.7445664 C27.8885089,26.3100895 22.450478,30.014884 16.3654071,29.999955 C10.2803361,29.9849357 4.8616682,26.253425 2.82845318,20.6778239 C0.795238154,15.1022228 2.586339,8.88600698 7.30299376,5.14843024 Z M22.435062,5.13545797 C17.7714115,2.688414 12.0352625,3.31211341 8.04296856,6.70033019 C4.05067462,10.088547 2.64069426,15.5296904 4.50530432,20.3522498 C6.36991439,25.1748092 11.1175109,28.3659544 16.4171031,28.3588979 C21.4899083,28.3582322 26.0753323,25.421839 28.0785927,20.891154 C26.2958184,19.9692444 24.9628908,18.3964917 24.3731506,16.5190156 C23.7834104,14.6415395 23.9851866,12.6131983 24.9340737,10.8803741 C23.3194495,9.80495777 22.3521076,8.02639539 22.3469613,6.12368896 C22.3457851,5.79237681 22.3752709,5.46163348 22.435062,5.13545797 Z M13.465949,20.1569855 C14.6448854,20.1569855 15.6006022,21.1136544 15.6006022,22.2937653 C15.6006022,23.4738762 14.6448854,24.4305451 13.465949,24.4305451 C12.2870127,24.4305451 11.3312959,23.4738762 11.3312959,22.2937653 C11.3312959,21.1136544 12.2870127,20.1569855 13.465949,20.1569855 Z M20.3922608,13.6397383 C21.5711972,13.6397383 22.5269139,14.5964072 22.5269139,15.7765181 C22.5269139,16.956629 21.5711972,17.9132979 20.3922608,17.9132979 C19.2133244,17.9132979 18.2576077,16.956629 18.2576077,15.7765181 C18.2576077,14.5964072 19.2133244,13.6397383 20.3922608,13.6397383 Z M11.1163443,9.5935311 C12.8192523,9.5935311 14.1997321,10.9753862 14.1997321,12.6799908 C14.1997321,14.3845955 12.8192523,15.7664506 11.1163443,15.7664506 C9.41343618,15.7664506 8.03295642,14.3845955 8.03295642,12.6799908 C8.03295642,10.9753862 9.41343618,9.5935311 11.1163443,9.5935311 Z"></path></svg>`,o=e=>e`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" focusable="false"><path d="M21 11.007H6.414l6.293-6.293L11.293 3.3l-8 8a.999.999 0 000 1.414l8 8 1.414-1.414-6.293-6.293H21v-2z"/></svg>`,r=e=>e`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" focusable="false"><path d="M11.3 16.715a.999.999 0 001.414 0l8-8L19.3 7.3l-7.293 7.293L4.714 7.3 3.3 8.715l8 8z"/></svg>`,a=e=>e`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" focusable="false"><path d="M8 18.7l-6-6.23 1.441-1.388 5.293 5.497L20.014 5.3l1.414 1.414-12 12c-.258.257-.922.51-1.428-.014"/></svg>`,c=e=>e`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" focusable="false"><path fill="#349651" d="M16 2c7.72 0 14 6.28 14 14s-6.28 14-14 14S2 23.72 2 16 8.28 2 16 2zm0 2C9.383 4 4 9.383 4 16s5.383 12 12 12 12-5.383 12-12S22.617 4 16 4zm6.45 6.666l1.405 1.424-9.365 9.243c-.215.213-.88.532-1.413-.009l-4.94-4.991 1.422-1.407 4.237 4.282 8.654-8.542z"/></svg>`,l=e=>e`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" focusable="false"><path d="M16 28a11.939 11.939 0 01-7.741-2.846L25.155 8.259A11.944 11.944 0 0128 16c0 6.617-5.383 12-12 12m0-24c2.949 0 5.649 1.074 7.741 2.845L6.845 23.74A11.94 11.94 0 014 16C4 9.383 9.383 4 16 4m0-2C8.268 2 2 8.268 2 16s6.268 14 14 14 14-6.268 14-14S23.732 2 16 2"/></svg>`;function d(e,t){switch(t){case"cookie":return i;case"arrowLeft":return o;case"notificationSuccess":return c;case"cancel":return l;case"chevronDown":return r;case"checkMark":return a;default:throw new Error("no such icon ".concat(e,", ").concat(t))}}let u=!1;var h,p,f,g;function v(e,t){return t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}}))}class _ extends((0,e.fNQ)(e.oiW)){static get properties(){return{isOpen:{type:Boolean,reflect:!0,attribute:"is-open"},level:{type:Number,reflect:!0,attribute:"level"},ucId:{type:String,attribute:"uc-id"},changes:{type:Object},pending:{type:Boolean}}}constructor(){super(),this.isOpen=!1,this.pending=!0,this.changes={},u||(e.ciZ.addIconResolver("ing",d),u=!0)}async firstUpdated(){this.ucService=new n(this.ucId),await this.ucService.init()&&this.open(0),this.pending=!1,this.interceptCookieLink(),this.fixDialogBackdrop()}fixDialogBackdrop(){const e=document.createElement("style");e.textContent=".global-overlays__backdrop--animation-in { animation: none !important; }",document.head.appendChild(e)}interceptCookieLink(){const e=document.querySelector('a[href="#uc-corner-modal-show"]');e&&e.addEventListener("click",(e=>{e.preventDefault(),this.open(1),window.history.replaceState("",document.title,window.location.pathname+window.location.search)}))}async accept(e){const t=Object.keys(this.changes).map((e=>({serviceId:e,status:this.changes[e]})));await this.ucService.UC.updateServices(t),this.closeOverlay(e)}async acceptAll(e){await this.ucService.UC.acceptAllServices(),this.closeOverlay(e)}async denyAll(e){await this.ucService.UC.denyAllServices(),this.closeOverlay(e)}getContent(t){const n=(0,e.dyc)(h||(h=v([' <ing-cc-dialog-level0\n      slot="content"\n      .ucs=',"\n      @accept-all=","\n      @deny-all=","\n      @click-adapt=","\n    ></ing-cc-dialog-level0>"])),this.ucService,this.acceptAll,this.denyAll,(()=>{this.level=1})),i=(0,e.dyc)(p||(p=v([' <ing-cc-dialog-level1\n      slot="content"\n      .ucs=',"\n      .changes=","\n      @click-details=","\n      @click-back=","\n      @click-accept=","\n      @service-changed=","\n    ></ing-cc-dialog-level1>"])),this.ucService,this.changes,(()=>{this.level=2}),(()=>{this.level=0}),this.accept,this.serviceChanged),s=(0,e.dyc)(f||(f=v([' <ing-cc-dialog-level2\n      slot="content"\n      .ucs=',"\n      .changes=","\n      @click-back=","\n      @click-accept=","\n      @service-changed=","\n    ></ing-cc-dialog-level2>"])),this.ucService,this.changes,(()=>{this.level=1}),this.accept,this.serviceChanged);return this.content=[n,i,s],this.content[t]}async open(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0;const t=s.e(2969).then(s.bind(s,2969)).then((e=>{let{CCDialogLevel0:t}=e;this.defineScopedElement("ing-cc-dialog-level0",t)})),n=s.e(4242).then(s.bind(s,4242)).then((e=>{let{CCDialogLevel1:t}=e;this.defineScopedElement("ing-cc-dialog-level1",t)})),i=s.e(452).then(s.bind(s,452)).then((e=>{let{CCDialogLevel2:t}=e;this.defineScopedElement("ing-cc-dialog-level2",t)})),o=Promise.resolve().then(s.bind(s,4084)).then((e=>{let{IngDialog:t}=e;this.defineScopedElement("ing-cc-dialog",t)})),r=s.e(8507).then(s.bind(s,8507)).then((e=>{let{IngCCDialogFrame:t}=e;this.defineScopedElement("ing-cc-dialog-frame",t)}));Promise.all([t,n,i,o,r]).then((()=>{this.level=e,this.changes={},this.isOpen=!0}))}closeOverlay(e){const t=new CustomEvent("close-overlay",{bubbles:!0,composed:!0});this.dispatchEvent(t),e.target.dispatchEvent(t),this.isOpen=!1}serviceChanged(e){const{service:t,checked:n}=e.detail;void 0!==this.changes[t.id]?delete this.changes[t.id]:this.changes[t.id]=n,this.requestUpdate()}render(){return this.isOpen&&!this.pending?(0,e.dyc)(g||(g=v(["\n          <ing-cc-dialog\n            ?opened=","\n            .config=",'\n          >\n            <div slot="invoker" aria-haspopup="dialog"></div>\n            <ing-cc-dialog-frame slot="content">\n              ',"\n            </ing-cc-dialog-frame>\n          </ing-cc-dialog>\n        "])),this.isOpen,{hidesOnEsc:!1,trapsKeyboardFocus:!0,hasBackdrop:!0,isBlocking:!0,preventsScroll:!0},this.getContent(this.level)):""}}customElements.get("ing-cc-manager")||customElements.define("ing-cc-manager",_)})()})();